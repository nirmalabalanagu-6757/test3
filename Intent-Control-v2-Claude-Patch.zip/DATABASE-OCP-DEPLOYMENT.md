# Database and OCP deployment

This package contains source changes, not a deployment image. Do not run a live migration merely because an AI integration completed.

## Schema ownership

| Source patch | Revisions | Purpose |
| --- | --- | --- |
| 0001 | 023, 024, 025 | Intent foundation, orchestration, communication priority |
| 0002 | 026 | Action Template Registry |
| 0003 | 027 | Agent intent scope |
| 0004 | 028, 029, 030 | Learning, assurance, schema reconciliation |
| 0005 / 0006 | none | Connection pinning / similar version proposals |
| 0007 | 031 | Structural candidate tool-call evidence |

Source revision `031_intent_call_learning` follows `030_reconcile_schema_drift`.
It adds `intent_learning_candidate.observation_json`: JSON, NOT NULL, database default `'{}'`.
No table recreation, credential migration, new .env variable or runtime dependency is required for 0007.

## Preflight with the real deployment interpreter

Use the same virtual environment/Python as the backend. Do not assume `/root/aipanel-main/venv/bin/alembic` exists.

```bash
python -m alembic -c backend/migrations/alembic.ini heads
python -m alembic -c backend/migrations/alembic.ini history
python -m alembic -c backend/migrations/alembic.ini current
```

Inspect actual schema and database revision before changing anything:

```sql
SELECT version_num FROM alembic_version;
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'intent_learning_candidate'
  AND column_name = 'observation_json';
```

A missing Alembic revision is not repaired by stamping the DB or renaming a random file. Restore the matching migration history and reconcile it deliberately.
Do not print credentials in command output or attach .env to a report.

## Divergent target history

- If earlier patches are already merged, do not rerun/create their schema changes.
- If 031 already exists equivalently, use it; do not add the column twice.
- If the target uses a different head or conflicting revision ID, generate an equivalent additive migration against its actual head, using its conventions and unique ID.
- Do not rewrite historical migrations, fabricate a parent, stamp over missing revisions or create duplicate tables.
- If several heads are intentional, follow the project's merge/migration procedure and document it rather than assuming source head 031 must be its literal revision.

## Controlled OCP rollout (after approval)

1. Preserve previous images/config and create a verified database backup or POC clone. A clone must be configured consistently with the chosen image; a database rename alone does not update application connections.
2. Integrate and test source in a branch; build updated backend/frontend images using existing OCP pipelines.
3. Schedule migration with existing writer/replica coordination; do not let every replica race to upgrade.
4. Run exactly one approved migration job/designated pod with the application's configuration:

```bash
python -m alembic -c backend/migrations/alembic.ini upgrade head
```

5. Confirm the expected target head and observation column; roll out updated images.
6. Check backend `/health`, authenticated admin UI, existing SSO, agent scope, Learning Queue, reviewed direct-action execution and fresh results.
7. Use synthetic/read-only test connections first. Do not auto-execute SQL writes or Ansible actions against actual systems.

## Rollback

Before old code returns, export and disable or restore rules containing new `$parameter` / `$from_step` bindings. Source versions before 0007 cannot interpret them.
The additive JSON column may remain; an automatic DB downgrade is not required for application rollback.
A reviewed downgrade of 031 removes observation metadata and is allowed only after checking later dependencies and backing up data. Restore a verified clone if the chosen rollback plan requires it.
See `ROLLBACK-GUIDE.md`.
