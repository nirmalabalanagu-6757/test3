# Intent Control v2 - cumulative Claude Sonnet 4.6 handoff

Latest source: `c2c58699c39a5a5263ead65398caac8b37a1df38` on `main`, pushed 2026-09-21.
This ZIP now contains **seven patches**, including the previous six unchanged.
It is an implementation handoff, not a complete application or an OCP image.

## Give this to Claude

1. Attach this ZIP and provide the target source repository.
2. Paste `CLAUDE_SONNET_4_6_PROMPT.txt` as the task.
3. Say that your target is the existing OCP application and its SSO must remain unchanged.
4. Require an inventory of already-present features before editing, then implementation, tests and the report template.

The prompt is self-contained: no original ChatGPT conversation is required.
It is plain text plus standard Git patches/source, with no model-specific runtime dependency.
Claude must still inspect and test the actual target. This is not a guarantee of automatic compatibility.

## Choose the correct integration path

- Already merged patches 0001-0006? Adapt **0007 only**, using the current source references and new guide.
- No intent features yet and exactly the declared source baseline? Apply 0001-0007 in order.
- Different repository, SSO implementation, migration history or partial prior merge? Use semantic integration: reproduce only missing behavior in the target's architecture. Do not force a patch.
- Existing approved rules are not automatically rewritten; recapture/review a new workflow version where needed.

Baseline: `9f9f182f733a2b371630982771ed68d323b9cb15`.
Previous final state: `9b49179667055e6ea603d515ac1678c514fa266a`.
Read `PATCH_MANIFEST.json` for the ordered commit list.

## Read in this order

1. `CLAUDE_SONNET_4_6_PROMPT.txt` - staged implementation instructions.
2. `NO-SSO-BOUNDARY.md` - protected integration boundaries.
3. `EXPECTED_BEHAVIOR.md` - cumulative acceptance criteria.
4. `LATEST-UPDATE-INTEGRATION.md` - patch 0007 code map, cases and limitations.
5. `LATEST_FILES_CHANGED.txt` - each latest changed file and why.
6. `DATABASE-OCP-DEPLOYMENT.md` and `ROLLBACK-GUIDE.md`.
7. `TEST_RESULTS.txt` and `CLAUDE-REPORT-TEMPLATE.md`.

`FILES_CHANGED.txt` lists all 70 affected source paths across the series.
`REFERENCE_FINAL_STATE/` contains their committed final versions for comparison, not bulk replacement.
`APPLY_PATCHES.sh` is a guarded helper for recognized exact source commits only.
`VERIFY_PATCH.sh` runs checks but never installs dependencies, starts services, pushes, or upgrades the database.
Neither helper replaces target-specific review. Use Git Bash for these Bash scripts, not PowerShell syntax.

SSO implementation files, .env, credentials, dependencies, caches, logs, build outputs and SHA-256 files are excluded.
General integration files may call the target's existing auth helpers: preserve those integrations and do not transplant standalone-VM auth behavior.
