# Patch 0007 integration guide

Source commit: `c2c58699c39a5a5263ead65398caac8b37a1df38`.
Parent: `9b49179667055e6ea603d515ac1678c514fa266a`.
24 changed files; 2,060 inserted and 57 deleted lines, including docs and tests.

## Goal and control flow

An unmatched successful request is observed in memory; a safe, typed, connection-pinned workflow is proposed for review. After approval, a matching request can reuse the workflow while fetching fresh results. It is not answer caching and does not automatically invent or publish Action Templates.

`chat request -> request-local capture -> tool starts/responses -> exact action matching -> candidate + structural evidence -> administrator review -> approved deterministic resolver -> fresh tool calls -> configured response`

## Integrate in dependency order

1. `backend/utils/intent_bindings.py`: validate parameter/dependency references and JSON pointers.
2. `backend/services/intent_parameters.py`: shared typed extraction, aliases/enums/regex and UTC dates.
3. `backend/services/intent_trace.py`: bounded ContextVar capture with call IDs and failure invalidation.
4. `backend/services/intent_workflow_learning.py`: exact published-action matching, ordered per-call plans, scoped parameters and result bindings.
5. Existing model/schema + migration 031: expose structural `observation_json`.
6. Existing callbacks, runner and chat request path: actually populate/pass the trace. A helper module without these integrations is incomplete.
7. Learning/resolution/orchestration/action validation: use compiled plans, deterministic parameters and fresh results while preserving all authorization checks.
8. Learning Queue: display each call's connection/status/dependencies/action choices and review reasons.
9. Backend/frontend tests and v1 docs.

Use `LATEST_FILES_CHANGED.txt` for exact paths and why each changes.

## Behavioral examples to reproduce

| Request variation | Expected result |
| --- | --- |
| server APP01 -> APP02, limit 25 -> 50 | Same approved compatible plan; new validated values; no stale result |
| Same tool called twice for two servers | Two steps with separate parameter scope |
| Tool A returns IDs then tool B uses them | B reads this run's A result through a validated pointer |
| Two matching published actions | Review required; never silently pick newest |
| A failed/skipped step | Its dependent steps must not call tools |
| Missing required server / invalid explicit limit | Clarification, not a guessed parameter |
| Disabled source agent | No intent matching/learning through that disabled scope |
| New JSON/CSV/SQL connector | Requires a registered adapter and compatible published action schema; not universal arbitrary inference |

## Existing intent upgrades

Patch 0006 generally preserves the existing plan when adding similar examples.
Patch 0007 can propose a reviewed upgrade of a compatible older agent-only plan to observed direct steps and parameters, while retaining identity/scope/response settings and stronger risk controls.
Rules are not rewritten automatically. A rule that already matches might need Shadow/recapture and an explicit reviewed version update.
Action versions remain immutable. An action/template name by itself is not proof that its implementation is equivalent.

## Database

The only new schema change in 0007 is the candidate's `observation_json` column (JSON, non-null, default empty object), after source revision 030.
See `DATABASE-OCP-DEPLOYMENT.md` for divergent history and deployment.
Old code cannot interpret new `$parameter` / `$from_step` workflow bindings. Disable or restore affected rules before a code rollback; the additive column can stay.

## Boundaries and limitations

- Direct no-execution-LLM replay requires a complete observed workflow and compatible published direct actions. Agent steps and configured LLM summaries still consume tokens.
- Dates use UTC; free-form dates, local time zones and conversational references are not generalized.
- Fixed SQL with separately bound parameters is supported. Unrestricted SQL/Ansible string substitution is not automatically generalized; restricted numeric/enum slots are supported.
- Raw CSV content is not automatically turned into cross-step pointers. An adapter can expose parsed structured outputs.
- The trace is bounded to 100 calls, 256,000 bytes per value and 2,000,000 bytes per request. Exceeding a limit prevents unsafe direct compilation.
- Evidence stores structural metadata; raw call arguments/results stay request-local. Existing prompt redaction/audit summaries retain their existing behavior.
- Source tests use synthetic adapters. No customer Skywise/backup/Ansible endpoint or target OCP/SSO environment was exercised.

For field examples and full administrator steps read `REFERENCE_FINAL_STATE/documentations/v1/intent-dynamic-workflows.md`.
