# Preserve existing SSO

Claude must treat the target application's SSO implementation as forbidden scope.

Do not change:

- OIDC, SAML, OAuth, identity-provider, login, logout, callback, token-validation, session, or role-mapping behavior.
- Existing ingress or reverse-proxy authentication configuration.
- Existing frontend login/session handling.
- Existing secrets, certificates, client IDs, client secrets, issuer URLs, or redirect URIs.

Intent Control administrator endpoints must continue using the application's existing role enforcement. Do not bypass authentication to make tests pass.

`frontend/src/api/client.ts` is changed only for backend-connectivity error reporting in patch 0003. Preserve all target-specific authorization headers, cookies, refresh logic, and SSO redirects while adapting that change.

Before completion, list changed paths and confirm no SSO-specific path or behavior changed.

No SSO-specific implementation files or configuration are supplied.
Shared files such as App.tsx, DashboardPage.tsx and api/client.ts exist in the historical reference set for routing/UI/connectivity integration only. Their full standalone-VM context is NOT authorization to replace target authentication. Port only intent-related hunks and preserve all existing session/auth behavior.
The new agents/base/callbacks.py is an agent TOOL callback, not an OAuth/SSO callback; merge only the capture additions.
Patch 0007 adds no authentication, login, session, role or deployment configuration.
