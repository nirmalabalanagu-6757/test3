#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[[ -n "$REPO_ROOT" ]] || { echo "ERROR: run from inside the target repository."; exit 1; }
cd "$REPO_ROOT"
if grep -Ei '^diff --git a/(.*[/])?(sso|oidc|saml|auth|authentication)([/_.-]|$)' "$SCRIPT_DIR"/*.patch; then
  echo "ERROR: protected authentication/SSO patch path found."
  exit 1
fi
if [[ -n "${PYTHON_BIN:-}" ]]; then
  PYTHON="$PYTHON_BIN"
elif [[ -x .venv/Scripts/python.exe ]]; then
  PYTHON=.venv/Scripts/python.exe
elif [[ -x venv/Scripts/python.exe ]]; then
  PYTHON=venv/Scripts/python.exe
elif [[ -x .venv/bin/python ]]; then
  PYTHON=.venv/bin/python
elif [[ -x venv/bin/python ]]; then
  PYTHON=venv/bin/python
elif command -v python3 >/dev/null 2>&1; then
  PYTHON=python3
else
  PYTHON=python
fi
"$PYTHON" -m compileall -q backend agents tests
"$PYTHON" -m pytest tests -q
"$PYTHON" -m alembic -c backend/migrations/alembic.ini heads
if ! command -v npm >/dev/null 2>&1 || [[ ! -d frontend/node_modules ]]; then
  echo "INCOMPLETE: Node/npm/frontend dependencies missing."
  echo "Use approved dependency setup, then rerun. This helper installs nothing."
  exit 1
fi
(cd frontend && npm test -- --run && npm run build)
echo "Automated checks passed. Review any pytest skips above."
echo "No DB migration/deployment was run. Protected auth behavior and target smoke tests still need verification."
