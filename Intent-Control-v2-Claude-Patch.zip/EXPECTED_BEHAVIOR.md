# Required behavior and acceptance contract

## Runtime intent execution

- A matching active intent routes deterministically before entry-agent LLM planning.
- Workflows support single, sequential, parallel, and DAG execution.
- Dependencies, timeouts, retries, stop/continue/fallback behavior, response modes, and audit metadata remain functional.
- Independent steps may run in parallel; dependent steps receive approved previous-step outputs.

## Tool and connection identity

- A single-tool step has exactly one Tool Registry name in `tools` and the same value in `connection_ref`.
- Older one-tool rules infer the same connection for backward compatibility.
- A `connection_ref` with zero or multiple allowed tools is invalid.
- Direct and agent Action Templates must resolve to the same registered tool.
- The runtime exposes only the approved connection to the selected agent.
- Tool credentials and endpoints remain owned by Tool Registry.

## Learning and deduplication

- Learning observes only unmatched top-level requests from agents with Intent Control enabled.
- Internal workflow calls do not recursively create learning candidates.
- Prompt examples are redacted before persistence.
- Actual function-call and function-response tool names are captured.
- Same normalized request and same route are grouped.
- Same request with a different route is not merged.
- Existing-intent comparison is deterministic, route compatible, operation-family compatible, and at least 0.80 similar.
- At or above 0.80, the Learning Queue proposes the next workflow version of the same intent.
- There is one pending update entry per existing intent, source agent, and compatible route.
- Below 0.80, learning proposes a separate new intent.

## Version update behavior

- An existing v1 intent proposes v2; v2 proposes v3.
- Approval updates the same database row and ID.
- Normal similar-example updates preserve the existing configuration. A patch 0007 reviewed upgrade from a compatible agent-only route may replace workflow steps/parameters with an observed direct plan, preserving intent identity, source scope, response behavior and stronger risk controls.
- New examples and stable keywords are merged without duplicates.
- An administrator cannot rename the update proposal to create a duplicate intent.
- A stale proposal cannot overwrite a newer intent version.
- The similarity score is displayed clearly in the Learning Queue.

## Response and Action Templates

- `direct` may return direct tool output without an execution LLM.
- `template` renders the configured response template without an aggregator LLM.
- `internal_summary` combines workflow results internally.
- `llm_summary` and `detailed` use an aggregator only when configured.
- Intent versioning preserves response mode, response template, and response options.
- Intent versioning preserves immutable Action Template references such as `backup.status@1`.
- Changing an Action Template requires an explicit published template version and administrator selection.

## Data handling

- The system stores intent configuration, routing metadata, execution status, and bounded summaries.
- It does not persist complete fetched business payloads by default.
- It never stores Tool Registry credentials in learned intent data.

## SSO

- Existing SSO and identity behavior is byte-for-byte or behaviorally unchanged.
- Intent APIs continue using the existing administrator role protection.
- No authentication bypass may be added for testing.

## Patch 0007: dynamic individual-call learning

- Capture repeated calls separately and deduplicate callback/event representations by call ID.
- Request traces are isolated and bounded; failed, blocked, unpaired, incomplete or oversized evidence cannot silently become a direct workflow.
- The runner invalidates partial traces when its invocation fails.
- Each direct step requires one exact published Action Template match for the complete observed arguments, assigned tool and allowed agent. Zero/multiple matches require review.
- Schema-based typed extraction supports labels/aliases, enums, configured regexes and UTC dates; invalid or ambiguous recognized inputs clarify.
- Different occurrences of a parameter can feed different same-tool calls.
- Optional inputs are omitted when supported, not silently set to a global row limit.
- Observed predecessor ordering is preserved; independent observed calls can run independently.
- Validated $from_step references read fresh current-run output; $parameter references use current validated request values.
- Explicit current request parameters take precedence over echoed prior outputs.
- Unknown dependencies, malformed pointers, missing fields and nested type violations fail safely.
- Failed/skipped predecessors block dependent tools.
- Evidence UI/API displays structural call metadata, matches and review reasons, never raw trace payloads.
- Keep ordinary agent execution if any contributing agent/call cannot safely compile.
- Deduplication checks compatible action/operation plans as well as route and prompt.
- Existing approved rules are not silently rewritten; upgrades remain reviewed and version checked.
- No new runtime dependency, SSO change or customer-credential requirement is introduced.
