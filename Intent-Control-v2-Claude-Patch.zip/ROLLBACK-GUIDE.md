# Recoverable rollback guide

Code rollback and database/workflow rollback are separate decisions. These helpers never delete databases or auto-run downgrades.

## Before applying

Preserve the target branch/commit, export affected intent definitions, back up/clone the database and retain previous images/config.
`APPLY_PATCHES.sh` creates backup and patch branches for exact source revisions only.
Claude's semantic integration must preserve an equivalent baseline before changing files.

## A patch fails before deployment

Inspect `git status`. If `git am` is in progress, `git am --abort` cancels that failed am operation.
Earlier successful patches remain on the new patch branch. The printed backup branch still points to the original source.
Switch to that backup branch (or original branch), after preserving any subsequent work:

```bash
git switch <printed-backup-branch>
```

No reset, branch deletion or force-push is needed.

## Before rolling a deployed 0007 application back

1. Export/review all new or upgraded intent definitions.
2. Disable rules using `$parameter` / `$from_step`, or restore their earlier exported definitions. Old code does not understand those bindings.
3. Preserve the database and current images/config before changes.
4. Roll application images back using the existing OCP process.
5. Verify DB connectivity, existing SSO, health and old intent behavior.

The additive observation_json column may remain in the DB. Do not automatically downgrade simply to roll application code back.
Downgrading 031 drops structural observation metadata; check later migration dependencies first and use a separately approved recovery plan.
Do not assume renaming a cloned DB is enough: the application connection configuration must point to the intended DB and its schema must match the selected code.

## After merging source

Use reviewed revert commits on shared branches instead of rewriting history. Determine the actual merge/adapted commit IDs from the target, not the source manifest.

```bash
git log --oneline --decorate -n 20
# Only after identifying the exact target commits to undo:
git revert <reviewed-newest-target-commit>
```

For multiple commits, plan newest-to-oldest reversions; do not paste a broad range without review.
Document which rules/images/migrations were restored and rerun the relevant tests.
