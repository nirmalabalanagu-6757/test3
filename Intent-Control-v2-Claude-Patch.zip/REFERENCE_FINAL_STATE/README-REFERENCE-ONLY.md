# Reference only

These 70 source files are the committed final state at `c2c58699c39a5a5263ead65398caac8b37a1df38` for the seven-patch series.

Do not bulk-copy this directory over a drifted target. Compare the relevant functions and schema, reproduce missing behavior, preserve target-specific integration, and run the target tests.

There is no SSO implementation payload. Shared entry points (App.tsx, dashboard, API client and routers) reference existing auth interfaces and are comparison-only: never replace target login/session/headers/role enforcement with standalone-VM behavior.

Other application dependencies and files are intentionally absent. This is not a runnable standalone application.
