"""Safe, disabled-by-default sample workflows for Intent Control."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.action_template import ActionTemplate
from backend.models.intent import IntentRule
from backend.schemas.action_template import ActionTemplateCreate
from backend.schemas.intent import IntentRuleCreate
from backend.services.action_template import ActionTemplateService
from backend.services.intent_control import IntentControlService

SAMPLE_OWNER = "intent-workflow-sample-seeder"


def sample_action_templates() -> list[ActionTemplateCreate]:
    """Return portable direct-action contracts backed by existing Skywise tools."""
    return [
        ActionTemplateCreate(
            name="sample.skywise.db-relationships.read",
            version=1,
            display_name="Sample: Skywise database relationships",
            description=(
                "Read a bounded set of database-to-application relationships from Skywise without an execution LLM."
            ),
            template_type="skywise",
            tool_name="fetch_skywise_db_relationships",
            execution_mode="direct",
            payload_template_json={
                "columns": "{{columns}}",
                "row_limit": "{{row_limit}}",
            },
            input_schema_json={
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "columns": {
                        "type": "string",
                        "default": "",
                        "description": "Optional comma-separated Skywise columns.",
                    },
                    "row_limit": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 1_000,
                        "default": 25,
                    },
                },
            },
            output_schema_json={
                "type": "object",
                "required": ["data", "total_count"],
                "properties": {
                    "data": {"type": "array"},
                    "total_count": {"type": "integer"},
                    "query_timestamp": {"type": "string"},
                },
            },
            policy_json={
                "risk_classification": "read_only",
                "requires_confirmation": False,
                "allowed_agents": ["database_agent"],
                "allowed_resources": ["Skywise:db_relationships"],
                "max_rows": 1_000,
                "max_response_bytes": 2_000_000,
            },
            execution_options_json={
                "include_unmapped_inputs": False,
                "strict_tool_arguments": True,
            },
            lifecycle_status="active",
        ),
        ActionTemplateCreate(
            name="sample.skywise.finops-list.read",
            version=1,
            display_name="Sample: Skywise FinOps objects",
            description=("Read a bounded set of Skywise FinOps objects without an execution LLM."),
            template_type="skywise",
            tool_name="fetch_skywise_finops_for_cloud",
            execution_mode="direct",
            payload_template_json={
                "object_type": "{{object_type}}",
                "row_limit": "{{row_limit}}",
                "properties": "{{properties}}",
            },
            input_schema_json={
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "object_type": {
                        "type": "string",
                        "default": "showback_item",
                    },
                    "row_limit": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 1_000,
                        "default": 25,
                    },
                    "properties": {
                        "type": "string",
                        "default": "",
                        "description": "Optional comma-separated Skywise properties.",
                    },
                },
            },
            output_schema_json={
                "type": "object",
                "required": ["items", "total_count"],
                "properties": {
                    "items": {"type": "array"},
                    "total_count": {"type": "integer"},
                    "object_type": {"type": "string"},
                    "query_timestamp": {"type": "string"},
                },
            },
            policy_json={
                "risk_classification": "read_only",
                "requires_confirmation": False,
                "allowed_agents": ["finops_agent"],
                "allowed_resources": ["Skywise:PslCloudShowbackItems"],
                "max_rows": 1_000,
                "max_response_bytes": 2_000_000,
            },
            execution_options_json={
                "include_unmapped_inputs": False,
                "strict_tool_arguments": True,
            },
            lifecycle_status="active",
        ),
    ]


def _parameter_config() -> dict[str, Any]:
    return {
        "required": [],
        "properties": {
            "row_limit": {
                "type": "integer",
                "default": 25,
                "pattern": r"\b(?:first|limit|top)\s+(?P<row_limit>\d{1,4})\b",
                "prompt": "Provide the maximum number of rows.",
            },
            "columns": {
                "type": "string",
                "default": "",
                "pattern": r"\b(?:columns?|fields?)\s+(?P<columns>[A-Za-z0-9_.-]+(?:\s*,\s*[A-Za-z0-9_.-]+)*)",
            },
            "object_type": {
                "type": "string",
                "default": "showback_item",
                "pattern": r"\bobject(?:\s+type)?\s+(?P<object_type>[A-Za-z0-9_-]+)",
            },
            "properties": {
                "type": "string",
                "default": "",
                "pattern": r"\bproperties\s+(?P<properties>[A-Za-z0-9_.-]+(?:\s*,\s*[A-Za-z0-9_.-]+)*)",
            },
        },
    }


def sample_intent_rules() -> list[IntentRuleCreate]:
    """Return disabled examples that administrators can inspect before enabling."""
    common_options = {
        "max_parallel_steps": 4,
        "max_total_steps": 4,
        "max_agents": 4,
        "total_timeout_sec": 120,
        "continue_on_optional_failure": True,
        "multi_intent_min_confidence": 0.80,
    }
    return [
        IntentRuleCreate(
            name="sample.skywise.database-dependencies",
            display_name="Sample: Skywise database dependencies",
            description=(
                "Disabled sample of deterministic matching followed by one direct Skywise database-relationship action."
            ),
            enabled=False,
            priority=50,
            match_strategy="hybrid",
            keyword_mode="any",
            keywords_json=[
                "skywise",
                "database",
                "dependency",
                "dependencies",
                "relationship",
                "relationships",
            ],
            negative_keywords_json=["delete", "drop", "modify", "write"],
            examples_json=[
                "Show Skywise database dependencies",
                "List the first 25 database application relationships",
            ],
            min_confidence=0.72,
            ambiguity_margin=0.10,
            ambiguity_action="clarify",
            target_agent="database_agent",
            allowed_source_agents_json=["concierge", "database_agent"],
            allowed_tools_json=["fetch_skywise_db_relationships"],
            orchestration_mode="single",
            workflow_json=[
                {
                    "id": "read-database-relationships",
                    "agent": "database_agent",
                    "tools": ["fetch_skywise_db_relationships"],
                    "action_template": "sample.skywise.db-relationships.read@1",
                    "action_inputs": {
                        "columns": "parameters.columns",
                        "row_limit": "parameters.row_limit",
                    },
                    "timeout_sec": 60,
                }
            ],
            allow_multi_intent=False,
            max_intents=1,
            execution_options_json=common_options,
            workflow_version=1,
            parameter_config_json=_parameter_config(),
            risk_classification="read_only",
            requires_confirmation=False,
            response_mode="direct",
            response_options_json={"sample": True},
            test_cases_json=[
                {
                    "name": "routes a bounded dependency read",
                    "query": "List the first 25 database application relationships",
                    "source_agent": "concierge",
                    "expected_decision": "route",
                    "expected_target_agent": "database_agent",
                    "expected_parameters_json": {"row_limit": 25},
                },
                {
                    "name": "rejects a destructive relationship request",
                    "query": "Delete a database relationship",
                    "source_agent": "concierge",
                    "expected_decision": "no_match",
                },
            ],
        ),
        IntentRuleCreate(
            name="sample.skywise.impact-and-cost",
            display_name="Sample: Skywise dependency and cost workflow",
            description=(
                "Disabled two-agent example that runs database relationships and "
                "FinOps reads in parallel, without an execution or summary LLM."
            ),
            enabled=False,
            priority=60,
            match_strategy="hybrid",
            keyword_mode="any",
            keywords_json=["skywise", "dependency", "impact", "cost", "finops"],
            negative_keywords_json=["delete", "drop", "modify", "write"],
            examples_json=[
                "Show Skywise database dependency and cloud cost impact",
                "Compare database relationships with FinOps showback items",
            ],
            min_confidence=0.78,
            ambiguity_margin=0.10,
            ambiguity_action="clarify",
            target_agent="database_agent",
            allowed_source_agents_json=[
                "concierge",
                "database_agent",
                "finops_agent",
            ],
            allowed_tools_json=[
                "fetch_skywise_db_relationships",
                "fetch_skywise_finops_for_cloud",
            ],
            orchestration_mode="parallel",
            workflow_json=[
                {
                    "id": "read-database-relationships",
                    "agent": "database_agent",
                    "tools": ["fetch_skywise_db_relationships"],
                    "action_template": "sample.skywise.db-relationships.read@1",
                    "action_inputs": {
                        "columns": "parameters.columns",
                        "row_limit": "parameters.row_limit",
                    },
                    "timeout_sec": 60,
                },
                {
                    "id": "read-finops-items",
                    "agent": "finops_agent",
                    "tools": ["fetch_skywise_finops_for_cloud"],
                    "action_template": "sample.skywise.finops-list.read@1",
                    "action_inputs": {
                        "object_type": "parameters.object_type",
                        "row_limit": "parameters.row_limit",
                        "properties": "parameters.properties",
                    },
                    "timeout_sec": 60,
                },
            ],
            allow_multi_intent=False,
            max_intents=1,
            execution_options_json=common_options,
            workflow_version=1,
            parameter_config_json=_parameter_config(),
            risk_classification="read_only",
            requires_confirmation=False,
            response_mode="internal_summary",
            response_options_json={"sample": True},
            test_cases_json=[
                {
                    "name": "routes the exact dependency and cost request",
                    "query": "Show Skywise database dependency and cloud cost impact",
                    "source_agent": "concierge",
                    "expected_decision": "route",
                    "expected_target_agent": "database_agent",
                    "expected_parameters_json": {"row_limit": 25},
                },
                {
                    "name": "ignores an unrelated backup request",
                    "query": "Show the latest database backup status",
                    "source_agent": "concierge",
                    "expected_decision": "no_match",
                },
            ],
        ),
    ]


async def seed_intent_workflow_samples(session: AsyncSession) -> dict[str, list[str]]:
    """Idempotently create sample templates and disabled intent rules."""
    result: dict[str, list[str]] = {
        "created_templates": [],
        "existing_templates": [],
        "created_intents": [],
        "existing_intents": [],
        "updated_intents": [],
    }
    template_service = ActionTemplateService()
    intent_service = IntentControlService()

    for data in sample_action_templates():
        existing = await session.scalar(
            select(ActionTemplate).where(
                ActionTemplate.name == data.name,
                ActionTemplate.version == data.version,
            )
        )
        reference = f"{data.name}@{data.version}"
        if existing is not None:
            result["existing_templates"].append(reference)
            continue
        await template_service.create_template(session, data, created_by=SAMPLE_OWNER)
        result["created_templates"].append(reference)

    for data in sample_intent_rules():
        existing = await session.scalar(select(IntentRule).where(IntentRule.name == data.name))
        if existing is not None:
            if existing.created_by == SAMPLE_OWNER and not (existing.test_cases_json or []):
                existing.test_cases_json = [
                    item.model_dump(mode="json") for item in data.test_cases_json
                ]
                existing.negative_keywords_json = list(data.negative_keywords_json)
                result["updated_intents"].append(data.name)
            result["existing_intents"].append(data.name)
            continue
        await intent_service.create_rule(session, data, created_by=SAMPLE_OWNER)
        result["created_intents"].append(data.name)

    return result
