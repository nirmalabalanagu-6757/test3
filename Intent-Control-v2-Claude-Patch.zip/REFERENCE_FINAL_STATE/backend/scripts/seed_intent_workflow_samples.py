"""Create safe, disabled Intent Control sample workflows."""

from __future__ import annotations

import asyncio
import json

from backend.database import async_session_factory
from backend.startup_config.intent_workflow_samples import (
    seed_intent_workflow_samples,
)


async def main() -> None:
    async with async_session_factory() as session:
        try:
            result = await seed_intent_workflow_samples(session)
            await session.commit()
        except Exception:
            await session.rollback()
            raise
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
