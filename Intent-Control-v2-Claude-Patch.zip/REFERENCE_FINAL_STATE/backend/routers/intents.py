"""Administrator APIs for dynamic Intent Control."""

# FastAPI's documented dependency-injection pattern uses calls in defaults.
# ruff: noqa: B008

import logging
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import require_role
from backend.models.intent import (
    IntentExecutionRun,
    IntentExecutionStep,
    IntentShadowEvaluation,
)
from backend.models.user import User
from backend.schemas.intent import (
    IntentAssuranceResponse,
    IntentDecision,
    IntentExecutionRunListResponse,
    IntentExecutionRunResponse,
    IntentExecutionStepResponse,
    IntentExportResponse,
    IntentImportRequest,
    IntentImportResponse,
    IntentReadinessReport,
    IntentRegressionResult,
    IntentResolveRequest,
    IntentRuleCreate,
    IntentRuleListResponse,
    IntentRuleResponse,
    IntentRuleUpdate,
    IntentShadowEvaluationListResponse,
    IntentShadowEvaluationResponse,
)
from backend.services.intent_assurance import IntentAssuranceService
from backend.services.intent_control import (
    IntentActivationBlockedError,
    IntentConfigurationError,
    IntentControlService,
    IntentNameExistsError,
    IntentNotFoundError,
)

router = APIRouter(
    prefix="/api/intents",
    tags=["intent-control"],
    dependencies=[Depends(require_role("admin"))],
)

_service = IntentControlService()
_assurance = IntentAssuranceService(_service)
logger = logging.getLogger(__name__)


def _error(
    status: int,
    code: str,
    message: str,
    request: Request,
    *,
    details: dict[str, Any] | None = None,
) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": details or {},
                "request_id": getattr(request.state, "request_id", "unknown"),
                "timestamp": datetime.now(UTC).isoformat(),
            }
        },
    )


def _invalidate_runtime(*agent_names: str | None) -> None:
    try:
        from backend.services.agent_runner import agent_runner

        agent_runner.invalidate_routing_runners()
        for name in agent_names:
            if name:
                agent_runner.invalidate_runners(name)
    except Exception:
        logger.warning("Failed to invalidate agent runners after intent change", exc_info=True)


@router.get("", response_model=IntentRuleListResponse)
async def list_intents(
    enabled: bool | None = Query(None),
    target_agent: str | None = Query(None),
    source_agent: str | None = Query(None),
    session: AsyncSession = Depends(get_session),
) -> Any:
    rules = await _service.list_rules(
        session,
        enabled=enabled,
        target_agent=target_agent,
        source_agent=source_agent,
    )
    return IntentRuleListResponse(
        intents=[IntentRuleResponse.model_validate(rule) for rule in rules],
        count=len(rules),
    )


@router.post("", response_model=IntentRuleResponse, status_code=201)
async def create_intent(
    data: IntentRuleCreate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        rule = await _service.create_rule(session, data, created_by=user.username)
        await session.commit()
        _invalidate_runtime(rule.target_agent)
        return IntentRuleResponse.model_validate(rule)
    except IntentNameExistsError as exc:
        await session.rollback()
        return _error(409, "INTENT_NAME_EXISTS", str(exc), request)
    except IntentActivationBlockedError as exc:
        await session.rollback()
        return _error(
            422,
            "INTENT_ACTIVATION_BLOCKED",
            str(exc),
            request,
            details={"readiness": exc.report.model_dump(mode="json")},
        )
    except IntentConfigurationError as exc:
        await session.rollback()
        return _error(422, "INVALID_INTENT_CONFIGURATION", str(exc), request)


@router.post("/resolve", response_model=IntentDecision)
async def test_resolve_intent(
    data: IntentResolveRequest,
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Resolve a query exactly as the runtime deterministic stage would."""
    decision = await _service.resolve(
        session,
        data.query,
        parameters=data.parameters,
        confirmed=data.confirmed,
        source_agent=data.source_agent,
    )
    # Persist only non-executing shadow observations, when any were produced.
    await session.commit()
    return decision


def _run_response(
    run: IntentExecutionRun,
    steps: list[IntentExecutionStep],
) -> IntentExecutionRunResponse:
    payload = IntentExecutionRunResponse.model_validate(run)
    payload.steps = [IntentExecutionStepResponse.model_validate(step) for step in steps]
    return payload


@router.get("/runs", response_model=IntentExecutionRunListResponse)
async def list_execution_runs(
    status: str | None = Query(None),
    source_agent: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    session: AsyncSession = Depends(get_session),
) -> Any:
    stmt = select(IntentExecutionRun)
    if status:
        stmt = stmt.where(IntentExecutionRun.status == status)
    if source_agent:
        stmt = stmt.where(IntentExecutionRun.source_agent == source_agent)
    stmt = stmt.order_by(IntentExecutionRun.started_at.desc()).limit(limit)
    runs = list((await session.execute(stmt)).scalars().all())
    if not runs:
        return IntentExecutionRunListResponse(runs=[], count=0)

    run_ids = [run.id for run in runs]
    step_rows = list(
        (
            await session.execute(
                select(IntentExecutionStep)
                .where(IntentExecutionStep.run_id.in_(run_ids))
                .order_by(IntentExecutionStep.started_at.asc())
            )
        ).scalars().all()
    )
    grouped: dict[str, list[IntentExecutionStep]] = {run_id: [] for run_id in run_ids}
    for step in step_rows:
        grouped.setdefault(step.run_id, []).append(step)
    return IntentExecutionRunListResponse(
        runs=[_run_response(run, grouped.get(run.id, [])) for run in runs],
        count=len(runs),
    )


@router.get("/runs/{run_id}", response_model=IntentExecutionRunResponse)
async def get_execution_run(
    run_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    run = await session.get(IntentExecutionRun, run_id)
    if run is None:
        return _error(404, "INTENT_RUN_NOT_FOUND", f"Intent run '{run_id}' not found", request)
    steps = list(
        (
            await session.execute(
                select(IntentExecutionStep)
                .where(IntentExecutionStep.run_id == run_id)
                .order_by(IntentExecutionStep.started_at.asc())
            )
        ).scalars().all()
    )
    return _run_response(run, steps)


@router.get("/assurance", response_model=IntentAssuranceResponse)
async def get_intent_assurance(
    session: AsyncSession = Depends(get_session),
) -> Any:
    reports, conflicts = await _assurance.list_reports(session)
    return IntentAssuranceResponse(
        reports=reports,
        conflicts=conflicts,
        count=len(reports),
    )


@router.get(
    "/shadow-evaluations",
    response_model=IntentShadowEvaluationListResponse,
)
async def list_shadow_evaluations(
    intent_id: str | None = Query(None),
    source_agent: str | None = Query(None),
    limit: int = Query(100, ge=1, le=500),
    session: AsyncSession = Depends(get_session),
) -> Any:
    stmt = select(IntentShadowEvaluation)
    if intent_id:
        stmt = stmt.where(IntentShadowEvaluation.intent_id == intent_id)
    if source_agent:
        stmt = stmt.where(IntentShadowEvaluation.source_agent == source_agent)
    rows = list(
        (
            await session.execute(
                stmt.order_by(IntentShadowEvaluation.created_at.desc()).limit(limit)
            )
        ).scalars().all()
    )
    return IntentShadowEvaluationListResponse(
        evaluations=[
            IntentShadowEvaluationResponse.model_validate(row) for row in rows
        ],
        count=len(rows),
    )


@router.get("/export", response_model=IntentExportResponse)
async def export_intents(session: AsyncSession = Depends(get_session)) -> Any:
    return IntentExportResponse(data=await _service.export_rules(session))


@router.post("/import", response_model=IntentImportResponse)
async def import_intents(
    data: IntentImportRequest,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    imported, updated, errors = await _service.import_rules(
        session,
        data.data,
        replace_existing=data.replace_existing,
        imported_by=user.username,
    )
    await session.commit()
    _invalidate_runtime()
    return IntentImportResponse(imported=imported, updated=updated, errors=errors)


@router.get("/{intent_id}", response_model=IntentRuleResponse)
async def get_intent(
    intent_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        return IntentRuleResponse.model_validate(await _service.get_rule(session, intent_id))
    except IntentNotFoundError as exc:
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)


@router.get("/{intent_id}/readiness", response_model=IntentReadinessReport)
async def get_intent_readiness(
    intent_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        rule = await _service.get_rule(session, intent_id)
        return await _assurance.readiness(session, rule)
    except IntentNotFoundError as exc:
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)


@router.post(
    "/{intent_id}/regression/run",
    response_model=list[IntentRegressionResult],
)
async def run_intent_regression(
    intent_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        rule = await _service.get_rule(session, intent_id)
        return await _assurance.run_regression_cases(session, rule)
    except IntentNotFoundError as exc:
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)


@router.put("/{intent_id}", response_model=IntentRuleResponse)
async def update_intent(
    intent_id: str,
    data: IntentRuleUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        old_rule = await _service.get_rule(session, intent_id)
        old_target = old_rule.target_agent
        rule = await _service.update_rule(session, intent_id, data, updated_by=user.username)
        await session.commit()
        _invalidate_runtime(old_target, rule.target_agent)
        return IntentRuleResponse.model_validate(rule)
    except IntentNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)
    except IntentNameExistsError as exc:
        await session.rollback()
        return _error(409, "INTENT_NAME_EXISTS", str(exc), request)
    except IntentActivationBlockedError as exc:
        await session.rollback()
        return _error(
            422,
            "INTENT_ACTIVATION_BLOCKED",
            str(exc),
            request,
            details={"readiness": exc.report.model_dump(mode="json")},
        )
    except IntentConfigurationError as exc:
        await session.rollback()
        return _error(422, "INVALID_INTENT_CONFIGURATION", str(exc), request)


@router.delete("/{intent_id}", response_model=IntentRuleResponse)
async def delete_intent(
    intent_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        rule = await _service.delete_rule(session, intent_id, deleted_by=user.username)
        response = IntentRuleResponse.model_validate(rule)
        await session.commit()
        _invalidate_runtime(rule.target_agent)
        return response
    except IntentNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)
