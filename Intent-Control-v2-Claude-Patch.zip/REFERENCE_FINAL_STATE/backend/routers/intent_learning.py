"""Administrator APIs for approval-gated dynamic intent learning."""

# FastAPI's dependency-injection pattern uses calls in defaults.
# ruff: noqa: B008

from datetime import UTC, datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import require_role
from backend.models.user import User
from backend.schemas.intent import IntentRuleResponse
from backend.schemas.intent_learning import (
    IntentLearningApprovalResponse,
    IntentLearningApproveRequest,
    IntentLearningCandidateListResponse,
    IntentLearningCandidateResponse,
    IntentLearningRejectRequest,
)
from backend.services.intent_control import (
    IntentConfigurationError,
    IntentNameExistsError,
)
from backend.services.intent_learning import (
    IntentLearningCandidateNotFoundError,
    IntentLearningCandidateStateError,
    IntentLearningService,
)

router = APIRouter(
    prefix="/api/intent-learning",
    tags=["intent-learning"],
    dependencies=[Depends(require_role("admin"))],
)
_service = IntentLearningService()


def _error(status: int, code: str, message: str, request: Request) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": {},
                "request_id": getattr(request.state, "request_id", "unknown"),
                "timestamp": datetime.now(UTC).isoformat(),
            }
        },
    )


@router.get("", response_model=IntentLearningCandidateListResponse)
async def list_candidates(
    status: Literal["pending", "approved", "rejected"] | None = Query("pending"),
    source_agent: str | None = Query(None),
    limit: int = Query(200, ge=1, le=1_000),
    session: AsyncSession = Depends(get_session),
) -> IntentLearningCandidateListResponse:
    candidates = await _service.list_candidates(
        session,
        status=status,
        source_agent=source_agent,
        limit=limit,
    )
    return IntentLearningCandidateListResponse(
        candidates=[IntentLearningCandidateResponse.model_validate(item) for item in candidates],
        count=len(candidates),
    )


@router.get("/{candidate_id}", response_model=IntentLearningCandidateResponse)
async def get_candidate(
    candidate_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        candidate = await _service.get_candidate(session, candidate_id)
        return IntentLearningCandidateResponse.model_validate(candidate)
    except IntentLearningCandidateNotFoundError as exc:
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)


@router.post(
    "/{candidate_id}/approve",
    response_model=IntentLearningApprovalResponse,
)
async def approve_candidate(
    candidate_id: str,
    data: IntentLearningApproveRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        candidate, intent = await _service.approve(
            session,
            candidate_id,
            reviewed_by=user.username,
            rule=data.rule,
            note=data.note,
        )
        await session.commit()
        return IntentLearningApprovalResponse(
            candidate=IntentLearningCandidateResponse.model_validate(candidate),
            intent=IntentRuleResponse.model_validate(intent),
        )
    except IntentLearningCandidateNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)
    except IntentLearningCandidateStateError as exc:
        await session.rollback()
        return _error(409, "INTENT_CANDIDATE_ALREADY_REVIEWED", str(exc), request)
    except IntentNameExistsError as exc:
        await session.rollback()
        return _error(409, "INTENT_NAME_EXISTS", str(exc), request)
    except (IntentConfigurationError, ValidationError) as exc:
        await session.rollback()
        return _error(422, "INVALID_INTENT_PROPOSAL", str(exc), request)


@router.post(
    "/{candidate_id}/reject",
    response_model=IntentLearningCandidateResponse,
)
async def reject_candidate(
    candidate_id: str,
    data: IntentLearningRejectRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        candidate = await _service.reject(
            session,
            candidate_id,
            reviewed_by=user.username,
            note=data.note,
        )
        await session.commit()
        return IntentLearningCandidateResponse.model_validate(candidate)
    except IntentLearningCandidateNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)
    except IntentLearningCandidateStateError as exc:
        await session.rollback()
        return _error(409, "INTENT_CANDIDATE_ALREADY_REVIEWED", str(exc), request)
