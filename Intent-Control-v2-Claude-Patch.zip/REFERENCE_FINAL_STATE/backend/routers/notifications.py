"""Notification API endpoints.

Implements: Task 23.3 — REST endpoints for notifications, rules, and subscriptions.
"""

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import get_current_user, require_role
from backend.models.user import User
from backend.schemas.notification import (
    ChannelCreate,
    ChannelResponse,
    HistoryListResponse,
    HistoryResponse,
    RuleCreate,
    RuleListResponse,
    RuleResponse,
    RuleUpdate,
    SendNotificationRequest,
    SendNotificationResponse,
    SubscriptionCreate,
    SubscriptionListResponse,
    SubscriptionResponse,
    SubscriptionUpdate,
)
from backend.services.notification import NotificationService

router = APIRouter(prefix="/api/notifications", tags=["notifications"])

_service = NotificationService()


# ------------------------------------------------------------------
# Notification history  (GET /api/notifications)
# ------------------------------------------------------------------


@router.get("", response_model=HistoryListResponse)
async def list_notifications(
    event_type: str | None = Query(None),
    severity: str | None = Query(None),
    channel_type: str | None = Query(None),
    delivery_status: str | None = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Return notification delivery history with optional filters.

    Dashboard view: timestamp, event type, severity, channel, delivery status.
    """
    entries = await _service.get_history(
        session,
        event_type=event_type,
        severity=severity,
        channel_type=channel_type,
        delivery_status=delivery_status,
        limit=limit,
        offset=offset,
    )
    return HistoryListResponse(
        notifications=[HistoryResponse.model_validate(e) for e in entries],
        count=len(entries),
    )


# ------------------------------------------------------------------
# Send notification  (POST /api/notifications/send)
# ------------------------------------------------------------------


@router.post("/send", response_model=SendNotificationResponse)
async def send_notification(
    body: SendNotificationRequest,
    user: User = Depends(require_role("admin")),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Dispatch a notification routed through matching rules."""
    result = await _service.send_notification(
        session,
        event_type=body.event_type,
        severity=body.severity,
        message=body.message,
        details=body.details,
    )
    await session.commit()
    return SendNotificationResponse(**result)


# ------------------------------------------------------------------
# Rules  (PUT /api/notifications/rules)
# ------------------------------------------------------------------


@router.get("/rules", response_model=RuleListResponse)
async def list_rules(
    event_type: str | None = Query(None),
    severity: str | None = Query(None),
    enabled: bool | None = Query(None),
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """List notification rules with optional filters."""
    rules = await _service.list_rules(
        session, event_type=event_type, severity=severity, enabled=enabled
    )
    return RuleListResponse(
        rules=[RuleResponse.model_validate(r) for r in rules],
        count=len(rules),
    )


@router.post("/rules", response_model=RuleResponse, status_code=201)
async def create_rule(
    body: RuleCreate,
    user: User = Depends(require_role("admin")),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Create a new notification rule (admin only)."""
    rule = await _service.create_rule(
        session,
        event_type=body.event_type,
        severity=body.severity,
        channel_id=body.channel_id,
        enabled=body.enabled,
    )
    await session.commit()
    return RuleResponse.model_validate(rule)


@router.put("/rules/{rule_id}", response_model=RuleResponse)
async def update_rule(
    rule_id: str,
    body: RuleUpdate,
    user: User = Depends(require_role("admin")),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Update an existing notification rule (admin only)."""
    rule = await _service.update_rule(
        session,
        rule_id,
        event_type=body.event_type,
        severity=body.severity,
        channel_id=body.channel_id,
        enabled=body.enabled,
    )
    if rule is None:
        raise HTTPException(status_code=404, detail="Rule not found")
    await session.commit()
    return RuleResponse.model_validate(rule)


@router.delete("/rules/{rule_id}", status_code=204)
async def delete_rule(
    rule_id: str,
    user: User = Depends(require_role("admin")),
    session: AsyncSession = Depends(get_session),
) -> None:
    """Delete a notification rule (admin only)."""
    deleted = await _service.delete_rule(session, rule_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Rule not found")
    await session.commit()


# ------------------------------------------------------------------
# Subscriptions  (PUT /api/notifications/subscriptions)
# ------------------------------------------------------------------


@router.get("/subscriptions", response_model=SubscriptionListResponse)
async def list_subscriptions(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """List the current user's notification subscriptions."""
    subs = await _service.get_subscriptions(session, user.user_id)
    return SubscriptionListResponse(
        subscriptions=[SubscriptionResponse.model_validate(s) for s in subs],
        count=len(subs),
    )


@router.post("/subscriptions", response_model=SubscriptionResponse, status_code=201)
async def create_subscription(
    body: SubscriptionCreate,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Subscribe the current user to a notification channel."""
    sub = await _service.subscribe(
        session,
        user_id=user.user_id,
        channel_type=body.channel_type,
        event_type=body.event_type,
        severity=body.severity,
    )
    await session.commit()
    return SubscriptionResponse.model_validate(sub)


@router.put("/subscriptions/{subscription_id}", response_model=SubscriptionResponse)
async def update_subscription(
    subscription_id: str,
    body: SubscriptionUpdate,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Update a notification subscription preference."""
    sub = await _service.update_subscription(
        session,
        subscription_id,
        user.user_id,
        channel_type=body.channel_type,
        event_type=body.event_type,
        severity=body.severity,
        enabled=body.enabled,
    )
    if sub is None:
        raise HTTPException(status_code=404, detail="Subscription not found")
    await session.commit()
    return SubscriptionResponse.model_validate(sub)


@router.delete("/subscriptions/{subscription_id}", status_code=204)
async def delete_subscription(
    subscription_id: str,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> None:
    """Unsubscribe from a notification channel."""
    deleted = await _service.unsubscribe(session, subscription_id, user.user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Subscription not found")
    await session.commit()


# ------------------------------------------------------------------
# Channels  (admin management)
# ------------------------------------------------------------------


@router.get("/channels", response_model=list[ChannelResponse])
async def list_channels(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """List all notification channels."""
    from sqlalchemy import select
    from backend.models.notification import NotificationChannel

    result = await session.execute(
        select(NotificationChannel).order_by(NotificationChannel.created_at.desc())
    )
    channels = list(result.scalars().all())
    return [ChannelResponse.model_validate(c) for c in channels]


@router.post("/channels", response_model=ChannelResponse, status_code=201)
async def create_channel(
    body: ChannelCreate,
    user: User = Depends(require_role("admin")),
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Create a notification channel (admin only)."""
    import uuid
    from backend.models.notification import NotificationChannel

    channel = NotificationChannel(
        id=str(uuid.uuid4()),
        channel_type=body.channel_type,
        config=body.config,
        enabled=body.enabled,
    )
    session.add(channel)
    await session.flush()
    await session.commit()
    return ChannelResponse.model_validate(channel)
