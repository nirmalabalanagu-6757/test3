"""Agent Registry and Lifecycle API endpoints.

Validates: Requirements 1.1, 1.4, 2.1, 2.2, 2.3
"""

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.models.agent import AgentRegistry
from backend.middleware.auth import get_current_user, require_role
from backend.models.user import User
from backend.schemas.agent import (
    AgentCreate,
    AgentListResponse,
    AgentResponse,
    AgentUpdate,
)
from backend.services.agent_lifecycle import AgentLifecycleService, InvalidTransitionError
from backend.services.agent_registry import (
    AgentNameExistsError,
    AgentNotFoundError,
    AgentRegistryService,
    InvalidAgentTypeError,
)
from backend.services.tool_registry import AssignmentExistsError, ToolNotFoundError, ToolRegistryService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/agents", tags=["agents"])

# Module-level service singletons
_registry_service = AgentRegistryService()
_lifecycle_service = AgentLifecycleService()
_tool_registry_service = ToolRegistryService()


def _error_response(status_code: int, code: str, message: str, request: Request) -> JSONResponse:
    """Build a consistent error JSONResponse."""
    request_id = getattr(request.state, "request_id", "unknown")
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": {},
                "request_id": request_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        },
    )


# ---------------------------------------------------------------------------
# CRUD endpoints
# ---------------------------------------------------------------------------


@router.get("", response_model=AgentListResponse)
async def list_agents(
    product: str | None = Query(None),
    agent_type: str | None = Query(None),
    status: str | None = Query(None),
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(get_current_user),
) -> Any:
    """List agents with optional filters."""
    agents = await _registry_service.list_agents(session, product=product, agent_type=agent_type, status=status)

    responses: list[AgentResponse] = []
    for a in agents:
        resp = AgentResponse.model_validate(a)
        rc = a.reasoning_config_json
        resp.reasoning_enabled = bool(rc and rc.get("enabled"))
        responses.append(resp)

    return AgentListResponse(agents=responses, count=len(responses))


@router.post("", response_model=AgentResponse, status_code=201)
async def register_agent(
    data: AgentCreate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Register a new agent."""
    try:
        # Register metadata + assignments in one transaction.  Nothing is committed
        # if any requested tool is missing or already assigned.
        agent = await _registry_service.register(session, data)
        for tool_name in data.tools:
            await _tool_registry_service.assign_tool_to_agent(
                session, tool_name, data.name, assigned_by=_user.username
            )
        if data.start_immediately:
            agent = await _lifecycle_service.start(session, data.name)
        await session.commit()

        try:
            from backend.services.agent_runner import agent_runner
            agent_runner.invalidate_runners(data.name)
            agent_runner.invalidate_routing_runners()
        except Exception:
            pass
        return AgentResponse.model_validate(agent)
    except AgentNameExistsError as exc:
        await session.rollback()
        return _error_response(409, "AGENT_NAME_EXISTS", str(exc), request)
    except InvalidAgentTypeError as exc:
        await session.rollback()
        return _error_response(422, "INVALID_AGENT_TYPE", str(exc), request)
    except ToolNotFoundError as exc:
        await session.rollback()
        return _error_response(422, "TOOL_NOT_FOUND", str(exc), request)
    except AssignmentExistsError as exc:
        await session.rollback()
        return _error_response(409, "ASSIGNMENT_EXISTS", str(exc), request)


@router.get("/{name}", response_model=AgentResponse)
async def get_agent(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(get_current_user),
) -> Any:
    """Get a single agent by name."""
    try:
        agent = await _registry_service.get(session, name)
        return AgentResponse.model_validate(agent)
    except AgentNotFoundError as exc:
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)


@router.put("/{name}", response_model=AgentResponse)
async def update_agent(
    name: str,
    data: AgentUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Update an existing agent's configuration."""
    try:
        agent = await _registry_service.update(session, name, data)
        await session.commit()

        try:
            from backend.services.agent_runner import agent_runner

            agent_runner.invalidate_runners(name)
            agent_runner.invalidate_routing_runners()
        except Exception:
            pass

        return AgentResponse.model_validate(agent)
    except AgentNotFoundError as exc:
        await session.rollback()
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)
    except InvalidAgentTypeError as exc:
        await session.rollback()
        return _error_response(422, "INVALID_AGENT_TYPE", str(exc), request)


@router.delete("/{name}", response_model=AgentResponse)
async def deregister_agent(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Deregister an agent (soft-delete via status change)."""
    try:
        agent = await _registry_service.deregister(session, name)
        await session.commit()
        try:
            from backend.services.agent_runner import agent_runner
            agent_runner.invalidate_runners(name)
            agent_runner.invalidate_routing_runners()
        except Exception:
            pass
        return AgentResponse.model_validate(agent)
    except AgentNotFoundError as exc:
        await session.rollback()
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)


# ---------------------------------------------------------------------------
# Lifecycle endpoints
# ---------------------------------------------------------------------------


@router.post("/{name}/start", response_model=AgentResponse)
async def start_agent(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Start an agent."""
    try:
        agent = await _lifecycle_service.start(session, name)
        await session.commit()
        try:
            from backend.services.agent_runner import agent_runner
            agent_runner.invalidate_runners(name)
            agent_runner.invalidate_routing_runners()
        except Exception:
            pass
        return AgentResponse.model_validate(agent)
    except AgentNotFoundError as exc:
        await session.rollback()
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)
    except InvalidTransitionError as exc:
        await session.rollback()
        return _error_response(409, "INVALID_TRANSITION", str(exc), request)


@router.post("/{name}/stop", response_model=AgentResponse)
async def stop_agent(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Stop an agent."""
    try:
        agent = await _lifecycle_service.stop(session, name)
        await session.commit()
        try:
            from backend.services.agent_runner import agent_runner
            agent_runner.invalidate_runners(name)
            agent_runner.invalidate_routing_runners()
        except Exception:
            pass
        return AgentResponse.model_validate(agent)
    except AgentNotFoundError as exc:
        await session.rollback()
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)
    except InvalidTransitionError as exc:
        await session.rollback()
        return _error_response(409, "INVALID_TRANSITION", str(exc), request)


@router.post("/{name}/reload", response_model=AgentResponse)
async def reload_agent(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Reload an agent: restart lifecycle and invalidate cached runners.

    Combines the old restart (lifecycle state reset) and refresh (runner
    cache invalidation) into a single action so the agent picks up the
    latest config, RAG documents, and tool assignments on next invocation.
    """
    try:
        agent = await _lifecycle_service.restart(session, name)

        from backend.services.audit_log import AuditLogService

        audit = AuditLogService()
        await audit.append(
            session,
            event_type="lifecycle",
            agent_name=name,
            details={
                "action": "reload",
                "message": f"Agent '{name}' reloaded (lifecycle reset + config refresh)",
                "triggered_by": _user.username,
            },
        )
        await session.commit()

        from backend.services.agent_runner import agent_runner

        agent_runner.invalidate_runners(name)
        agent_runner.invalidate_routing_runners()

        return AgentResponse.model_validate(agent)
    except AgentNotFoundError as exc:
        await session.rollback()
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)
    except InvalidTransitionError as exc:
        await session.rollback()
        return _error_response(409, "INVALID_TRANSITION", str(exc), request)


# ---------------------------------------------------------------------------
# Agent config YAML endpoints
# ---------------------------------------------------------------------------

_AGENTS_DIR = Path(__file__).resolve().parent.parent.parent / "agents"


def _find_config_path(agent_name: str) -> Path | None:
    """Locate the config YAML for an agent by convention."""
    # Try exact directory name, then with _agent suffix stripped
    candidates = [agent_name, agent_name.removesuffix("_agent"), agent_name.replace("-", "_")]
    for name in candidates:
        for ext in ("yaml", "yml", "json"):
            p = _AGENTS_DIR / name / f"config.{ext}"
            if p.is_file():
                return p
    return None


def _model_config_for_yaml(raw: str | None) -> Any:
    """Render model_config_json naturally in the YAML editor."""
    if not raw:
        return ""
    text = raw.strip()
    if text.startswith(("{", "[")):
        try:
            import json

            return json.loads(text)
        except Exception:
            pass
    return raw


@router.get("/{name}/config", response_class=PlainTextResponse)
async def get_agent_config(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(get_current_user),
) -> Any:
    """Return file-backed config or a DB-generated YAML config for dynamic agents."""
    config_path = _find_config_path(name)
    if config_path is not None:
        return PlainTextResponse(
            config_path.read_text(),
            media_type="text/yaml",
            headers={"Cache-Control": "no-store"},
        )

    try:
        import yaml

        agent = await _registry_service.get(session, name)
        data = {
            "name": agent.name,
            "description": agent.description or "",
            "instruction": agent.instruction or "",
            "product": agent.product,
            "agent_type": agent.agent_type,
            "model": _model_config_for_yaml(agent.model_config_json),
            "allow_world_knowledge": agent.allow_world_knowledge,
            "intent_control_enabled": agent.intent_control_enabled,
            "reasoning_config": agent.reasoning_config_json or {"enabled": False},
            "generate_content_config": agent.generate_content_config_json or {},
        }
        return PlainTextResponse(
            yaml.safe_dump(data, sort_keys=False, allow_unicode=True),
            media_type="text/yaml",
            headers={"Cache-Control": "no-store", "X-AIOps-Config-Source": "database"},
        )
    except AgentNotFoundError as exc:
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)


@router.put("/{name}/config", response_class=PlainTextResponse)
async def update_agent_config(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Update file-backed config, or update DB configuration for a dynamic agent."""
    raw = await request.body()
    raw_text = raw.decode("utf-8")
    config_path = _find_config_path(name)

    if config_path is not None:
        # Validate a temporary copy before touching the live file.  If database
        # synchronization fails after replacement, restore the original config.
        tmp_path = config_path.with_name(f".{config_path.stem}.aiops-tmp{config_path.suffix}")
        original_text = config_path.read_text()
        try:
            from agents.base.config_loader import load_agent_config

            tmp_path.write_text(raw_text)
            cfg = load_agent_config(str(tmp_path))
            agent = await _registry_service.get(session, name)
            agent.reasoning_config_json = cfg.reasoning_config
            agent.generate_content_config_json = cfg.generate_content_config
            agent.description = cfg.description
            agent.instruction = cfg.instruction
            agent.model_config_json = cfg.model
            agent.product = cfg.product or agent.product
            agent.allow_world_knowledge = cfg.allow_world_knowledge
            await session.flush()
            tmp_path.replace(config_path)
            try:
                await session.commit()
            except Exception:
                config_path.write_text(original_text)
                raise
        except AgentNotFoundError as exc:
            await session.rollback()
            tmp_path.unlink(missing_ok=True)
            return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)
        except Exception as exc:
            await session.rollback()
            tmp_path.unlink(missing_ok=True)
            logger.warning("Rejected invalid agent config for %s: %s", name, exc)
            return _error_response(422, "INVALID_CONFIG", f"Could not parse/update config: {exc}", request)
    else:
        try:
            import yaml

            parsed = yaml.safe_load(raw_text) or {}
            if not isinstance(parsed, dict):
                return _error_response(422, "INVALID_CONFIG", "Agent config must be a YAML/JSON object", request)

            await _registry_service.get(session, name)  # explicit existence check
            config_updates: dict[str, Any] = {}
            key_map = {
                "description": "description",
                "instruction": "instruction",
                "product": "product",
                "agent_type": "agent_type",
                "reasoning_config": "reasoning_config_json",
                "generate_content_config": "generate_content_config_json",
                "allow_world_knowledge": "allow_world_knowledge",
                "intent_control_enabled": "intent_control_enabled",
            }
            for yaml_key, schema_key in key_map.items():
                if yaml_key in parsed:
                    config_updates[schema_key] = parsed[yaml_key]
            if "model" in parsed:
                model_value = parsed.get("model")
                if isinstance(model_value, (dict, list)):
                    import json

                    config_updates["model_config_json"] = json.dumps(model_value)
                else:
                    config_updates["model_config_json"] = str(model_value) if model_value is not None else None
            update = AgentUpdate(**config_updates)
            await _registry_service.update(session, name, update)
            await session.commit()
        except AgentNotFoundError as exc:
            await session.rollback()
            return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)
        except Exception as exc:
            await session.rollback()
            return _error_response(422, "INVALID_CONFIG", f"Could not parse/update config: {exc}", request)

    try:
        from backend.services.agent_runner import agent_runner

        agent_runner.invalidate_runners(name)
        agent_runner.invalidate_routing_runners()
    except Exception:
        pass

    # Return the canonical effective config so the editor refreshes cleanly.
    if config_path is not None:
        return PlainTextResponse(config_path.read_text(), media_type="text/yaml")

    import yaml
    agent = await _registry_service.get(session, name)
    rendered = yaml.safe_dump(
        {
            "name": agent.name,
            "description": agent.description or "",
            "instruction": agent.instruction or "",
            "product": agent.product,
            "agent_type": agent.agent_type,
            "model": _model_config_for_yaml(agent.model_config_json),
            "allow_world_knowledge": agent.allow_world_knowledge,
            "intent_control_enabled": agent.intent_control_enabled,
            "reasoning_config": agent.reasoning_config_json or {"enabled": False},
            "generate_content_config": agent.generate_content_config_json or {},
        },
        sort_keys=False,
        allow_unicode=True,
    )
    return PlainTextResponse(rendered, media_type="text/yaml", headers={"X-AIOps-Config-Source": "database"})


@router.get("/{name}/health", response_model=None)
async def get_agent_health(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(get_current_user),
) -> Any:
    """Get the latest health status for an agent."""
    try:
        agent = await _registry_service.get(session, name)
        return {
            "name": agent.name,
            "lifecycle_status": agent.lifecycle_status,
            "last_health_check": (agent.last_health_check.isoformat() if agent.last_health_check else None),
            "last_health_result": agent.last_health_result,
            "consecutive_health_failures": agent.consecutive_health_failures,
            "health_check_interval_sec": agent.health_check_interval_sec,
        }
    except AgentNotFoundError as exc:
        return _error_response(404, "AGENT_NOT_FOUND", str(exc), request)
