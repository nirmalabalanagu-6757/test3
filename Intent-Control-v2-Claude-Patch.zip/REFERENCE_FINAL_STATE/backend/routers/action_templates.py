"""Administrator APIs for the Universal Action Template Registry."""

# FastAPI's dependency-injection pattern uses calls in defaults.
# ruff: noqa: B008

from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import require_role
from backend.models.user import User
from backend.schemas.action_template import (
    ActionTemplateCloneRequest,
    ActionTemplateCreate,
    ActionTemplateListResponse,
    ActionTemplateRenderRequest,
    ActionTemplateRenderResponse,
    ActionTemplateResponse,
    ActionTemplateUpdate,
)
from backend.services.action_template import (
    ActionTemplateConfigurationError,
    ActionTemplateExistsError,
    ActionTemplateInUseError,
    ActionTemplateNotFoundError,
    ActionTemplateService,
)

router = APIRouter(
    prefix="/api/action-templates",
    tags=["action-template-registry"],
    dependencies=[Depends(require_role("admin"))],
)
_service = ActionTemplateService()


def _error(status: int, code: str, message: str, request: Request) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": {},
                "request_id": getattr(request.state, "request_id", "unknown"),
                "timestamp": datetime.now(UTC).isoformat(),
            }
        },
    )


@router.get("", response_model=ActionTemplateListResponse)
async def list_action_templates(
    lifecycle_status: str | None = Query(None),
    template_type: str | None = Query(None),
    tool_name: str | None = Query(None),
    session: AsyncSession = Depends(get_session),
) -> Any:
    templates = await _service.list_templates(
        session,
        lifecycle_status=lifecycle_status,
        template_type=template_type,
        tool_name=tool_name,
    )
    return ActionTemplateListResponse(
        action_templates=[
            ActionTemplateResponse.model_validate(template) for template in templates
        ],
        count=len(templates),
    )


@router.post("", response_model=ActionTemplateResponse, status_code=201)
async def create_action_template(
    data: ActionTemplateCreate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        template = await _service.create_template(
            session, data, created_by=user.username
        )
        await session.commit()
        return ActionTemplateResponse.model_validate(template)
    except ActionTemplateExistsError as exc:
        await session.rollback()
        return _error(409, "ACTION_TEMPLATE_EXISTS", str(exc), request)
    except ActionTemplateConfigurationError as exc:
        await session.rollback()
        return _error(422, "INVALID_ACTION_TEMPLATE", str(exc), request)


@router.post("/{template_id}/clone", response_model=ActionTemplateResponse, status_code=201)
async def clone_action_template(
    template_id: str,
    data: ActionTemplateCloneRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        template = await _service.clone_template(
            session,
            template_id,
            version=data.version,
            created_by=user.username,
        )
        await session.commit()
        return ActionTemplateResponse.model_validate(template)
    except ActionTemplateNotFoundError as exc:
        await session.rollback()
        return _error(404, "ACTION_TEMPLATE_NOT_FOUND", str(exc), request)
    except ActionTemplateExistsError as exc:
        await session.rollback()
        return _error(409, "ACTION_TEMPLATE_EXISTS", str(exc), request)
    except ActionTemplateConfigurationError as exc:
        await session.rollback()
        return _error(422, "INVALID_ACTION_TEMPLATE", str(exc), request)


@router.post("/{template_id}/render", response_model=ActionTemplateRenderResponse)
async def render_action_template(
    template_id: str,
    data: ActionTemplateRenderRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        template = await _service.get_template(session, template_id)
        snapshot = _service.snapshot(template)
        return _service.render_snapshot(
            snapshot,
            inputs=data.inputs,
            query=data.query,
            step_outputs=data.step_outputs,
        )
    except ActionTemplateNotFoundError as exc:
        return _error(404, "ACTION_TEMPLATE_NOT_FOUND", str(exc), request)
    except ActionTemplateConfigurationError as exc:
        return _error(422, "ACTION_TEMPLATE_RENDER_FAILED", str(exc), request)


@router.get("/{template_id}", response_model=ActionTemplateResponse)
async def get_action_template(
    template_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        template = await _service.get_template(session, template_id)
        return ActionTemplateResponse.model_validate(template)
    except ActionTemplateNotFoundError as exc:
        return _error(404, "ACTION_TEMPLATE_NOT_FOUND", str(exc), request)


@router.put("/{template_id}", response_model=ActionTemplateResponse)
async def update_action_template(
    template_id: str,
    data: ActionTemplateUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        template = await _service.update_template(
            session, template_id, data, updated_by=user.username
        )
        await session.commit()
        return ActionTemplateResponse.model_validate(template)
    except ActionTemplateNotFoundError as exc:
        await session.rollback()
        return _error(404, "ACTION_TEMPLATE_NOT_FOUND", str(exc), request)
    except ActionTemplateConfigurationError as exc:
        await session.rollback()
        return _error(422, "INVALID_ACTION_TEMPLATE", str(exc), request)


@router.delete("/{template_id}", response_model=ActionTemplateResponse)
async def delete_action_template(
    template_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        template = await _service.delete_template(
            session, template_id, deleted_by=user.username
        )
        response = ActionTemplateResponse.model_validate(template)
        await session.commit()
        return response
    except ActionTemplateNotFoundError as exc:
        await session.rollback()
        return _error(404, "ACTION_TEMPLATE_NOT_FOUND", str(exc), request)
    except ActionTemplateInUseError as exc:
        await session.rollback()
        return _error(409, "ACTION_TEMPLATE_IN_USE", str(exc), request)
