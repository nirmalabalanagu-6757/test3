"""Validation schemas for dynamic intent-control administration and resolution."""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from backend.schemas.action_template import ResolvedActionTemplate

MatchStrategy = Literal["hybrid", "exact", "keywords", "regex", "examples"]
KeywordMode = Literal["any", "all"]
AmbiguityAction = Literal["llm_fallback", "clarify", "fallback", "deny", "route_best"]
RiskClassification = Literal["read_only", "write", "execute"]
ResponseMode = Literal["auto", "direct", "template", "internal_summary", "llm_summary", "detailed"]
OrchestrationMode = Literal["single", "sequential", "parallel", "dag"]
FailureAction = Literal["stop", "continue", "fallback"]
DecisionType = Literal[
    "route", "clarify", "confirm", "deny", "llm_fallback", "no_match", "unavailable"
]
IntentLifecycleState = Literal["draft", "shadow", "active"]
AssuranceSeverity = Literal["info", "warning", "blocker"]
AssuranceStatus = Literal["ready", "warning", "blocked"]


class IntentRegressionCase(BaseModel):
    """One synthetic request and its expected deterministic routing outcome."""

    name: str = Field(..., min_length=1, max_length=160)
    query: str = Field(..., min_length=1, max_length=20_000)
    source_agent: str = Field("concierge", min_length=1, max_length=128)
    parameters_json: dict[str, Any] = Field(default_factory=dict)
    confirmed: bool = False
    expected_decision: DecisionType = "route"
    expected_target_agent: str | None = Field(None, max_length=128)
    expected_parameters_json: dict[str, Any] = Field(default_factory=dict)


class IntentWorkflowStep(BaseModel):
    """One database-configured agent step in an intent workflow."""

    id: str = Field(..., min_length=1, max_length=128, pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$")
    agent: str = Field(..., min_length=1, max_length=128)
    tools: list[str] = Field(default_factory=list, max_length=100)
    connection_ref: str | None = Field(
        None,
        max_length=128,
        description=(
            "Exact Tool Registry name captured for a single-tool workflow step. "
            "The runtime exposes only this connection to the selected agent."
        ),
    )
    depends_on: list[str] = Field(default_factory=list, max_length=50)
    prompt_template: str | None = Field(None, max_length=20_000)
    action_template: str | None = Field(
        None,
        max_length=160,
        pattern=r"^[A-Za-z][A-Za-z0-9_.-]*(?:@[1-9][0-9]*)?$",
    )
    action_inputs: dict[str, Any] = Field(default_factory=dict)
    input_mapping: dict[str, Any] = Field(default_factory=dict)
    condition: dict[str, Any] = Field(default_factory=dict)
    required: bool = True
    timeout_sec: int = Field(120, ge=1, le=3_600)
    retry_count: int = Field(0, ge=0, le=10)
    on_failure: FailureAction = "stop"
    fallback_agent: str | None = Field(None, max_length=128)
    output_key: str | None = Field(None, max_length=128)

    @field_validator("tools", "depends_on")
    @classmethod
    def clean_step_lists(cls, value: list[str]) -> list[str]:
        return IntentRuleBase.clean_string_lists(value)

    @field_validator("connection_ref", mode="before")
    @classmethod
    def clean_connection_ref(cls, value: Any) -> str | None:
        if value is None:
            return None
        cleaned = str(value).strip()
        return cleaned or None

    @model_validator(mode="after")
    def validate_failure_configuration(self) -> "IntentWorkflowStep":
        if self.on_failure == "fallback" and not self.fallback_agent:
            raise ValueError("fallback_agent is required when on_failure is 'fallback'")
        if self.id in self.depends_on:
            raise ValueError(f"workflow step '{self.id}' cannot depend on itself")
        # A single registered tool is also the connection reference. Infer it
        # for older rules while persisting it explicitly for every new rule.
        if self.connection_ref is None and len(self.tools) == 1:
            self.connection_ref = self.tools[0]
        elif self.connection_ref is not None and not self.tools:
            self.tools = [self.connection_ref]
        if self.connection_ref is not None and self.tools != [self.connection_ref]:
            raise ValueError(
                f"workflow step '{self.id}' connection_ref must be its only allowed tool"
            )
        from backend.utils.intent_bindings import validate_binding

        validate_binding(self.action_inputs, self.depends_on)
        return self


class ResolvedWorkflowStep(IntentWorkflowStep):
    """Workflow step with an immutable action-template runtime snapshot."""

    resolved_action: ResolvedActionTemplate | None = None


class IntentExecutionOptions(BaseModel):
    """Portable limits applied by the workflow orchestrator."""

    max_parallel_steps: int = Field(4, ge=1, le=20)
    max_total_steps: int = Field(25, ge=1, le=100)
    max_agents: int = Field(10, ge=1, le=20)
    total_timeout_sec: int = Field(600, ge=1, le=7_200)
    continue_on_optional_failure: bool = True
    multi_intent_min_confidence: float = Field(0.75, ge=0.0, le=1.0)


class IntentRuleBase(BaseModel):
    """Fields shared by create and response schemas."""

    name: str = Field(
        ...,
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$",
        description="Stable intent identifier, for example incident.search",
    )
    display_name: str | None = Field(None, max_length=160)
    description: str | None = None
    enabled: bool = True
    shadow_mode: bool = False
    priority: int = Field(100, ge=0, le=100_000)
    match_strategy: MatchStrategy = "hybrid"
    keyword_mode: KeywordMode = "any"
    keywords_json: list[str] = Field(default_factory=list, max_length=100)
    negative_keywords_json: list[str] = Field(default_factory=list, max_length=100)
    regex_patterns_json: list[str] = Field(default_factory=list, max_length=25)
    examples_json: list[str] = Field(default_factory=list, max_length=100)
    min_confidence: float = Field(0.70, ge=0.0, le=1.0)
    ambiguity_margin: float = Field(0.10, ge=0.0, le=1.0)
    ambiguity_action: AmbiguityAction = "llm_fallback"
    target_agent: str = Field(..., min_length=1, max_length=128)
    fallback_agent: str | None = Field(None, max_length=128)
    allowed_source_agents_json: list[str] = Field(default_factory=list, max_length=100)
    allowed_tools_json: list[str] = Field(default_factory=list, max_length=100)
    orchestration_mode: OrchestrationMode = "single"
    workflow_json: list[IntentWorkflowStep] = Field(default_factory=list, max_length=100)
    allow_multi_intent: bool = False
    max_intents: int = Field(1, ge=1, le=10)
    aggregator_agent: str | None = Field(None, max_length=128)
    execution_options_json: IntentExecutionOptions = Field(default_factory=IntentExecutionOptions)
    workflow_version: int = Field(1, ge=1)
    parameter_config_json: dict[str, Any] = Field(default_factory=dict)
    risk_classification: RiskClassification = "read_only"
    requires_confirmation: bool = False
    response_mode: ResponseMode = "auto"
    response_template: str | None = None
    response_options_json: dict[str, Any] = Field(default_factory=dict)
    test_cases_json: list[IntentRegressionCase] = Field(default_factory=list, max_length=200)

    @field_validator(
        "keywords_json",
        "negative_keywords_json",
        "regex_patterns_json",
        "examples_json",
        "allowed_source_agents_json",
        "allowed_tools_json",
    )
    @classmethod
    def clean_string_lists(cls, value: list[str]) -> list[str]:
        """Trim, remove blank entries, and preserve first-occurrence order."""
        cleaned: list[str] = []
        seen: set[str] = set()
        for item in value:
            text = str(item).strip()
            marker = text.casefold()
            if text and marker not in seen:
                cleaned.append(text)
                seen.add(marker)
        return cleaned

    @model_validator(mode="after")
    def validate_match_configuration(self) -> "IntentRuleBase":
        if self.enabled and self.shadow_mode:
            raise ValueError("an intent cannot be active and in shadow mode at the same time")
        configured = {
            "exact": bool(self.examples_json or self.keywords_json),
            "keywords": bool(self.keywords_json),
            "regex": bool(self.regex_patterns_json),
            "examples": bool(self.examples_json),
            "hybrid": bool(self.keywords_json or self.regex_patterns_json or self.examples_json),
        }
        if not configured[self.match_strategy]:
            raise ValueError(
                f"match_strategy '{self.match_strategy}' requires matching values"
            )
        if self.ambiguity_action == "fallback" and not self.fallback_agent:
            raise ValueError("fallback_agent is required when ambiguity_action is 'fallback'")
        if self.response_mode == "template" and not (self.response_template or "").strip():
            raise ValueError("response_template is required when response_mode is 'template'")
        if self.orchestration_mode == "single" and len(self.workflow_json) > 1:
            raise ValueError("single orchestration mode accepts at most one workflow step")
        if not self.allow_multi_intent and self.max_intents != 1:
            raise ValueError("max_intents must be 1 when multi-intent resolution is disabled")
        self._validate_workflow_graph()
        return self

    def _validate_workflow_graph(self) -> None:
        if not self.workflow_json:
            return
        if len(self.workflow_json) > self.execution_options_json.max_total_steps:
            raise ValueError("workflow exceeds execution_options_json.max_total_steps")
        ids = [step.id for step in self.workflow_json]
        if len(set(ids)) != len(ids):
            raise ValueError("workflow step IDs must be unique")
        known = set(ids)
        for step in self.workflow_json:
            from backend.utils.intent_bindings import validate_binding

            validate_binding(step.action_inputs, step.depends_on, set(self.parameter_config_json.get("properties", {})))
            missing = [dependency for dependency in step.depends_on if dependency not in known]
            if missing:
                raise ValueError(
                    f"workflow step '{step.id}' has unknown dependencies: {', '.join(missing)}"
                )
        if len({step.agent for step in self.workflow_json}) > self.execution_options_json.max_agents:
            raise ValueError("workflow exceeds execution_options_json.max_agents")

        pending = {step.id: set(step.depends_on) for step in self.workflow_json}
        resolved: set[str] = set()
        while pending:
            ready = [step_id for step_id, deps in pending.items() if deps <= resolved]
            if not ready:
                raise ValueError("workflow dependencies contain a cycle")
            resolved.update(ready)
            for step_id in ready:
                del pending[step_id]


class IntentRuleCreate(IntentRuleBase):
    """Create an intent rule."""


class IntentRuleUpdate(BaseModel):
    """Update one or more fields on an intent rule."""

    name: str | None = Field(None, min_length=1, max_length=128, pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$")
    display_name: str | None = Field(None, max_length=160)
    description: str | None = None
    enabled: bool | None = None
    shadow_mode: bool | None = None
    priority: int | None = Field(None, ge=0, le=100_000)
    match_strategy: MatchStrategy | None = None
    keyword_mode: KeywordMode | None = None
    keywords_json: list[str] | None = Field(None, max_length=100)
    negative_keywords_json: list[str] | None = Field(None, max_length=100)
    regex_patterns_json: list[str] | None = Field(None, max_length=25)
    examples_json: list[str] | None = Field(None, max_length=100)
    min_confidence: float | None = Field(None, ge=0.0, le=1.0)
    ambiguity_margin: float | None = Field(None, ge=0.0, le=1.0)
    ambiguity_action: AmbiguityAction | None = None
    target_agent: str | None = Field(None, min_length=1, max_length=128)
    fallback_agent: str | None = Field(None, max_length=128)
    allowed_source_agents_json: list[str] | None = Field(None, max_length=100)
    allowed_tools_json: list[str] | None = Field(None, max_length=100)
    orchestration_mode: OrchestrationMode | None = None
    workflow_json: list[IntentWorkflowStep] | None = Field(None, max_length=100)
    allow_multi_intent: bool | None = None
    max_intents: int | None = Field(None, ge=1, le=10)
    aggregator_agent: str | None = Field(None, max_length=128)
    execution_options_json: IntentExecutionOptions | None = None
    workflow_version: int | None = Field(None, ge=1)
    parameter_config_json: dict[str, Any] | None = None
    risk_classification: RiskClassification | None = None
    requires_confirmation: bool | None = None
    response_mode: ResponseMode | None = None
    response_template: str | None = None
    response_options_json: dict[str, Any] | None = None
    test_cases_json: list[IntentRegressionCase] | None = Field(None, max_length=200)

    @field_validator(
        "keywords_json",
        "negative_keywords_json",
        "regex_patterns_json",
        "examples_json",
        "allowed_source_agents_json",
        "allowed_tools_json",
    )
    @classmethod
    def clean_optional_string_lists(cls, value: list[str] | None) -> list[str] | None:
        if value is None:
            return None
        return IntentRuleBase.clean_string_lists(value)


class IntentRuleResponse(IntentRuleBase):
    id: str
    created_by: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class IntentRuleListResponse(BaseModel):
    intents: list[IntentRuleResponse]
    count: int


class IntentAssuranceCheck(BaseModel):
    code: str
    severity: AssuranceSeverity
    message: str


class IntentRegressionResult(BaseModel):
    name: str
    passed: bool
    expected_decision: DecisionType
    actual_decision: DecisionType
    expected_target_agent: str | None = None
    actual_target_agent: str | None = None
    message: str
    confidence: float = 0.0


class IntentConflict(BaseModel):
    intent_id: str
    intent_name: str
    other_intent_id: str
    other_intent_name: str
    severity: AssuranceSeverity
    score: float
    reasons: list[str] = Field(default_factory=list)


class IntentReadinessReport(BaseModel):
    intent_id: str
    intent_name: str
    lifecycle_state: IntentLifecycleState
    status: AssuranceStatus
    ready_to_activate: bool
    checks: list[IntentAssuranceCheck] = Field(default_factory=list)
    regression_results: list[IntentRegressionResult] = Field(default_factory=list)
    conflicts: list[IntentConflict] = Field(default_factory=list)


class IntentAssuranceResponse(BaseModel):
    reports: list[IntentReadinessReport]
    conflicts: list[IntentConflict]
    count: int


class IntentShadowEvaluationResponse(BaseModel):
    id: str
    intent_id: str | None
    intent_name: str
    source_agent: str
    query_hash: str
    query_summary: str | None
    confidence: float
    matched_by_json: list[str]
    predicted_decision: str
    predicted_target_agent: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class IntentShadowEvaluationListResponse(BaseModel):
    evaluations: list[IntentShadowEvaluationResponse]
    count: int


class IntentCandidate(BaseModel):
    intent_id: str
    intent_name: str
    target_agent: str
    score: float
    priority: int
    matched_by: list[str] = Field(default_factory=list)


class ResolvedIntent(BaseModel):
    """One selected intent and its executable workflow snapshot."""

    intent_id: str
    intent_name: str
    confidence: float
    orchestration_mode: OrchestrationMode
    workflow_version: int
    workflow_steps: list[ResolvedWorkflowStep]
    aggregator_agent: str | None = None
    extracted_parameters: dict[str, Any] = Field(default_factory=dict)
    response_mode: ResponseMode = "auto"
    response_template: str | None = None
    response_options: dict[str, Any] = Field(default_factory=dict)
    execution_options: IntentExecutionOptions = Field(default_factory=IntentExecutionOptions)

    @field_validator("workflow_steps", mode="before")
    @classmethod
    def normalize_resolved_steps(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        return [
            item.model_dump() if isinstance(item, IntentWorkflowStep) else item
            for item in value
        ]


class IntentResolveRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=20_000)
    source_agent: str = Field("concierge", min_length=1, max_length=128)
    parameters: dict[str, Any] = Field(default_factory=dict)
    confirmed: bool = False


class IntentDecision(BaseModel):
    decision: DecisionType
    source_agent: str = "concierge"
    intent_id: str | None = None
    intent_name: str | None = None
    target_agent: str | None = None
    allowed_tools: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    reason: str
    extracted_parameters: dict[str, Any] = Field(default_factory=dict)
    missing_parameters: list[str] = Field(default_factory=list)
    clarification_prompt: str | None = None
    risk_classification: RiskClassification | None = None
    requires_confirmation: bool = False
    response_mode: ResponseMode | None = None
    response_template: str | None = None
    response_options: dict[str, Any] = Field(default_factory=dict)
    candidates: list[IntentCandidate] = Field(default_factory=list)
    selected_intents: list[ResolvedIntent] = Field(default_factory=list)
    orchestration_mode: str = "single"


class IntentImportRequest(BaseModel):
    data: str = Field(..., description="JSON document exported by Intent Control")
    replace_existing: bool = False


class IntentImportResponse(BaseModel):
    imported: int
    updated: int
    errors: list[str]


class IntentExportResponse(BaseModel):
    format: Literal["json"] = "json"
    data: str


class IntentExecutionStepResponse(BaseModel):
    id: str
    run_id: str
    intent_name: str
    step_id: str
    agent_name: str
    action_template_name: str | None
    action_template_version: int | None
    allowed_tools_json: list[str]
    used_tools_json: list[str]
    status: str
    attempts: int
    output_summary: str | None
    error: str | None
    started_at: datetime | None
    finished_at: datetime | None
    duration_ms: int | None

    model_config = {"from_attributes": True}


class IntentExecutionRunResponse(BaseModel):
    id: str
    session_id: str | None
    user_id: str | None
    source_agent: str | None
    query_hash: str
    query_summary: str | None
    intent_names_json: list[str]
    orchestration_mode: str
    workflow_versions_json: dict[str, int]
    status: str
    error: str | None
    response_summary: str | None
    started_at: datetime
    finished_at: datetime | None
    duration_ms: int | None
    steps: list[IntentExecutionStepResponse] = Field(default_factory=list)

    model_config = {"from_attributes": True}


class IntentExecutionRunListResponse(BaseModel):
    runs: list[IntentExecutionRunResponse]
    count: int
