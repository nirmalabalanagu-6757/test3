"""Schemas for reusable, versioned action-template administration."""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

ActionTemplateType = Literal[
    "sql",
    "rest",
    "graphql",
    "skywise",
    "ansible",
    "json",
    "csv",
    "mcp",
    "python",
]
ActionExecutionMode = Literal["agent", "direct"]
ActionTemplateStatus = Literal["draft", "active", "deprecated", "disabled"]
ActionRisk = Literal["read_only", "write", "execute"]


class ActionTemplatePolicy(BaseModel):
    """Portable governance limits enforced independently of an LLM."""

    risk_classification: ActionRisk = "read_only"
    requires_confirmation: bool = False
    allowed_agents: list[str] = Field(default_factory=list, max_length=100)
    allowed_resources: list[str] = Field(default_factory=list, max_length=200)
    max_rows: int = Field(1_000, ge=1, le=100_000)
    max_response_bytes: int = Field(2_000_000, ge=1_024, le=50_000_000)

    @field_validator("allowed_agents", "allowed_resources")
    @classmethod
    def clean_agents(cls, value: list[str]) -> list[str]:
        return list(dict.fromkeys(item.strip() for item in value if item.strip()))


class ActionTemplateExecutionOptions(BaseModel):
    """Generic rendering and invocation behavior."""

    text_argument: str | None = Field(None, max_length=128)
    include_unmapped_inputs: bool = False
    strict_tool_arguments: bool = True


class ActionTemplateBase(BaseModel):
    name: str = Field(
        ...,
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$",
    )
    version: int = Field(1, ge=1, le=1_000_000)
    display_name: str | None = Field(None, max_length=160)
    description: str | None = None
    template_type: ActionTemplateType
    tool_name: str = Field(..., min_length=1, max_length=128)
    execution_mode: ActionExecutionMode = "agent"
    template_text: str | None = Field(None, max_length=100_000)
    payload_template_json: dict[str, Any] | list[Any] | None = None
    input_schema_json: dict[str, Any] = Field(default_factory=dict)
    output_schema_json: dict[str, Any] = Field(default_factory=dict)
    policy_json: ActionTemplatePolicy = Field(default_factory=ActionTemplatePolicy)
    execution_options_json: ActionTemplateExecutionOptions = Field(
        default_factory=ActionTemplateExecutionOptions
    )
    lifecycle_status: ActionTemplateStatus = "draft"

    @model_validator(mode="after")
    def validate_contract(self) -> "ActionTemplateBase":
        schema_type = self.input_schema_json.get("type")
        if schema_type not in {None, "object"}:
            raise ValueError("input_schema_json must describe an object")
        if self.execution_mode == "direct" and isinstance(
            self.payload_template_json, list
        ):
            raise ValueError(
                "direct execution requires payload_template_json to be an object"
            )
        if (
            self.template_text
            and self.execution_mode == "direct"
            and not self.execution_options_json.text_argument
        ):
            raise ValueError(
                "execution_options_json.text_argument is required for direct text templates"
            )
        return self


class ActionTemplateCreate(ActionTemplateBase):
    """Create one immutable template version."""


class ActionTemplateUpdate(BaseModel):
    display_name: str | None = Field(None, max_length=160)
    description: str | None = None
    template_type: ActionTemplateType | None = None
    tool_name: str | None = Field(None, min_length=1, max_length=128)
    execution_mode: ActionExecutionMode | None = None
    template_text: str | None = Field(None, max_length=100_000)
    payload_template_json: dict[str, Any] | list[Any] | None = None
    input_schema_json: dict[str, Any] | None = None
    output_schema_json: dict[str, Any] | None = None
    policy_json: ActionTemplatePolicy | None = None
    execution_options_json: ActionTemplateExecutionOptions | None = None
    lifecycle_status: ActionTemplateStatus | None = None


class ActionTemplateResponse(ActionTemplateBase):
    id: str
    created_by: str | None
    updated_by: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ActionTemplateListResponse(BaseModel):
    action_templates: list[ActionTemplateResponse]
    count: int


class ActionTemplateCloneRequest(BaseModel):
    version: int | None = Field(None, ge=1, le=1_000_000)


class ActionTemplateRenderRequest(BaseModel):
    inputs: dict[str, Any] = Field(default_factory=dict)
    query: str = Field("", max_length=20_000)
    step_outputs: dict[str, Any] = Field(default_factory=dict)


class ResolvedActionTemplate(BaseModel):
    """Immutable runtime snapshot embedded in a resolved workflow."""

    id: str
    reference: str
    name: str
    version: int
    template_type: ActionTemplateType
    tool_name: str
    execution_mode: ActionExecutionMode
    template_text: str | None = None
    payload_template_json: dict[str, Any] | list[Any] | None = None
    input_schema_json: dict[str, Any] = Field(default_factory=dict)
    output_schema_json: dict[str, Any] = Field(default_factory=dict)
    policy: ActionTemplatePolicy = Field(default_factory=ActionTemplatePolicy)
    execution_options: ActionTemplateExecutionOptions = Field(
        default_factory=ActionTemplateExecutionOptions
    )
    checksum: str


class ActionTemplateRenderResponse(BaseModel):
    reference: str
    checksum: str
    validated_inputs: dict[str, Any]
    rendered_text: str | None
    rendered_payload: dict[str, Any] | list[Any] | None
    tool_arguments: dict[str, Any]
