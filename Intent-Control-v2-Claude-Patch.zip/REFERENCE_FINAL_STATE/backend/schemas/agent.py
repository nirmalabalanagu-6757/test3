"""Pydantic schemas for Agent Registry request/response validation."""

from datetime import datetime

from pydantic import BaseModel, Field


class AgentCreate(BaseModel):
    """Schema for registering a new database-driven agent."""

    name: str = Field(
        ...,
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z][A-Za-z0-9_]*$",
        description="Unique agent name. Use letters, numbers and underscores; start with a letter.",
    )
    display_name: str | None = Field(None, max_length=128, description="Human-friendly display name")
    description: str | None = Field(None, description="Agent description used by the concierge for routing")
    instruction: str | None = Field(None, description="System instruction for the agent")
    product: str = Field(..., min_length=1, max_length=64, description="Product area")
    agent_type: str = Field(..., description="Agent type: 'specialized' or 'concierge'")
    adk_agent_class: str | None = Field(None, max_length=256, description="Optional legacy ADK agent class path")
    model_config_json: str | None = Field(None, description="Model name or JSON model configuration")
    reasoning_config_json: dict | None = Field(None, description="Optional model-agnostic reasoning configuration")
    generate_content_config_json: dict | None = Field(None, description="Optional ADK generation configuration")
    allow_world_knowledge: bool = Field(False, description="Whether to allow general world knowledge")
    intent_control_enabled: bool = Field(
        True,
        description="Whether this agent may originate or receive deterministic intent routing",
    )
    tools: list[str] = Field(default_factory=list, description="Tools to assign atomically during registration")
    start_immediately: bool = Field(False, description="Move the agent to running after successful registration")


class AgentUpdate(BaseModel):
    """Schema for updating an existing agent (all fields optional)."""

    display_name: str | None = None
    description: str | None = None
    instruction: str | None = None
    product: str | None = Field(None, max_length=64)
    agent_type: str | None = None
    model_config_json: str | None = None
    reasoning_config_json: dict | None = None
    generate_content_config_json: dict | None = None
    allow_world_knowledge: bool | None = None
    intent_control_enabled: bool | None = None


class AgentResponse(BaseModel):
    """Schema for returning agent data."""

    name: str
    display_name: str | None
    description: str | None
    instruction: str | None
    product: str
    agent_type: str
    adk_agent_class: str | None
    model_config_json: str | None
    reasoning_config_json: dict | None = None
    generate_content_config_json: dict | None = None
    allow_world_knowledge: bool
    intent_control_enabled: bool
    reasoning_enabled: bool | None = None
    lifecycle_status: str
    last_health_check: datetime | None
    last_health_result: str | None
    last_used_at: datetime | None = None
    health_check_interval_sec: int
    consecutive_health_failures: int
    registered_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AgentListResponse(BaseModel):
    """Schema for returning a list of agents."""

    agents: list[AgentResponse]
    count: int
