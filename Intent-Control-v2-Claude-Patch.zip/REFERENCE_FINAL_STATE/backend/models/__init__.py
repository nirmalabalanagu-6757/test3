"""All SQLAlchemy ORM models for the AIOps Governance Platform.

Import this module to ensure every model is registered with the shared Base
before Alembic or engine.create_all() inspects metadata.
"""

from backend.models.action_template import ActionTemplate
from backend.models.agent import AgentDocumentation, AgentRegistry
from backend.models.alert import AlertRule
from backend.models.audit import AuditLog
from backend.models.backup import BackupRecord
from backend.models.config_model import Configuration, FeatureFlag, Migration
from backend.models.document import RagDocument, RagDocumentLatest
from backend.models.intent import (
    IntentExecutionRun,
    IntentExecutionStep,
    IntentLearningCandidate,
    IntentRule,
    IntentShadowEvaluation,
)
from backend.models.llm_model import LlmModelRegistry
from backend.models.notification import NotificationChannel, NotificationHistory, NotificationRule
from backend.models.policy import CommunicationPolicy
from backend.models.session import Session
from backend.models.token import TokenBudget, TokenUsage
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.models.user import User

__all__ = [
    "ActionTemplate",
    "AgentDocumentation",
    "AgentRegistry",
    "AlertRule",
    "AuditLog",
    "BackupRecord",
    "CommunicationPolicy",
    "Configuration",
    "FeatureFlag",
    "IntentExecutionRun",
    "IntentExecutionStep",
    "IntentLearningCandidate",
    "IntentRule",
    "IntentShadowEvaluation",
    "LlmModelRegistry",
    "Migration",
    "NotificationChannel",
    "NotificationHistory",
    "NotificationRule",
    "RagDocument",
    "RagDocumentLatest",
    "Session",
    "TokenBudget",
    "TokenUsage",
    "ToolAgentAssignment",
    "ToolRegistry",
    "User",
]
