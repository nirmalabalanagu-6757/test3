"""Database model for administrator-managed intent routing rules."""

import uuid
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class IntentRule(Base):
    """A dynamic intent rule evaluated before an entry agent invokes its LLM."""

    __tablename__ = "intent_rule"
    __table_args__ = (
        CheckConstraint(
            "NOT (enabled AND shadow_mode)",
            name="ck_intent_rule_single_lifecycle_state",
        ),
        Index("ix_intent_rule_enabled_priority", "enabled", "priority"),
        Index("ix_intent_rule_shadow_priority", "shadow_mode", "priority"),
        Index("ix_intent_rule_target_agent", "target_agent"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    display_name: Mapped[str | None] = mapped_column(String(160), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    # Shadow rules are evaluated and measured but can never route or execute.
    # ``enabled`` and ``shadow_mode`` are mutually exclusive at schema/API level.
    shadow_mode: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=100)

    # Matching configuration.
    match_strategy: Mapped[str] = mapped_column(
        String(20), nullable=False, default="hybrid"
    )  # hybrid | exact | keywords | regex | examples
    keyword_mode: Mapped[str] = mapped_column(String(10), nullable=False, default="any")  # any | all
    keywords_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    negative_keywords_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    regex_patterns_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    examples_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    min_confidence: Mapped[float] = mapped_column(Float, nullable=False, default=0.70)
    ambiguity_margin: Mapped[float] = mapped_column(Float, nullable=False, default=0.10)
    ambiguity_action: Mapped[str] = mapped_column(
        String(24), nullable=False, default="llm_fallback"
    )  # llm_fallback | clarify | fallback | deny | route_best

    # Routing and governance configuration. Names are validated by the service
    # instead of foreign keys so import/restore order stays flexible.
    target_agent: Mapped[str] = mapped_column(String(128), nullable=False)
    fallback_agent: Mapped[str | None] = mapped_column(String(128), nullable=True)
    # Empty means the safe default: Concierge and the target agent. Explicit
    # values restrict which entry agents may resolve and execute this intent.
    allowed_source_agents_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    allowed_tools_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    orchestration_mode: Mapped[str] = mapped_column(
        String(20), nullable=False, default="single"
    )  # single | sequential | parallel | dag
    workflow_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    allow_multi_intent: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    max_intents: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    aggregator_agent: Mapped[str | None] = mapped_column(String(128), nullable=True)
    execution_options_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    workflow_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    parameter_config_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    risk_classification: Mapped[str] = mapped_column(String(20), nullable=False, default="read_only")
    requires_confirmation: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # The response policy is metadata for the selected agent/tool execution
    # layer. Limits are deliberately optional and administrator-configured.
    response_mode: Mapped[str] = mapped_column(
        String(24), nullable=False, default="auto"
    )  # auto | direct | template | internal_summary | llm_summary | detailed
    response_template: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_options_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

    # Administrator-owned deterministic regression cases. They contain only
    # test prompts, expected routing metadata, and synthetic parameters.
    test_cases_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)

    created_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )


class IntentShadowEvaluation(Base):
    """A non-executing prediction made by a rule in shadow mode."""

    __tablename__ = "intent_shadow_evaluation"
    __table_args__ = (
        Index("ix_intent_shadow_evaluation_created", "created_at"),
        Index("ix_intent_shadow_evaluation_intent_created", "intent_id", "created_at"),
        Index("ix_intent_shadow_evaluation_source_created", "source_agent", "created_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    intent_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("intent_rule.id", ondelete="SET NULL"),
        nullable=True,
    )
    intent_name: Mapped[str] = mapped_column(String(128), nullable=False)
    source_agent: Mapped[str] = mapped_column(String(128), nullable=False)
    query_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    query_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    matched_by_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    predicted_decision: Mapped[str] = mapped_column(String(24), nullable=False)
    predicted_target_agent: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


class IntentLearningCandidate(Base):
    """An unmatched top-level request awaiting administrator review."""

    __tablename__ = "intent_learning_candidate"
    __table_args__ = (
        Index(
            "ix_intent_learning_candidate_status_last_seen",
            "status",
            "last_seen_at",
        ),
        Index(
            "ix_intent_learning_candidate_source_status",
            "source_agent",
            "status",
        ),
        Index("ix_intent_learning_candidate_fingerprint", "fingerprint"),
        Index(
            "uq_intent_learning_pending_fingerprint",
            "source_agent",
            "fingerprint",
            unique=True,
            postgresql_where=text("status = 'pending'"),
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")  # pending | approved | rejected
    source_agent: Mapped[str] = mapped_column(String(128), nullable=False)
    fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    normalized_pattern: Mapped[str] = mapped_column(Text, nullable=False)
    examples_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    observed_route_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    model_names_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    occurrence_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    proposal_confidence: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    proposed_execution_mode: Mapped[str] = mapped_column(
        String(24), nullable=False, default="agent_llm"
    )  # direct_action | agent_llm | multi_agent
    proposed_rule_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    observation_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    suggested_intent_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("intent_rule.id", ondelete="SET NULL"),
        nullable=True,
    )
    approved_intent_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("intent_rule.id", ondelete="SET NULL"),
        nullable=True,
    )
    reviewed_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    review_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )


class IntentExecutionRun(Base):
    """Metadata for one intent-controlled execution; business payloads are not stored."""

    __tablename__ = "intent_execution_run"
    __table_args__ = (
        Index("ix_intent_execution_run_session_started", "session_id", "started_at"),
        Index("ix_intent_execution_run_status_started", "status", "started_at"),
        Index("ix_intent_execution_run_source_started", "source_agent", "started_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    user_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    source_agent: Mapped[str | None] = mapped_column(String(128), nullable=True)
    query_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    query_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    intent_names_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    orchestration_mode: Mapped[str] = mapped_column(String(20), nullable=False)
    workflow_versions_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="running")
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)


class IntentExecutionStep(Base):
    """Auditable status for one agent step in an intent execution run."""

    __tablename__ = "intent_execution_step"
    __table_args__ = (
        Index("ix_intent_execution_step_run", "run_id", "started_at"),
        Index("ix_intent_execution_step_agent", "agent_name", "started_at"),
        Index(
            "ix_intent_execution_step_action_template",
            "action_template_name",
            "action_template_version",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    run_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("intent_execution_run.id", ondelete="CASCADE"),
        nullable=False,
    )
    intent_name: Mapped[str] = mapped_column(String(128), nullable=False)
    step_id: Mapped[str] = mapped_column(String(128), nullable=False)
    agent_name: Mapped[str] = mapped_column(String(128), nullable=False)
    action_template_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    action_template_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    allowed_tools_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    used_tools_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    output_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
