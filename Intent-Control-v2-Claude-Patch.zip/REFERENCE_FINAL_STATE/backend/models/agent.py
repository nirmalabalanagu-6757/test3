"""SQLAlchemy models for Agent Registry and Agent Documentation."""

from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class AgentRegistry(Base):
    __tablename__ = "agent_registry"
    __table_args__ = (
        Index("ix_agent_registry_routable", "lifecycle_status", "agent_type"),
        Index(
            "ix_agent_registry_intent_control",
            "intent_control_enabled",
            "lifecycle_status",
        ),
    )

    name: Mapped[str] = mapped_column(String(128), primary_key=True)
    display_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    instruction: Mapped[str | None] = mapped_column(Text, nullable=True)
    product: Mapped[str] = mapped_column(String(64), nullable=False)
    agent_type: Mapped[str] = mapped_column(String(20), nullable=False)  # specialized | concierge
    adk_agent_class: Mapped[str | None] = mapped_column(String(256), nullable=True)
    model_config_json: Mapped[str | None] = mapped_column("model_config", Text, nullable=True)
    reasoning_config_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    generate_content_config_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    allow_world_knowledge: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="0")
    intent_control_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default="1"
    )
    lifecycle_status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="registered"
    )  # registered | starting | running | degraded | stopped | deregistered
    last_health_check: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_health_result: Mapped[str | None] = mapped_column(String(256), nullable=True)
    health_check_interval_sec: Mapped[int] = mapped_column(Integer, nullable=False, default=60)
    consecutive_health_failures: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    registered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )


class AgentDocumentation(Base):
    __tablename__ = "agent_documentation"

    agent_name: Mapped[str] = mapped_column(
        String(128),
        primary_key=True,
    )
    content: Mapped[str | None] = mapped_column(Text, nullable=True)
    needs_review: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    last_author: Mapped[str | None] = mapped_column(String(128), nullable=True)
    last_updated: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
