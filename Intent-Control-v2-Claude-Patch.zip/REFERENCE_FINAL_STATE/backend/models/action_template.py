"""Versioned, reusable action templates for deterministic tool execution."""

import uuid
from datetime import datetime

from sqlalchemy import JSON, DateTime, Index, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class ActionTemplate(Base):
    """A credential-free contract that maps validated inputs to one tool call."""

    __tablename__ = "action_template"
    __table_args__ = (
        UniqueConstraint("name", "version", name="uq_action_template_name_version"),
        Index("ix_action_template_status_type", "lifecycle_status", "template_type"),
        Index("ix_action_template_tool", "tool_name"),
    )

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    display_name: Mapped[str | None] = mapped_column(String(160), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    template_type: Mapped[str] = mapped_column(String(24), nullable=False)
    tool_name: Mapped[str] = mapped_column(String(128), nullable=False)
    execution_mode: Mapped[str] = mapped_column(
        String(16), nullable=False, default="agent"
    )  # agent | direct
    template_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    payload_template_json: Mapped[dict | list | None] = mapped_column(JSON, nullable=True)
    input_schema_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    output_schema_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    policy_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    execution_options_json: Mapped[dict] = mapped_column(
        JSON, nullable=False, default=dict
    )
    lifecycle_status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="draft"
    )  # draft | active | deprecated | disabled
    created_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    updated_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )
