"""Explicit, validated references used by learned action inputs."""

import json
import re
from typing import Any


def validate_binding(value: Any, dependencies: list[str], parameters: set[str] | None = None) -> None:
    if isinstance(value, dict):
        if "$from_step" in value:
            binding = value["$from_step"]
            if (
                set(value) != {"$from_step"}
                or not isinstance(binding, dict)
                or set(binding) != {"step", "path"}
                or not isinstance(binding["step"], str)
                or binding["step"] not in dependencies
            ):
                raise ValueError("$from_step must reference a declared workflow dependency")
            path = binding["path"]
            if (
                not isinstance(path, str)
                or len(path) > 1000
                or (path and not path.startswith("/"))
                or re.search(r"~(?![01])", path)
            ):
                raise ValueError("$from_step path must be a valid JSON pointer")
        elif "$parameter" in value:
            name = value["$parameter"]
            if (
                set(value) - {"$parameter", "optional"}
                or not isinstance(name, str)
                or not name
                or ("optional" in value and not isinstance(value["optional"], bool))
            ):
                raise ValueError("Invalid $parameter binding")
            if parameters is not None and name not in parameters:
                raise ValueError(f"Action input references undeclared parameter '{name}'")
        else:
            for child in value.values():
                validate_binding(child, dependencies, parameters)
    elif isinstance(value, list):
        for child in value:
            validate_binding(child, dependencies, parameters)


def step_value(outputs: dict[str, Any], binding: dict[str, str]) -> Any:
    name, path = binding["step"], binding["path"]
    if name not in outputs:
        raise ValueError(f"Required step output '{name}' is unavailable")
    current = outputs[name]
    if isinstance(current, str):
        try:
            current = json.loads(current)
        except (ValueError, TypeError):
            if path:
                raise ValueError(f"Step '{name}' did not return structured JSON") from None
    for segment in path.split("/")[1:] if path else []:
        key = segment.replace("~1", "/").replace("~0", "~")
        if isinstance(current, dict) and key in current:
            current = current[key]
        elif isinstance(current, list) and re.fullmatch(r"0|[1-9][0-9]*", key) and int(key) < len(current):
            current = current[int(key)]
        else:
            raise ValueError(f"Required result field '{path}' is missing from step '{name}'")
    return current
