"""Chat service — routes WebSocket messages to agents via ADK Runner.

Validates: Requirements 7.1, 7.2, 7.3, 7.6

Responsibilities:
  - Validate that the target agent exists and is running.
  - Get or create a session for multi-turn conversation state.
  - Forward the user message to the agent's ADK Runner (stubbed).
  - Stream the response back to the caller.
  - Return alternatives when the target agent is unavailable.
"""

import logging
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import AgentRegistry
from backend.schemas.chat import (
    AgentUnavailableResponse,
    ChatError,
    ChatMessage,
    ChatResponse,
)
from backend.services.agent_registry import AgentNotFoundError, AgentRegistryService
from backend.services.audit_log import AuditLogService
from backend.services.session_manager import SessionManagerService
from backend.services.token_manager import TokenManagerService

logger = logging.getLogger(__name__)


class ChatService:
    """Handles WebSocket chat message routing and session integration."""

    def __init__(
        self,
        registry: AgentRegistryService | None = None,
        session_manager: SessionManagerService | None = None,
        audit_log: AuditLogService | None = None,
    ) -> None:
        self._registry = registry or AgentRegistryService()
        self._session_mgr = session_manager or SessionManagerService()
        self._audit = audit_log or AuditLogService()
        self._token_mgr = TokenManagerService()

    # ------------------------------------------------------------------
    # Agent availability
    # ------------------------------------------------------------------

    async def check_agent_available(
        self,
        db: AsyncSession,
        agent_name: str,
    ) -> AgentRegistry:
        """Return the agent record if it exists.

        Raises:
            AgentNotFoundError: If the agent does not exist.
        """
        return await self._registry.get(db, agent_name)

    async def get_running_alternatives(
        self,
        db: AsyncSession,
        agent_name: str,
        product: str | None = None,
    ) -> list[str]:
        """Return names of running agents in the same product area (excluding *agent_name*)."""
        stmt = select(AgentRegistry).where(
            AgentRegistry.lifecycle_status == "running",
            AgentRegistry.name != agent_name,
        )
        if product:
            stmt = stmt.where(AgentRegistry.product == product)

        result = await db.execute(stmt)
        return [a.name for a in result.scalars().all()]

    async def build_unavailable_response(
        self,
        db: AsyncSession,
        agent: AgentRegistry,
    ) -> AgentUnavailableResponse:
        """Build an unavailability message with alternative agents."""
        alternatives = await self.get_running_alternatives(db, agent.name, product=agent.product)
        return AgentUnavailableResponse(
            agent_name=agent.name,
            lifecycle_status=agent.lifecycle_status,
            message=(f"Agent '{agent.name}' is currently {agent.lifecycle_status} and cannot process messages."),
            alternatives=alternatives,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    async def get_or_create_session(
        self,
        db: AsyncSession,
        agent_name: str,
        user_id: str,
        session_id: str | None = None,
    ) -> tuple[str, int]:
        """Return (session_id, turn_index) for the conversation.

        If *session_id* is provided, looks up the existing session and
        increments its turn counter stored in state. Otherwise creates a
        new session.
        """
        if session_id:
            sess = await self._session_mgr.get_session(db, session_id)
            await self._session_mgr.update_activity(db, session_id)

            # Maintain a turn counter in session state
            turn = await self._session_mgr.get_state(db, session_id, "turn_index")
            turn_index = (turn or 0) + 1
            await self._session_mgr.set_state(db, session_id, "turn_index", turn_index)

            return sess.session_id, turn_index

        # Create new session
        sess = await self._session_mgr.create_session(db, user_id=user_id, agent_name=agent_name)
        await self._session_mgr.set_state(db, sess.session_id, "turn_index", 1)
        return sess.session_id, 1

    # ------------------------------------------------------------------
    # Agent invocation (real ADK Runner / Gemini integration)
    # ------------------------------------------------------------------

    async def invoke_agent(
        self,
        db: AsyncSession,
        agent_name: str,
        session_id: str,
        user_message: str,
        user_id: str = "anonymous",
    ) -> tuple[str, dict[str, list[str]], str | None]:
        """Forward a message to the agent via ADK Runner or direct Gemini call.

        Returns (response_text, agent_tools, model_name).
        """
        import time

        from backend.services.agent_runner import agent_runner
        from backend.services.metrics_collector import metrics_collector

        await self._session_mgr.clear_temp_state(db, session_id)
        await self._session_mgr.set_state(db, session_id, "temp:last_user_message", user_message)

        t0 = time.monotonic()
        status = "ok"
        agent_tools: dict[str, list[str]] = {}
        model_name: str | None = None
        try:
            response_text, agent_tools, model_name = await agent_runner.invoke_with_runner(
                agent_name=agent_name,
                session_id=session_id,
                user_id=user_id,
                user_message=user_message,
            )
        except Exception:
            status = "error"
            raise
        finally:
            elapsed_ms = (time.monotonic() - t0) * 1000
            metrics_collector.record_request(
                agent_name=agent_name,
                response_time_ms=elapsed_ms,
                prompt_tokens=0,
                completion_tokens=0,
                status=status,
                session_id=session_id,
                user_id=user_id,
            )

        await self._session_mgr.set_state(db, session_id, "temp:last_agent_response", response_text)

        return response_text, agent_tools, model_name

    # ------------------------------------------------------------------
    # Full message handling flow
    # ------------------------------------------------------------------

    async def handle_message(
        self,
        db: AsyncSession,
        agent_name: str,
        message: ChatMessage,
    ) -> ChatResponse | AgentUnavailableResponse | ChatError:
        """Process a single chat message end-to-end.

        Flow:
          1. Validate agent exists and is running.
          2. Get or create session.
          3. Invoke agent (stub).
          4. Build and return the response.

        Returns one of:
          - ChatResponse on success.
          - AgentUnavailableResponse if the agent is not running.
          - ChatError on unexpected failures.
        """
        # 1. Check agent exists
        try:
            agent = await self.check_agent_available(db, agent_name)
        except AgentNotFoundError:
            return ChatError(
                error_code="AGENT_NOT_FOUND",
                message=f"Agent '{agent_name}' does not exist.",
                timestamp=datetime.now(timezone.utc).isoformat(),
            )

        # 2. Check agent is running
        if agent.lifecycle_status != "running":
            return await self.build_unavailable_response(db, agent)

        # 3. Get or create session
        try:
            session_id, turn_index = await self.get_or_create_session(
                db,
                agent_name=agent_name,
                user_id=message.user_id,
                session_id=message.session_id,
            )
        except Exception as exc:
            return ChatError(
                error_code="SESSION_ERROR",
                message=f"Failed to manage session: {exc}",
                timestamp=datetime.now(timezone.utc).isoformat(),
            )

        # 4. Invoke the agent
        from backend.services.intent_trace import capture_tool_calls

        try:
            with capture_tool_calls() as tool_trace:
                response_text, agent_tools, model_name = await self.invoke_agent(
                    db, agent_name, session_id, message.content, user_id=message.user_id
                )
        except Exception as exc:
            return ChatError(
                error_code="AGENT_INVOCATION_ERROR",
                message=f"Agent invocation failed: {exc}",
                timestamp=datetime.now(timezone.utc).isoformat(),
            )

        # 5. Capture unmatched top-level requests for approval-gated learning.
        # Matched intent executions carry an ``intent_control`` marker and are
        # ignored by the learning service, preventing duplicate candidates.
        try:
            from backend.services.intent_learning import IntentLearningService

            await IntentLearningService().observe(
                db,
                source_agent=agent_name,
                query=message.content,
                contributing_agents=agent_tools,
                model_name=model_name,
                tool_trace=tool_trace,
            )
        except Exception:
            # Learning is auxiliary and must never make chat unavailable.
            logger.exception(
                "Intent learning capture failed for entry agent '%s'",
                agent_name,
            )

        # 6. Increment model usage counter
        if model_name:
            try:
                from sqlalchemy import text

                await db.execute(
                    text("UPDATE llm_model_registry SET invocation_count = invocation_count + 1 WHERE name = :name"),
                    {"name": model_name},
                )
            except Exception:
                pass

        # 7. Query context window usage for this session
        context_used_tokens: int | None = None
        context_window_tokens: int | None = None
        try:
            prompt_tokens, _ = await self._token_mgr.get_session_latest_usage(db, session_id)
            if prompt_tokens > 0:
                context_used_tokens = prompt_tokens
                from backend.startup_config.model_definitions import get_model_context_window

                context_window_tokens = get_model_context_window(model_name or "")
        except Exception:
            pass

        # 8. Build model settings from DB columns (no file I/O)
        model_settings: dict[str, Any] | None = None
        settings: dict[str, Any] = {}
        gcc = agent.generate_content_config_json
        if gcc:
            for key in ("temperature", "max_output_tokens"):
                if key in gcc:
                    settings[key] = gcc[key]
        if agent.reasoning_config_json:
            settings["reasoning"] = agent.reasoning_config_json
        settings["allow_world_knowledge"] = bool(agent.allow_world_knowledge)
        if settings:
            model_settings = settings

        # 9. Update last_used_at timestamp
        try:
            agent.last_used_at = datetime.now(timezone.utc)
            await db.flush()
        except Exception:
            pass

        # 10. Audit the interaction (include model)
        await self._audit.append(
            db,
            event_type="interaction",
            agent_name=agent_name,
            session_id=session_id,
            user_id=message.user_id,
            request_summary=message.content[:256],
            response_summary=response_text[:256],
            details={
                "action": "chat_message",
                "turn_index": turn_index,
                "model": model_name,
            },
        )

        return ChatResponse(
            agent_name=agent_name,
            session_id=session_id,
            content=response_text,
            turn_index=turn_index,
            timestamp=datetime.now(timezone.utc).isoformat(),
            contributing_agents=agent_tools,
            model_name=model_name,
            model_settings=model_settings,
            context_used_tokens=context_used_tokens,
            context_window_tokens=context_window_tokens,
        )
