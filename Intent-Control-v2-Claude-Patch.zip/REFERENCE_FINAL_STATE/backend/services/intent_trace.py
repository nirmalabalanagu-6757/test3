"""Request-local tool observations. Business arguments/results never leave this scope.

Only the compiler's structural evidence is persisted on learning candidates.
ADK event IDs correlate calls and responses; repeated tool names remain distinct.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ObservedToolCall:
    id: str
    agent: str
    tool: str
    arguments: dict[str, Any]
    predecessors: list[str] = field(default_factory=list)
    status: str = "pending"
    output: Any = None
    event_id: str | None = None


class ToolCallTrace:
    MAX_CALLS = 100
    MAX_VALUE_BYTES = 256_000
    MAX_TOTAL_BYTES = 2_000_000

    def __init__(self) -> None:
        self.calls: list[ObservedToolCall] = []
        self.incomplete = False
        self._bytes = 0

    def _copy(self, value: Any) -> Any:
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
        size = len(encoded.encode("utf-8"))
        if size > self.MAX_VALUE_BYTES or self._bytes + size > self.MAX_TOTAL_BYTES:
            raise ValueError("Observation limit reached")
        self._bytes += size
        return json.loads(encoded)

    def call(self, agent: str, tool: str, arguments: Any, event_id: str | None = None) -> None:
        if len(self.calls) >= self.MAX_CALLS:
            self.incomplete = True
            return
        if event_id and any(item.event_id == event_id for item in self.calls):
            return
        try:
            copied = self._copy(arguments)
            if not isinstance(copied, dict):
                raise TypeError("Arguments must be an object")
        except (TypeError, ValueError, RecursionError):
            self.incomplete = True
            return
        self.calls.append(
            ObservedToolCall(
                id=f"call_{len(self.calls) + 1}",
                agent=agent,
                tool=tool,
                arguments=copied,
                event_id=event_id,
                predecessors=[item.id for item in self.calls if item.status == "completed"],
            )
        )

    def response(self, agent: str, tool: str, output: Any, event_id: str | None = None) -> None:
        matches = [
            item
            for item in self.calls
            if item.status == "pending"
            and item.tool == tool
            and (item.event_id == event_id if event_id else item.agent == agent)
        ]
        # Without IDs, concurrent same-name calls cannot be paired reliably.
        if len(matches) != 1:
            if not event_id or not any(item.event_id == event_id and item.status != "pending" for item in self.calls):
                self.incomplete = True
            return
        call = matches[0]
        try:
            call.output = self._copy(output)
        except (TypeError, ValueError, RecursionError):
            self.incomplete = True
            call.status = "unavailable"
            return
        failed = isinstance(output, dict) and (
            bool(output.get("error"))
            or output.get("success") is False
            or output.get("blocked") is True
            or output.get("isError") is True
            or str(output.get("status", "")).casefold() in {"error", "failed", "denied"}
            or (isinstance(output.get("status_code"), int) and output["status_code"] >= 400)
        )
        if isinstance(output, str):
            failed = bool(re.match(r"(?i)\s*(?:HTTP\s+[45]\d\d\b|error\b|failed\b|permission denied\b)", output))
        call.status = "failed" if failed else "completed"


_active_trace: ContextVar[ToolCallTrace | None] = ContextVar("intent_tool_trace", default=None)


def invalidate_tool_trace() -> None:
    trace = _active_trace.get()
    if trace is not None:
        trace.incomplete = True


@contextmanager
def capture_tool_calls() -> Iterator[ToolCallTrace]:
    trace = ToolCallTrace()
    token = _active_trace.set(trace)
    try:
        yield trace
    finally:
        _active_trace.reset(token)


def record_tool_event(agent: str, part: Any) -> None:
    trace = _active_trace.get()
    if trace is None:
        return
    call = getattr(part, "function_call", None)
    response = getattr(part, "function_response", None)
    if call and getattr(call, "name", None):
        trace.call(agent, call.name, getattr(call, "args", {}) or {}, getattr(call, "id", None))
    if response and getattr(response, "name", None):
        trace.response(agent, response.name, getattr(response, "response", None), getattr(response, "id", None))


def record_tool_callback(
    *, context: Any, tool: Any, arguments: Any, response: Any = None, finished: bool = False
) -> None:
    trace = _active_trace.get()
    event_id = getattr(context, "function_call_id", None)
    if trace is None or not event_id:
        return
    agent, name = getattr(context, "agent_name", "unknown"), getattr(tool, "name", "")
    if finished:
        trace.response(agent, name, response, event_id)
    else:
        trace.call(agent, name, arguments or {}, event_id)
