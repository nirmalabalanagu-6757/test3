"""Administration, validation, and safe rendering for action templates."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.action_template import ActionTemplate
from backend.models.intent import IntentRule
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.schemas.action_template import (
    ActionTemplateCreate,
    ActionTemplateExecutionOptions,
    ActionTemplatePolicy,
    ActionTemplateRenderResponse,
    ActionTemplateUpdate,
    ResolvedActionTemplate,
)
from backend.services.audit_log import AuditLogService

_REFERENCE_RE = re.compile(r"^(?P<name>[A-Za-z][A-Za-z0-9_.-]*)(?:@(?P<version>\d+))?$")
_PLACEHOLDER_RE = re.compile(r"{{\s*([A-Za-z][A-Za-z0-9_.-]*)\s*}}")
_SQL_MUTATION_RE = re.compile(
    r"\b(insert|update|delete|drop|alter|truncate|grant|revoke|merge|call|execute|copy)\b",
    flags=re.IGNORECASE,
)
_SQL_RESOURCE_RE = re.compile(
    r"\b(?:from|join)\s+([A-Za-z0-9_.\-`\"]+)", flags=re.IGNORECASE
)
_EXECUTION_FIELDS = {
    "template_type",
    "tool_name",
    "execution_mode",
    "template_text",
    "payload_template_json",
    "input_schema_json",
    "output_schema_json",
    "policy_json",
    "execution_options_json",
}


class ActionTemplateNotFoundError(Exception):
    pass


class ActionTemplateExistsError(Exception):
    pass


class ActionTemplateConfigurationError(Exception):
    pass


class ActionTemplateInUseError(Exception):
    pass


class ActionTemplateService:
    """Manage immutable versions and render deterministic tool arguments."""

    def __init__(self, audit_log: AuditLogService | None = None) -> None:
        self._audit = audit_log or AuditLogService()

    async def list_templates(
        self,
        session: AsyncSession,
        *,
        lifecycle_status: str | None = None,
        template_type: str | None = None,
        tool_name: str | None = None,
    ) -> list[ActionTemplate]:
        stmt = select(ActionTemplate)
        if lifecycle_status:
            stmt = stmt.where(ActionTemplate.lifecycle_status == lifecycle_status)
        if template_type:
            stmt = stmt.where(ActionTemplate.template_type == template_type)
        if tool_name:
            stmt = stmt.where(ActionTemplate.tool_name == tool_name)
        stmt = stmt.order_by(ActionTemplate.name, ActionTemplate.version.desc())
        return list((await session.execute(stmt)).scalars().all())

    async def get_template(
        self, session: AsyncSession, template_id: str
    ) -> ActionTemplate:
        template = await session.get(ActionTemplate, template_id)
        if template is None:
            raise ActionTemplateNotFoundError(
                f"Action template '{template_id}' was not found"
            )
        return template

    async def create_template(
        self,
        session: AsyncSession,
        data: ActionTemplateCreate,
        *,
        created_by: str | None = None,
    ) -> ActionTemplate:
        await self._ensure_reference_available(session, data.name, data.version)
        await self._validate_configuration(session, data)
        template = ActionTemplate(
            **data.model_dump(mode="json"),
            created_by=created_by,
            updated_by=created_by,
        )
        session.add(template)
        await session.flush()
        await self._audit_change(session, "action_template_created", template, created_by)
        return template

    async def update_template(
        self,
        session: AsyncSession,
        template_id: str,
        data: ActionTemplateUpdate,
        *,
        updated_by: str | None = None,
    ) -> ActionTemplate:
        template = await self.get_template(session, template_id)
        updates = data.model_dump(exclude_unset=True, mode="json")
        if (
            template.lifecycle_status in {"active", "deprecated", "disabled"}
            and _EXECUTION_FIELDS & updates.keys()
        ):
            raise ActionTemplateConfigurationError(
                "Published template versions are immutable; clone a new version"
            )
        if (
            template.lifecycle_status != "draft"
            and updates.get("lifecycle_status") == "draft"
        ):
            raise ActionTemplateConfigurationError(
                "A published template version cannot return to draft; clone a new version"
            )

        merged = {
            field: updates.get(field, getattr(template, field))
            for field in ActionTemplateCreate.model_fields
        }
        validated = ActionTemplateCreate.model_validate(merged)
        await self._validate_configuration(session, validated)

        changes: dict[str, dict[str, Any]] = {}
        for field, value in validated.model_dump(mode="json").items():
            old = getattr(template, field)
            if old != value:
                changes[field] = {"old": old, "new": value}
                setattr(template, field, value)
        template.updated_by = updated_by
        await session.flush()
        await session.refresh(template)
        await self._audit_change(
            session,
            "action_template_updated",
            template,
            updated_by,
            changes=changes,
        )
        return template

    async def clone_template(
        self,
        session: AsyncSession,
        template_id: str,
        *,
        version: int | None = None,
        created_by: str | None = None,
    ) -> ActionTemplate:
        source = await self.get_template(session, template_id)
        if version is None:
            latest = await session.scalar(
                select(func.max(ActionTemplate.version)).where(
                    ActionTemplate.name == source.name
                )
            )
            version = int(latest or 0) + 1
        data = ActionTemplateCreate(
            **{
                field: getattr(source, field)
                for field in ActionTemplateCreate.model_fields
                if field not in {"version", "lifecycle_status"}
            },
            version=version,
            lifecycle_status="draft",
        )
        return await self.create_template(session, data, created_by=created_by)

    async def delete_template(
        self,
        session: AsyncSession,
        template_id: str,
        *,
        deleted_by: str | None = None,
    ) -> ActionTemplate:
        template = await self.get_template(session, template_id)
        if template.lifecycle_status != "draft":
            raise ActionTemplateInUseError(
                "Only draft action-template versions can be deleted; disable or deprecate published versions"
            )
        reference = f"{template.name}@{template.version}"
        rules = list((await session.execute(select(IntentRule))).scalars().all())
        users = [
            rule.name
            for rule in rules
            if any(
                isinstance(step, dict)
                and step.get("action_template") in {reference, template.name}
                for step in (rule.workflow_json or [])
            )
        ]
        if users:
            raise ActionTemplateInUseError(
                f"Action template '{reference}' is referenced by intents: {', '.join(users)}"
            )
        await self._audit_change(session, "action_template_deleted", template, deleted_by)
        await session.delete(template)
        await session.flush()
        return template

    async def resolve_reference(
        self,
        session: AsyncSession,
        reference: str,
        *,
        require_usable: bool = True,
    ) -> ResolvedActionTemplate:
        match = _REFERENCE_RE.fullmatch(reference.strip())
        if not match:
            raise ActionTemplateConfigurationError(
                "Action-template references must use 'name' or 'name@version'"
            )
        name = match.group("name")
        version_text = match.group("version")
        stmt = select(ActionTemplate).where(ActionTemplate.name == name)
        if version_text:
            stmt = stmt.where(ActionTemplate.version == int(version_text))
        else:
            stmt = stmt.where(ActionTemplate.lifecycle_status == "active").order_by(
                ActionTemplate.version.desc()
            )
        template = (await session.execute(stmt.limit(1))).scalar_one_or_none()
        if template is None:
            raise ActionTemplateNotFoundError(
                f"Action template reference '{reference}' was not found"
            )
        if require_usable and template.lifecycle_status not in {"active", "deprecated"}:
            raise ActionTemplateConfigurationError(
                f"Action template '{template.name}@{template.version}' is {template.lifecycle_status}"
            )
        return self.snapshot(template)

    async def validate_for_agent(
        self,
        session: AsyncSession,
        snapshot: ResolvedActionTemplate,
        agent_name: str,
    ) -> None:
        allowed_agents = snapshot.policy.allowed_agents
        if allowed_agents and agent_name not in allowed_agents:
            raise ActionTemplateConfigurationError(
                f"Action template '{snapshot.reference}' is not allowed for agent '{agent_name}'"
            )
        tool = await session.get(ToolRegistry, snapshot.tool_name)
        if tool is None:
            raise ActionTemplateConfigurationError(
                f"Action template tool '{snapshot.tool_name}' does not exist"
            )
        if tool.lifecycle_status != "active":
            raise ActionTemplateConfigurationError(
                f"Action template tool '{snapshot.tool_name}' is not active"
            )
        aliases = {agent_name, agent_name.replace("-", "_")}
        if not agent_name.endswith("_agent"):
            aliases.add(f"{agent_name}_agent")
        assignment = await session.scalar(
            select(ToolAgentAssignment.tool_name).where(
                ToolAgentAssignment.tool_name == snapshot.tool_name,
                ToolAgentAssignment.agent_name.in_(aliases),
            )
        )
        if assignment is None:
            raise ActionTemplateConfigurationError(
                f"Tool '{snapshot.tool_name}' is not assigned to agent '{agent_name}'"
            )

    @classmethod
    def snapshot(cls, template: ActionTemplate) -> ResolvedActionTemplate:
        data = {
            "id": template.id,
            "reference": f"{template.name}@{template.version}",
            "name": template.name,
            "version": template.version,
            "template_type": template.template_type,
            "tool_name": template.tool_name,
            "execution_mode": template.execution_mode,
            "template_text": template.template_text,
            "payload_template_json": template.payload_template_json,
            "input_schema_json": template.input_schema_json or {},
            "output_schema_json": template.output_schema_json or {},
            "policy": ActionTemplatePolicy.model_validate(template.policy_json or {}),
            "execution_options": ActionTemplateExecutionOptions.model_validate(
                template.execution_options_json or {}
            ),
        }
        checksum = hashlib.sha256(
            json.dumps(data, sort_keys=True, default=str, separators=(",", ":")).encode()
        ).hexdigest()
        return ResolvedActionTemplate(**data, checksum=checksum)

    @classmethod
    def render_snapshot(
        cls,
        snapshot: ResolvedActionTemplate,
        *,
        inputs: dict[str, Any],
        query: str = "",
        step_outputs: dict[str, Any] | None = None,
    ) -> ActionTemplateRenderResponse:
        validated = cls._apply_defaults(dict(inputs), snapshot.input_schema_json)
        cls._validate_input_schema(validated, snapshot.input_schema_json)
        context: dict[str, Any] = {
            **validated,
            "inputs": validated,
            "query": query,
            "steps": step_outputs or {},
        }
        rendered_text = (
            cls._render_value(snapshot.template_text, context)
            if snapshot.template_text is not None
            else None
        )
        rendered_payload = cls._render_value(snapshot.payload_template_json, context)

        arguments: dict[str, Any] = {}
        if snapshot.execution_options.include_unmapped_inputs:
            arguments.update(validated)
        if rendered_payload is not None:
            if not isinstance(rendered_payload, dict):
                if snapshot.execution_mode == "direct":
                    raise ActionTemplateConfigurationError(
                        "Direct action-template payload must render to an object"
                    )
            else:
                arguments.update(rendered_payload)
        if rendered_text is not None:
            argument = snapshot.execution_options.text_argument
            if not argument:
                raise ActionTemplateConfigurationError(
                    "A rendered text template requires execution_options_json.text_argument"
                )
            arguments[argument] = rendered_text

        if snapshot.template_type == "sql" and rendered_text:
            cls._validate_sql(rendered_text, snapshot.policy)

        return ActionTemplateRenderResponse(
            reference=snapshot.reference,
            checksum=snapshot.checksum,
            validated_inputs=validated,
            rendered_text=rendered_text,
            rendered_payload=rendered_payload,
            tool_arguments=arguments,
        )

    @classmethod
    def validate_output(cls, value: Any, schema: dict[str, Any]) -> None:
        """Validate the useful top-level JSON Schema subset used by tool contracts."""
        if not schema:
            return
        expected = schema.get("type")
        type_map = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        if expected in type_map and not isinstance(value, type_map[expected]):
            raise ActionTemplateConfigurationError(
                f"Action output must be {expected}"
            )
        if expected in {"integer", "number"} and isinstance(value, bool):
            raise ActionTemplateConfigurationError(
                f"Action output must be {expected}"
            )
        if isinstance(value, dict):
            cls._validate_input_schema(value, schema)
        if isinstance(value, list) and isinstance(schema.get("items"), dict):
            for index, item in enumerate(value):
                item_schema = schema["items"]
                item_type = item_schema.get("type")
                if item_type in type_map and not isinstance(item, type_map[item_type]):
                    raise ActionTemplateConfigurationError(
                        f"Action output item {index} must be {item_type}"
                    )

    async def _ensure_reference_available(
        self, session: AsyncSession, name: str, version: int
    ) -> None:
        existing = await session.scalar(
            select(ActionTemplate.id).where(
                ActionTemplate.name == name,
                ActionTemplate.version == version,
            )
        )
        if existing is not None:
            raise ActionTemplateExistsError(
                f"Action template '{name}@{version}' already exists"
            )

    async def _validate_configuration(
        self, session: AsyncSession, data: ActionTemplateCreate
    ) -> None:
        tool = await session.get(ToolRegistry, data.tool_name)
        if tool is None:
            raise ActionTemplateConfigurationError(
                f"Registered tool '{data.tool_name}' does not exist"
            )
        if data.lifecycle_status == "active" and tool.lifecycle_status != "active":
            raise ActionTemplateConfigurationError(
                f"Tool '{data.tool_name}' must be active before publishing this template"
            )
        if data.template_type == "sql" and data.template_text:
            self._validate_sql(data.template_text, data.policy_json)

        placeholders = self._collect_placeholders(
            [data.template_text, data.payload_template_json]
        )
        properties = set((data.input_schema_json.get("properties") or {}).keys())
        allowed_roots = properties | {"inputs", "query", "steps"}
        unknown = sorted(
            placeholder
            for placeholder in placeholders
            if placeholder.split(".", 1)[0] not in allowed_roots
        )
        if unknown:
            raise ActionTemplateConfigurationError(
                "Template placeholders are not declared by input_schema_json: "
                + ", ".join(unknown)
            )

    @classmethod
    def _collect_placeholders(cls, values: list[Any]) -> set[str]:
        found: set[str] = set()

        def visit(value: Any) -> None:
            if isinstance(value, str):
                found.update(_PLACEHOLDER_RE.findall(value))
            elif isinstance(value, dict):
                for item in value.values():
                    visit(item)
            elif isinstance(value, list):
                for item in value:
                    visit(item)

        for value in values:
            visit(value)
        return found

    @classmethod
    def _render_value(cls, value: Any, context: dict[str, Any]) -> Any:
        if isinstance(value, dict):
            return {key: cls._render_value(item, context) for key, item in value.items()}
        if isinstance(value, list):
            return [cls._render_value(item, context) for item in value]
        if not isinstance(value, str):
            return value

        full = _PLACEHOLDER_RE.fullmatch(value)
        if full:
            return cls._lookup(context, full.group(1))

        def replace(match: re.Match[str]) -> str:
            resolved = cls._lookup(context, match.group(1))
            if isinstance(resolved, (dict, list)):
                return json.dumps(resolved, ensure_ascii=False, separators=(",", ":"))
            return str(resolved)

        return _PLACEHOLDER_RE.sub(replace, value)

    @staticmethod
    def _lookup(context: dict[str, Any], path: str) -> Any:
        current: Any = context
        for part in path.split("."):
            if not isinstance(current, dict) or part not in current:
                raise ActionTemplateConfigurationError(
                    f"No value was provided for template placeholder '{{{{{path}}}}}'"
                )
            current = current[part]
        return current

    @classmethod
    def _apply_defaults(
        cls, inputs: dict[str, Any], schema: dict[str, Any]
    ) -> dict[str, Any]:
        properties = schema.get("properties", {})
        if isinstance(properties, dict):
            for name, spec in properties.items():
                if name not in inputs and isinstance(spec, dict) and "default" in spec:
                    inputs[name] = spec["default"]
        return inputs

    @classmethod
    def _validate_input_schema(
        cls, inputs: dict[str, Any], schema: dict[str, Any]
    ) -> None:
        required = schema.get("required", [])
        missing = [name for name in required if name not in inputs or inputs[name] is None]
        if missing:
            raise ActionTemplateConfigurationError(
                "Missing required action inputs: " + ", ".join(map(str, missing))
            )
        properties = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            unknown = sorted(set(inputs) - set(properties))
            if unknown:
                raise ActionTemplateConfigurationError(
                    "Unknown action inputs: " + ", ".join(unknown)
                )
        for name, value in inputs.items():
            spec = properties.get(name, {}) if isinstance(properties, dict) else {}
            if not isinstance(spec, dict):
                continue
            cls._validate_property(name, value, spec)

    @staticmethod
    def _validate_property(name: str, value: Any, spec: dict[str, Any]) -> None:
        expected = spec.get("type")
        type_map = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        if expected in type_map:
            valid_type = type_map[expected]
            valid = isinstance(value, valid_type)
            if expected in {"integer", "number"} and isinstance(value, bool):
                valid = False
            if not valid:
                raise ActionTemplateConfigurationError(
                    f"Action input '{name}' must be {expected}"
                )
        if "enum" in spec and value not in spec["enum"]:
            raise ActionTemplateConfigurationError(
                f"Action input '{name}' must be one of {spec['enum']}"
            )
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if "minimum" in spec and value < spec["minimum"]:
                raise ActionTemplateConfigurationError(
                    f"Action input '{name}' is below its minimum"
                )
            if "maximum" in spec and value > spec["maximum"]:
                raise ActionTemplateConfigurationError(
                    f"Action input '{name}' exceeds its maximum"
                )
        if isinstance(value, str):
            if "minLength" in spec and len(value) < int(spec["minLength"]):
                raise ActionTemplateConfigurationError(
                    f"Action input '{name}' is shorter than minLength"
                )
            if "maxLength" in spec and len(value) > int(spec["maxLength"]):
                raise ActionTemplateConfigurationError(
                    f"Action input '{name}' exceeds maxLength"
                )
            if spec.get("pattern") and not re.fullmatch(str(spec["pattern"]), value):
                raise ActionTemplateConfigurationError(
                    f"Action input '{name}' does not match its required pattern"
                )
        if isinstance(value, list):
            if len(value) < spec.get("minItems", 0) or len(value) > spec.get("maxItems", float("inf")):
                raise ActionTemplateConfigurationError(f"Action input '{name}' has an invalid number of items")
            if isinstance(spec.get("items"), dict):
                for index, item in enumerate(value):
                    ActionTemplateService._validate_property(f"{name}[{index}]", item, spec["items"])
        if isinstance(value, dict):
            ActionTemplateService._validate_input_schema(value, spec)

    @staticmethod
    def _validate_sql(sql: str, policy: ActionTemplatePolicy) -> None:
        stripped = sql.strip()
        if not stripped:
            raise ActionTemplateConfigurationError("SQL template cannot be empty")
        statements = [part for part in stripped.split(";") if part.strip()]
        if len(statements) != 1:
            raise ActionTemplateConfigurationError(
                "SQL action templates must contain exactly one statement"
            )
        if policy.risk_classification == "read_only":
            if not re.match(r"^(select|with)\b", statements[0].lstrip(), re.IGNORECASE):
                raise ActionTemplateConfigurationError(
                    "Read-only SQL action templates must start with SELECT or WITH"
                )
            if _SQL_MUTATION_RE.search(statements[0]):
                raise ActionTemplateConfigurationError(
                    "Read-only SQL action templates cannot contain mutation keywords"
                )
        if policy.allowed_resources:
            allowed = {item.casefold().strip('`"') for item in policy.allowed_resources}
            resources = {
                match.casefold().strip('`"')
                for match in _SQL_RESOURCE_RE.findall(statements[0])
            }
            denied = sorted(resources - allowed)
            if denied:
                raise ActionTemplateConfigurationError(
                    "SQL template references resources outside the allowlist: "
                    + ", ".join(denied)
                )

    async def _audit_change(
        self,
        session: AsyncSession,
        action: str,
        template: ActionTemplate,
        user_id: str | None,
        *,
        changes: dict[str, Any] | None = None,
    ) -> None:
        details: dict[str, Any] = {
            "action": action,
            "action_template_id": template.id,
            "reference": f"{template.name}@{template.version}",
            "template_type": template.template_type,
            "execution_mode": template.execution_mode,
            "lifecycle_status": template.lifecycle_status,
        }
        if changes is not None:
            details["changes"] = changes
        await self._audit.append(
            session,
            "config_change",
            user_id=user_id,
            tool_name=template.tool_name,
            details=details,
        )
