"""High-level, transactional registration for database-driven agents."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from agents.base.governed_agent import AgentConfig
from backend.models.agent import AgentRegistry
from backend.schemas.agent import AgentCreate
from backend.schemas.document import DocumentCreate
from backend.services.agent_registry import AgentRegistryService
from backend.services.audit_log import AuditLogService
from backend.services.document_store import DocumentStoreService
from backend.services.tool_registry import ToolRegistryService


@dataclass
class RegistrationResult:
    """Result of a full agent registration."""

    agent: AgentRegistry
    documents: list[Any] = field(default_factory=list)
    tools_assigned: list[str] = field(default_factory=list)


class AgentRegistrationService:
    """Register an agent, its RAG documents, and tool assignments atomically.

    The service intentionally does not commit.  The caller owns the transaction,
    so a missing tool or invalid document rolls back the entire registration.
    """

    def __init__(
        self,
        registry: AgentRegistryService | None = None,
        document_store: DocumentStoreService | None = None,
        tool_registry: ToolRegistryService | None = None,
        audit_log: AuditLogService | None = None,
    ) -> None:
        self._audit = audit_log or AuditLogService()
        self._registry = registry or AgentRegistryService(audit_log=self._audit)
        self._doc_store = document_store or DocumentStoreService(audit_log=self._audit)
        self._tool_registry = tool_registry or ToolRegistryService()

    async def register_agent(
        self,
        session: AsyncSession,
        config: AgentConfig,
        *,
        display_name: str | None = None,
        product: str = "general",
        agent_type: str = "specialized",
        tools: list[str] | None = None,
        rag_documents: list[dict[str, str]] | None = None,
        intent_control_enabled: bool = True,
        start_immediately: bool = False,
        user_id: str | None = None,
    ) -> RegistrationResult:
        agent_data = AgentCreate(
            name=config.name,
            display_name=display_name,
            description=config.description or None,
            instruction=config.instruction or None,
            product=product,
            agent_type=agent_type,
            model_config_json=config.model,
            reasoning_config_json=config.reasoning_config,
            generate_content_config_json=config.generate_content_config,
            allow_world_knowledge=config.allow_world_knowledge,
            intent_control_enabled=intent_control_enabled,
            tools=tools or [],
            start_immediately=start_immediately,
        )
        agent = await self._registry.register(session, agent_data)

        created_docs: list[Any] = []
        for doc_spec in rag_documents or []:
            doc = await self._doc_store.create(
                session,
                DocumentCreate(
                    agent_name=config.name,
                    title=doc_spec["title"],
                    content=doc_spec["content"],
                    author=doc_spec.get("author", user_id or "system"),
                ),
            )
            created_docs.append(doc)

        tools_assigned: list[str] = []
        for tool_name in tools or []:
            await self._tool_registry.assign_tool_to_agent(
                session,
                tool_name,
                config.name,
                assigned_by=user_id,
            )
            tools_assigned.append(tool_name)

        if start_immediately:
            # Keep lifecycle semantics explicit while remaining in one transaction.
            agent.lifecycle_status = "running"
            await session.flush()
            await self._audit.append(
                session,
                event_type="lifecycle",
                agent_name=config.name,
                user_id=user_id,
                details={"action": "registered_and_started"},
            )

        return RegistrationResult(agent=agent, documents=created_docs, tools_assigned=tools_assigned)
