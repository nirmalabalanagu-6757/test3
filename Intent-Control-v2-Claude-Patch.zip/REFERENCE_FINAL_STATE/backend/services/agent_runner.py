"""ADK Runner service — manages agent instances and forwards messages via Gemini.

Bridges the platform's session management with ADK's Runner/Session system.
Each registered agent gets a lazily-initialized Runner instance backed by
ADK's InMemorySessionService (conversation history lives in ADK; platform
session state is synced separately).
"""

import asyncio
import hashlib
import logging
import os
from collections import OrderedDict
from dataclasses import replace
from pathlib import Path
from typing import Any

from backend.startup_config.model_definitions import resolve_location as _resolve_location

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# LRU cache for bounded runner / session storage
# ---------------------------------------------------------------------------


class _LRUCache:
    """OrderedDict-based LRU cache with a fixed maximum size.

    Not thread-safe; callers must hold an external lock when used
    from concurrent async code.
    """

    def __init__(self, maxsize: int) -> None:
        self._maxsize = maxsize
        self._data: OrderedDict[str, Any] = OrderedDict()

    def get(self, key: str) -> Any | None:
        if key in self._data:
            self._data.move_to_end(key)
            return self._data[key]
        return None

    def put(self, key: str, value: Any) -> None:
        if key in self._data:
            self._data.move_to_end(key)
        self._data[key] = value
        while len(self._data) > self._maxsize:
            evicted_key, _ = self._data.popitem(last=False)
            logger.debug("LRU evicted cache key: %s", evicted_key)

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __len__(self) -> int:
        return len(self._data)

    def invalidate(self, prefix: str) -> int:
        to_remove = [k for k in self._data if k.startswith(prefix)]
        for k in to_remove:
            del self._data[k]
        return len(to_remove)

    def clear(self) -> None:
        self._data.clear()


# ---------------------------------------------------------------------------
# Agent registry — maps agent_name → builder callable
# ---------------------------------------------------------------------------

_AGENT_BUILDERS: dict[str, Any] = {}
_agents_registered = False


def _register_known_agents() -> None:
    """Register all known agent builders (called lazily on first use)."""
    global _agents_registered
    if _agents_registered:
        return
    _agents_registered = True

    # Register non-Gemini LLM adapters before any agent build
    try:
        import agents.base.anthropic_llm  # noqa: F401
    except ImportError:
        pass
    try:
        import agents.base.openai_compat_llm  # noqa: F401
    except ImportError:
        pass

    try:
        from agents.backup.agent import backup_governed_agent

        _AGENT_BUILDERS["backup-agent"] = lambda: backup_governed_agent
        _AGENT_BUILDERS["backup_agent"] = lambda: backup_governed_agent
        logger.info("Registered Backup agent builder")
    except ImportError:
        logger.warning("Could not import Backup agent")

    try:
        from agents.controlm.agent import controlm_governed_agent

        _AGENT_BUILDERS["controlm-agent"] = lambda: controlm_governed_agent
        _AGENT_BUILDERS["controlm_agent"] = lambda: controlm_governed_agent
        logger.info("Registered Control-M agent builder")
    except ImportError:
        logger.warning("Could not import Control-M agent")

    try:
        from agents.finops.agent import finops_governed_agent

        _AGENT_BUILDERS["finops-agent"] = lambda: finops_governed_agent
        _AGENT_BUILDERS["finops_agent"] = lambda: finops_governed_agent
        logger.info("Registered FinOps agent builder")
    except ImportError:
        logger.warning("Could not import FinOps agent")

    try:
        from agents.database.agent import database_governed_agent

        _AGENT_BUILDERS["database-agent"] = lambda: database_governed_agent
        _AGENT_BUILDERS["database_agent"] = lambda: database_governed_agent
        logger.info("Registered Database agent builder")
    except ImportError:
        logger.warning("Could not import Database agent")

    try:
        from agents.faq.agent import faq_governed_agent

        _AGENT_BUILDERS["faq-agent"] = lambda: faq_governed_agent
        _AGENT_BUILDERS["faq_agent"] = lambda: faq_governed_agent
        logger.info("Registered FAQ agent builder")
    except ImportError:
        logger.warning("Could not import FAQ agent")

    try:
        from agents.r2p.agent import r2p_governed_agent

        _AGENT_BUILDERS["r2p-agent"] = lambda: r2p_governed_agent
        _AGENT_BUILDERS["r2p_agent"] = lambda: r2p_governed_agent
        logger.info("Registered R2P agent builder")
    except ImportError:
        logger.warning("Could not import R2P agent")

    try:
        from agents.concierge.agent import ConciergeAgent
        from agents.base.config_loader import load_agent_config

        config_path = str(Path(__file__).parent.parent.parent / "agents" / "concierge" / "config.yaml")
        if Path(config_path).exists():
            config = load_agent_config(config_path)
            _AGENT_BUILDERS["concierge"] = lambda: ConciergeAgent(config)
            logger.info("Registered Concierge agent builder")
    except ImportError:
        logger.warning("Could not import Concierge agent")


class AgentRunnerService:
    """Manages ADK Runner instances for real Gemini-powered agent invocations.

    Falls back to a simple google.genai direct call if the full ADK Runner
    is not available, ensuring the agent always responds via Gemini.

    The concierge agent is special-cased: it uses Gemini to decide which
    specialized agent to route to, then invokes that agent and returns
    its response — all in a single turn visible to the user.
    """

    # Agent names that act as concierge routers
    _CONCIERGE_NAMES = {"concierge", "concierge_agent", "concierge-agent"}

    def __init__(self) -> None:
        self._runners: _LRUCache = _LRUCache(maxsize=128)
        self._adk_sessions: _LRUCache = _LRUCache(maxsize=1024)
        self._session_service: Any = None
        self._initialized = False
        self._lock = asyncio.Lock()

    def invalidate_runners(self, agent_name: str) -> int:
        """Remove all cached runners for *agent_name*. Returns count removed."""
        count = self._runners.invalidate(f"{agent_name}:")
        if count:
            logger.info("Invalidated %d cached runner(s) for agent '%s'", count, agent_name)
        return count

    def invalidate_routing_runners(self) -> int:
        """Invalidate concierge/router runners after registry or assignment changes."""
        total = 0
        for name in self._CONCIERGE_NAMES:
            total += self._runners.invalidate(f"{name}:")
        if total:
            logger.info("Invalidated %d concierge routing runner(s)", total)
        return total

    def invalidate_all_runners(self) -> int:
        """Clear every cached runner. Intended for administrative config changes."""
        count = len(self._runners)
        self._runners.clear()
        return count

    def _ensure_init(self) -> None:
        """Lazy initialization — only import ADK when first needed."""
        if self._initialized:
            return
        self._initialized = True

        try:
            from google.adk.sessions import InMemorySessionService

            self._session_service = InMemorySessionService()
            logger.info("ADK InMemorySessionService initialized")
        except ImportError:
            logger.warning("google.adk not available — will use direct genai calls")
            self._session_service = None

    def _resolve_adk_agent_name(self, agent_name: str) -> str:
        """Resolve the canonical ADK agent name from config.yaml.

        Maps DB names (e.g. "concierge") to the ADK agent name used
        in config.yaml (e.g. "concierge_agent") so token usage records
        are consistent regardless of invocation path.
        """
        _register_known_agents()
        builder = _AGENT_BUILDERS.get(agent_name)
        if builder:
            try:
                governed = builder()
                if hasattr(governed, "config") and governed.config.name:
                    return governed.config.name
            except Exception:
                pass
        return agent_name

    async def _record_direct_usage(
        self,
        agent_name: str,
        model: str,
        response: Any,
        session_id: str | None = None,
        user_id: str | None = None,
    ) -> None:
        """Record token usage from a direct google.genai response.

        Extracts usage_metadata from the genai GenerateContentResponse so
        that token counts are tracked even when the ADK Runner path is
        not used (e.g. fallback to invoke_direct).
        """
        try:
            prompt_tokens = 0
            completion_tokens = 0

            usage_metadata = getattr(response, "usage_metadata", None)
            if usage_metadata is not None:
                prompt_tokens = (
                    getattr(usage_metadata, "prompt_token_count", None)
                    or getattr(usage_metadata, "prompt_tokens", None)
                    or 0
                )
                completion_tokens = (
                    getattr(usage_metadata, "candidates_token_count", None)
                    or getattr(usage_metadata, "completion_tokens", None)
                    or 0
                )

            # Normalise model name (strip Vertex AI path prefixes)
            resolved_model = model
            for prefix in (
                "publishers/google/models/",
                "publishers/anthropic/models/",
                "anthropic/models/",
                "models/",
            ):
                if resolved_model.startswith(prefix):
                    resolved_model = resolved_model[len(prefix) :]
                    break

            # Use the ADK agent name so records match the callback path
            canonical_name = self._resolve_adk_agent_name(agent_name)

            from backend.database import async_session_factory
            from backend.services.token_manager import TokenManagerService

            token_service = TokenManagerService()
            async with async_session_factory() as session:
                await token_service.record_usage(
                    session,
                    agent_name=canonical_name,
                    prompt_tokens=int(prompt_tokens),
                    completion_tokens=int(completion_tokens),
                    model=resolved_model,
                    session_id=session_id,
                    user_id=user_id,
                )
                await session.commit()

            logger.info(
                "record_direct_usage: agent=%s model=%s prompt=%d completion=%d",
                canonical_name,
                resolved_model,
                prompt_tokens,
                completion_tokens,
            )
        except Exception:
            logger.debug(
                "record_direct_usage: failed for agent=%s — non-fatal",
                agent_name,
                exc_info=True,
            )

    async def _get_rag_context(self, agent_name: str) -> str:
        """Load RAG documents for the agent — DB first, filesystem fallback.

        Priority:
        1. Documents stored in the database (editable via the governance UI)
        2. Static files in agents/{agent}/documents/*.md (initial/fallback)
        """
        # Normalise agent name for lookups (faq-agent → faq_agent)
        canonical = agent_name.replace("-", "_")

        # --- Try database documents first ---
        # Collect docs from all name variants (faq_agent, faq-agent, etc.)
        try:
            from backend.database import async_session_factory
            from backend.services.document_store import DocumentStoreService

            svc = DocumentStoreService()
            variants = list(dict.fromkeys([canonical, agent_name]))  # deduplicate, order preserved
            all_docs = []
            async with async_session_factory() as db:
                for variant in variants:
                    docs = await svc.list_documents(db, agent_name=variant)
                    all_docs.extend(docs)

                if all_docs:
                    doc_ids = list({doc.id for doc in all_docs})
                    try:
                        from datetime import datetime, timezone

                        from sqlalchemy import update

                        from backend.models.document import RagDocumentLatest

                        await db.execute(
                            update(RagDocumentLatest)
                            .where(RagDocumentLatest.document_id.in_(doc_ids))
                            .values(last_used_at=datetime.now(timezone.utc))
                        )
                        await db.commit()
                    except Exception:
                        pass

            if all_docs:
                parts = [doc.content for doc in all_docs if doc.content and doc.content.strip()]
                if parts:
                    logger.debug("Loaded %d RAG doc(s) from DB for '%s'", len(parts), agent_name)
                    return "\n\n---\n\n".join(parts)
        except Exception:
            logger.debug("DB RAG lookup unavailable for '%s', falling back to filesystem", agent_name)

        # --- Filesystem fallback ---
        return self._get_rag_context_from_files(agent_name)

    def _get_rag_context_from_files(self, agent_name: str) -> str:
        """Load RAG documents from static agent document directories."""
        canonical = agent_name.replace("-", "_")
        agents_root = Path(__file__).parent.parent.parent / "agents"

        # Try multiple directory name conventions
        for dir_name in (canonical, agent_name, canonical.replace("_agent", "")):
            doc_dir = agents_root / dir_name / "documents"
            if doc_dir.exists():
                context_parts = []
                for doc_file in sorted(doc_dir.glob("*.md")):
                    context_parts.append(doc_file.read_text())
                if context_parts:
                    return "\n\n---\n\n".join(context_parts)

        return ""

    def _get_agent_instruction(self, agent_name: str) -> str:
        """Get the agent's system instruction."""
        _register_known_agents()
        builder = _AGENT_BUILDERS.get(agent_name)
        if builder:
            try:
                governed = builder()
                return governed.config.instruction or ""
            except Exception:
                pass

        # Fallback instruction
        return (
            "You are a helpful AI assistant for the AIOps Governance Platform. "
            "Answer questions accurately and concisely."
        )

    def _get_agent_model(self, agent_name: str) -> str:
        """Get the model configured for this agent with fallback."""
        _register_known_agents()
        builder = _AGENT_BUILDERS.get(agent_name)
        if builder:
            try:
                governed = builder()
                if hasattr(governed, "model") and governed.model:
                    return governed.model
                if hasattr(governed, "config") and governed.config.model:
                    return governed.config.model
            except Exception:
                pass
        return os.getenv("DEFAULT_MODEL", "gemini-2.5-flash")

    def _get_governed_agent_instruction(
        self,
        agent_name: str,
        db_world_knowledge: bool = False,
        db_product: str | None = None,
        db_model: str | None = None,
        db_instruction: str | None = None,
        db_description: str | None = None,
    ) -> str:
        """Return governed instruction using code config or a DB-only dynamic agent."""
        _register_known_agents()
        builder = _AGENT_BUILDERS.get(agent_name)
        try:
            from agents.base.governed_agent import AgentConfig, GovernedAgent

            if builder:
                singleton = builder()
                overrides: dict[str, Any] = {
                    "allow_world_knowledge": db_world_knowledge,
                }
                if db_product is not None:
                    overrides["product"] = db_product
                if db_model is not None:
                    overrides["model"] = db_model
                if db_instruction is not None:
                    overrides["instruction"] = db_instruction.replace("{", "(").replace("}", ")")
                if db_description is not None:
                    overrides["description"] = db_description
                governed = GovernedAgent(replace(singleton.config, **overrides))
            else:
                governed = GovernedAgent(
                    AgentConfig(
                        name=agent_name.replace("-", "_"),
                        description=db_description or "Database-registered AIOps agent",
                        instruction=(db_instruction or self._get_agent_instruction(agent_name))
                        .replace("{", "(")
                        .replace("}", ")"),
                        model=db_model or self._get_agent_model(agent_name),
                        product=db_product,
                        allow_world_knowledge=db_world_knowledge,
                    )
                )
            return governed._augmented_instruction()
        except Exception:
            return db_instruction or self._get_agent_instruction(agent_name)

    async def invoke_direct(
        self,
        agent_name: str,
        session_id: str,
        user_message: str,
        db_world_knowledge: bool = False,
        db_product: str | None = None,
        db_model: str | None = None,
        db_instruction: str | None = None,
        db_description: str | None = None,
    ) -> str:
        """Fallback: invoke Gemini directly via google.genai (no ADK Runner).

        This provides real LLM responses even without full ADK Runner support.
        No multi-turn conversation history in this mode.
        """
        try:
            from google import genai

            # Prefer Vertex AI (ADC credentials) over API key, with fallback
            gcp_project = os.getenv("GOOGLE_CLOUD_PROJECT", "")
            api_key = os.getenv("GOOGLE_API_KEY", "")
            model = db_model or self._get_agent_model(agent_name)
            gcp_location = _resolve_location(model)

            client = None
            if gcp_project:
                try:
                    client = genai.Client(
                        vertexai=True,
                        project=gcp_project,
                        location=gcp_location,
                    )
                except Exception as adc_err:
                    logger.warning(
                        "Vertex AI ADC unavailable (%s), falling back to GOOGLE_API_KEY",
                        adc_err,
                    )

            if client is None:
                if not api_key:
                    return (
                        "Neither Vertex AI (ADC credentials) nor GOOGLE_API_KEY is available. "
                        "Please configure Application Default Credentials or set GOOGLE_API_KEY."
                    )
                client = genai.Client(api_key=api_key)
            if gcp_project and model.startswith("claude"):
                model = f"anthropic/models/{model}"
            instruction = self._get_governed_agent_instruction(
                agent_name, db_world_knowledge, db_product, db_model, db_instruction, db_description
            )
            rag_context = await self._get_rag_context(agent_name)

            # Build the prompt with system instruction and RAG context
            system_parts = [instruction]
            if rag_context:
                system_parts.append(f"\n\n## Reference Documentation\n\n{rag_context}")

            # Retry on transient errors (429, 503)
            last_error = None
            for attempt in range(4):
                try:
                    response = await client.aio.models.generate_content(
                        model=model,
                        contents=user_message,
                        config=genai.types.GenerateContentConfig(
                            system_instruction="\n".join(system_parts),
                            temperature=0.7,
                            max_output_tokens=2048,
                        ),
                    )

                    # Record token usage from the direct genai response
                    await self._record_direct_usage(agent_name, model, response, session_id=session_id)

                    if response.text:
                        return response.text
                    return "I received your message but the model returned an empty response."
                except Exception as e:
                    err_str = str(e)
                    # ADC error during API call — fall back to API key
                    if "default credentials" in err_str.lower() and api_key:
                        logger.warning(
                            "Vertex AI ADC failed during API call for '%s', retrying with GOOGLE_API_KEY",
                            agent_name,
                        )
                        client = genai.Client(api_key=api_key)
                        continue
                    if any(code in err_str for code in ("429", "503", "UNAVAILABLE", "RESOURCE_EXHAUSTED")):
                        last_error = e
                        delay = (2**attempt) + 0.5
                        logger.warning(
                            "Gemini transient error (attempt %d/4) for '%s': %s — retrying in %.1fs",
                            attempt + 1,
                            agent_name,
                            err_str[:100],
                            delay,
                        )
                        await asyncio.sleep(delay)
                        continue
                    raise

            # All retries exhausted
            return (
                f"The AI service is temporarily unavailable (tried 4 times). "
                f"Please try again in a moment. Last error: {last_error}"
            )

        except ImportError:
            return (
                f"[No LLM available] Agent '{agent_name}' cannot generate responses. "
                f"Install google-genai or google-adk to enable AI responses."
            )
        except Exception as exc:
            logger.exception("Direct Gemini invocation failed for agent '%s'", agent_name)
            return f"An error occurred while generating a response: {exc}"

    # ------------------------------------------------------------------
    # Concierge routing
    # ------------------------------------------------------------------

    def _is_concierge(self, agent_name: str) -> bool:
        return agent_name.replace("-", "_").replace(" ", "_").lower() in {
            n.replace("-", "_") for n in self._CONCIERGE_NAMES
        }

    async def _resolve_controlled_intent(
        self,
        *,
        source_agent: str,
        session_id: str,
        user_id: str,
        user_message: str,
    ) -> Any | None:
        """Run deterministic Intent Control before invoking an agent LLM.

        ``None`` means the existing agent path should continue normally. Other
        decisions are enforced by :meth:`invoke_with_runner`.
        """
        try:
            from backend.database import async_session_factory
            from backend.services.audit_log import AuditLogService
            from backend.services.intent_control import IntentControlService

            async with async_session_factory() as db:
                decision = await IntentControlService().resolve(
                    db,
                    user_message,
                    source_agent=source_agent,
                )
                if decision.decision in {"no_match", "llm_fallback"}:
                    # A normal-routing decision may still have produced safe,
                    # non-executing observations for rules in shadow mode.
                    await db.commit()
                    return None

                await AuditLogService().append(
                    db,
                    "delegation" if decision.decision == "route" else "interaction",
                    session_id=session_id,
                    user_id=user_id,
                    source_agent=decision.source_agent,
                    target_agent=decision.target_agent,
                    details={
                        "action": "intent_control_decision",
                        "decision": decision.decision,
                        "source_agent": decision.source_agent,
                        "intent_id": decision.intent_id,
                        "intent_name": decision.intent_name,
                        "confidence": decision.confidence,
                        "risk_classification": decision.risk_classification,
                        "allowed_tools": decision.allowed_tools,
                        "response_mode": decision.response_mode,
                        "orchestration_mode": decision.orchestration_mode,
                        "selected_intents": [item.intent_name for item in decision.selected_intents],
                        "reason": decision.reason,
                    },
                    request_summary=user_message[:512],
                )
                await db.commit()
                return decision
        except Exception:
            # Intent Control is an enhancement around the existing agent path.
            # A database/configuration outage must preserve the established
            # execution path instead of taking chat offline.
            logger.exception(
                "Intent Control evaluation failed for agent '%s'; using normal agent path",
                source_agent,
            )
            return None

    async def _get_running_agents_block(self) -> str:
        """Fetch running specialized agents from the DB and format them."""
        try:
            from backend.database import async_session_factory
            from backend.services.agent_routing import AgentRoutingService

            routing = AgentRoutingService()
            async with async_session_factory() as db:
                agents = await routing.get_available_agents(db)

            if not agents:
                return "(No specialized agents are currently running.)"

            lines = []
            for a in agents:
                lines.append(f"- {a.name} | product: {a.product} | {a.description or 'No description'}")
            return "\n".join(lines)
        except Exception:
            logger.exception("Failed to fetch running agents for concierge")
            return "(Could not retrieve agent list.)"

    async def _route_and_invoke(
        self,
        session_id: str,
        user_id: str,
        user_message: str,
    ) -> str:
        """Concierge flow: use LLM to pick an agent, then invoke it.

        Returns a combined response that includes which agent handled
        the request and the agent's actual answer.
        """
        try:
            import httpx as _httpx
            import json
            import re

            agents_block = await self._get_running_agents_block()

            # Step 1: Ask the LLM which agent to route to
            routing_prompt = (
                "You are the Concierge Agent for the AIOps Governance Platform.\n"
                "Your job is to route user queries to the right specialized agent.\n\n"
                f"AVAILABLE AGENTS:\n{agents_block}\n\n"
                "INSTRUCTIONS:\n"
                "- Pick the best matching agent from the list above.\n"
                "- If any agent's product area is relevant, route to it.\n"
                "- For general or ambiguous queries, route to whichever agent's product area is closest.\n"
                "- Say 'none' only if no agent fits, or the query is clearly harmful or nonsensical.\n"
                "- Respond with ONLY this JSON (no markdown, no extra text):\n"
                '{"agent": "<exact-agent-name>", "reason": "<brief reason>"}\n\n'
                f"USER QUERY: {user_message}"
            )

            # Resolve the routing model the same way every other agent does:
            # from the concierge's config.yaml (which honours the DEFAULT_MODEL
            # override applied in config_loader), instead of a bespoke env var.
            # CONCIERGE_MODEL remains an optional explicit override.
            model = (
                os.getenv("CONCIERGE_MODEL")
                or self._get_agent_model("concierge")
                or os.getenv("DEFAULT_MODEL", "gemini-2.5-flash")
            )
            gcp_project = os.getenv("GOOGLE_CLOUD_PROJECT", "")

            if gcp_project and not model.startswith(("local-", "qwen", "llama", "openai-compat")):
                from google import genai

                _client = None
                api_key = os.getenv("GOOGLE_API_KEY", "")
                # Try Vertex AI (ADC), fall back to API key
                try:
                    _client = genai.Client(
                        vertexai=True,
                        project=gcp_project,
                        location=_resolve_location(model),
                    )
                    vertex_model = model
                    if model.startswith("claude"):
                        vertex_model = f"anthropic/models/{model}"
                    response = await _client.aio.models.generate_content(
                        model=vertex_model,
                        contents=routing_prompt,
                        config=genai.types.GenerateContentConfig(
                            temperature=0.1,
                            max_output_tokens=256,
                        ),
                    )
                    routing_text = (response.text or "").strip()
                except Exception as vertex_err:
                    if "default credentials" not in str(vertex_err).lower() or not api_key:
                        raise
                    logger.warning("Vertex AI ADC unavailable for concierge routing, falling back to GOOGLE_API_KEY")
                    _client = genai.Client(api_key=api_key)
                    response = await _client.aio.models.generate_content(
                        model=model,
                        contents=routing_prompt,
                        config=genai.types.GenerateContentConfig(
                            temperature=0.1,
                            max_output_tokens=256,
                        ),
                    )
                    routing_text = (response.text or "").strip()
            else:
                # Fallback: OpenAI-compatible API (local dev)
                base_url = os.getenv("OPENAI_COMPAT_BASE_URL", "http://localhost:8080/v1")
                api_key = os.getenv("OPENAI_COMPAT_API_KEY", "not-needed")
                async with _httpx.AsyncClient(timeout=60) as client:
                    resp = await client.post(
                        f"{base_url}/chat/completions",
                        json={
                            "model": os.getenv("OPENAI_COMPAT_MODEL", model),
                            "messages": [{"role": "user", "content": routing_prompt}],
                            "max_tokens": 256,
                            "temperature": 0.1,
                        },
                        headers={
                            "Authorization": f"Bearer {api_key}",
                            "Content-Type": "application/json",
                        },
                    )
                    resp.raise_for_status()
                    data = resp.json()
                routing_text = (data["choices"][0]["message"]["content"] or "").strip()
            logger.info("Concierge routing response: %s", routing_text)

            # Step 2: Parse the routing decision
            try:
                clean = re.sub(r"```\w*\n?", "", routing_text).strip()
                json_match = re.search(r"\{.*?\}", clean, re.DOTALL)
                if json_match:
                    decision = json.loads(json_match.group())
                else:
                    decision = json.loads(clean)
            except (json.JSONDecodeError, ValueError):
                decision = {"agent": "none", "reason": routing_text}
                for line in agents_block.split("\n"):
                    if line.startswith("- "):
                        name = line.split("|")[0].replace("- ", "").strip()
                        if name.lower() in routing_text.lower():
                            decision = {"agent": name, "reason": "matched from response text"}
                            break

            target_agent = decision.get("agent", "none")
            reason = decision.get("reason", "")

            # Step 3: Record routing decision
            try:
                from backend.database import async_session_factory
                from backend.services.agent_routing import AgentRoutingService

                routing_svc = AgentRoutingService()
                async with async_session_factory() as db:
                    await routing_svc.record_routing_decision(
                        db,
                        source_agent="concierge",
                        target_agent=target_agent,
                        reason=reason,
                        user_query=user_message[:256],
                    )
                    await db.commit()
            except Exception:
                logger.warning("Failed to record routing decision in audit log")

            # Step 4: If no agent matched, ask for clarification
            if target_agent == "none" or not target_agent:
                return (
                    f"I'm not sure which specialist can help with that. {reason}\n\nAvailable agents:\n{agents_block}"
                )

            # Step 5: Invoke the target agent
            logger.info("Concierge routing to '%s': %s", target_agent, reason)
            agent_response, _, _ = await self.invoke_with_runner(
                agent_name=target_agent,
                session_id=session_id,
                user_id=user_id,
                user_message=user_message,
            )

            return f"*Routed to **{target_agent}** ({reason})*\n\n{agent_response}"

        except Exception as exc:
            logger.exception("Concierge routing failed")
            return f"I encountered an error while routing your request: {exc}"

    async def _build_adk_agent(
        self,
        agent_name: str,
        rag_context: str,
        allow_world_knowledge: bool = False,
        product: str | None = None,
        model: str | None = None,
        db_instruction: str | None = None,
        db_description: str | None = None,
        db_reasoning_config: dict | None = None,
        db_generate_content_config: dict | None = None,
        allowed_tool_names: list[str] | None = None,
        intent_context: dict[str, Any] | None = None,
    ) -> Any:
        """Build a governed ADK agent from code config or the database alone.

        Existing Python agent modules remain supported as compatibility/optimized
        implementations.  If no builder exists, a generic :class:`GovernedAgent`
        is constructed from ``agent_registry`` so no code deployment is required.
        """
        _register_known_agents()
        builder = _AGENT_BUILDERS.get(agent_name)

        # A concierge sub-agent build may arrive without DB overrides, so load
        # the registry row here when the agent has no Python builder.
        if not builder and not any(
            (db_instruction, db_description, product, model, db_reasoning_config, db_generate_content_config)
        ):
            try:
                from backend.database import async_session_factory
                from backend.models.agent import AgentRegistry

                async with async_session_factory() as db:
                    record = await db.get(AgentRegistry, agent_name)
                    if record is None:
                        record = await db.get(AgentRegistry, agent_name.replace("-", "_"))
                    if record is None or record.lifecycle_status == "deregistered":
                        logger.warning("Cannot build unknown/deregistered dynamic agent '%s'", agent_name)
                        return None
                    allow_world_knowledge = record.allow_world_knowledge
                    product = record.product
                    db_instruction = record.instruction or db_instruction
                    db_description = record.description or db_description
                    db_reasoning_config = record.reasoning_config_json or db_reasoning_config
                    db_generate_content_config = record.generate_content_config_json or db_generate_content_config
                    if not model and record.model_config_json:
                        import json

                        raw_model = record.model_config_json.strip()
                        if raw_model.startswith("{"):
                            try:
                                parsed = json.loads(raw_model)
                                model = parsed.get("model") if isinstance(parsed, dict) else None
                            except Exception:
                                pass
                        else:
                            model = raw_model
            except Exception:
                logger.warning("Failed to load DB config for dynamic agent '%s'", agent_name, exc_info=True)

        from agents.base.governed_agent import AgentConfig, GovernedAgent

        if builder:
            singleton = builder()
            overrides: dict[str, Any] = {"allow_world_knowledge": allow_world_knowledge}
            if product is not None:
                overrides["product"] = product
            if model is not None:
                overrides["model"] = model
            if db_instruction is not None:
                overrides["instruction"] = db_instruction.replace("{", "(").replace("}", ")")
            if db_description is not None:
                overrides["description"] = db_description
            if db_reasoning_config is not None:
                overrides["reasoning_config"] = db_reasoning_config
            if db_generate_content_config is not None:
                overrides["generate_content_config"] = db_generate_content_config

            agent_cls = type(singleton) if isinstance(singleton, GovernedAgent) else GovernedAgent
            governed = agent_cls(replace(singleton.config, **overrides))
        else:
            governed = GovernedAgent(
                AgentConfig(
                    name=agent_name.replace("-", "_"),
                    description=db_description or "Database-registered AIOps agent",
                    instruction=(
                        db_instruction
                        or "You are a governed AIOps specialist. Use only assigned active tools and follow platform policy."
                    )
                    .replace("{", "(")
                    .replace("}", ")"),
                    model=model or os.getenv("DEFAULT_MODEL", "gemini-2.5-flash"),
                    product=product,
                    allow_world_knowledge=allow_world_knowledge,
                    reasoning_config=db_reasoning_config,
                    generate_content_config=db_generate_content_config,
                )
            )
            logger.info("Built generic database-driven agent config for '%s'", agent_name)

        # Keep the base instruction here. GovernedAgent.build() applies the
        # product/world-knowledge out-of-scope suffix exactly once.
        instruction = governed.config.instruction

        agent_tools = list(governed.config.tools or [])
        allowed = {name.casefold() for name in allowed_tool_names or []}
        try:
            from backend.database import async_session_factory
            from backend.services.tool_loader import get_tool_descriptions_for_agent, get_tools_for_agent

            async with async_session_factory() as db:
                db_tools = await get_tools_for_agent(db, agent_name)
                # Deduplicate by callable name to avoid static+DB duplicates.
                seen = {getattr(t, "__name__", repr(t)) for t in agent_tools}
                for tool in db_tools:
                    marker = getattr(tool, "__name__", repr(tool))
                    if marker not in seen:
                        agent_tools.append(tool)
                        seen.add(marker)
                tool_docs = await get_tool_descriptions_for_agent(db, agent_name)
                if allowed_tool_names is not None:
                    tool_docs = [
                        (tool_name, detail) for tool_name, detail in tool_docs if tool_name.casefold() in allowed
                    ]
                if tool_docs:
                    docs_section = "\n\n## Tool Instructions\n\n"
                    for tool_name, detail in tool_docs:
                        safe_detail = detail.replace("{", "(").replace("}", ")")
                        docs_section += f"### {tool_name}\n\n{safe_detail}\n\n"
                    instruction = f"{instruction}{docs_section}"
        except Exception:
            logger.warning("Failed to load DB tools for agent '%s'", agent_name, exc_info=True)

        if allowed_tool_names is not None:
            agent_tools = [
                tool
                for tool in agent_tools
                if str(getattr(tool, "__name__", getattr(tool, "name", ""))).casefold() in allowed
            ]

        if intent_context:
            intent_name = str(intent_context.get("intent_name") or "unknown")
            response_mode = str(intent_context.get("response_mode") or "auto")
            risk = str(intent_context.get("risk_classification") or "read_only")
            parameter_text = str(intent_context.get("parameters") or {}).replace("{", "(").replace("}", ")")
            response_template = str(intent_context.get("response_template") or "").replace("{", "(").replace("}", ")")
            response_options = str(intent_context.get("response_options") or {}).replace("{", "(").replace("}", ")")
            template_line = f"Response template: {response_template}\n" if response_template else ""
            instruction = (
                f"{instruction}\n\n## Resolved Intent Control\n\n"
                f"Intent: {intent_name}\n"
                f"Risk: {risk}\n"
                f"Response mode: {response_mode}\n"
                f"Resolved parameters: {parameter_text}\n"
                f"Response options: {response_options}\n"
                f"{template_line}"
                "Follow this administrator-approved route and use only the tools made available to you."
            )

        if rag_context:
            safe_rag = rag_context.replace("{", "(").replace("}", ")")
            instruction = f"{instruction}\n\n## Reference Documentation\n\n{safe_rag}"

        if self._is_concierge(agent_name):
            try:
                governed.config.tools = agent_tools
                governed.config.instruction = instruction
                try:
                    from backend.database import async_session_factory
                    from backend.services.agent_routing import AgentRoutingService

                    async with async_session_factory() as db:
                        available = await AgentRoutingService().get_available_agents(db)
                        paired: list[tuple[dict[str, Any], Any]] = []
                        for agent_info in available:
                            sub_rag = await self._get_rag_context(agent_info.name)
                            sub_agent = await self._build_adk_agent(agent_info.name, sub_rag)
                            if sub_agent is not None:
                                paired.append(
                                    (
                                        {
                                            "name": agent_info.name,
                                            "product": agent_info.product,
                                            "description": agent_info.description or "",
                                        },
                                        sub_agent,
                                    )
                                )
                        governed.populate_sub_agents(
                            [p[0] for p in paired],
                            sub_agent_instances=[p[1] for p in paired],
                        )
                except Exception:
                    logger.warning("Failed to populate concierge sub-agents", exc_info=True)
                return governed.build()
            except Exception:
                logger.exception("Failed to build ConciergeAgent via .build()")
                return None

        try:
            # GovernedAgent.build includes policy + tool governance callbacks.
            governed.config.tools = agent_tools
            governed.config.instruction = instruction
            return governed.build()
        except Exception:
            logger.debug("Failed to build ADK LlmAgent for '%s'", agent_name, exc_info=True)
            return None

    async def _invoke_via_runner(
        self,
        agent_name: str,
        session_id: str,
        user_id: str,
        user_message: str,
        db_world_knowledge: bool = False,
        db_product: str | None = None,
        db_model: str | None = None,
        db_instruction: str | None = None,
        db_description: str | None = None,
        db_reasoning_config: dict | None = None,
        db_generate_content_config: dict | None = None,
        allowed_tool_names: list[str] | None = None,
        intent_context: dict[str, Any] | None = None,
    ) -> tuple[str, dict[str, list[str]]] | None:
        """Try to invoke the agent via ADK Runner.

        Returns (response_text, contributing_agents) on success, or None if
        ADK is unavailable so the caller can fall back to direct Gemini.
        """
        self._ensure_init()
        if self._session_service is None:
            logger.warning("ADK session service not initialized — skipping Runner")
            return None

        try:
            from google.adk.runners import Runner
            from google.genai import types

            logger.info("_invoke_via_runner: building agent '%s'", agent_name)
            # Load RAG context (outside lock — I/O-heavy)
            rag_context = await self._get_rag_context(agent_name)
            rag_hash = hashlib.md5(rag_context.encode()).hexdigest()[:12] if rag_context else ""

            # Build ADK agent (outside lock — I/O-heavy)
            adk_agent = await self._build_adk_agent(
                agent_name,
                rag_context,
                allow_world_knowledge=db_world_knowledge,
                product=db_product,
                model=db_model,
                db_instruction=db_instruction,
                db_description=db_description,
                db_reasoning_config=db_reasoning_config,
                db_generate_content_config=db_generate_content_config,
                allowed_tool_names=allowed_tool_names,
                intent_context=intent_context,
            )
            if adk_agent is None:
                return None

            # Get or create Runner — lock prevents duplicate creation from concurrent coroutines
            instr_hash = hashlib.md5((db_instruction or "").encode()).hexdigest()[:12]
            intent_hash = hashlib.md5(
                repr((sorted(allowed_tool_names or []), intent_context or {})).encode()
            ).hexdigest()[:12]
            runner_key = (
                f"{agent_name}:{db_world_knowledge}:{db_model}:{db_product}:{rag_hash}:{instr_hash}:{intent_hash}"
            )
            async with self._lock:
                runner = self._runners.get(runner_key)
                if runner is None:
                    runner = Runner(
                        agent=adk_agent,
                        app_name="aiops-governance",
                        session_service=self._session_service,
                    )
                    self._runners.put(runner_key, runner)
                    logger.info("Created ADK Runner for agent '%s' (key='%s')", agent_name, runner_key)

            # Ensure ADK session exists — lock spans the await to prevent TOCTOU race
            adk_session_key = f"{agent_name}:{session_id}"
            async with self._lock:
                if self._adk_sessions.get(adk_session_key) is None:
                    adk_session = await self._session_service.create_session(
                        app_name="aiops-governance",
                        user_id=user_id,
                        session_id=adk_session_key,
                    )
                    self._adk_sessions.put(adk_session_key, adk_session)
                    logger.debug("Created ADK session '%s'", adk_session_key)

            # Build the user message
            message = types.Content(
                role="user",
                parts=[types.Part(text=user_message)],
            )

            # Run the agent and collect the final response
            response_parts: list[str] = []
            agent_tools: dict[str, list[str]] = {}
            async for event in runner.run_async(
                user_id=user_id,
                session_id=adk_session_key,
                new_message=message,
            ):
                if hasattr(event, "author") and event.author:
                    logger.info("ADK event from '%s': final=%s", event.author, event.is_final_response())
                    if event.author not in agent_tools:
                        agent_tools[event.author] = []
                    if event.content and event.content.parts:
                        for part in event.content.parts:
                            from backend.services.intent_trace import record_tool_event

                            record_tool_event(event.author, part)
                            function_event = (
                                getattr(part, "function_response", None)
                                or getattr(part, "function_call", None)
                            )
                            if function_event and getattr(function_event, "name", None):
                                tool_name = function_event.name
                                if tool_name not in agent_tools[event.author]:
                                    agent_tools[event.author].append(tool_name)
                if event.is_final_response() and event.content and event.content.parts:
                    for part in event.content.parts:
                        if hasattr(part, "text") and part.text:
                            response_parts.append(part.text)

            if response_parts:
                return "\n".join(response_parts), agent_tools

            return "I received your message but the agent returned an empty response.", agent_tools

        except ImportError:
            logger.debug("ADK Runner not available — will fall back to direct Gemini")
            return None
        except Exception as exc:
            logger.exception("ADK Runner invocation failed for agent '%s'", agent_name)
            from backend.services.intent_trace import invalidate_tool_trace

            invalidate_tool_trace()
            model = db_model or self._get_agent_model(agent_name) or ""
            if model.startswith("claude"):
                return f"Agent invocation failed: {exc}", {}
            return None

    async def _invoke_openai_compat(
        self,
        agent_name: str,
        session_id: str,
        user_message: str,
        db_world_knowledge: bool = False,
        db_product: str | None = None,
        db_model: str | None = None,
        db_instruction: str | None = None,
        db_description: str | None = None,
    ) -> str:
        """Fallback: invoke a local OpenAI-compatible model directly (no ADK Runner)."""
        try:
            import httpx

            base_url = os.getenv("OPENAI_COMPAT_BASE_URL", "http://localhost:8080/v1")
            model = db_model or os.getenv("OPENAI_COMPAT_MODEL", "default")
            api_key = os.getenv("OPENAI_COMPAT_API_KEY", "not-needed")

            instruction = self._get_governed_agent_instruction(
                agent_name, db_world_knowledge, db_product, db_model, db_instruction, db_description
            )
            rag_context = await self._get_rag_context(agent_name)

            messages = []
            system_content = instruction
            if rag_context:
                system_content += f"\n\n## Reference Documentation\n\n{rag_context}"
            messages.append({"role": "system", "content": system_content})
            messages.append({"role": "user", "content": user_message})

            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(
                    f"{base_url}/chat/completions",
                    json={
                        "model": model,
                        "messages": messages,
                        "max_tokens": 2048,
                        "temperature": 0.7,
                    },
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            content = data["choices"][0]["message"]["content"]
            return content or "The model returned an empty response."

        except Exception as exc:
            logger.exception("OpenAI-compat direct invocation failed for agent '%s'", agent_name)
            return f"An error occurred while generating a response: {exc}"

    async def invoke_with_runner(
        self,
        agent_name: str,
        session_id: str,
        user_id: str,
        user_message: str,
        allowed_tool_names: list[str] | None = None,
        intent_context: dict[str, Any] | None = None,
        _skip_intent_control: bool = False,
    ) -> tuple[str, dict[str, list[str]], str]:
        """Invoke the agent using ADK Runner with direct Gemini fallback.

        Returns (response_text, agent_tools, model_name).

        Tries the full ADK Runner first (multi-turn support, governance
        callbacks, token tracking). Falls back to direct google.genai
        call if ADK is unavailable or the Runner fails.

        The concierge agent now uses ADK's tool system for direct tool
        invocation when no specialized agent handles the domain.
        """
        # Deterministic administrator-managed intents run before every entry
        # agent's LLM. Agent-level enablement and per-intent source scope are
        # enforced by IntentControlService. Workflow-internal calls set
        # ``_skip_intent_control`` to prevent recursive intent execution.
        if not _skip_intent_control:
            decision = await self._resolve_controlled_intent(
                source_agent=agent_name,
                session_id=session_id,
                user_id=user_id,
                user_message=user_message,
            )
            if decision is not None:
                if decision.decision == "route" and decision.selected_intents:
                    from backend.services.intent_orchestrator import intent_orchestrator

                    orchestrated = await intent_orchestrator.execute(
                        decision,
                        session_id=session_id,
                        user_id=user_id,
                        user_message=user_message,
                        invoke_agent=self.invoke_with_runner,
                    )
                    intent_markers = orchestrated.tools.setdefault("intent_control", [])
                    for selected in decision.selected_intents:
                        if selected.intent_name not in intent_markers:
                            intent_markers.append(selected.intent_name)
                    intent_markers.append(f"run:{orchestrated.run_id}")
                    return orchestrated.response, orchestrated.tools, orchestrated.model

                if decision.decision in {"clarify", "confirm"}:
                    message = decision.clarification_prompt or decision.reason
                elif decision.decision == "deny":
                    message = f"This request was blocked by Intent Control. {decision.reason}"
                else:
                    message = f"The configured intent target is unavailable. {decision.reason}"
                return message, {"intent_control": [decision.intent_name or "unknown"]}, "intent-control"

        # Retrieve dynamic agent metadata from the DB if available
        db_world_knowledge = False
        db_product = None
        db_model = None
        db_instruction = None
        db_description = None
        db_reasoning_config = None
        db_generate_content_config = None
        db_has_active_tools = False

        try:
            from backend.database import async_session_factory
            from backend.services.agent_registry import AgentRegistryService

            registry_svc = AgentRegistryService()
            async with async_session_factory() as db:
                try:
                    agent_record = await registry_svc.get(db, agent_name)
                except Exception:
                    canonical = agent_name.replace("-", "_")
                    agent_record = await registry_svc.get(db, canonical)

                db_world_knowledge = agent_record.allow_world_knowledge
                db_product = agent_record.product
                db_instruction = agent_record.instruction
                db_description = agent_record.description
                db_reasoning_config = agent_record.reasoning_config_json
                db_generate_content_config = agent_record.generate_content_config_json

                # Local/OpenAI-compatible models normally use a lightweight
                # direct path, but assigned tools require the full ADK runner
                # so tool calls and governance callbacks are preserved.
                try:
                    from sqlalchemy import select
                    from backend.models.tool import ToolAgentAssignment, ToolRegistry

                    candidates = {agent_record.name, agent_record.name.replace("-", "_")}
                    if not agent_record.name.endswith("_agent"):
                        candidates.add(f"{agent_record.name}_agent")
                    tool_result = await db.execute(
                        select(ToolAgentAssignment.tool_name)
                        .join(ToolRegistry, ToolRegistry.name == ToolAgentAssignment.tool_name)
                        .where(
                            ToolAgentAssignment.agent_name.in_(candidates),
                            ToolRegistry.lifecycle_status == "active",
                        )
                        .limit(1)
                    )
                    db_has_active_tools = tool_result.first() is not None
                except Exception:
                    logger.warning("Unable to determine active tool assignments for '%s'", agent_name, exc_info=True)

                # Parse model from model_config_json
                if agent_record.model_config_json:
                    import json

                    model_cfg = agent_record.model_config_json.strip()
                    if model_cfg.startswith("{") and model_cfg.endswith("}"):
                        try:
                            cfg_dict = json.loads(model_cfg)
                            if isinstance(cfg_dict, dict):
                                db_model = cfg_dict.get("model")
                        except Exception:
                            pass
                    else:
                        db_model = model_cfg
        except Exception:
            logger.warning("Failed to retrieve agent configuration from DB, using file defaults")

        # Resolve model name to decide if we should use openai-compat or Gemini
        model_name = db_model or self._get_agent_model(agent_name) or ""

        is_local_model = model_name.startswith(("local-", "qwen", "llama", "openai-compat"))

        # Keep the low-overhead direct path only for local agents that have no
        # active tools and are not the concierge.  Tool-enabled local agents
        # use ADK, whose OpenAICompatLlm adapter supports function calling.
        if is_local_model and not db_has_active_tools and not self._is_concierge(agent_name):
            logger.info(
                "Agent '%s' using direct OpenAI-compat call (model=%s, no active tools)", agent_name, model_name
            )
            result = await self._invoke_openai_compat(
                agent_name,
                session_id,
                user_message,
                db_world_knowledge=db_world_knowledge,
                db_product=db_product,
                db_model=db_model,
                db_instruction=db_instruction,
                db_description=db_description,
            )
            return result, {agent_name: []}, model_name
        if is_local_model:
            logger.info(
                "Agent '%s' using ADK OpenAI-compatible adapter to preserve dynamic tools/routing",
                agent_name,
            )

        # Try ADK Runner for Gemini/Claude and tool-enabled local models
        logger.info("Attempting ADK Runner for agent '%s'", agent_name)
        runner_result = await self._invoke_via_runner(
            agent_name,
            session_id,
            user_id,
            user_message,
            db_world_knowledge=db_world_knowledge,
            db_product=db_product,
            db_model=db_model,
            db_instruction=db_instruction,
            db_description=db_description,
            db_reasoning_config=db_reasoning_config,
            db_generate_content_config=db_generate_content_config,
            allowed_tool_names=allowed_tool_names,
            intent_context=intent_context,
        )
        if runner_result is not None:
            logger.info("Agent '%s' responded via ADK Runner", agent_name)
            return runner_result[0], runner_result[1], model_name

        # If ADK is unavailable or the local server does not support the full
        # runner contract, degrade gracefully to a plain local chat response.
        # This fallback intentionally cannot execute tools.
        if is_local_model:
            logger.warning("ADK path unavailable for local agent '%s'; falling back without tool execution", agent_name)
            result = await self._invoke_openai_compat(
                agent_name,
                session_id,
                user_message,
                db_world_knowledge=db_world_knowledge,
                db_product=db_product,
                db_model=db_model,
                db_instruction=db_instruction,
                db_description=db_description,
            )
            return result, {agent_name: []}, model_name

        # Claude models must go through the ADK Runner + AnthropicLlm adapter;
        # the invoke_direct fallback uses google.genai which cannot serve Claude.
        if model_name.startswith("claude"):
            logger.error("ADK Runner returned None for Claude model '%s' on agent '%s'", model_name, agent_name)
            return (
                (
                    f"Failed to invoke Claude model '{model_name}'. "
                    "Check that the Anthropic API key or Vertex AI credentials are configured correctly."
                ),
                {agent_name: []},
                model_name,
            )

        # Fallback to direct Gemini
        logger.info("Agent '%s' falling back to direct Gemini", agent_name)
        fallback_text = await self.invoke_direct(
            agent_name,
            session_id,
            user_message,
            db_world_knowledge=db_world_knowledge,
            db_product=db_product,
            db_model=db_model,
            db_instruction=db_instruction,
            db_description=db_description,
        )
        return fallback_text, {agent_name: []}, model_name


# Module-level singleton
agent_runner = AgentRunnerService()
