"""Agent Registry service — CRUD operations with validation and audit logging."""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import AgentRegistry
from backend.schemas.agent import AgentCreate, AgentUpdate
from backend.services.audit_log import AuditLogService

VALID_AGENT_TYPES = {"specialized", "concierge"}


class AgentNameExistsError(Exception):
    """Raised when attempting to register an agent with a duplicate name."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.code = "AGENT_NAME_EXISTS"
        super().__init__(f"Agent with name '{name}' already exists")


class AgentNotFoundError(Exception):
    """Raised when an agent cannot be found by name."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Agent '{name}' not found")


class InvalidAgentTypeError(Exception):
    """Raised when agent_type is not a valid value."""

    def __init__(self, agent_type: str) -> None:
        self.agent_type = agent_type
        super().__init__(f"Invalid agent_type '{agent_type}'. Must be one of: {', '.join(sorted(VALID_AGENT_TYPES))}")


class AgentRegistryService:
    """Service for managing agent registry CRUD operations."""

    def __init__(self, audit_log: AuditLogService | None = None) -> None:
        self._audit = audit_log or AuditLogService()

    async def register(self, session: AsyncSession, data: AgentCreate) -> AgentRegistry:
        """Register a new agent.

        Validates name uniqueness and required fields, persists the record,
        and emits a lifecycle audit event.

        Raises:
            AgentNameExistsError: If an agent with the same name already exists.
            InvalidAgentTypeError: If agent_type is not valid.
        """
        if data.agent_type not in VALID_AGENT_TYPES:
            raise InvalidAgentTypeError(data.agent_type)

        existing = await session.get(AgentRegistry, data.name)
        if existing is not None:
            raise AgentNameExistsError(data.name)

        agent = AgentRegistry(
            name=data.name,
            display_name=data.display_name,
            description=data.description,
            instruction=data.instruction,
            product=data.product,
            agent_type=data.agent_type,
            adk_agent_class=data.adk_agent_class,
            model_config_json=data.model_config_json,
            reasoning_config_json=data.reasoning_config_json,
            generate_content_config_json=data.generate_content_config_json,
            allow_world_knowledge=data.allow_world_knowledge,
            intent_control_enabled=data.intent_control_enabled,
            lifecycle_status="registered",
        )
        session.add(agent)
        await session.flush()

        await self._audit.append(
            session,
            event_type="lifecycle",
            agent_name=data.name,
            details={"action": "registered"},
        )

        return agent

    async def get(self, session: AsyncSession, name: str) -> AgentRegistry:
        """Get an agent by name.

        Raises:
            AgentNotFoundError: If no agent with the given name exists.
        """
        agent = await session.get(AgentRegistry, name)
        if agent is None:
            raise AgentNotFoundError(name)
        return agent

    async def list_agents(
        self,
        session: AsyncSession,
        *,
        product: str | None = None,
        agent_type: str | None = None,
        status: str | None = None,
    ) -> list[AgentRegistry]:
        """List agents with optional filters.

        Args:
            session: Async database session.
            product: Filter by product area.
            agent_type: Filter by agent type.
            status: Filter by lifecycle status.

        Returns:
            List of matching AgentRegistry records.
        """
        stmt = select(AgentRegistry)

        if product is not None:
            stmt = stmt.where(AgentRegistry.product == product)
        if agent_type is not None:
            stmt = stmt.where(AgentRegistry.agent_type == agent_type)
        if status is not None:
            stmt = stmt.where(AgentRegistry.lifecycle_status == status)

        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def update(self, session: AsyncSession, name: str, data: AgentUpdate) -> AgentRegistry:
        """Update an agent's configuration.

        Only non-None fields in data are applied.

        Raises:
            AgentNotFoundError: If no agent with the given name exists.
        """
        agent = await session.get(AgentRegistry, name)
        if agent is None:
            raise AgentNotFoundError(name)

        update_fields = data.model_dump(exclude_unset=True)
        if "agent_type" in update_fields and update_fields["agent_type"] not in VALID_AGENT_TYPES:
            raise InvalidAgentTypeError(str(update_fields["agent_type"]))
        for field, value in update_fields.items():
            setattr(agent, field, value)

        await session.flush()
        await session.refresh(agent)
        return agent

    async def deregister(self, session: AsyncSession, name: str) -> AgentRegistry:
        """Deregister an agent by setting its status to 'deregistered'.

        Emits a lifecycle audit event.

        Raises:
            AgentNotFoundError: If no agent with the given name exists.
        """
        agent = await session.get(AgentRegistry, name)
        if agent is None:
            raise AgentNotFoundError(name)

        agent.lifecycle_status = "deregistered"
        await session.flush()
        await session.refresh(agent)

        await self._audit.append(
            session,
            event_type="lifecycle",
            agent_name=name,
            details={"action": "deregistered"},
        )

        return agent
