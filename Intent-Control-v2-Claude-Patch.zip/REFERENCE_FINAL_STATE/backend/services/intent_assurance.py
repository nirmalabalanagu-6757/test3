"""Pre-flight, regression, conflict, and shadow assurance for Intent Control."""

from __future__ import annotations

import os
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import AgentRegistry
from backend.models.intent import IntentRule
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.schemas.intent import (
    IntentAssuranceCheck,
    IntentCandidate,
    IntentConflict,
    IntentDecision,
    IntentReadinessReport,
    IntentRegressionCase,
    IntentRegressionResult,
)
from backend.services.action_template import (
    ActionTemplateConfigurationError,
    ActionTemplateNotFoundError,
    ActionTemplateService,
)
from backend.services.intent_control import IntentConfigurationError, IntentControlService


class IntentAssuranceService:
    """Prove that a rule is safe enough to activate without executing it."""

    def __init__(self, intents: IntentControlService | None = None) -> None:
        self._intents = intents or IntentControlService()
        self._actions = ActionTemplateService()

    async def list_reports(
        self,
        session: AsyncSession,
    ) -> tuple[list[IntentReadinessReport], list[IntentConflict]]:
        rules = list(
            (
                await session.execute(
                    select(IntentRule).order_by(IntentRule.name.asc())
                )
            ).scalars().all()
        )
        reports = [await self.readiness(session, rule, all_rules=rules) for rule in rules]
        conflicts: list[IntentConflict] = []
        seen: set[tuple[str, str]] = set()
        for report in reports:
            for conflict in report.conflicts:
                pair = tuple(sorted((conflict.intent_id, conflict.other_intent_id)))
                if pair not in seen:
                    seen.add(pair)
                    conflicts.append(conflict)
        return reports, conflicts

    async def readiness(
        self,
        session: AsyncSession,
        rule: IntentRule,
        *,
        all_rules: list[IntentRule] | None = None,
    ) -> IntentReadinessReport:
        checks: list[IntentAssuranceCheck] = []

        def add(code: str, severity: str, message: str) -> None:
            checks.append(
                IntentAssuranceCheck(
                    code=code,
                    severity=severity,
                    message=message,
                )
            )

        required_agents = {rule.target_agent}
        optional_agents: set[str] = set()
        if rule.fallback_agent:
            optional_agents.add(rule.fallback_agent)
        if rule.aggregator_agent:
            required_agents.add(rule.aggregator_agent)

        raw_steps = list(rule.workflow_json or [])
        for raw_step in raw_steps:
            if not isinstance(raw_step, dict):
                add("workflow.invalid_step", "blocker", "A workflow step is not a JSON object")
                continue
            agent_name = str(raw_step.get("agent") or "").strip()
            if agent_name:
                (required_agents if raw_step.get("required", True) else optional_agents).add(agent_name)
            fallback_name = str(raw_step.get("fallback_agent") or "").strip()
            if fallback_name:
                optional_agents.add(fallback_name)

        for agent_name in sorted(required_agents | optional_agents):
            required = agent_name in required_agents
            agent = await session.get(AgentRegistry, agent_name)
            if agent is None:
                add(
                    "agent.missing",
                    "blocker" if required else "warning",
                    f"{'Required' if required else 'Fallback'} agent '{agent_name}' does not exist",
                )
                continue
            if agent.intent_control_enabled is False:
                add(
                    "agent.intent_disabled",
                    "blocker" if required else "warning",
                    f"Intent Control is disabled for agent '{agent_name}'",
                )
            if agent.lifecycle_status != "running":
                add(
                    "agent.not_running",
                    "warning",
                    f"Agent '{agent_name}' is currently {agent.lifecycle_status}; configuration is valid but runtime routing may be unavailable",
                )

        configured_sources = list(rule.allowed_source_agents_json or [])
        disabled_sources = 0
        for source_name in configured_sources:
            source = await session.get(AgentRegistry, source_name)
            if source is None:
                add(
                    "source_agent.missing",
                    "blocker",
                    f"Allowed source agent '{source_name}' does not exist",
                )
            elif source.intent_control_enabled is False:
                disabled_sources += 1
                add(
                    "source_agent.intent_disabled",
                    "warning",
                    f"Allowed source agent '{source_name}' currently has Intent Control disabled",
                )
        if configured_sources and disabled_sources == len(configured_sources):
            add(
                "source_agent.none_enabled",
                "blocker",
                "All explicitly allowed source agents have Intent Control disabled",
            )

        tool_bindings: set[tuple[str, str]] = set()
        workflow_tool_names: set[str] = set()
        direct_steps = 0
        llm_steps = 0
        if not raw_steps:
            llm_steps = 1
            tool_bindings.update(
                (str(name), rule.target_agent)
                for name in (rule.allowed_tools_json or [])
            )
            if not rule.allowed_tools_json:
                add(
                    "tools.implicit_allowlist",
                    "warning",
                    "The default agent workflow has no explicit per-intent tool allowlist",
                )

        for raw_step in raw_steps:
            if not isinstance(raw_step, dict):
                continue
            step_id = str(raw_step.get("id") or "unknown")
            agent_name = str(raw_step.get("agent") or rule.target_agent)
            reference = str(raw_step.get("action_template") or "").strip()
            configured_tools = [str(name) for name in (raw_step.get("tools") or [])]
            connection_ref = str(raw_step.get("connection_ref") or "").strip()
            if connection_ref:
                if configured_tools and configured_tools != [connection_ref]:
                    add(
                        "workflow.connection_mismatch",
                        "blocker",
                        f"Step '{step_id}' connection_ref '{connection_ref}' must be its only allowed tool",
                    )
                workflow_tool_names.add(connection_ref)
                tool_bindings.add((connection_ref, agent_name))
            for tool_name in configured_tools:
                normalized_tool = str(tool_name)
                workflow_tool_names.add(normalized_tool)
                tool_bindings.add((normalized_tool, agent_name))
            if not reference:
                llm_steps += 1
                continue
            try:
                action = await self._actions.resolve_reference(session, reference)
                await self._actions.validate_for_agent(session, action, agent_name)
                if connection_ref and connection_ref != action.tool_name:
                    add(
                        "workflow.action_connection_mismatch",
                        "blocker",
                        f"Step '{step_id}' connection_ref '{connection_ref}' does not match action-template tool '{action.tool_name}'",
                    )
                workflow_tool_names.add(action.tool_name)
                tool_bindings.add((action.tool_name, agent_name))
                if action.execution_mode == "direct":
                    direct_steps += 1
                else:
                    llm_steps += 1
                    add(
                        "workflow.agent_action",
                        "warning",
                        f"Step '{step_id}' uses agent-mode action template '{reference}' and will invoke an LLM",
                    )
            except (ActionTemplateConfigurationError, ActionTemplateNotFoundError) as exc:
                add("action_template.invalid", "blocker", f"Step '{step_id}': {exc}")

        # A top-level allowlist is the union across workflow steps. Only names
        # not explicitly bound by a step are assumed to belong to the target.
        if raw_steps:
            tool_bindings.update(
                (str(name), rule.target_agent)
                for name in (rule.allowed_tools_json or [])
                if str(name) not in workflow_tool_names
            )

        checked_bindings: set[tuple[str, str]] = set()
        for tool_name, agent_name in sorted(tool_bindings):
            binding = (tool_name, agent_name)
            if binding in checked_bindings:
                continue
            checked_bindings.add(binding)
            await self._check_tool(session, tool_name, agent_name, add)

        if llm_steps:
            add(
                "workflow.llm_required",
                "warning",
                f"{llm_steps} workflow step(s) require an agent LLM; deterministic matching still occurs before those calls",
            )
        if direct_steps and not llm_steps and not rule.aggregator_agent:
            add(
                "workflow.direct_only",
                "info",
                "All workflow steps use direct Action Templates; execution does not require an LLM",
            )
        if rule.aggregator_agent:
            add(
                "workflow.llm_aggregator",
                "warning",
                f"Aggregator '{rule.aggregator_agent}' adds one final LLM synthesis call",
            )
        if rule.response_mode in {"llm_summary", "detailed"}:
            add(
                "response.llm_mode",
                "warning",
                f"Response mode '{rule.response_mode}' can add an LLM response-processing call",
            )

        regression_results = await self.run_regression_cases(session, rule)
        if not regression_results:
            add(
                "regression.none",
                "warning",
                "No regression cases are configured; add representative positive and negative requests before production",
            )
        else:
            failures = [result for result in regression_results if not result.passed]
            if failures:
                for failure in failures:
                    add(
                        "regression.failed",
                        "blocker",
                        f"Regression '{failure.name}' failed: {failure.message}",
                    )
            else:
                add(
                    "regression.passed",
                    "info",
                    f"All {len(regression_results)} configured regression case(s) passed",
                )

        if all_rules is None:
            all_rules = list((await session.execute(select(IntentRule))).scalars().all())
        conflicts = [
            conflict
            for other in all_rules
            if other.id != rule.id
            if (conflict := self.conflict_between(rule, other)) is not None
        ]
        for conflict in conflicts:
            add(
                "matching.conflict",
                conflict.severity,
                f"Potential overlap with '{conflict.other_intent_name}' ({conflict.score:.2f}): {', '.join(conflict.reasons)}",
            )

        blockers = [item for item in checks if item.severity == "blocker"]
        warnings = [item for item in checks if item.severity == "warning"]
        status = "blocked" if blockers else "warning" if warnings else "ready"
        return IntentReadinessReport(
            intent_id=rule.id,
            intent_name=rule.name,
            lifecycle_state=self.lifecycle_state(rule),
            status=status,
            ready_to_activate=not blockers,
            checks=checks,
            regression_results=regression_results,
            conflicts=conflicts,
        )

    async def _check_tool(
        self,
        session: AsyncSession,
        tool_name: str,
        agent_name: str,
        add: Any,
    ) -> None:
        tool = await session.get(ToolRegistry, tool_name)
        if tool is None:
            add("tool.missing", "blocker", f"Tool '{tool_name}' does not exist")
            return
        if tool.lifecycle_status != "active":
            add(
                "tool.inactive",
                "blocker",
                f"Tool '{tool_name}' is {tool.lifecycle_status}, not active",
            )
        aliases = {agent_name, agent_name.replace("-", "_")}
        if not agent_name.endswith("_agent"):
            aliases.add(f"{agent_name}_agent")
        assignment = await session.scalar(
            select(ToolAgentAssignment.tool_name).where(
                ToolAgentAssignment.tool_name == tool_name,
                ToolAgentAssignment.agent_name.in_(aliases),
            )
        )
        if assignment is None:
            add(
                "tool.unassigned",
                "blocker",
                f"Tool '{tool_name}' is not assigned to agent '{agent_name}'",
            )

        auth_type = str(tool.auth_type or "none")
        from backend.services.tool_loader import get_tool_callable

        builtin = get_tool_callable(tool.name)
        builtin_module = str(getattr(builtin, "__module__", ""))
        python_backed = builtin is not None
        python_skywise = builtin_module == "backend.tools.skywise_tools"
        target_is_skywise = "skywise" in str(tool.target_system or "").casefold()
        environment_bearer = bool(
            os.getenv("FOUNDRY_TOKEN") or os.getenv("SKYWISE_TOKEN")
        )
        registry_bearer = auth_type == "bearer" and bool(tool.credential_encrypted)
        credential_auth = {
            "api_key",
            "api_key_query",
            "bearer",
            "basic",
            "digest",
            "oauth2_client_credentials",
        }
        if auth_type in credential_auth and not tool.credential_encrypted:
            add(
                "tool.credential_missing",
                "blocker",
                f"Tool '{tool_name}' uses {auth_type} authentication but has no stored credential",
            )
        if auth_type == "oauth2_client_credentials" and (
            not tool.oauth2_token_url or not tool.oauth2_client_id
        ):
            add(
                "tool.oauth_incomplete",
                "blocker",
                f"Tool '{tool_name}' is missing its OAuth token URL or client ID",
            )
        if target_is_skywise and not (
            registry_bearer or (python_skywise and environment_bearer)
        ):
            add(
                "tool.skywise_credential_missing",
                "blocker",
                f"Skywise tool '{tool_name}' has neither a saved bearer credential nor a FOUNDRY_TOKEN/SKYWISE_TOKEN runtime setting",
            )
        elif python_skywise and environment_bearer and not registry_bearer:
            add(
                "tool.skywise_environment_credential",
                "info",
                f"Skywise tool '{tool_name}' will use the runtime environment bearer token",
            )
        if tool.tool_type == "api_connector" and not tool.api_endpoint:
            add(
                "tool.endpoint_missing",
                "blocker",
                f"API connector '{tool_name}' has no endpoint",
            )
        if (
            tool.connector_type == "skywise_v2_read_table"
            and not python_backed
            and auth_type != "bearer"
        ):
            add(
                "tool.skywise_auth",
                "blocker",
                f"Skywise v2 tool '{tool_name}' must use bearer authentication",
            )
        if (
            tool.tool_type == "api_connector"
            and auth_type == "none"
            and not python_backed
        ):
            add(
                "tool.unauthenticated_api",
                "warning",
                f"API connector '{tool_name}' is configured without authentication",
            )
        if tool.verify_tls is False:
            add(
                "tool.tls_disabled",
                "warning",
                f"TLS certificate verification is disabled for tool '{tool_name}'",
            )

    async def run_regression_cases(
        self,
        session: AsyncSession,
        rule: IntentRule,
    ) -> list[IntentRegressionResult]:
        results: list[IntentRegressionResult] = []
        for index, raw_case in enumerate(rule.test_cases_json or []):
            try:
                case = IntentRegressionCase.model_validate(raw_case)
            except Exception as exc:  # noqa: BLE001 - malformed stored data is reported as a failed case
                results.append(
                    IntentRegressionResult(
                        name=f"case-{index + 1}",
                        passed=False,
                        expected_decision="route",
                        actual_decision="unavailable",
                        message=f"Invalid test case: {exc}",
                    )
                )
                continue
            try:
                decision = await self.evaluate_rule(session, rule, case)
            except Exception as exc:  # noqa: BLE001 - assurance must report, never hide, invalid stored state
                decision = IntentDecision(
                    decision="unavailable",
                    source_agent=case.source_agent,
                    reason=f"Regression evaluation failed: {exc}",
                )
            results.append(self.compare_case(case, decision))
        return results

    async def evaluate_rule(
        self,
        session: AsyncSession,
        rule: IntentRule,
        case: IntentRegressionCase,
    ) -> IntentDecision:
        """Evaluate one specific rule without considering its lifecycle or executing it."""
        source_agent, source_enabled = await self._intents._source_agent_state(
            session, case.source_agent
        )
        if not source_enabled:
            return IntentDecision(
                decision="no_match",
                source_agent=source_agent,
                reason=f"Intent Control is disabled for source agent '{source_agent}'",
            )
        if not self._intents._source_agent_allowed(rule, source_agent):
            return IntentDecision(
                decision="no_match",
                source_agent=source_agent,
                reason=f"Source agent '{source_agent}' is outside this rule's access scope",
            )
        if not await self._intents._target_agent_accepts_intents(session, rule):
            return IntentDecision(
                decision="no_match",
                source_agent=source_agent,
                reason="A required target agent has Intent Control disabled",
            )

        scored = self._intents._score_rule(rule, case.query)
        if scored is None or scored.score < rule.min_confidence:
            return IntentDecision(
                decision="no_match",
                source_agent=source_agent,
                confidence=round(scored.score, 4) if scored else 0.0,
                reason="The rule did not meet its confidence threshold",
            )
        candidate = IntentCandidate(
            intent_id=rule.id,
            intent_name=rule.name,
            target_agent=rule.target_agent,
            score=round(scored.score, 4),
            priority=rule.priority,
            matched_by=list(scored.matched_by),
        )
        base = self._intents._decision_base(scored, [candidate])
        base["source_agent"] = source_agent
        extracted, missing = self._intents._extract_parameters(
            rule,
            case.query,
            case.parameters_json,
        )
        if missing:
            return IntentDecision(
                decision="clarify",
                **base,
                reason=f"Required parameters are missing: {', '.join(missing)}",
                extracted_parameters=extracted,
                missing_parameters=missing,
            )
        if rule.requires_confirmation and not case.confirmed:
            return IntentDecision(
                decision="confirm",
                **base,
                reason="The selected workflow requires confirmation",
                extracted_parameters=extracted,
            )
        try:
            resolved = await self._intents._resolved_intent(
                session,
                scored,
                extracted,
            )
        except IntentConfigurationError as exc:
            return IntentDecision(
                decision="unavailable",
                **base,
                reason=str(exc),
                extracted_parameters=extracted,
            )
        return IntentDecision(
            decision="route",
            **base,
            reason=f"Rule '{rule.name}' matched in regression evaluation",
            extracted_parameters=extracted,
            selected_intents=[resolved],
            orchestration_mode=resolved.orchestration_mode,
        )

    @staticmethod
    def compare_case(
        case: IntentRegressionCase,
        decision: IntentDecision,
    ) -> IntentRegressionResult:
        failures: list[str] = []
        if decision.decision != case.expected_decision:
            failures.append(
                f"expected decision {case.expected_decision}, got {decision.decision}"
            )
        if (
            case.expected_target_agent is not None
            and decision.target_agent != case.expected_target_agent
        ):
            failures.append(
                f"expected target {case.expected_target_agent}, got {decision.target_agent or 'none'}"
            )
        for key, expected in case.expected_parameters_json.items():
            actual = decision.extracted_parameters.get(key)
            if actual != expected:
                failures.append(
                    f"parameter {key} expected {expected!r}, got {actual!r}"
                )
        return IntentRegressionResult(
            name=case.name,
            passed=not failures,
            expected_decision=case.expected_decision,
            actual_decision=decision.decision,
            expected_target_agent=case.expected_target_agent,
            actual_target_agent=decision.target_agent,
            message="Passed" if not failures else "; ".join(failures),
            confidence=decision.confidence,
        )

    @classmethod
    def conflict_between(
        cls,
        rule: IntentRule,
        other: IntentRule,
    ) -> IntentConflict | None:
        source_overlap = cls._source_scope(rule) & cls._source_scope(other)
        if not source_overlap:
            return None

        reasons: list[str] = []
        scores: list[float] = []
        left_keywords = {str(item).casefold() for item in (rule.keywords_json or [])}
        right_keywords = {str(item).casefold() for item in (other.keywords_json or [])}
        common = left_keywords & right_keywords
        union = left_keywords | right_keywords
        if common and (len(common) >= 2 or len(union) == 1):
            score = len(common) / len(union)
            if score >= 0.35:
                scores.append(min(0.94, 0.55 + 0.39 * score))
                reasons.append(f"overlapping keywords: {', '.join(sorted(common))}")

        left_examples = [" ".join(str(item).casefold().split()) for item in (rule.examples_json or [])]
        right_examples = [" ".join(str(item).casefold().split()) for item in (other.examples_json or [])]
        if left_examples and right_examples:
            best = max(
                IntentControlService._example_similarity(left, right)
                for left in left_examples
                for right in right_examples
            )
            if best >= 0.80:
                scores.append(best)
                reasons.append(f"similar examples ({best:.2f})")

        regex_overlap = set(rule.regex_patterns_json or []) & set(other.regex_patterns_json or [])
        if regex_overlap:
            scores.append(0.99)
            reasons.append("identical regular expression")

        if not scores:
            return None
        score = max(scores)
        if score < 0.75:
            return None
        other_is_live = bool(other.enabled or getattr(other, "shadow_mode", False))
        severity = (
            "blocker"
            if score >= 0.95 and rule.target_agent != other.target_agent and other_is_live
            else "warning"
        )
        reasons.append(f"shared source scope: {', '.join(sorted(source_overlap))}")
        return IntentConflict(
            intent_id=rule.id,
            intent_name=rule.name,
            other_intent_id=other.id,
            other_intent_name=other.name,
            severity=severity,
            score=round(score, 4),
            reasons=reasons,
        )

    @classmethod
    def _source_scope(cls, rule: IntentRule) -> set[str]:
        configured = list(rule.allowed_source_agents_json or [])
        values = configured or ["concierge", rule.target_agent]
        return {IntentControlService._normalize_agent_name(item) for item in values}

    @staticmethod
    def lifecycle_state(rule: IntentRule) -> str:
        if bool(rule.enabled):
            return "active"
        if bool(getattr(rule, "shadow_mode", False)):
            return "shadow"
        return "draft"
