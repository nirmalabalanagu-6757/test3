"""Dynamic execution engine for multi-intent, multi-agent workflows."""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import logging
import time
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from backend.models.intent import IntentExecutionRun, IntentExecutionStep
from backend.schemas.intent import IntentDecision, ResolvedIntent, ResolvedWorkflowStep
from backend.services.action_template import ActionTemplateService

logger = logging.getLogger(__name__)
_MISSING_INPUT = object()

AgentInvoker = Callable[..., Awaitable[tuple[str, dict[str, list[str]], str]]]


@dataclass
class StepResult:
    step_id: str
    agent: str
    status: str
    output: str = ""
    tools: dict[str, list[str]] = field(default_factory=dict)
    model: str | None = None
    attempts: int = 0
    error: str | None = None


@dataclass
class IntentResult:
    intent_name: str
    status: str
    output: str
    steps: dict[str, StepResult]
    tools: dict[str, list[str]]
    model: str | None = None


@dataclass
class OrchestrationResult:
    run_id: str
    status: str
    response: str
    tools: dict[str, list[str]]
    model: str


class IntentOrchestrator:
    """Execute immutable workflow snapshots produced by Intent Control."""

    _MAX_CONTEXT_CHARS = 64_000
    _SUMMARY_CHARS = 2_000

    async def execute(
        self,
        decision: IntentDecision,
        *,
        session_id: str,
        user_id: str,
        user_message: str,
        invoke_agent: AgentInvoker,
    ) -> OrchestrationResult:
        if not decision.selected_intents:
            raise ValueError("Intent decision has no executable workflow snapshot")

        run_id = str(uuid.uuid4())
        started = time.monotonic()
        await self._create_run(run_id, decision, session_id, user_id, user_message)

        selected = decision.selected_intents
        source_agent = decision.source_agent or "concierge"
        total_timeout = max(item.execution_options.total_timeout_sec for item in selected)
        status = "completed"
        error: str | None = None
        try:
            async with asyncio.timeout(total_timeout):
                if len(selected) == 1:
                    intent_results = [
                        await self._execute_intent(
                            run_id,
                            selected[0],
                            source_agent,
                            session_id,
                            user_id,
                            user_message,
                            invoke_agent,
                        )
                    ]
                else:
                    intent_results = list(
                        await asyncio.gather(
                            *[
                                self._execute_intent(
                                    run_id,
                                    item,
                                    source_agent,
                                    session_id,
                                    user_id,
                                    user_message,
                                    invoke_agent,
                                )
                                for item in selected
                            ]
                        )
                    )
            if any(result.status == "failed" for result in intent_results):
                status = "partial" if any(result.status == "completed" for result in intent_results) else "failed"
            response = self._combine_intent_results(intent_results)
            tools = self._merge_tool_maps(*(result.tools for result in intent_results))
            model = ", ".join(sorted({result.model for result in intent_results if result.model})) or "intent-control"
        except TimeoutError:
            status = "failed"
            error = f"Intent workflow exceeded its {total_timeout}-second total timeout"
            response = error
            tools = {}
            model = "intent-control"
        except Exception as exc:
            logger.exception("Intent workflow run %s failed", run_id)
            status = "failed"
            error = str(exc)
            response = f"The intent workflow failed: {exc}"
            tools = {}
            model = "intent-control"

        duration_ms = int((time.monotonic() - started) * 1_000)
        await self._finish_run(run_id, status, response, error, duration_ms)
        return OrchestrationResult(
            run_id=run_id,
            status=status,
            response=response,
            tools=tools,
            model=model,
        )

    async def _execute_intent(
        self,
        run_id: str,
        intent: ResolvedIntent,
        source_agent: str,
        session_id: str,
        user_id: str,
        user_message: str,
        invoke_agent: AgentInvoker,
    ) -> IntentResult:
        pending = {step.id: step for step in intent.workflow_steps}
        results: dict[str, StepResult] = {}
        max_parallel = intent.execution_options.max_parallel_steps

        while pending:
            blocked = [
                step_id
                for step_id, step in pending.items()
                if any(
                    dependency in results and results[dependency].status != "completed"
                    for dependency in step.depends_on
                )
            ]
            for step_id in blocked:
                step = pending.pop(step_id)
                result = StepResult(
                    step_id=step.id,
                    agent=step.agent,
                    status="skipped",
                    error="A dependency failed",
                )
                results[step.id] = result
                await self._record_skipped_step(run_id, intent.intent_name, step, result.error)

            ready = [step for step in pending.values() if set(step.depends_on) <= set(results)]
            if not ready:
                if pending:
                    raise RuntimeError(f"Workflow '{intent.intent_name}' cannot make progress; check dependencies")
                break

            if intent.orchestration_mode in {"single", "sequential"}:
                batch = ready[:1]
            else:
                batch = ready[:max_parallel]

            batch_results = await asyncio.gather(
                *[
                    self._execute_step(
                        run_id,
                        intent,
                        step,
                        source_agent,
                        session_id,
                        user_id,
                        user_message,
                        results,
                        invoke_agent,
                    )
                    for step in batch
                ]
            )
            stop = False
            for step, result in zip(batch, batch_results, strict=True):
                pending.pop(step.id, None)
                results[step.id] = result
                if (
                    result.status == "failed"
                    and step.on_failure == "stop"
                    and (step.required or not intent.execution_options.continue_on_optional_failure)
                ):
                    stop = True
            if stop:
                for step in list(pending.values()):
                    results[step.id] = StepResult(
                        step_id=step.id,
                        agent=step.agent,
                        status="skipped",
                        error="A required workflow step failed",
                    )
                    await self._record_skipped_step(run_id, intent.intent_name, step, "A required workflow step failed")
                pending.clear()

        successful = [result for result in results.values() if result.status == "completed"]
        failed_required = [
            results[step.id]
            for step in intent.workflow_steps
            if step.required and results[step.id].status != "completed"
        ]
        status = "failed" if failed_required else "completed"
        output, model, aggregate_tools = await self._aggregate_intent(
            intent,
            successful,
            session_id,
            user_id,
            user_message,
            invoke_agent,
        )
        tools = self._merge_tool_maps(*(result.tools for result in results.values()), aggregate_tools)
        return IntentResult(intent.intent_name, status, output, results, tools, model)

    async def _execute_step(
        self,
        run_id: str,
        intent: ResolvedIntent,
        step: ResolvedWorkflowStep,
        source_agent: str,
        session_id: str,
        user_id: str,
        user_message: str,
        previous: dict[str, StepResult],
        invoke_agent: AgentInvoker,
    ) -> StepResult:
        if not self._condition_matches(step.condition, previous, intent.extracted_parameters):
            await self._record_skipped_step(run_id, intent.intent_name, step, "Condition evaluated to false")
            return StepResult(step.id, step.agent, "skipped", error="Condition evaluated to false")

        record_id = await self._start_step(run_id, intent.intent_name, step)
        started = time.monotonic()
        authorized, policy_reason = await self._authorize_step(
            run_id,
            intent.intent_name,
            step,
            previous,
            session_id,
            user_id,
            source_agent=source_agent,
        )
        if not authorized:
            result = StepResult(
                step.id,
                step.agent,
                "failed",
                attempts=0,
                error=policy_reason,
            )
            await self._finish_step(record_id, result, 0)
            return result

        prompt = self._build_step_prompt(intent, step, user_message, previous)
        attempts = 0
        last_error: Exception | None = None
        agents_to_try = [step.agent]
        if step.on_failure == "fallback" and step.fallback_agent:
            agents_to_try.append(step.fallback_agent)

        for agent_name in agents_to_try:
            if agent_name != step.agent:
                fallback_step = step.model_copy(update={"agent": agent_name})
                fallback_allowed, fallback_reason = await self._authorize_step(
                    run_id,
                    intent.intent_name,
                    fallback_step,
                    previous,
                    session_id,
                    user_id,
                    source_agent=source_agent,
                )
                if not fallback_allowed:
                    last_error = RuntimeError(fallback_reason)
                    continue
            for _ in range(step.retry_count + 1):
                attempts += 1
                try:
                    if step.resolved_action and step.resolved_action.execution_mode == "direct":
                        invocation = self._invoke_action_template(
                            run_id=run_id,
                            intent=intent,
                            step=step,
                            agent_name=agent_name,
                            session_id=session_id,
                            user_id=user_id,
                            user_message=user_message,
                            previous=previous,
                        )
                    else:
                        invocation = invoke_agent(
                            agent_name=agent_name,
                            session_id=session_id,
                            user_id=user_id,
                            user_message=prompt,
                            allowed_tool_names=list(step.tools) if step.tools else None,
                            intent_context={
                                "intent_name": intent.intent_name,
                                "workflow_version": intent.workflow_version,
                                "workflow_step": step.id,
                                "connection_ref": step.connection_ref,
                                "risk_classification": "workflow",
                                "response_mode": intent.response_mode,
                                "response_template": intent.response_template,
                                "response_options": intent.response_options,
                                "parameters": intent.extracted_parameters,
                                "action_template": (step.resolved_action.reference if step.resolved_action else None),
                            },
                            _skip_intent_control=True,
                        )
                    response, tools, model = await asyncio.wait_for(invocation, timeout=step.timeout_sec)
                    duration_ms = int((time.monotonic() - started) * 1_000)
                    result = StepResult(
                        step.id,
                        agent_name,
                        "completed",
                        response,
                        tools,
                        model,
                        attempts,
                    )
                    await self._finish_step(record_id, result, duration_ms)
                    return result
                except Exception as exc:  # noqa: BLE001 - retry/fallback policy handles it
                    last_error = exc
                    logger.warning(
                        "Intent run %s step %s attempt %d failed: %s",
                        run_id,
                        step.id,
                        attempts,
                        exc,
                    )

        duration_ms = int((time.monotonic() - started) * 1_000)
        result = StepResult(
            step.id,
            agents_to_try[-1],
            "failed",
            attempts=attempts,
            error=str(last_error or "Unknown workflow step failure"),
        )
        await self._finish_step(record_id, result, duration_ms)
        return result

    async def _invoke_action_template(
        self,
        *,
        run_id: str,
        intent: ResolvedIntent,
        step: ResolvedWorkflowStep,
        agent_name: str,
        session_id: str,
        user_id: str,
        user_message: str,
        previous: dict[str, StepResult],
    ) -> tuple[str, dict[str, list[str]], str]:
        """Execute one validated action snapshot without an additional LLM call."""
        action = step.resolved_action
        if action is None:
            raise RuntimeError("Direct action execution requires a resolved action snapshot")
        if step.connection_ref and step.connection_ref != action.tool_name:
            raise RuntimeError(
                f"Workflow connection '{step.connection_ref}' does not match "
                f"action-template tool '{action.tool_name}'"
            )
        rendered = self._render_action(intent, step, user_message, previous)

        from backend.database import async_session_factory
        from backend.services.audit_log import AuditLogService
        from backend.services.tool_loader import get_tool_callable_async

        async with async_session_factory() as db:
            service = ActionTemplateService()
            await service.validate_for_agent(db, action, agent_name)
            tool = await get_tool_callable_async(db, action.tool_name)
            if tool is None:
                raise RuntimeError(f"Action-template tool '{action.tool_name}' has no active executable runtime")

        arguments = rendered.tool_arguments
        if action.execution_options.strict_tool_arguments:
            signature = inspect.signature(tool)
            accepts_kwargs = any(
                parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in signature.parameters.values()
            )
            if not accepts_kwargs:
                unknown = sorted(set(arguments) - set(signature.parameters))
                if unknown:
                    raise RuntimeError(
                        f"Action template '{action.reference}' supplies unsupported tool "
                        f"arguments: {', '.join(unknown)}"
                    )
                try:
                    signature.bind(**arguments)
                except TypeError as exc:
                    raise RuntimeError(
                        f"Action template '{action.reference}' does not satisfy tool '{action.tool_name}': {exc}"
                    ) from exc

        result = tool(**arguments)
        if inspect.isawaitable(result):
            result = await result
        result = self._limit_action_output(
            result,
            max_rows=action.policy.max_rows,
            max_response_bytes=action.policy.max_response_bytes,
        )
        ActionTemplateService.validate_output(result, action.output_schema_json)
        if isinstance(result, str):
            response = result
        else:
            response = json.dumps(result, default=str, ensure_ascii=False, indent=2)

        try:
            async with async_session_factory() as db:
                await AuditLogService().append(
                    db,
                    "tool_invocation",
                    agent_name=agent_name,
                    session_id=session_id,
                    user_id=user_id,
                    tool_name=action.tool_name,
                    details={
                        "action": "action_template_direct_execution",
                        "run_id": run_id,
                        "intent_name": intent.intent_name,
                        "step_id": step.id,
                        "connection_ref": step.connection_ref or action.tool_name,
                        "action_template": action.reference,
                        "action_template_checksum": action.checksum,
                        "argument_names": sorted(arguments),
                    },
                    request_summary=(f"Direct action {action.reference} with {len(arguments)} validated argument(s)"),
                    response_summary=response[: self._SUMMARY_CHARS],
                )
                await db.commit()
        except Exception:
            logger.exception("Failed to audit direct action-template invocation %s", action.reference)
        return response, {agent_name: [action.tool_name]}, "action-template"

    @staticmethod
    def _limit_action_output(
        value: Any,
        *,
        max_rows: int,
        max_response_bytes: int,
    ) -> Any:
        if isinstance(value, list):
            value = value[:max_rows]
        elif isinstance(value, dict):
            value = dict(value)
            for key in ("results", "data", "rows", "items"):
                if isinstance(value.get(key), list):
                    value[key] = value[key][:max_rows]
        encoded = json.dumps(value, default=str, ensure_ascii=False).encode()
        if len(encoded) > max_response_bytes:
            raise RuntimeError(f"Action-template response exceeded max_response_bytes={max_response_bytes}")
        return value

    async def _authorize_step(
        self,
        run_id: str,
        intent_name: str,
        step: ResolvedWorkflowStep,
        previous: dict[str, StepResult],
        session_id: str,
        user_id: str,
        *,
        source_agent: str = "concierge",
    ) -> tuple[bool, str]:
        """Enforce and record every agent-to-agent edge before execution."""
        source_agents = {
            previous[dependency].agent
            for dependency in step.depends_on
            if dependency in previous and previous[dependency].status == "completed"
        } or {source_agent}
        try:
            from backend.database import async_session_factory
            from backend.services.audit_log import AuditLogService
            from backend.services.communication_policy import CommunicationPolicyService

            async with async_session_factory() as db:
                policy = CommunicationPolicyService()
                audit = AuditLogService()
                for source in sorted(source_agents):
                    decision = await policy.check_policy(db, source, step.agent)
                    event_type = "delegation" if decision.decision == "allow" else "policy_violation"
                    await audit.append(
                        db,
                        event_type,
                        session_id=session_id,
                        user_id=user_id,
                        source_agent=source,
                        target_agent=step.agent,
                        details={
                            "action": "intent_workflow_delegation",
                            "run_id": run_id,
                            "intent_name": intent_name,
                            "step_id": step.id,
                            "decision": decision.decision,
                            "matched_rule_id": decision.matched_rule_id,
                            "reason": decision.reason,
                        },
                    )
                    if decision.decision == "deny":
                        await db.commit()
                        return False, (f"Communication policy denied {source} -> {step.agent}: {decision.reason}")
                await db.commit()
            return True, "Communication policy allowed all workflow edges"
        except Exception:
            logger.exception(
                "Communication policy check failed for run %s step %s; preserving configured fail-open behavior",
                run_id,
                step.id,
            )
            return True, "Communication policy service unavailable; fail-open behavior applied"

    async def _aggregate_intent(
        self,
        intent: ResolvedIntent,
        successful: list[StepResult],
        session_id: str,
        user_id: str,
        user_message: str,
        invoke_agent: AgentInvoker,
    ) -> tuple[str, str | None, dict[str, list[str]]]:
        if not successful:
            return f"Intent '{intent.intent_name}' produced no successful step results.", None, {}

        rendered = self._render_step_results(successful)
        if intent.response_mode == "template" and intent.response_template:
            response = (
                intent.response_template.replace("{intent}", intent.intent_name)
                .replace("{query}", user_message)
                .replace("{results}", rendered)
            )
            return response, None, {}

        if intent.aggregator_agent and intent.response_mode in {"auto", "llm_summary", "detailed"}:
            prompt = (
                f"Synthesize the completed workflow results for intent '{intent.intent_name}'.\n"
                "Use only the supplied results, preserve important identifiers, and clearly identify failures.\n\n"
                f"Original request:\n{user_message}\n\nResults:\n{rendered[: self._MAX_CONTEXT_CHARS]}"
            )
            response, tools, model = await invoke_agent(
                agent_name=intent.aggregator_agent,
                session_id=session_id,
                user_id=user_id,
                user_message=prompt,
                allowed_tool_names=[],
                intent_context={
                    "intent_name": intent.intent_name,
                    "workflow_step": "aggregate",
                    "response_mode": intent.response_mode,
                    "parameters": intent.extracted_parameters,
                },
                _skip_intent_control=True,
            )
            return response, model, tools

        if len(successful) == 1 and intent.response_mode in {"auto", "direct"}:
            result = successful[0]
            return result.output, result.model, {}
        return rendered, successful[-1].model, {}

    @staticmethod
    def _condition_matches(
        condition: dict[str, Any],
        previous: dict[str, StepResult],
        parameters: dict[str, Any],
    ) -> bool:
        if not condition:
            return True
        source = str(condition.get("source") or "")
        operator = str(condition.get("operator") or "equals")
        expected = condition.get("value")
        if source.startswith("parameters."):
            actual: Any = parameters.get(source.split(".", 1)[1])
        elif source.startswith("steps."):
            parts = source.split(".")
            result = previous.get(parts[1]) if len(parts) > 1 else None
            field_name = parts[2] if len(parts) > 2 else "status"
            actual = getattr(result, field_name, None) if result else None
        else:
            return False
        if operator == "equals":
            return actual == expected
        if operator == "not_equals":
            return actual != expected
        if operator == "contains":
            return str(expected) in str(actual)
        if operator == "exists":
            return actual is not None
        return False

    def _build_step_prompt(
        self,
        intent: ResolvedIntent,
        step: ResolvedWorkflowStep,
        user_message: str,
        previous: dict[str, StepResult],
    ) -> str:
        dependency_outputs: dict[str, str] = {}
        step_config = {item.id: item for item in intent.workflow_steps}
        for dependency in step.depends_on:
            if dependency not in previous or previous[dependency].status != "completed":
                continue
            output = previous[dependency].output[: self._MAX_CONTEXT_CHARS]
            dependency_outputs[dependency] = output
            alias = step_config[dependency].output_key
            if alias:
                dependency_outputs[alias] = output
        mapped = {
            key: self._resolve_mapping(value, intent.extracted_parameters, dependency_outputs, user_message)
            for key, value in step.input_mapping.items()
        }
        context = json.dumps(
            {
                "intent": intent.intent_name,
                "parameters": intent.extracted_parameters,
                "mapped_inputs": mapped,
                "dependency_results": dependency_outputs,
            },
            default=str,
            ensure_ascii=False,
        )
        template = step.prompt_template or (
            "Complete workflow step '{step}' for intent '{intent}'. Address the original request "
            "using the approved tools and supplied structured context."
        )
        rendered = (
            template.replace("{step}", step.id)
            .replace("{intent}", intent.intent_name)
            .replace("{query}", user_message)
            .replace("{context}", context)
        )
        if "{context}" not in template:
            rendered += f"\n\nOriginal request:\n{user_message}\n\nWorkflow context:\n{context}"
        if step.resolved_action and step.resolved_action.execution_mode == "agent":
            action = self._render_action(intent, step, user_message, previous)
            contract = {
                "reference": action.reference,
                "checksum": action.checksum,
                "tool": step.resolved_action.tool_name,
                "template_type": step.resolved_action.template_type,
                "rendered_text": action.rendered_text,
                "tool_arguments": action.tool_arguments,
                "policy": step.resolved_action.policy.model_dump(mode="json"),
            }
            rendered += (
                "\n\nApproved action-template contract:\n"
                + json.dumps(contract, default=str, ensure_ascii=False)
                + "\nInvoke only the named tool with these validated arguments. "
                "Do not invent or broaden parameters."
            )
        return rendered[: self._MAX_CONTEXT_CHARS]

    def _render_action(
        self,
        intent: ResolvedIntent,
        step: ResolvedWorkflowStep,
        user_message: str,
        previous: dict[str, StepResult],
    ):
        action = step.resolved_action
        if action is None:
            raise RuntimeError("Workflow step has no resolved action template")
        dependency_outputs: dict[str, Any] = {}
        step_config = {item.id: item for item in intent.workflow_steps}
        for dependency in step.depends_on:
            result = previous.get(dependency)
            if result is None or result.status != "completed":
                continue
            dependency_outputs[dependency] = result.output
            alias = step_config[dependency].output_key
            if alias:
                dependency_outputs[alias] = result.output
        source_inputs = step.action_inputs or intent.extracted_parameters
        inputs = {
            key: self._resolve_action_value(
                value,
                intent.extracted_parameters,
                dependency_outputs,
                user_message,
            )
            for key, value in source_inputs.items()
        }
        inputs = {key: value for key, value in inputs.items() if value is not _MISSING_INPUT}
        return ActionTemplateService.render_snapshot(
            action,
            inputs=inputs,
            query=user_message,
            step_outputs=dependency_outputs,
        )

    @classmethod
    def _resolve_action_value(
        cls,
        value: Any,
        parameters: dict[str, Any],
        step_outputs: dict[str, Any],
        user_message: str,
    ) -> Any:
        if isinstance(value, dict):
            if "$from_step" in value:
                from backend.utils.intent_bindings import step_value

                return step_value(step_outputs, value["$from_step"])
            if "$parameter" in value:
                name = value["$parameter"]
                if name in parameters:
                    return parameters[name]
                if value.get("optional"):
                    return _MISSING_INPUT
                raise ValueError(f"Required action parameter '{name}' is unavailable")
            resolved = {
                key: cls._resolve_action_value(item, parameters, step_outputs, user_message)
                for key, item in value.items()
            }
            return {key: item for key, item in resolved.items() if item is not _MISSING_INPUT}
        if isinstance(value, list):
            resolved = [cls._resolve_action_value(item, parameters, step_outputs, user_message) for item in value]
            if any(item is _MISSING_INPUT for item in resolved):
                raise ValueError("Optional parameter omission is not supported inside an array")
            return resolved
        return cls._resolve_mapping(value, parameters, step_outputs, user_message)

    @staticmethod
    def _resolve_mapping(
        value: Any,
        parameters: dict[str, Any],
        step_outputs: dict[str, str],
        user_message: str,
    ) -> Any:
        if not isinstance(value, str):
            return value
        if value == "query":
            return user_message
        if value.startswith("parameters."):
            return parameters.get(value.split(".", 1)[1])
        if value.startswith("steps."):
            return step_outputs.get(value.split(".", 1)[1])
        return value

    @staticmethod
    def _render_step_results(results: list[StepResult]) -> str:
        sections = []
        for result in results:
            sections.append(f"### {result.step_id} — {result.agent}\n\n{result.output}")
        return "\n\n".join(sections)

    @staticmethod
    def _combine_intent_results(results: list[IntentResult]) -> str:
        if len(results) == 1:
            return results[0].output
        return "\n\n".join(f"## {result.intent_name}\n\n{result.output}" for result in results)

    @staticmethod
    def _merge_tool_maps(*maps: dict[str, list[str]]) -> dict[str, list[str]]:
        merged: dict[str, list[str]] = {}
        for item in maps:
            for agent, tools in item.items():
                destination = merged.setdefault(agent, [])
                for tool in tools:
                    if tool not in destination:
                        destination.append(tool)
        return merged

    async def _create_run(
        self,
        run_id: str,
        decision: IntentDecision,
        session_id: str,
        user_id: str,
        user_message: str,
    ) -> None:
        try:
            from backend.database import async_session_factory

            async with async_session_factory() as db:
                db.add(
                    IntentExecutionRun(
                        id=run_id,
                        session_id=session_id,
                        user_id=user_id,
                        source_agent=decision.source_agent,
                        query_hash=hashlib.sha256(user_message.encode()).hexdigest(),
                        query_summary=user_message[:512],
                        intent_names_json=[item.intent_name for item in decision.selected_intents],
                        orchestration_mode=decision.orchestration_mode,
                        workflow_versions_json={
                            item.intent_name: item.workflow_version for item in decision.selected_intents
                        },
                        status="running",
                    )
                )
                await db.commit()
        except Exception:
            logger.exception("Failed to persist intent execution run %s", run_id)

    async def _finish_run(
        self,
        run_id: str,
        status: str,
        response: str,
        error: str | None,
        duration_ms: int,
    ) -> None:
        try:
            from backend.database import async_session_factory

            async with async_session_factory() as db:
                run = await db.get(IntentExecutionRun, run_id)
                if run:
                    run.status = status
                    run.error = error
                    run.response_summary = response[: self._SUMMARY_CHARS]
                    run.finished_at = datetime.now(UTC)
                    run.duration_ms = duration_ms
                    await db.commit()
        except Exception:
            logger.exception("Failed to finish intent execution run %s", run_id)

    async def _start_step(
        self,
        run_id: str,
        intent_name: str,
        step: ResolvedWorkflowStep,
    ) -> str:
        record_id = str(uuid.uuid4())
        try:
            from backend.database import async_session_factory

            async with async_session_factory() as db:
                db.add(
                    IntentExecutionStep(
                        id=record_id,
                        run_id=run_id,
                        intent_name=intent_name,
                        step_id=step.id,
                        agent_name=step.agent,
                        action_template_name=(step.resolved_action.name if step.resolved_action else None),
                        action_template_version=(step.resolved_action.version if step.resolved_action else None),
                        allowed_tools_json=list(step.tools),
                        status="running",
                        started_at=datetime.now(UTC),
                    )
                )
                await db.commit()
        except Exception:
            logger.exception("Failed to persist intent step %s", record_id)
        return record_id

    async def _record_skipped_step(
        self,
        run_id: str,
        intent_name: str,
        step: ResolvedWorkflowStep,
        reason: str,
    ) -> None:
        try:
            from backend.database import async_session_factory

            async with async_session_factory() as db:
                now = datetime.now(UTC)
                db.add(
                    IntentExecutionStep(
                        id=str(uuid.uuid4()),
                        run_id=run_id,
                        intent_name=intent_name,
                        step_id=step.id,
                        agent_name=step.agent,
                        action_template_name=(step.resolved_action.name if step.resolved_action else None),
                        action_template_version=(step.resolved_action.version if step.resolved_action else None),
                        allowed_tools_json=list(step.tools),
                        status="skipped",
                        attempts=0,
                        error=reason,
                        started_at=now,
                        finished_at=now,
                        duration_ms=0,
                    )
                )
                await db.commit()
        except Exception:
            logger.exception("Failed to persist skipped intent step %s", step.id)

    async def _finish_step(
        self,
        record_id: str,
        result: StepResult,
        duration_ms: int,
    ) -> None:
        try:
            from backend.database import async_session_factory

            async with async_session_factory() as db:
                record = await db.get(IntentExecutionStep, record_id)
                if record:
                    record.agent_name = result.agent
                    record.status = result.status
                    record.attempts = result.attempts
                    record.used_tools_json = [
                        f"{agent}:{tool}" for agent, tools in result.tools.items() for tool in tools
                    ]
                    record.output_summary = result.output[: self._SUMMARY_CHARS] or None
                    record.error = result.error
                    record.finished_at = datetime.now(UTC)
                    record.duration_ms = duration_ms
                    await db.commit()
        except Exception:
            logger.exception("Failed to finish intent step %s", record_id)


intent_orchestrator = IntentOrchestrator()
