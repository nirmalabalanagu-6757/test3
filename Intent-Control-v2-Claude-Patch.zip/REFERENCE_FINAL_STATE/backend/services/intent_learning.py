"""Approval-gated, database-driven intent learning from unmatched requests."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import UTC, datetime
from difflib import SequenceMatcher
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.action_template import ActionTemplate
from backend.models.agent import AgentRegistry
from backend.models.intent import IntentLearningCandidate, IntentRule
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.schemas.intent import IntentRuleCreate, IntentRuleUpdate
from backend.services.action_template import (
    ActionTemplateConfigurationError,
    ActionTemplateNotFoundError,
    ActionTemplateService,
)
from backend.services.audit_log import AuditLogService
from backend.services.intent_control import IntentControlService
from backend.services.intent_trace import ToolCallTrace
from backend.services.intent_workflow_learning import compile_workflow

_TOKEN_RE = re.compile(r"[a-z][a-z0-9_.-]*", flags=re.IGNORECASE)
_UUID_RE = re.compile(
    r"\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b",
    flags=re.IGNORECASE,
)
_DATE_RE = re.compile(r"\b\d{4}-\d{2}-\d{2}(?:[T ][0-9:.+-]+Z?)?\b")
_IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_NUMBER_RE = re.compile(r"(?<![a-z])[-+]?\d+(?:\.\d+)?(?![a-z])", flags=re.IGNORECASE)
_SECRET_ASSIGNMENT_RE = re.compile(
    r"(?i)\b(api[_ -]?key|access[_ -]?token|token|password|secret|authorization)"
    r"\s*[:=]\s*([^\s,;]+)"
)
_BEARER_RE = re.compile(r"(?i)\bbearer\s+[^\s,;]+")
_LONG_TOKEN_RE = re.compile(r"\b[A-Za-z0-9_-]{40,}\b")

_STOP_WORDS = {
    "a",
    "an",
    "and",
    "are",
    "can",
    "could",
    "for",
    "from",
    "give",
    "i",
    "in",
    "is",
    "it",
    "me",
    "my",
    "of",
    "on",
    "please",
    "the",
    "this",
    "to",
    "want",
    "with",
    "would",
}
_OPERATION_GROUPS = {
    "read": {"check", "describe", "fetch", "find", "get", "list", "read", "search", "show", "status"},
    "create": {"add", "create", "enable", "register", "start"},
    "update": {"change", "edit", "modify", "rotate", "set", "update"},
    "delete": {"delete", "disable", "drop", "remove", "stop"},
    "backup": {"backup", "snapshot"},
    "restore": {"recover", "restore"},
    "execute": {"execute", "run", "trigger"},
}
_QUERY_INPUT_NAMES = {"input", "message", "prompt", "query", "request", "text"}
_RISK_ORDER = {"read_only": 0, "write": 1, "execute": 2}


class IntentLearningCandidateNotFoundError(Exception):
    def __init__(self, candidate_id: str) -> None:
        super().__init__(f"Intent learning candidate '{candidate_id}' not found")
        self.candidate_id = candidate_id


class IntentLearningCandidateStateError(Exception):
    pass


class IntentLearningService:
    """Capture unmatched prompts and propose portable intent rules without an LLM."""

    _MAX_EXAMPLES = 20
    _MAX_MODELS = 20
    _CLUSTER_LIMIT = 200
    _CLUSTER_THRESHOLD = 0.80
    _RELATED_RULE_THRESHOLD = 0.80

    def __init__(self, audit_log: AuditLogService | None = None) -> None:
        self._audit = audit_log or AuditLogService()
        self._intents = IntentControlService(self._audit)
        self._actions = ActionTemplateService(self._audit)

    async def list_candidates(
        self,
        session: AsyncSession,
        *,
        status: str | None = None,
        source_agent: str | None = None,
        limit: int = 200,
    ) -> list[IntentLearningCandidate]:
        stmt = select(IntentLearningCandidate)
        if status:
            stmt = stmt.where(IntentLearningCandidate.status == status)
        if source_agent:
            stmt = stmt.where(IntentLearningCandidate.source_agent == source_agent)
        stmt = stmt.order_by(IntentLearningCandidate.last_seen_at.desc()).limit(limit)
        return list((await session.execute(stmt)).scalars().all())

    async def get_candidate(
        self,
        session: AsyncSession,
        candidate_id: str,
    ) -> IntentLearningCandidate:
        candidate = await session.get(IntentLearningCandidate, candidate_id)
        if candidate is None:
            raise IntentLearningCandidateNotFoundError(candidate_id)
        return candidate

    async def observe(
        self,
        session: AsyncSession,
        *,
        source_agent: str,
        query: str,
        contributing_agents: dict[str, list[str]] | None = None,
        model_name: str | None = None,
        tool_trace: ToolCallTrace | None = None,
    ) -> IntentLearningCandidate | None:
        """Record one unmatched top-level request when agent capture is enabled."""
        if "intent_control" in (contributing_agents or {}):
            return None

        agents = list((await session.execute(select(AgentRegistry))).scalars().all())
        canonical_agents = {self._normalize_name(agent.name): agent for agent in agents}
        source_record = canonical_agents.get(self._normalize_name(source_agent))
        if source_record is None or source_record.intent_control_enabled is False:
            return None

        redacted = self._redact_query(query)[:20_000].strip()
        if len(redacted) < 3:
            return None
        normalized = self._normalize_query(redacted)
        if not normalized:
            return None

        observed_agents = {agent: list(names) for agent, names in (contributing_agents or {}).items()}
        if tool_trace is not None:
            for call in tool_trace.calls:
                observed_agents.setdefault(call.agent, []).append(call.tool)
        route = await self._sanitize_route(
            session,
            source_record.name,
            observed_agents,
            canonical_agents,
        )
        observation: dict[str, Any] = {}
        proposal, execution_mode, confidence = await self._build_proposal(
            session, source_record.name, [redacted], route, 1,
            tool_trace=tool_trace, observation=observation, query=query,
        )
        plan_key = observation.get("plan_key", "")
        route_marker = self._route_marker(route)
        fingerprint = hashlib.sha256(
            f"{source_record.name.casefold()}\n{normalized}\n{route_marker}\n{plan_key}".encode()
        ).hexdigest()
        # Serialize this source agent's short learning update so concurrent
        # near-identical prompts cannot create separate pending clusters.
        await session.execute(
            text("SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))"),
            {"key": f"intent-learning:{source_record.name}"},
        )

        related_rule, related_score = await self._find_related_rule(
            session,
            source_record.name,
            normalized,
            route,
            plan_key=plan_key,
            observed_plan=proposal,
        )

        candidate = await session.scalar(
            select(IntentLearningCandidate).where(
                IntentLearningCandidate.status == "pending",
                IntentLearningCandidate.source_agent == source_record.name,
                IntentLearningCandidate.fingerprint == fingerprint,
            )
        )
        if candidate is not None and not self._routes_match(
            dict(candidate.observed_route_json or {}),
            route,
        ):
            candidate = None
        if candidate is not None and (candidate.observation_json or {}).get("plan_key", "") != plan_key:
            candidate = None
        if candidate is None and related_rule is not None:
            candidate = await self._find_pending_rule_update(
                session,
                source_record.name,
                related_rule.id,
                route,
                plan_key=plan_key,
            )
        if candidate is None:
            candidate = await self._find_similar_pending(
                session,
                source_record.name,
                normalized,
                route,
                plan_key=plan_key,
            )

        now = datetime.now(UTC)
        if candidate is None:
            candidate = IntentLearningCandidate(
                status="pending",
                source_agent=source_record.name,
                fingerprint=fingerprint,
                normalized_pattern=normalized,
                examples_json=[redacted],
                observed_route_json=route,
                model_names_json=[model_name] if model_name else [],
                occurrence_count=1,
                observation_json=observation,
                first_seen_at=now,
                last_seen_at=now,
            )
            session.add(candidate)
        else:
            candidate.examples_json = self._append_unique(
                list(candidate.examples_json or []),
                redacted,
                self._MAX_EXAMPLES,
            )
            candidate.observed_route_json = self._merge_routes(
                dict(candidate.observed_route_json or {}),
                route,
            )
            if model_name:
                candidate.model_names_json = self._append_unique(
                    list(candidate.model_names_json or []),
                    model_name,
                    self._MAX_MODELS,
                )
            candidate.occurrence_count = int(candidate.occurrence_count or 0) + 1
            candidate.last_seen_at = now

        proposal["examples_json"] = list(candidate.examples_json or [])
        proposal["keywords_json"] = self._keywords(proposal["examples_json"])
        proposal["min_confidence"] = 0.70 if candidate.occurrence_count >= 3 else 0.75
        candidate.observation_json = observation
        if related_rule is not None:
            proposal = self._extend_rule_proposal(
                related_rule,
                list(candidate.examples_json or []),
                learned_proposal=proposal if plan_key else None,
            )
            execution_mode = await self._existing_rule_execution_mode(
                session,
                IntentRule(**proposal),
            )
            # Existing-intent candidates display deterministic similarity,
            # rather than the confidence estimate used for new proposals.
            confidence = related_score
            candidate.suggested_intent_id = related_rule.id
        else:
            candidate.suggested_intent_id = None
        candidate.proposed_rule_json = proposal
        candidate.proposed_execution_mode = execution_mode
        candidate.proposal_confidence = confidence
        await session.flush()
        return candidate

    async def approve(
        self,
        session: AsyncSession,
        candidate_id: str,
        *,
        reviewed_by: str,
        rule: IntentRuleCreate | None = None,
        note: str | None = None,
    ) -> tuple[IntentLearningCandidate, IntentRule]:
        candidate = await self.get_candidate(session, candidate_id)
        self._require_pending(candidate)

        suggested = (
            await session.get(IntentRule, candidate.suggested_intent_id) if candidate.suggested_intent_id else None
        )

        if rule is None:
            raw = dict(candidate.proposed_rule_json or {})
            if suggested is None or raw.get("name") != suggested.name:
                raw["name"] = await self._available_rule_name(
                    session,
                    str(raw.get("name") or "learned.intent"),
                )
            rule = IntentRuleCreate.model_validate(raw)

        previous_version: int | None = None
        extends_existing = suggested is not None
        if extends_existing:
            if rule.name != suggested.name:
                raise IntentLearningCandidateStateError(
                    "A similar-intent proposal must update the suggested intent; "
                    "it cannot create a duplicate under another name"
                )
            previous_version = int(suggested.workflow_version or 1)
            expected_version = previous_version + 1
            if rule.workflow_version != expected_version:
                raise IntentLearningCandidateStateError(
                    f"Intent '{suggested.name}' changed after this proposal was generated. "
                    f"Review a refreshed proposal for workflow version {expected_version}."
                )
            intent = await self._intents.update_rule(
                session,
                suggested.id,
                IntentRuleUpdate(**rule.model_dump(mode="json")),
                updated_by=reviewed_by,
            )
        else:
            intent = await self._intents.create_rule(
                session,
                rule,
                created_by=reviewed_by,
            )
        candidate.status = "approved"
        candidate.approved_intent_id = intent.id
        candidate.reviewed_by = reviewed_by
        candidate.review_note = note
        candidate.reviewed_at = datetime.now(UTC)
        await self._audit.append(
            session,
            "config_change",
            user_id=reviewed_by,
            agent_name=candidate.source_agent,
            details={
                "action": (
                    "intent_learning_candidate_extended" if extends_existing else "intent_learning_candidate_approved"
                ),
                "candidate_id": candidate.id,
                "intent_id": intent.id,
                "intent_name": intent.name,
                "execution_mode": candidate.proposed_execution_mode,
                "occurrence_count": candidate.occurrence_count,
                "similarity": candidate.proposal_confidence if extends_existing else None,
                "previous_workflow_version": previous_version,
                "workflow_version": intent.workflow_version,
            },
        )
        await session.flush()
        return candidate, intent

    async def reject(
        self,
        session: AsyncSession,
        candidate_id: str,
        *,
        reviewed_by: str,
        note: str | None = None,
    ) -> IntentLearningCandidate:
        candidate = await self.get_candidate(session, candidate_id)
        self._require_pending(candidate)
        candidate.status = "rejected"
        candidate.reviewed_by = reviewed_by
        candidate.review_note = note
        candidate.reviewed_at = datetime.now(UTC)
        await self._audit.append(
            session,
            "config_change",
            user_id=reviewed_by,
            agent_name=candidate.source_agent,
            details={
                "action": "intent_learning_candidate_rejected",
                "candidate_id": candidate.id,
                "occurrence_count": candidate.occurrence_count,
            },
        )
        await session.flush()
        return candidate

    async def _find_related_rule(
        self,
        session: AsyncSession,
        source_agent: str,
        normalized_query: str,
        observed_route: dict[str, list[str]],
        *,
        plan_key: str = "",
        observed_plan: dict[str, Any] | None = None,
    ) -> tuple[IntentRule | None, float]:
        rules = list((await session.execute(select(IntentRule).where(IntentRule.enabled.is_(True)))).scalars().all())
        query_signature = self._operation_signature(normalized_query)
        best: IntentRule | None = None
        best_score = 0.0
        for rule in rules:
            previous_plan_key = (rule.parameter_config_json or {}).get("learning_plan_key")
            if plan_key:
                if previous_plan_key and previous_plan_key != plan_key:
                    continue
                if not previous_plan_key:
                    old_actions = [step.get("action_template") for step in (rule.workflow_json or [])]
                    new_actions = [step.get("action_template") for step in (observed_plan or {}).get("workflow_json", [])]
                    if any(old_actions) and old_actions != new_actions:
                        continue
            if not IntentControlService._source_agent_allowed(rule, source_agent):
                continue
            if not await self._rule_matches_observed_route(
                session,
                rule,
                observed_route,
            ):
                continue
            references = list(rule.examples_json or []) + list(rule.keywords_json or [])
            for reference in references:
                normalized_reference = self._normalize_query(str(reference))
                reference_signature = self._operation_signature(normalized_reference)
                if query_signature and reference_signature and query_signature != reference_signature:
                    continue
                score = self._similarity(normalized_query, normalized_reference)
                if score < self._RELATED_RULE_THRESHOLD:
                    continue
                if score > best_score:
                    best = rule
                    best_score = score
        return best, round(best_score, 4)

    async def _rule_matches_observed_route(
        self,
        session: AsyncSession,
        rule: IntentRule,
        observed_route: dict[str, list[str]],
    ) -> bool:
        observed = {
            self._normalize_name(agent): set(tools)
            for agent, tools in observed_route.items()
            if tools
        }
        if not observed:
            return True

        configured: dict[str, set[str]] = {}
        raw_steps = list(rule.workflow_json or [])
        if not raw_steps:
            tools = {str(name) for name in (rule.allowed_tools_json or [])}
            if tools:
                configured[self._normalize_name(rule.target_agent)] = tools
            return configured == observed

        for raw_step in raw_steps:
            if not isinstance(raw_step, dict):
                return False
            agent = self._normalize_name(
                str(raw_step.get("agent") or rule.target_agent)
            )
            tools = {str(name) for name in (raw_step.get("tools") or [])}
            connection_ref = str(raw_step.get("connection_ref") or "").strip()
            if connection_ref:
                tools.add(connection_ref)
            action_reference = str(raw_step.get("action_template") or "").strip()
            if action_reference:
                try:
                    action = await self._actions.resolve_reference(
                        session,
                        action_reference,
                    )
                except (
                    ActionTemplateConfigurationError,
                    ActionTemplateNotFoundError,
                ):
                    return False
                tools.add(action.tool_name)
            if tools:
                configured.setdefault(agent, set()).update(tools)
        return configured == observed

    @staticmethod
    def _extend_rule_proposal(
        rule: IntentRule,
        examples: list[str],
        *,
        learned_proposal: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        raw = {field: getattr(rule, field) for field in IntentRuleCreate.model_fields}
        proposal = IntentRuleCreate.model_validate(raw).model_dump(mode="json")
        proposal["workflow_version"] = int(rule.workflow_version or 1) + 1
        proposal["examples_json"] = IntentLearningService._merge_unique(
            list(proposal.get("examples_json") or []),
            examples,
            100,
        )
        if proposal["match_strategy"] in {"hybrid", "keywords"}:
            proposal["keywords_json"] = IntentLearningService._merge_unique(
                list(proposal.get("keywords_json") or []),
                IntentLearningService._keywords(examples),
                100,
            )
        if learned_proposal and not (rule.parameter_config_json or {}).get("learning_plan_key"):
            # An older route-only intent can acquire a fully observed workflow
            # through the same reviewed v2 proposal. Keep its identity, access,
            # response settings, and any stricter confirmation/risk policy.
            for field in ("workflow_json", "orchestration_mode", "parameter_config_json"):
                proposal[field] = learned_proposal[field]
            for field in ("max_total_steps", "max_agents"):
                proposal["execution_options_json"][field] = max(
                    proposal["execution_options_json"][field], learned_proposal["execution_options_json"][field])
            proposal["risk_classification"] = IntentLearningService._higher_risk(
                proposal["risk_classification"], learned_proposal["risk_classification"])
            proposal["requires_confirmation"] = proposal["requires_confirmation"] or learned_proposal["requires_confirmation"]
        return proposal

    async def _find_pending_rule_update(
        self,
        session: AsyncSession,
        source_agent: str,
        intent_id: str,
        route: dict[str, list[str]],
        *,
        plan_key: str = "",
    ) -> IntentLearningCandidate | None:
        """Return the one pending update entry for a route-compatible intent."""
        pending = list(
            (
                await session.execute(
                    select(IntentLearningCandidate)
                    .where(
                        IntentLearningCandidate.status == "pending",
                        IntentLearningCandidate.source_agent == source_agent,
                        IntentLearningCandidate.suggested_intent_id == intent_id,
                    )
                    .order_by(IntentLearningCandidate.last_seen_at.desc())
                    .limit(self._CLUSTER_LIMIT)
                )
            )
            .scalars()
            .all()
        )
        for item in pending:
            if (
                item.suggested_intent_id == intent_id
                and (item.observation_json or {}).get("plan_key", "") == plan_key
                and item.source_agent == source_agent
                and self._routes_match(dict(item.observed_route_json or {}), route)
            ):
                return item
        return None

    @staticmethod
    async def _existing_rule_execution_mode(
        session: AsyncSession,
        rule: IntentRule,
    ) -> str:
        steps = list(rule.workflow_json or [])
        if not steps:
            return "agent_llm"
        action_service = ActionTemplateService()
        for step in steps:
            reference = step.get("action_template") if isinstance(step, dict) else None
            if not reference:
                return "multi_agent" if len(steps) > 1 else "agent_llm"
            try:
                action = await action_service.resolve_reference(session, str(reference))
            except (ActionTemplateConfigurationError, ActionTemplateNotFoundError):
                return "multi_agent" if len(steps) > 1 else "agent_llm"
            if action.execution_mode != "direct":
                return "multi_agent" if len(steps) > 1 else "agent_llm"
        if rule.aggregator_agent:
            return "multi_agent" if len(steps) > 1 else "agent_llm"
        return "direct_action"

    async def _find_similar_pending(
        self,
        session: AsyncSession,
        source_agent: str,
        normalized: str,
        route: dict[str, list[str]],
        *,
        plan_key: str = "",
    ) -> IntentLearningCandidate | None:
        pending = list(
            (
                await session.execute(
                    select(IntentLearningCandidate)
                    .where(
                        IntentLearningCandidate.status == "pending",
                        IntentLearningCandidate.source_agent == source_agent,
                    )
                    .order_by(IntentLearningCandidate.last_seen_at.desc())
                    .limit(self._CLUSTER_LIMIT)
                )
            )
            .scalars()
            .all()
        )
        signature = self._operation_signature(normalized)
        best: IntentLearningCandidate | None = None
        best_score = 0.0
        for item in pending:
            if (item.observation_json or {}).get("plan_key", "") != plan_key:
                continue
            if not self._routes_match(
                dict(item.observed_route_json or {}),
                route,
            ):
                continue
            item_signature = self._operation_signature(item.normalized_pattern)
            if signature and item_signature and signature != item_signature:
                continue
            score = self._similarity(normalized, item.normalized_pattern)
            if score >= self._CLUSTER_THRESHOLD and score > best_score:
                best = item
                best_score = score
        return best

    async def _sanitize_route(
        self,
        session: AsyncSession,
        source_agent: str,
        observed: dict[str, list[str]],
        canonical_agents: dict[str, AgentRegistry],
    ) -> dict[str, list[str]]:
        tools = list((await session.execute(select(ToolRegistry))).scalars().all())
        canonical_tools = {self._normalize_name(tool.name): tool for tool in tools}
        route: dict[str, list[str]] = {}
        for raw_agent, raw_tools in observed.items():
            agent = canonical_agents.get(self._normalize_name(str(raw_agent)))
            if agent is None:
                continue
            destination = route.setdefault(agent.name, [])
            for raw_tool in raw_tools or []:
                tool = canonical_tools.get(self._normalize_name(str(raw_tool)))
                if tool is None or tool.lifecycle_status != "active":
                    continue
                if tool.name not in destination:
                    destination.append(tool.name)

        source_is_concierge = self._normalize_name(source_agent) in {
            "concierge",
            "concierge_agent",
        }
        if source_is_concierge:
            # Intent workflows deliberately target specialized agents. When
            # Concierge answered by itself there is no safe target to invent;
            # preserve the candidate with an empty route for administrator
            # completion instead.
            route.pop(source_agent, None)
        if not route and not source_is_concierge:
            route[source_agent] = []
        return route

    async def _build_proposal(
        self,
        session: AsyncSession,
        source_agent: str,
        examples: list[str],
        route: dict[str, list[str]],
        occurrence_count: int,
        *,
        tool_trace: ToolCallTrace | None = None,
        observation: dict[str, Any] | None = None,
        query: str = "",
    ) -> tuple[dict[str, Any], str, float]:
        keywords = self._keywords(examples)
        target_agents = list(route)
        all_tools = list(dict.fromkeys(tool for tools in route.values() for tool in tools))
        tool_records = (
            {
                tool.name: tool
                for tool in (await session.execute(select(ToolRegistry).where(ToolRegistry.name.in_(all_tools))))
                .scalars()
                .all()
            }
            if all_tools
            else {}
        )
        template_records = (
            list(
                (
                    await session.execute(
                        select(ActionTemplate)
                        .where(
                            ActionTemplate.lifecycle_status == "active",
                            ActionTemplate.execution_mode == "direct",
                            ActionTemplate.tool_name.in_(all_tools),
                        )
                        .order_by(ActionTemplate.version.desc())
                    )
                )
                .scalars()
                .all()
            )
            if all_tools
            else []
        )
        assignments = (
            set(
                (
                    await session.execute(
                        select(
                            ToolAgentAssignment.agent_name,
                            ToolAgentAssignment.tool_name,
                        ).where(ToolAgentAssignment.tool_name.in_(all_tools))
                    )
                ).all()
            )
            if all_tools
            else set()
        )

        workflow: list[dict[str, Any]] = []
        parameter_properties: dict[str, Any] = {}
        required_parameters: list[str] = []
        direct_steps = 0
        risk = "read_only"
        for index, agent in enumerate(target_agents, start=1):
            agent_tools = list(route.get(agent, []))
            step: dict[str, Any] = {
                "id": self._step_id(agent, index),
                "agent": agent,
                "tools": agent_tools,
                "depends_on": [],
            }
            if len(agent_tools) == 1:
                # This is the stable connector identity. Credentials/endpoints
                # remain in Tool Registry and can be rotated without changing
                # the approved intent.
                step["connection_ref"] = agent_tools[0]
            direct = self._select_direct_template(
                template_records,
                agent,
                agent_tools,
                assignments,
            )
            if direct is not None:
                template, action_inputs, properties, required = direct
                step["action_template"] = f"{template.name}@{template.version}"
                step["action_inputs"] = action_inputs
                step["tools"] = [template.tool_name]
                step["connection_ref"] = template.tool_name
                parameter_properties.update(properties)
                required_parameters.extend(name for name in required if name not in required_parameters)
                direct_steps += 1
                policy = dict(template.policy_json or {})
                risk = self._higher_risk(
                    risk,
                    str(policy.get("risk_classification") or "read_only"),
                )
            for tool_name in agent_tools:
                tool = tool_records.get(tool_name)
                if tool is not None:
                    risk = self._higher_risk(risk, tool.risk_classification)
            workflow.append(step)

        learned_parameters: dict[str, Any] | None = None
        if tool_trace is not None and (tool_trace.calls or tool_trace.incomplete):
            learned = compile_workflow(
                tool_trace, route=route, templates=template_records,
                assignments=assignments, query=query,
            )
            if observation is not None:
                observation.update(learned.evidence)
            if learned.direct:
                workflow = learned.steps
                learned_parameters = learned.parameters
                direct_steps = len(workflow)
                # Version/operation, call order and data bindings define the
                # reusable plan. Resource values never enter this signature.
                plan_key = hashlib.sha256(json.dumps(workflow, sort_keys=True).encode()).hexdigest()
                learned_parameters["learning_plan_key"] = plan_key
                if observation is not None:
                    observation["plan_key"] = plan_key
            else:
                # An incomplete/ambiguous observation cannot approve a partial
                # replay. Retain ordinary agent execution plus review evidence.
                direct_steps = 0
                for step in workflow:
                    step.pop("action_template", None)
                    step.pop("action_inputs", None)
                parameter_properties, required_parameters = {}, []

        if workflow and direct_steps == len(workflow):
            execution_mode = "direct_action"
        elif len(workflow) > 1:
            execution_mode = "multi_agent"
        else:
            execution_mode = "agent_llm"

        confirmation = risk != "read_only"
        for step in workflow:
            for template in template_records:
                if step.get("action_template") == f"{template.name}@{template.version}":
                    policy = template.policy_json or {}
                    risk = self._higher_risk(risk, str(policy.get("risk_classification") or "read_only"))
                    confirmation = confirmation or bool(policy.get("requires_confirmation")) or risk != "read_only"

        slug = "-".join(keywords[:4]) or "observed-request"
        source_slug = re.sub(r"[^a-z0-9]+", "-", source_agent.casefold()).strip("-")
        name = f"learned.{source_slug}.{slug}"[:128].rstrip(".-")
        display = " ".join(word.title() for word in keywords[:6]) or "Observed Request"
        min_confidence = 0.70 if occurrence_count >= 3 else 0.75
        proposal_confidence = min(
            0.95,
            0.55 + min(occurrence_count, 5) * 0.05 + (0.10 if workflow and direct_steps == len(workflow) else 0),
        )
        if not target_agents:
            proposal_confidence = min(proposal_confidence, 0.40)
        proposal = {
            "name": name,
            "display_name": display,
            "description": (
                "Approval-gated rule proposed from "
                f"{occurrence_count} unmatched top-level request(s)."
                + (
                    " Select a specialized target agent before approval because no downstream route was observed."
                    if not target_agents
                    else ""
                )
            ),
            "enabled": True,
            "priority": 100,
            "match_strategy": "hybrid",
            "keyword_mode": "any",
            "keywords_json": keywords,
            "negative_keywords_json": [],
            "regex_patterns_json": [],
            "examples_json": examples[: self._MAX_EXAMPLES],
            "min_confidence": min_confidence,
            "ambiguity_margin": 0.10,
            "ambiguity_action": "clarify",
            "target_agent": target_agents[0] if target_agents else "",
            "fallback_agent": None,
            "allowed_source_agents_json": [source_agent],
            "allowed_tools_json": all_tools,
            "orchestration_mode": ("dag" if learned_parameters is not None and len(workflow) > 1
                                   else "parallel" if len(workflow) > 1 else "single"),
            "workflow_json": workflow,
            "allow_multi_intent": True,
            "max_intents": 5,
            "aggregator_agent": None,
            "execution_options_json": {
                "max_parallel_steps": min(max(len(workflow), 1), 10),
                "max_total_steps": max(len(workflow), 1),
                "max_agents": max(len(target_agents), 1),
                "total_timeout_sec": 600,
                "continue_on_optional_failure": True,
                "multi_intent_min_confidence": 0.75,
            },
            "workflow_version": 1,
            "parameter_config_json": learned_parameters or {
                "required": required_parameters,
                "properties": parameter_properties,
            },
            "risk_classification": risk,
            "requires_confirmation": confirmation,
            "response_mode": "direct" if len(workflow) == 1 else "internal_summary",
            "response_template": None,
            "response_options_json": {},
        }
        return proposal, execution_mode, round(proposal_confidence, 4)

    @classmethod
    def _select_direct_template(
        cls,
        templates: list[ActionTemplate],
        agent: str,
        tools: list[str],
        assignments: set[tuple[str, str]],
    ) -> tuple[ActionTemplate, dict[str, str], dict[str, Any], list[str]] | None:
        if len(tools) != 1:
            return None
        normalized_assignments = {
            (cls._normalize_name(assigned_agent), tool_name) for assigned_agent, tool_name in assignments
        }
        if (cls._normalize_name(agent), tools[0]) not in normalized_assignments:
            return None
        matches = []
        for template in templates:
            if template.tool_name != tools[0]:
                continue
            policy = dict(template.policy_json or {})
            allowed = [cls._normalize_name(item) for item in policy.get("allowed_agents", [])]
            if allowed and cls._normalize_name(agent) not in allowed:
                continue
            mapping = cls._action_input_mapping(dict(template.input_schema_json or {}))
            if mapping is not None:
                action_inputs, properties, required = mapping
                matches.append((template, action_inputs, properties, required))
        return matches[0] if len(matches) == 1 else None

    @staticmethod
    def _action_input_mapping(
        schema: dict[str, Any],
    ) -> tuple[dict[str, str], dict[str, Any], list[str]] | None:
        properties = schema.get("properties", {})
        if not isinstance(properties, dict):
            return None
        action_inputs: dict[str, str] = {}
        parameter_properties: dict[str, Any] = {}
        required_parameters: list[str] = []
        for raw_name in schema.get("required", []):
            name = str(raw_name)
            raw_spec = properties.get(name, {})
            spec = raw_spec if isinstance(raw_spec, dict) else {}
            if "default" in spec:
                continue
            if name.casefold() in _QUERY_INPUT_NAMES:
                action_inputs[name] = "query"
                continue
            pattern = spec.get("pattern")
            if not pattern:
                return None
            action_inputs[name] = f"parameters.{name}"
            parameter_properties[name] = {
                "type": spec.get("type", "string"),
                "pattern": str(pattern),
                "prompt": str(spec.get("description") or f"Provide {name}"),
            }
            required_parameters.append(name)
        return action_inputs, parameter_properties, required_parameters

    async def _available_rule_name(self, session: AsyncSession, proposed: str) -> str:
        base = proposed[:128].rstrip(".-") or "learned.intent"
        name = base
        suffix = 2
        while await session.scalar(select(IntentRule.id).where(IntentRule.name == name)):
            marker = f"-{suffix}"
            name = f"{base[: 128 - len(marker)]}{marker}"
            suffix += 1
        return name

    @staticmethod
    def _require_pending(candidate: IntentLearningCandidate) -> None:
        if candidate.status != "pending":
            raise IntentLearningCandidateStateError(f"Candidate '{candidate.id}' is already {candidate.status}")

    @staticmethod
    def _normalize_name(value: str) -> str:
        return value.strip().replace("-", "_").replace(" ", "_").casefold()

    @classmethod
    def _redact_query(cls, value: str) -> str:
        redacted = _BEARER_RE.sub("Bearer <secret>", value)
        redacted = _SECRET_ASSIGNMENT_RE.sub(lambda match: f"{match.group(1)}=<secret>", redacted)
        return _LONG_TOKEN_RE.sub("<secret>", redacted)

    @staticmethod
    def _normalize_query(value: str) -> str:
        normalized = value.casefold()
        normalized = _UUID_RE.sub("<uuid>", normalized)
        normalized = _DATE_RE.sub("<date>", normalized)
        normalized = _IP_RE.sub("<ip>", normalized)
        normalized = _NUMBER_RE.sub("<number>", normalized)
        return " ".join(normalized.split())

    @staticmethod
    def _operation_signature(value: str) -> tuple[str, ...]:
        tokens = set(_TOKEN_RE.findall(value.casefold()))
        return tuple(name for name, words in _OPERATION_GROUPS.items() if tokens & words)

    @staticmethod
    def _similarity(first: str, second: str) -> float:
        first_tokens = set(_TOKEN_RE.findall(first))
        second_tokens = set(_TOKEN_RE.findall(second))
        union = first_tokens | second_tokens
        jaccard = len(first_tokens & second_tokens) / len(union) if union else 0.0
        sequence = SequenceMatcher(None, first, second).ratio()
        return max(jaccard, sequence)

    @staticmethod
    def _append_unique(items: list[str], value: str, maximum: int) -> list[str]:
        markers = {item.casefold() for item in items}
        if value.casefold() not in markers:
            items.append(value)
        return items[-maximum:]

    @staticmethod
    def _merge_routes(
        existing: dict[str, list[str]],
        observed: dict[str, list[str]],
    ) -> dict[str, list[str]]:
        merged = {agent: list(tools) for agent, tools in existing.items()}
        for agent, tools in observed.items():
            destination = merged.setdefault(agent, [])
            for tool in tools:
                if tool not in destination:
                    destination.append(tool)
        return merged

    @staticmethod
    def _route_marker(route: dict[str, list[str]]) -> str:
        canonical = {
            str(agent): sorted({str(tool) for tool in tools})
            for agent, tools in sorted(route.items())
        }
        return json.dumps(canonical, sort_keys=True, separators=(",", ":"))

    @classmethod
    def _routes_match(
        cls,
        first: dict[str, list[str]],
        second: dict[str, list[str]],
    ) -> bool:
        return cls._route_marker(first) == cls._route_marker(second)

    @staticmethod
    def _merge_unique(
        existing: list[str],
        additions: list[str],
        maximum: int,
    ) -> list[str]:
        merged = list(existing)
        seen = {item.casefold() for item in merged}
        for item in additions:
            if item.casefold() not in seen:
                merged.append(item)
                seen.add(item.casefold())
        return merged[-maximum:]

    @staticmethod
    def _keywords(examples: list[str]) -> list[str]:
        counts: dict[str, int] = {}
        first_seen: dict[str, int] = {}
        index = 0
        for example in examples:
            normalized = IntentLearningService._normalize_query(example)
            for token in _TOKEN_RE.findall(normalized):
                if token in _STOP_WORDS or token in {"date", "ip", "number", "secret", "uuid"} or len(token) < 2:
                    continue
                counts[token] = counts.get(token, 0) + 1
                first_seen.setdefault(token, index)
                index += 1
        ranked = sorted(
            counts,
            key=lambda token: (-counts[token], first_seen[token], token),
        )
        return ranked[:8]

    @staticmethod
    def _meaningful_tokens(value: str) -> set[str]:
        return {
            token
            for token in _TOKEN_RE.findall(value.casefold())
            if token not in _STOP_WORDS and token not in {"date", "ip", "number", "secret", "uuid"} and len(token) >= 2
        }

    @staticmethod
    def _step_id(agent: str, index: int) -> str:
        base = re.sub(r"[^A-Za-z0-9_.-]+", "-", agent).strip("-.") or "agent"
        if not base[0].isalpha():
            base = f"agent-{base}"
        return f"{base[:110]}-{index}"

    @staticmethod
    def _higher_risk(first: str, second: str) -> str:
        valid_second = second if second in _RISK_ORDER else "execute"
        return max((first, valid_second), key=lambda item: _RISK_ORDER[item])
