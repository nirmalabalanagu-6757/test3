"""Schema-configured parameter extraction shared by learning and execution."""

from __future__ import annotations

import re
from datetime import UTC, date, datetime, timedelta
from typing import Any

from backend.services.action_template import ActionTemplateConfigurationError, ActionTemplateService

_ALIASES = {
    "row_limit": ["row limit", "limit", "first", "top"],
    "rowLimit": ["row limit", "limit", "first", "top"],
}


def aliases_for(name: str, spec: dict[str, Any]) -> list[str]:
    config = spec.get("x-intent", {})
    configured = config.get("aliases", []) if isinstance(config, dict) else []
    words = re.sub(r"([a-z])([A-Z])", r"\1 \2", name).replace("_", " ")
    return list(
        dict.fromkeys(
            [
                name,
                words,
                *_ALIASES.get(name, []),
                *(str(alias) for alias in configured if isinstance(alias, str) and alias.strip()),
            ]
        )
    )


def coerce(value: Any, spec: dict[str, Any]) -> Any:
    kind = spec.get("type")
    if isinstance(value, str):
        if kind == "integer":
            return int(value)
        if kind == "number":
            return float(value)
        if kind == "boolean":
            if value.casefold() not in {"true", "false", "yes", "no", "1", "0", "on", "off"}:
                raise ValueError("Invalid boolean")
            return value.casefold() in {"true", "yes", "1", "on"}
        for member in spec.get("enum", []):
            if isinstance(member, str) and value.casefold() == member.casefold():
                return member
    return value


def valid_value(name: str, value: Any, spec: dict[str, Any]) -> bool:
    try:
        ActionTemplateService._validate_property(name, value, spec)
        if spec.get("format") == "date":
            date.fromisoformat(value)
        return value is not None
    except (ActionTemplateConfigurationError, ValueError, TypeError):
        return False


def _date_matches(query: str, spec: dict[str, Any], today: date) -> list[tuple[Any, tuple[int, int]]]:
    role = spec.get("x-intent", {}).get("date_role", "single")
    matches: list[tuple[Any, tuple[int, int]]] = []
    for match in re.finditer(r"\b(today|yesterday|last\s+(\d{1,3})\s+days?)\b", query, re.IGNORECASE):
        phrase = match.group(1).casefold()
        if phrase in {"today", "yesterday"}:
            value = today - timedelta(days=phrase == "yesterday")
        elif role in {"start", "end"} and 1 <= int(match.group(2)) <= 366:
            value = today if role == "end" else today - timedelta(days=int(match.group(2)) - 1)
        else:
            matches.append((match.group(0), match.span()))
            continue
        matches.append((value.isoformat(), match.span()))
    return matches


def find_values(name: str, spec: dict[str, Any], query: str, *, today: date | None = None):
    """Return typed matches and spans; multiple different matches are ambiguous."""
    config = spec.get("x-intent", {})
    config = config if isinstance(config, dict) else {}
    matches: list[tuple[Any, tuple[int, int]]] = []
    pattern = config.get("pattern")
    # Existing rules used `pattern` both as extractor and validator. Keep their
    # extraction syntax while new schemas can separate these two concerns.
    if pattern or (spec.get("pattern") and not config):
        for match in re.finditer(str(pattern or spec["pattern"]), query, re.IGNORECASE):
            group = name if name in match.groupdict() else 1 if match.groups() else 0
            matches.append((match.group(group), match.span(group)))
    if config.get("extractor") == "date":
        matches.extend(_date_matches(query, spec, today or datetime.now(UTC).date()))
    if config.get("extractor") in {"label", "date", "enum"}:
        labels = "|".join(re.escape(alias) for alias in sorted(aliases_for(name, spec), key=len, reverse=True))
        pattern = rf"(?<![\w])(?:{labels})(?:\s*[:=]\s*|\s+)(?:\"([^\"]+)\"|'([^']+)'|([\w./:@+-]+))"
        for match in re.finditer(pattern, query, re.IGNORECASE):
            group = next(index for index in (1, 2, 3) if match.group(index) is not None)
            matches.append((match.group(group), match.span(group)))
        if config.get("extractor") == "enum" and not matches:
            for member in spec.get("enum", []):
                if not isinstance(member, str) or not member:
                    continue
                for match in re.finditer(rf"(?<!\w){re.escape(member)}(?!\w)", query, re.IGNORECASE):
                    matches.append((member, match.span()))
    typed = []
    for value, span in matches:
        try:
            typed.append((coerce(value, spec), span))
        except (ValueError, TypeError):
            typed.append((value, span))
    occurrence = config.get("occurrence")
    if isinstance(occurrence, int) and occurrence >= 0:
        return typed[occurrence : occurrence + 1]
    return typed


def extract_parameters(config: dict[str, Any], query: str, supplied: dict[str, Any], *, today: date | None = None):
    values = dict(supplied)
    invalid: list[str] = []
    properties = config.get("properties", {})
    for name, raw_spec in properties.items() if isinstance(properties, dict) else []:
        spec = raw_spec if isinstance(raw_spec, dict) else {}
        modern = bool(spec.get("x-intent"))
        if name not in values:
            matches = find_values(name, spec, query, today=today)
            if matches:
                first = matches[0][0]
                if any(type(value) is not type(first) or value != first for value, _ in matches):
                    invalid.append(name)
                    continue
                values[name] = first
            elif "default" in spec:
                values[name] = spec["default"]
        # Preserve legacy extractor patterns; modern extraction has a separate
        # schema pattern so the complete scalar can be validated independently.
        if modern and name in values and not valid_value(name, values[name], spec):
            invalid.append(name)
            values.pop(name)
    missing = [str(name) for name in config.get("required", []) if values.get(str(name)) in (None, "")]
    return values, list(dict.fromkeys([*missing, *invalid]))


def parameterized_example(query: str, config: dict[str, Any]) -> str:
    spans: list[tuple[int, int, str]] = []
    for name, spec in config.get("properties", {}).items():
        if not isinstance(spec, dict) or not spec.get("x-intent"):
            continue
        matches = find_values(name, spec, query)
        if matches and all(valid_value(name, value, spec) and value == matches[0][0] for value, _ in matches):
            spans.extend((start, end, name) for _, (start, end) in matches)
    # A shared relative range supplies both start and end; mask it once.
    result = query
    last_start = len(query) + 1
    for start, end, name in sorted(set(spans), reverse=True):
        if end > last_start:
            continue
        result = result[:start] + " parameter " + result[end:]
        last_start = start
    return " ".join(result.casefold().split())
