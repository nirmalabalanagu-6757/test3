"""Database-driven intent matching, governance, and administration."""

from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import AgentRegistry
from backend.models.intent import IntentRule, IntentShadowEvaluation
from backend.models.tool import ToolRegistry
from backend.schemas.intent import (
    IntentCandidate,
    IntentDecision,
    IntentExecutionOptions,
    IntentRuleCreate,
    IntentRuleUpdate,
    IntentWorkflowStep,
    ResolvedIntent,
    ResolvedWorkflowStep,
)
from backend.services.action_template import (
    ActionTemplateConfigurationError,
    ActionTemplateNotFoundError,
    ActionTemplateService,
)
from backend.services.audit_log import AuditLogService

logger = logging.getLogger(__name__)

_RULE_FIELDS = tuple(IntentRuleCreate.model_fields)
_TOKEN_RE = re.compile(r"[\w.-]+", re.UNICODE)
_BEARER_RE = re.compile(r"(?i)\bbearer\s+[^\s,;]+")
_SECRET_ASSIGNMENT_RE = re.compile(
    r"(?i)\b(api[_ -]?key|access[_ -]?token|token|password|secret|authorization)"
    r"\s*[:=]\s*([^\s,;]+)"
)
_LONG_TOKEN_RE = re.compile(r"\b[A-Za-z0-9_-]{40,}\b")


class IntentNotFoundError(Exception):
    def __init__(self, intent_id: str) -> None:
        super().__init__(f"Intent rule '{intent_id}' not found")
        self.intent_id = intent_id


class IntentNameExistsError(Exception):
    def __init__(self, name: str) -> None:
        super().__init__(f"Intent rule with name '{name}' already exists")
        self.name = name


class IntentConfigurationError(Exception):
    pass


class IntentActivationBlockedError(IntentConfigurationError):
    """Raised when an administrator tries to activate an unsafe rule."""

    def __init__(self, report: Any) -> None:
        self.report = report
        blockers = [item.message for item in report.checks if item.severity == "blocker"]
        message = "; ".join(blockers[:5]) or "Intent readiness checks failed"
        super().__init__(f"Intent '{report.intent_name}' cannot be activated: {message}")


@dataclass(frozen=True)
class _ScoredRule:
    rule: IntentRule
    score: float
    matched_by: tuple[str, ...]


class IntentControlService:
    """Manage and deterministically resolve administrator-defined intents."""

    def __init__(self, audit_log: AuditLogService | None = None) -> None:
        self._audit = audit_log or AuditLogService()
        self._actions = ActionTemplateService(self._audit)

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    async def list_rules(
        self,
        session: AsyncSession,
        *,
        enabled: bool | None = None,
        target_agent: str | None = None,
        source_agent: str | None = None,
    ) -> list[IntentRule]:
        stmt = select(IntentRule)
        if enabled is not None:
            stmt = stmt.where(IntentRule.enabled == enabled)
        if target_agent:
            stmt = stmt.where(IntentRule.target_agent == target_agent)
        stmt = stmt.order_by(IntentRule.priority.desc(), IntentRule.name.asc())
        result = await session.execute(stmt)
        rules = list(result.scalars().all())
        if source_agent:
            rules = [rule for rule in rules if self._source_agent_allowed(rule, source_agent)]
        return rules

    async def get_rule(self, session: AsyncSession, intent_id: str) -> IntentRule:
        rule = await session.get(IntentRule, intent_id)
        if rule is None:
            raise IntentNotFoundError(intent_id)
        return rule

    async def create_rule(
        self,
        session: AsyncSession,
        data: IntentRuleCreate,
        *,
        created_by: str | None = None,
    ) -> IntentRule:
        await self._ensure_name_available(session, data.name)
        await self._validate_references(session, data)
        self._validate_patterns(data)

        rule = IntentRule(**data.model_dump(mode="json"), created_by=created_by)
        session.add(rule)
        await session.flush()
        await self._ensure_activation_ready(session, rule)
        await self._audit_change(session, "intent_created", rule, created_by)
        return rule

    async def update_rule(
        self,
        session: AsyncSession,
        intent_id: str,
        data: IntentRuleUpdate,
        *,
        updated_by: str | None = None,
    ) -> IntentRule:
        rule = await self.get_rule(session, intent_id)
        updates = data.model_dump(exclude_unset=True)
        if "name" in updates and updates["name"] != rule.name:
            await self._ensure_name_available(session, updates["name"])

        versioned_fields = {
            "target_agent",
            "allowed_tools_json",
            "orchestration_mode",
            "workflow_json",
            "aggregator_agent",
            "execution_options_json",
        }
        if versioned_fields & updates.keys() and "workflow_version" not in updates:
            updates["workflow_version"] = int(getattr(rule, "workflow_version", 1) or 1) + 1
        merged = {field: updates.get(field, getattr(rule, field)) for field in _RULE_FIELDS}
        validated = IntentRuleCreate(**merged)
        await self._validate_references(session, validated)
        self._validate_patterns(validated)

        changes: dict[str, dict[str, Any]] = {}
        for field, value in validated.model_dump(mode="json").items():
            old = getattr(rule, field)
            if old != value:
                changes[field] = {"old": old, "new": value}
                setattr(rule, field, value)

        await session.flush()
        await self._ensure_activation_ready(session, rule)
        # ``updated_at`` is generated by PostgreSQL. Refresh it while still in
        # the async greenlet context so response serialization never triggers
        # an implicit lazy load (MissingGreenlet).
        await session.refresh(rule)
        await self._audit_change(
            session, "intent_updated", rule, updated_by, changes=changes
        )
        return rule

    async def delete_rule(
        self,
        session: AsyncSession,
        intent_id: str,
        *,
        deleted_by: str | None = None,
    ) -> IntentRule:
        rule = await self.get_rule(session, intent_id)
        await self._audit_change(session, "intent_deleted", rule, deleted_by)
        await session.delete(rule)
        await session.flush()
        return rule

    # ------------------------------------------------------------------
    # Runtime resolution
    # ------------------------------------------------------------------

    async def resolve(
        self,
        session: AsyncSession,
        query: str,
        *,
        parameters: dict[str, Any] | None = None,
        confirmed: bool = False,
        source_agent: str = "concierge",
    ) -> IntentDecision:
        """Resolve one or more configured intents without making an LLM call."""
        effective_source, source_enabled = await self._source_agent_state(session, source_agent)
        if not source_enabled:
            return IntentDecision(
                decision="no_match",
                source_agent=effective_source,
                reason=(
                    f"Intent Control is disabled for source agent '{effective_source}'; "
                    "normal agent routing will be used"
                ),
                candidates=[],
            )

        await self._record_shadow_evaluations(
            session,
            query,
            parameters=parameters or {},
            confirmed=confirmed,
            source_agent=effective_source,
        )

        rules = await self.list_rules(
            session,
            enabled=True,
            source_agent=effective_source,
        )
        eligible_rules = [
            rule
            for rule in rules
            if await self._target_agent_accepts_intents(session, rule)
        ]
        scored = [self._score_rule(rule, query) for rule in eligible_rules]
        matches = [item for item in scored if item is not None]
        matches.sort(key=lambda item: (item.score, item.rule.priority), reverse=True)

        candidates = [self._candidate(item) for item in matches[:5]]
        if not matches:
            return IntentDecision(
                decision="no_match",
                source_agent=effective_source,
                reason=(
                    f"No enabled intent rule accessible to agent '{effective_source}' "
                    "matched the query"
                ),
                candidates=[],
            )

        best = matches[0]
        if best.score < best.rule.min_confidence:
            return IntentDecision(
                decision="no_match",
                source_agent=effective_source,
                confidence=round(best.score, 4),
                reason=(
                    f"Best intent '{best.rule.name}' scored {best.score:.2f}, below "
                    f"its {best.rule.min_confidence:.2f} threshold"
                ),
                candidates=candidates,
            )

        target_override: str | None = None
        if not bool(getattr(best.rule, "allow_multi_intent", False)):
            qualifying_second = None
            if len(matches) > 1 and matches[1].score >= matches[1].rule.min_confidence:
                qualifying_second = matches[1]
            if (
                qualifying_second is not None
                and best.score - qualifying_second.score <= best.rule.ambiguity_margin
            ):
                ambiguous = self._ambiguity_decision(
                    best,
                    qualifying_second,
                    candidates,
                    effective_source,
                )
                if ambiguous is not None:
                    if ambiguous.decision == "route" and ambiguous.target_agent:
                        target_override = ambiguous.target_agent
                    else:
                        return ambiguous

        selected = self._select_matches(matches)
        resolved_intents: list[ResolvedIntent] = []
        all_missing: list[str] = []
        prompts: list[str] = []
        extracted_by_intent: dict[str, dict[str, Any]] = {}

        for index, item in enumerate(selected):
            extracted, missing = self._extract_parameters(item.rule, query, parameters or {})
            extracted_by_intent[item.rule.name] = extracted
            resolved_intents.append(
                await self._resolved_intent(
                    session,
                    item,
                    extracted,
                    target_override=target_override if index == 0 else None,
                )
            )
            props = (item.rule.parameter_config_json or {}).get("properties", {})
            for name in missing:
                qualified = name if len(selected) == 1 else f"{item.rule.name}.{name}"
                all_missing.append(qualified)
                spec = props.get(name, {}) if isinstance(props, dict) else {}
                prompts.append(str(spec.get("prompt") or f"Provide '{qualified}'"))

        base = self._decision_base(best, candidates)
        base["source_agent"] = effective_source
        if target_override:
            base["target_agent"] = target_override
        decision_mode = "multi" if len(resolved_intents) > 1 else resolved_intents[0].orchestration_mode
        primary_parameters = extracted_by_intent.get(best.rule.name, {})

        if all_missing:
            return IntentDecision(
                decision="clarify",
                **base,
                reason=f"Parameters are missing, invalid, or ambiguous: {', '.join(all_missing)}",
                extracted_parameters=primary_parameters,
                missing_parameters=all_missing,
                clarification_prompt="; ".join(prompts),
                selected_intents=resolved_intents,
                orchestration_mode=decision_mode,
            )

        confirmation_rules = [item.rule for item in selected if item.rule.requires_confirmation]
        if confirmation_rules and not confirmed:
            names = ", ".join(rule.display_name or rule.name for rule in confirmation_rules)
            risks = ", ".join(sorted({rule.risk_classification for rule in confirmation_rules}))
            return IntentDecision(
                decision="confirm",
                **base,
                reason=f"The selected workflow requires confirmation for risk: {risks}",
                extracted_parameters=primary_parameters,
                clarification_prompt=f"Confirm execution of: {names}.",
                selected_intents=resolved_intents,
                orchestration_mode=decision_mode,
            )

        matched_names = ", ".join(item.rule.name for item in selected)
        decision = IntentDecision(
            decision="route",
            **base,
            reason=f"Matched intent workflow(s): {matched_names}",
            extracted_parameters=primary_parameters,
            selected_intents=resolved_intents,
            orchestration_mode=decision_mode,
        )
        return await self._check_workflow_availability(session, decision)

    async def _record_shadow_evaluations(
        self,
        session: AsyncSession,
        query: str,
        *,
        parameters: dict[str, Any],
        confirmed: bool,
        source_agent: str,
    ) -> None:
        """Measure shadow rules without routing, invoking an agent, or calling a tool."""
        result = await session.execute(
            select(IntentRule)
            .where(
                IntentRule.shadow_mode.is_(True),
                IntentRule.enabled.is_(False),
            )
            .order_by(IntentRule.priority.desc(), IntentRule.name.asc())
            .limit(50)
        )
        rules = [
            rule
            for rule in result.scalars().all()
            if bool(getattr(rule, "shadow_mode", False))
            and not bool(getattr(rule, "enabled", False))
            and self._source_agent_allowed(rule, source_agent)
        ]
        if not rules:
            return

        query_hash = hashlib.sha256(query.encode("utf-8")).hexdigest()
        summary = self._redact_query(query)[:512] or None
        for rule in rules:
            if not await self._target_agent_accepts_intents(session, rule):
                continue
            scored = self._score_rule(rule, query)
            if scored is None:
                continue
            _extracted, missing = self._extract_parameters(rule, query, parameters)
            if scored.score < rule.min_confidence:
                predicted = "no_match"
            elif missing:
                predicted = "clarify"
            elif rule.requires_confirmation and not confirmed:
                predicted = "confirm"
            else:
                predicted = "route"
            session.add(
                IntentShadowEvaluation(
                    intent_id=rule.id,
                    intent_name=rule.name,
                    source_agent=source_agent,
                    query_hash=query_hash,
                    query_summary=summary,
                    confidence=round(scored.score, 4),
                    matched_by_json=list(scored.matched_by),
                    predicted_decision=predicted,
                    predicted_target_agent=rule.target_agent if predicted == "route" else None,
                )
            )

    @staticmethod
    def _redact_query(value: str) -> str:
        redacted = _BEARER_RE.sub("Bearer <secret>", value)
        redacted = _SECRET_ASSIGNMENT_RE.sub(
            lambda match: f"{match.group(1)}=<secret>",
            redacted,
        )
        return _LONG_TOKEN_RE.sub("<secret>", redacted).strip()

    @staticmethod
    def _normalize_agent_name(name: str) -> str:
        normalized = name.strip().replace("-", "_").casefold()
        if normalized in {"concierge", "concierge_agent"}:
            return "concierge"
        return normalized

    @classmethod
    def _source_agent_allowed(cls, rule: IntentRule, source_agent: str) -> bool:
        configured = list(getattr(rule, "allowed_source_agents_json", None) or [])
        # An empty scope preserves existing installations while remaining
        # least-privilege: only Concierge and the rule's target can enter.
        allowed = configured or ["concierge", rule.target_agent]
        normalized = cls._normalize_agent_name(source_agent)
        return normalized in {cls._normalize_agent_name(item) for item in allowed}

    async def _source_agent_state(
        self,
        session: AsyncSession,
        source_agent: str,
    ) -> tuple[str, bool]:
        candidates = [source_agent]
        normalized = self._normalize_agent_name(source_agent)
        if normalized == "concierge":
            candidates.extend(["concierge", "concierge_agent", "concierge-agent"])
        for candidate in dict.fromkeys(candidates):
            agent = await session.get(AgentRegistry, candidate)
            if agent is not None:
                return agent.name, getattr(agent, "intent_control_enabled", True) is not False
        # A missing alias may still be used by an administrator's dry-run.
        # Rule-level access scope remains enforced and prevents broad access.
        return normalized, True

    @staticmethod
    async def _target_agent_accepts_intents(
        session: AsyncSession,
        rule: IntentRule,
    ) -> bool:
        required_names = {rule.target_agent}
        for raw_step in getattr(rule, "workflow_json", None) or []:
            if isinstance(raw_step, dict) and raw_step.get("required", True) and raw_step.get("agent"):
                required_names.add(str(raw_step["agent"]))
        for name in required_names:
            agent = await session.get(AgentRegistry, name)
            if agent is not None and getattr(agent, "intent_control_enabled", True) is False:
                return False
        return True

    @staticmethod
    def _select_matches(matches: list[_ScoredRule]) -> list[_ScoredRule]:
        """Select one match by default, or several when the best rule opts in."""
        best = matches[0]
        if not bool(getattr(best.rule, "allow_multi_intent", False)):
            return [best]
        raw_options = getattr(best.rule, "execution_options_json", None) or {}
        options = IntentExecutionOptions.model_validate(raw_options)
        maximum = int(getattr(best.rule, "max_intents", 1) or 1)
        selected = [
            item
            for item in matches
            if item.score >= item.rule.min_confidence
            and item.score >= options.multi_intent_min_confidence
        ]
        return selected[:maximum] or [best]

    async def _workflow_steps(
        self,
        session: AsyncSession,
        rule: IntentRule,
        *,
        target_override: str | None = None,
    ) -> list[ResolvedWorkflowStep]:
        raw_steps = getattr(rule, "workflow_json", None) or []
        if raw_steps:
            configured = [IntentWorkflowStep.model_validate(step) for step in raw_steps]
        else:
            configured = [
                IntentWorkflowStep(
                    id="primary",
                    agent=target_override or rule.target_agent,
                    tools=list(rule.allowed_tools_json or []),
                    fallback_agent=rule.fallback_agent,
                    on_failure="fallback" if rule.fallback_agent else "stop",
                )
            ]

        steps: list[ResolvedWorkflowStep] = []
        for configured_step in configured:
            resolved_action = None
            tools = list(configured_step.tools)
            connection_ref = configured_step.connection_ref
            if configured_step.action_template:
                try:
                    resolved_action = await self._actions.resolve_reference(
                        session, configured_step.action_template
                    )
                    await self._actions.validate_for_agent(
                        session, resolved_action, configured_step.agent
                    )
                except (
                    ActionTemplateConfigurationError,
                    ActionTemplateNotFoundError,
                ) as exc:
                    raise IntentConfigurationError(str(exc)) from exc
                if connection_ref and connection_ref != resolved_action.tool_name:
                    raise IntentConfigurationError(
                        f"Workflow step '{configured_step.id}' connection_ref "
                        f"'{connection_ref}' does not match action-template tool "
                        f"'{resolved_action.tool_name}'"
                    )
                connection_ref = resolved_action.tool_name
                tools = [resolved_action.tool_name]
            elif connection_ref:
                tools = [connection_ref]
            step_data = configured_step.model_dump()
            step_data["tools"] = tools
            step_data["connection_ref"] = connection_ref
            steps.append(
                ResolvedWorkflowStep(
                    **step_data,
                    resolved_action=resolved_action,
                )
            )

        mode = str(getattr(rule, "orchestration_mode", None) or "single")
        if mode == "sequential" and len(steps) > 1:
            sequenced: list[ResolvedWorkflowStep] = []
            for index, step in enumerate(steps):
                if index and not step.depends_on:
                    step = step.model_copy(update={"depends_on": [steps[index - 1].id]})
                sequenced.append(step)
            steps = sequenced
        return steps

    async def _resolved_intent(
        self,
        session: AsyncSession,
        item: _ScoredRule,
        parameters: dict[str, Any],
        *,
        target_override: str | None = None,
    ) -> ResolvedIntent:
        rule = item.rule
        raw_options = getattr(rule, "execution_options_json", None) or {}
        return ResolvedIntent(
            intent_id=rule.id,
            intent_name=rule.name,
            confidence=round(item.score, 4),
            orchestration_mode=str(getattr(rule, "orchestration_mode", None) or "single"),
            workflow_version=int(getattr(rule, "workflow_version", None) or 1),
            workflow_steps=await self._workflow_steps(
                session, rule, target_override=target_override
            ),
            aggregator_agent=getattr(rule, "aggregator_agent", None),
            extracted_parameters=parameters,
            response_mode=rule.response_mode,
            response_template=rule.response_template,
            response_options=dict(rule.response_options_json or {}),
            execution_options=IntentExecutionOptions.model_validate(raw_options),
        )

    @classmethod
    def _score_rule(cls, rule: IntentRule, query: str) -> _ScoredRule | None:
        normalized = " ".join(query.casefold().split())
        query_tokens = set(_TOKEN_RE.findall(normalized))
        if not normalized:
            return None

        for blocked in rule.negative_keywords_json or []:
            if cls._contains_term(normalized, query_tokens, str(blocked)):
                return None

        strategy = rule.match_strategy
        scores: list[tuple[float, str]] = []

        examples = [" ".join(str(x).casefold().split()) for x in (rule.examples_json or [])]
        keywords = [" ".join(str(x).casefold().split()) for x in (rule.keywords_json or [])]

        config = rule.parameter_config_json or {}
        if config.get("match_parameterized_examples") and strategy in {"hybrid", "examples"}:
            from backend.services.intent_parameters import parameterized_example

            canonical = parameterized_example(query, config)
            if (" parameter " in f" {canonical} " and len(canonical.split()) >= 3
                    and any(canonical == parameterized_example(example, config) for example in examples)):
                scores.append((0.96, "parameterized_example"))

        if strategy in {"hybrid", "exact"} and (
            normalized in examples or normalized in keywords
        ):
            scores.append((1.0, "exact"))

        if strategy in {"hybrid", "keywords"} and keywords:
            hits = sum(cls._contains_term(normalized, query_tokens, word) for word in keywords)
            if hits and (rule.keyword_mode == "any" or hits == len(keywords)):
                coverage = hits / len(keywords)
                scores.append((min(0.95, 0.55 + (0.40 * coverage)), f"keywords:{hits}/{len(keywords)}"))

        if strategy in {"hybrid", "regex"}:
            for pattern in rule.regex_patterns_json or []:
                if re.search(str(pattern), query, flags=re.IGNORECASE):
                    scores.append((0.97, "regex"))
                    break

        if strategy in {"hybrid", "examples"} and examples:
            best_similarity = max(cls._example_similarity(normalized, example) for example in examples)
            if best_similarity >= 0.50:
                scores.append((min(0.90, 0.45 + (0.45 * best_similarity)), "example"))

        if not scores:
            return None
        score = max(value for value, _ in scores)
        matched_by = tuple(label for value, label in scores if value >= score - 0.05)
        return _ScoredRule(rule=rule, score=score, matched_by=matched_by)

    @staticmethod
    def _contains_term(normalized_query: str, query_tokens: set[str], term: str) -> bool:
        normalized_term = " ".join(term.casefold().split())
        if not normalized_term:
            return False
        if len(_TOKEN_RE.findall(normalized_term)) == 1:
            return normalized_term in query_tokens
        return normalized_term in normalized_query

    @staticmethod
    def _example_similarity(query: str, example: str) -> float:
        query_tokens = set(_TOKEN_RE.findall(query))
        example_tokens = set(_TOKEN_RE.findall(example))
        union = query_tokens | example_tokens
        jaccard = len(query_tokens & example_tokens) / len(union) if union else 0.0
        sequence = SequenceMatcher(None, query, example).ratio()
        return max(jaccard, sequence)

    @staticmethod
    def _extract_parameters(
        rule: IntentRule,
        query: str,
        supplied: dict[str, Any],
    ) -> tuple[dict[str, Any], list[str]]:
        from backend.services.intent_parameters import extract_parameters

        return extract_parameters(rule.parameter_config_json or {}, query, supplied)

    @staticmethod
    def _coerce_value(value: Any, type_name: Any) -> Any:
        if type_name == "integer":
            try:
                return int(value)
            except (TypeError, ValueError):
                return value
        if type_name == "number":
            try:
                return float(value)
            except (TypeError, ValueError):
                return value
        if type_name == "boolean":
            if isinstance(value, str):
                return value.casefold() in {"true", "1", "yes", "on"}
            return bool(value)
        return value

    @staticmethod
    def _has_value(value: Any) -> bool:
        return value is not None and value != ""

    @staticmethod
    def _candidate(item: _ScoredRule) -> IntentCandidate:
        return IntentCandidate(
            intent_id=item.rule.id,
            intent_name=item.rule.name,
            target_agent=item.rule.target_agent,
            score=round(item.score, 4),
            priority=item.rule.priority,
            matched_by=list(item.matched_by),
        )

    @staticmethod
    def _decision_base(best: _ScoredRule, candidates: list[IntentCandidate]) -> dict[str, Any]:
        rule = best.rule
        return {
            "intent_id": rule.id,
            "intent_name": rule.name,
            "target_agent": rule.target_agent,
            "allowed_tools": list(rule.allowed_tools_json or []),
            "confidence": round(best.score, 4),
            "risk_classification": rule.risk_classification,
            "requires_confirmation": rule.requires_confirmation,
            "response_mode": rule.response_mode,
            "response_template": rule.response_template,
            "response_options": dict(rule.response_options_json or {}),
            "candidates": candidates,
        }

    def _ambiguity_decision(
        self,
        best: _ScoredRule,
        second: _ScoredRule,
        candidates: list[IntentCandidate],
        source_agent: str,
    ) -> IntentDecision | None:
        action = best.rule.ambiguity_action
        if action == "route_best":
            return None

        base = self._decision_base(best, candidates)
        base["source_agent"] = source_agent
        reason = (
            f"Ambiguous match between '{best.rule.name}' ({best.score:.2f}) and "
            f"'{second.rule.name}' ({second.score:.2f})"
        )
        if action == "fallback" and best.rule.fallback_agent:
            base["target_agent"] = best.rule.fallback_agent
            return IntentDecision(decision="route", **base, reason=f"{reason}; using fallback agent")
        if action == "deny":
            return IntentDecision(decision="deny", **base, reason=reason)
        if action == "clarify":
            return IntentDecision(
                decision="clarify",
                **base,
                reason=reason,
                clarification_prompt=(
                    f"Did you mean '{best.rule.display_name or best.rule.name}' or "
                    f"'{second.rule.display_name or second.rule.name}'?"
                ),
            )
        return IntentDecision(decision="llm_fallback", **base, reason=reason)

    async def _check_workflow_availability(
        self, session: AsyncSession, decision: IntentDecision
    ) -> IntentDecision:
        """Resolve configured fallbacks and reject unavailable required steps."""
        unavailable: list[str] = []
        substitutions: list[str] = []
        for resolved in decision.selected_intents:
            checked_steps: list[ResolvedWorkflowStep] = []
            for step in resolved.workflow_steps:
                agent = await session.get(AgentRegistry, step.agent)
                if (
                    agent is not None
                    and agent.lifecycle_status == "running"
                    and getattr(agent, "intent_control_enabled", True) is not False
                ):
                    checked_steps.append(step)
                    continue

                fallback_name = step.fallback_agent
                fallback = await session.get(AgentRegistry, fallback_name) if fallback_name else None
                if (
                    fallback is not None
                    and fallback.lifecycle_status == "running"
                    and getattr(fallback, "intent_control_enabled", True) is not False
                ):
                    checked_steps.append(step.model_copy(update={"agent": fallback.name}))
                    substitutions.append(f"{step.id}: {step.agent} -> {fallback.name}")
                    continue

                checked_steps.append(step)
                if step.required:
                    unavailable.append(f"{resolved.intent_name}.{step.id} ({step.agent})")
            resolved.workflow_steps = checked_steps

            if resolved.aggregator_agent:
                aggregator = await session.get(AgentRegistry, resolved.aggregator_agent)
                if (
                    aggregator is None
                    or aggregator.lifecycle_status != "running"
                    or getattr(aggregator, "intent_control_enabled", True) is False
                ):
                    substitutions.append(
                        f"{resolved.intent_name}: unavailable aggregator ignored"
                    )
                    resolved.aggregator_agent = None

        if substitutions:
            decision.reason += "; " + "; ".join(substitutions)
        if unavailable:
            decision.decision = "unavailable"
            decision.reason += "; required workflow agents are unavailable: " + ", ".join(unavailable)
        elif decision.selected_intents and decision.selected_intents[0].workflow_steps:
            decision.target_agent = decision.selected_intents[0].workflow_steps[0].agent
        return decision

    # ------------------------------------------------------------------
    # Import/export and validation
    # ------------------------------------------------------------------

    async def export_rules(self, session: AsyncSession) -> str:
        rules = await self.list_rules(session)
        payload = {
            "version": 4,
            "intents": [
                {field: getattr(rule, field) for field in _RULE_FIELDS}
                for rule in rules
            ],
        }
        return json.dumps(payload, indent=2)

    async def import_rules(
        self,
        session: AsyncSession,
        raw_data: str,
        *,
        replace_existing: bool = False,
        imported_by: str | None = None,
    ) -> tuple[int, int, list[str]]:
        try:
            parsed = json.loads(raw_data)
        except ValueError as exc:
            return 0, 0, [f"Invalid JSON: {exc}"]
        items = parsed.get("intents", []) if isinstance(parsed, dict) else parsed
        if not isinstance(items, list):
            return 0, 0, ["Import must contain an 'intents' array"]

        imported = 0
        updated = 0
        errors: list[str] = []
        for index, item in enumerate(items):
            try:
                data = IntentRuleCreate.model_validate(item)
                result = await session.execute(select(IntentRule).where(IntentRule.name == data.name))
                existing = result.scalar_one_or_none()
                if existing is None:
                    await self.create_rule(session, data, created_by=imported_by)
                    imported += 1
                elif replace_existing:
                    await self.update_rule(
                        session,
                        existing.id,
                        IntentRuleUpdate(**data.model_dump()),
                        updated_by=imported_by,
                    )
                    updated += 1
                else:
                    errors.append(f"Item {index}: intent '{data.name}' already exists")
            except Exception as exc:  # noqa: BLE001 - import reports per-item failures and continues
                errors.append(f"Item {index}: {exc}")
        return imported, updated, errors

    async def _ensure_name_available(self, session: AsyncSession, name: str) -> None:
        result = await session.execute(select(IntentRule.id).where(IntentRule.name == name))
        if result.scalar_one_or_none() is not None:
            raise IntentNameExistsError(name)

    async def _ensure_activation_ready(
        self,
        session: AsyncSession,
        rule: IntentRule,
    ) -> None:
        if not bool(rule.enabled):
            return
        # Imported lazily to keep the assurance service free to reuse the
        # deterministic matcher without creating a module import cycle.
        from backend.services.intent_assurance import IntentAssuranceService

        report = await IntentAssuranceService(self).readiness(session, rule)
        if not report.ready_to_activate:
            raise IntentActivationBlockedError(report)

    async def _validate_references(self, session: AsyncSession, data: IntentRuleCreate) -> None:
        agent_names = {data.target_agent}
        if data.fallback_agent:
            agent_names.add(data.fallback_agent)
        if data.aggregator_agent:
            agent_names.add(data.aggregator_agent)
        for step in data.workflow_json:
            agent_names.add(step.agent)
            if step.fallback_agent:
                agent_names.add(step.fallback_agent)

        for agent_name in sorted(agent_names):
            agent = await session.get(AgentRegistry, agent_name)
            if agent is None:
                raise IntentConfigurationError(f"Workflow agent '{agent_name}' does not exist")
            if agent.agent_type != "specialized":
                raise IntentConfigurationError(
                    f"Workflow agent '{agent_name}' must be a specialized agent"
                )

        for source_name in data.allowed_source_agents_json:
            source = await session.get(AgentRegistry, source_name)
            if source is None:
                raise IntentConfigurationError(
                    f"Allowed source agent '{source_name}' does not exist"
                )

        tool_names = set(data.allowed_tools_json)
        risk_rank = {"read_only": 0, "write": 1, "execute": 2}
        for step in data.workflow_json:
            tool_names.update(step.tools)
            if step.connection_ref:
                tool_names.add(step.connection_ref)
            if not step.action_template:
                continue
            try:
                action = await self._actions.resolve_reference(
                    session, step.action_template
                )
                await self._actions.validate_for_agent(session, action, step.agent)
            except (
                ActionTemplateConfigurationError,
                ActionTemplateNotFoundError,
            ) as exc:
                raise IntentConfigurationError(str(exc)) from exc
            if step.tools and set(step.tools) != {action.tool_name}:
                raise IntentConfigurationError(
                    f"Workflow step '{step.id}' uses action template "
                    f"'{action.reference}' and may only expose tool '{action.tool_name}'"
                )
            if step.connection_ref and step.connection_ref != action.tool_name:
                raise IntentConfigurationError(
                    f"Workflow step '{step.id}' connection_ref '{step.connection_ref}' "
                    f"does not match action-template tool '{action.tool_name}'"
                )
            if (
                action.policy.requires_confirmation
                and not data.requires_confirmation
            ):
                raise IntentConfigurationError(
                    f"Action template '{action.reference}' requires intent confirmation"
                )
            if (
                risk_rank[action.policy.risk_classification]
                > risk_rank[data.risk_classification]
            ):
                raise IntentConfigurationError(
                    f"Intent risk '{data.risk_classification}' is lower than action "
                    f"template '{action.reference}' risk "
                    f"'{action.policy.risk_classification}'"
                )
            tool_names.add(action.tool_name)
        for tool_name in sorted(tool_names):
            if await session.get(ToolRegistry, tool_name) is None:
                raise IntentConfigurationError(f"Allowed tool '{tool_name}' does not exist")

    @staticmethod
    def _validate_patterns(data: IntentRuleCreate) -> None:
        patterns = list(data.regex_patterns_json)
        parameter_props = data.parameter_config_json.get("properties", {})
        if isinstance(parameter_props, dict):
            patterns.extend(
                str(spec["pattern"])
                for spec in parameter_props.values()
                if isinstance(spec, dict) and spec.get("pattern")
            )
            for spec in parameter_props.values():
                if not isinstance(spec, dict) or not spec.get("x-intent"):
                    continue
                extraction = spec["x-intent"]
                if not isinstance(extraction, dict):
                    raise IntentConfigurationError("x-intent extraction settings must be an object")
                if extraction.get("extractor") not in {None, "label", "enum", "date"}:
                    raise IntentConfigurationError("Unsupported intent parameter extractor")
                if extraction.get("pattern"):
                    patterns.append(str(extraction["pattern"]))
                aliases = extraction.get("aliases", [])
                if not isinstance(aliases, list) or len(aliases) > 25 or any(
                    not isinstance(alias, str) or not alias.strip() or len(alias) > 128 for alias in aliases
                ):
                    raise IntentConfigurationError("Parameter aliases must be up to 25 nonempty names of 128 characters")
                if "occurrence" in extraction and (type(extraction["occurrence"]) is not int
                                                    or not 0 <= extraction["occurrence"] < 100):
                    raise IntentConfigurationError("Parameter occurrence must be between 0 and 99")
        for pattern in patterns:
            if len(pattern) > 1_000:
                raise IntentConfigurationError("Regular expressions must not exceed 1,000 characters")
            try:
                re.compile(pattern, flags=re.IGNORECASE)
            except re.error as exc:
                raise IntentConfigurationError(f"Invalid regular expression '{pattern}': {exc}") from exc

    async def _audit_change(
        self,
        session: AsyncSession,
        action: str,
        rule: IntentRule,
        user_id: str | None,
        *,
        changes: dict[str, Any] | None = None,
    ) -> None:
        details: dict[str, Any] = {
            "action": action,
            "intent_id": rule.id,
            "intent_name": rule.name,
            "target_agent": rule.target_agent,
            "allowed_source_agents": list(
                getattr(rule, "allowed_source_agents_json", None) or []
            ),
            "orchestration_mode": getattr(rule, "orchestration_mode", "single"),
            "workflow_version": getattr(rule, "workflow_version", 1),
            "workflow_agents": [
                str(step.get("agent"))
                for step in (getattr(rule, "workflow_json", None) or [])
                if isinstance(step, dict) and step.get("agent")
            ],
        }
        if changes is not None:
            details["changes"] = changes
        await self._audit.append(
            session,
            "config_change",
            target_agent=rule.target_agent,
            user_id=user_id,
            details=details,
        )
