"""Compile bounded observations into reviewed, parameterized action workflows.

Arguments and results are used only to prove a template match and data binding.
Persisted evidence contains names, dependencies and reasons, never their values.
"""

from __future__ import annotations

import copy
import json
import re
from dataclasses import dataclass
from typing import Any

from backend.services.action_template import ActionTemplateConfigurationError, ActionTemplateService
from backend.services.intent_parameters import aliases_for, coerce, find_values, valid_value
from backend.services.intent_trace import ObservedToolCall, ToolCallTrace

_SLOT = re.compile(r"\{\{\s*(?:inputs\.)?([A-Za-z][A-Za-z0-9_]*)\s*\}\}")
_SECRET = re.compile(r"password|credential|secret|token|authorization|api.?key|cookie", re.IGNORECASE)


def _equal(left: Any, right: Any) -> bool:
    return type(left) is type(right) and left == right


def _contains_secret(value: Any) -> bool:
    if isinstance(value, dict):
        return any(_SECRET.search(str(key)) or _contains_secret(item) for key, item in value.items())
    if isinstance(value, list):
        return any(_contains_secret(item) for item in value)
    return isinstance(value, str) and bool(
        re.search(r"(?i)\bbearer\s+\S+|\b(?:password|secret|token|api[_-]?key)\s*[:=]|-----BEGIN .*PRIVATE KEY", value)
    )


def _unify(pattern: Any, observed: Any, inputs: dict[str, Any], properties: dict[str, Any]) -> bool:
    if isinstance(pattern, dict):
        return (
            isinstance(observed, dict)
            and set(pattern) == set(observed)
            and all(_unify(item, observed[key], inputs, properties) for key, item in pattern.items())
        )
    if isinstance(pattern, list):
        return (
            isinstance(observed, list)
            and len(pattern) == len(observed)
            and all(_unify(a, b, inputs, properties) for a, b in zip(pattern, observed))
        )
    if not isinstance(pattern, str) or not _SLOT.search(pattern):
        return _equal(pattern, observed)
    full = _SLOT.fullmatch(pattern)
    if full:
        name = full.group(1)
        if name not in properties or (name in inputs and not _equal(inputs[name], observed)):
            return False
        inputs[name] = observed
        return True
    if not isinstance(observed, str) or re.search(r"\}\}\s*\{\{", pattern):
        return False
    pieces, offset, names = [], 0, []
    for slot in _SLOT.finditer(pattern):
        name = slot.group(1)
        if name not in properties:
            return False
        pieces.append(re.escape(pattern[offset : slot.start()]))
        pieces.append(rf"(?P={name})" if name in names else rf"(?P<{name}>.+?)")
        names.append(name)
        offset = slot.end()
    pieces.append(re.escape(pattern[offset:]))
    match = re.fullmatch("".join(pieces), observed, re.DOTALL)
    if not match:
        return False
    for name, value in match.groupdict().items():
        try:
            value = coerce(value, properties[name])
        except (TypeError, ValueError):
            return False
        if name in inputs and not _equal(inputs[name], value):
            return False
        inputs[name] = value
    return True


def template_inputs(template: Any, arguments: dict[str, Any], query: str) -> dict[str, Any] | None:
    """Only exact render equivalence proves that a published action was observed."""
    properties = (template.input_schema_json or {}).get("properties", {})
    if not isinstance(properties, dict) or _contains_secret(arguments):
        return None
    inputs: dict[str, Any] = {}
    options = template.execution_options_json or {}
    payload = template.payload_template_json or {}
    if not isinstance(payload, dict):
        return None
    text_arg = options.get("text_argument") if template.template_text is not None else None
    payload_args = {key: value for key, value in arguments.items() if key != text_arg}
    if options.get("include_unmapped_inputs"):
        extras = {key: value for key, value in payload_args.items() if key not in payload}
        if set(extras) - set(properties):
            return None
        inputs.update(extras)
        payload_args = {key: value for key, value in payload_args.items() if key in payload}
    if not _unify(payload, payload_args, inputs, properties):
        return None
    if template.template_text is not None:
        if text_arg not in arguments or not _unify(template.template_text, arguments[text_arg], inputs, properties):
            return None
        if template.template_type in {"sql", "ansible"}:
            # Auto-learning must not turn captured SQL/playbook text into an
            # unrestricted string interpolation surface. Bind data separately.
            for name in _SLOT.findall(template.template_text):
                spec = properties.get(name, {})
                if spec.get("type") not in {"integer", "number"} and not spec.get("enum"):
                    return None
    try:
        rendered = ActionTemplateService.render_snapshot(
            ActionTemplateService.snapshot(template),
            inputs=inputs,
            query=query,
        )
    except (ValueError, TypeError, KeyError, ActionTemplateConfigurationError):
        return None
    return rendered.validated_inputs if _equal(rendered.tool_arguments, arguments) else None


def _paths(value: Any, target: Any, path: str = "", depth: int = 0):
    if depth > 8:
        return
    if _equal(value, target):
        yield path
    if isinstance(value, dict):
        for key, item in list(value.items())[:100]:
            if not _SECRET.search(str(key)):
                escaped = str(key).replace("~", "~0").replace("/", "~1")
                yield from _paths(item, target, f"{path}/{escaped}", depth + 1)
    elif isinstance(value, list):
        for index, item in enumerate(value[:100]):
            yield from _paths(item, target, f"{path}/{index}", depth + 1)


def _parameter_spec(name: str, spec: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(spec)
    config = dict(result.get("x-intent") or {})
    config.setdefault("extractor", "date" if spec.get("format") == "date" else "enum" if spec.get("enum") else "label")
    config["aliases"] = aliases_for(name, spec)
    if config["extractor"] == "date":
        config.setdefault(
            "date_role",
            "start"
            if "start" in name or name.startswith("from")
            else "end"
            if "end" in name or name.startswith("to")
            else "single",
        )
    result["x-intent"] = config
    return result


@dataclass
class LearnedWorkflow:
    steps: list[dict[str, Any]]
    parameters: dict[str, Any]
    evidence: dict[str, Any]
    direct: bool


def compile_workflow(
    trace: ToolCallTrace,
    *,
    route: dict[str, list[str]],
    templates: list[Any],
    assignments: set[tuple[str, str]],
    query: str,
) -> LearnedWorkflow:
    normalize = lambda name: name.casefold().replace("-", "_")
    agents = {normalize(agent): agent for agent in route}
    calls = [
        call
        for call in trace.calls
        if normalize(call.agent) in agents and call.tool in route[agents[normalize(call.agent)]]
    ]
    steps, evidence, properties, required = [], [], {}, []
    completed: dict[str, ObservedToolCall] = {}
    unobserved_agents = sorted(set(agents) - {normalize(call.agent) for call in calls})
    direct = bool(calls) and not trace.incomplete and not unobserved_agents
    for call in calls:
        agent = agents[normalize(call.agent)]
        dependencies = [name for name in call.predecessors if name in completed]
        step = {
            "id": call.id,
            "agent": agent,
            "tools": [call.tool],
            "connection_ref": call.tool,
            "depends_on": dependencies,
            "action_inputs": {},
        }
        detail = {
            "id": call.id,
            "agent": agent,
            "tool": call.tool,
            "status": call.status,
            "argument_names": sorted(key for key in call.arguments if not _SECRET.search(key)),
            "depends_on": dependencies,
            "reason": "No published direct action matches the observed call",
        }
        eligible = []
        for template in templates:
            policy = template.policy_json or {}
            if (
                template.tool_name != call.tool
                or template.execution_mode != "direct"
                or template.lifecycle_status != "active"
                or (normalize(agent), call.tool) not in {(normalize(a), t) for a, t in assignments}
                or (
                    policy.get("allowed_agents")
                    and normalize(agent) not in {normalize(a) for a in policy["allowed_agents"]}
                )
            ):
                continue
            values = template_inputs(template, call.arguments, query)
            if values is not None:
                eligible.append((template, values))
        detail["matching_actions"] = [f"{tpl.name}@{tpl.version}" for tpl, _ in eligible]
        if len(eligible) != 1 or call.status != "completed":
            direct = False
            if call.status != "completed":
                detail["reason"] = "Call did not complete successfully; direct replay is unavailable"
            elif len(eligible) > 1:
                detail["reason"] = "Multiple actions match; select the intended action during review"
        else:
            template, values = eligible[0]
            step["action_template"] = f"{template.name}@{template.version}"
            detail["action_template"] = step["action_template"]
            detail["reason"] = "Exact argument match to one published action"
            specs = (template.input_schema_json or {}).get("properties", {})
            for name, value in values.items():
                spec = specs.get(name, {})
                if not isinstance(spec, dict) or _SECRET.search(name):
                    direct = False
                    detail["reason"] = "An input requires manual mapping"
                    continue
                if (
                    _equal(value, query)
                    and spec.get("type") == "string"
                    and name in {"query", "prompt", "message", "text"}
                ):
                    step["action_inputs"][name] = "query"
                    continue
                param_name = f"{call.id}_{name}"
                param_spec = _parameter_spec(name, spec)
                matches = find_values(param_name, param_spec, query)
                matching = [index for index, (item, _) in enumerate(matches) if _equal(item, value)]
                # Infer only meaningful, unique data links from completed calls.
                # Explicit request parameters take precedence over echoed values.
                links = []
                meaningful = (
                    (isinstance(value, str) and len(value) >= 3)
                    or (isinstance(value, (list, dict)) and bool(value))
                    or (type(value) is int and re.search(r"(?:^|_)id$|Id$", name))
                )
                if meaningful and not matching:
                    for predecessor in dependencies:
                        output = completed[predecessor].output
                        if isinstance(output, str):
                            try:
                                output = json.loads(output)
                            except (ValueError, TypeError):
                                pass
                        links.extend((predecessor, path) for path in _paths(output, value))
                if links:
                    if len(links) == 1:
                        source, path = links[0]
                        step["action_inputs"][name] = {"$from_step": {"step": source, "path": path}}
                    else:
                        direct = False
                        detail["reason"] = "Several prior result fields match an input; review its data source"
                    continue
                if matching and valid_value(name, value, spec):
                    if any(not _equal(item, value) for item, _ in matches):
                        if len(matching) != 1:
                            direct = False
                            detail["reason"] = "Repeated input values need explicit parameter mapping"
                            continue
                        param_spec["x-intent"]["occurrence"] = matching[0]
                elif "default" not in spec or not _equal(spec["default"], value):
                    direct = False
                    detail["reason"] = "Input cannot be extracted from the request or a prior result; review mapping"
                    continue
                properties[param_name] = param_spec
                if name in (template.input_schema_json or {}).get("required", []) and "default" not in spec:
                    required.append(param_name)
                step["action_inputs"][name] = {
                    "$parameter": param_name,
                    "optional": name not in (template.input_schema_json or {}).get("required", []),
                }
            # Allow future overrides of omitted optional inputs when the action
            # passes schema inputs through as actual tool arguments.
            if (template.execution_options_json or {}).get("include_unmapped_inputs"):
                for name, spec in specs.items():
                    if name not in values and isinstance(spec, dict) and not _SECRET.search(name):
                        param_name = f"{call.id}_{name}"
                        properties[param_name] = _parameter_spec(name, spec)
                        step["action_inputs"][name] = {"$parameter": param_name, "optional": True}
        if call.status == "completed":
            completed[call.id] = call
        steps.append(step)
        evidence.append(detail)
    return LearnedWorkflow(
        steps,
        {"properties": properties, "required": required, "match_parameterized_examples": True},
        {
            "version": 1,
            "complete": not trace.incomplete,
            "direct_ready": direct,
            "calls": evidence,
            "unobserved_agents": [agents[name] for name in unobserved_agents],
        },
        direct,
    )
