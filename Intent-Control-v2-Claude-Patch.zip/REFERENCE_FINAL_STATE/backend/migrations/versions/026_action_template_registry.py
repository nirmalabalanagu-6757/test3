"""Add the Universal Action Template Registry.

Revision ID: 026_action_templates
Revises: 025_policy_priority
"""

import sqlalchemy as sa
from alembic import op

revision = "026_action_templates"
down_revision = "025_policy_priority"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "action_template",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("display_name", sa.String(length=160), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("template_type", sa.String(length=24), nullable=False),
        sa.Column("tool_name", sa.String(length=128), nullable=False),
        sa.Column("execution_mode", sa.String(length=16), nullable=False, server_default="agent"),
        sa.Column("template_text", sa.Text(), nullable=True),
        sa.Column("payload_template_json", sa.JSON(), nullable=True),
        sa.Column("input_schema_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
        sa.Column("output_schema_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
        sa.Column("policy_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
        sa.Column("execution_options_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
        sa.Column("lifecycle_status", sa.String(length=20), nullable=False, server_default="draft"),
        sa.Column("created_by", sa.String(length=128), nullable=True),
        sa.Column("updated_by", sa.String(length=128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name", "version", name="uq_action_template_name_version"),
    )
    op.create_index(
        "ix_action_template_status_type",
        "action_template",
        ["lifecycle_status", "template_type"],
    )
    op.create_index("ix_action_template_tool", "action_template", ["tool_name"])

    op.add_column(
        "intent_execution_step",
        sa.Column("action_template_name", sa.String(length=128), nullable=True),
    )
    op.add_column(
        "intent_execution_step",
        sa.Column("action_template_version", sa.Integer(), nullable=True),
    )
    op.create_index(
        "ix_intent_execution_step_action_template",
        "intent_execution_step",
        ["action_template_name", "action_template_version"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_intent_execution_step_action_template",
        table_name="intent_execution_step",
    )
    op.drop_column("intent_execution_step", "action_template_version")
    op.drop_column("intent_execution_step", "action_template_name")
    op.drop_index("ix_action_template_tool", table_name="action_template")
    op.drop_index("ix_action_template_status_type", table_name="action_template")
    op.drop_table("action_template")
