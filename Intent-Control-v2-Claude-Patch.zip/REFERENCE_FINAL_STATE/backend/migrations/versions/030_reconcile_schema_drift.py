"""Reconcile long-standing model/schema drift.

Revision ID: 030_reconcile_schema_drift
Revises: 029_intent_assurance
"""

import sqlalchemy as sa
from alembic import op

revision = "030_reconcile_schema_drift"
down_revision = "029_intent_assurance"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "notification_subscription",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("user_id", sa.String(length=128), nullable=False),
        sa.Column("channel_type", sa.String(length=20), nullable=False),
        sa.Column("event_type", sa.String(length=64), nullable=False),
        sa.Column("severity", sa.String(length=20), nullable=False),
        sa.Column(
            "enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.PrimaryKeyConstraint("id"),
    )

    op.add_column(
        "configuration",
        sa.Column(
            "is_secret",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )

    op.alter_column(
        "tool_registry",
        "auth_type",
        existing_type=sa.String(length=20),
        type_=sa.String(length=32),
        existing_nullable=False,
        existing_server_default="none",
    )


def downgrade() -> None:
    op.alter_column(
        "tool_registry",
        "auth_type",
        existing_type=sa.String(length=32),
        type_=sa.String(length=20),
        existing_nullable=False,
        existing_server_default="none",
    )
    op.drop_column("configuration", "is_secret")
    op.drop_table("notification_subscription")
