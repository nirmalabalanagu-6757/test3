"""Add database-driven intent control rules.

Revision ID: 023_intent_control
Revises: 022_skywise_connector_type
"""

import sqlalchemy as sa
from alembic import op

revision = "023_intent_control"
down_revision = "022_skywise_connector_type"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "intent_rule",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False, unique=True),
        sa.Column("display_name", sa.String(160), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("priority", sa.Integer(), nullable=False, server_default="100"),
        sa.Column("match_strategy", sa.String(20), nullable=False, server_default="hybrid"),
        sa.Column("keyword_mode", sa.String(10), nullable=False, server_default="any"),
        sa.Column("keywords_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("negative_keywords_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("regex_patterns_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("examples_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("min_confidence", sa.Float(), nullable=False, server_default="0.70"),
        sa.Column("ambiguity_margin", sa.Float(), nullable=False, server_default="0.10"),
        sa.Column("ambiguity_action", sa.String(24), nullable=False, server_default="llm_fallback"),
        sa.Column("target_agent", sa.String(128), nullable=False),
        sa.Column("fallback_agent", sa.String(128), nullable=True),
        sa.Column("allowed_tools_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("parameter_config_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
        sa.Column("risk_classification", sa.String(20), nullable=False, server_default="read_only"),
        sa.Column("requires_confirmation", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("response_mode", sa.String(24), nullable=False, server_default="auto"),
        sa.Column("response_template", sa.Text(), nullable=True),
        sa.Column("response_options_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
        sa.Column("created_by", sa.String(128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_intent_rule_enabled_priority", "intent_rule", ["enabled", "priority"])
    op.create_index("ix_intent_rule_target_agent", "intent_rule", ["target_agent"])


def downgrade() -> None:
    op.drop_index("ix_intent_rule_target_agent", table_name="intent_rule")
    op.drop_index("ix_intent_rule_enabled_priority", table_name="intent_rule")
    op.drop_table("intent_rule")
