"""Add dynamic intent-learning candidates.

Revision ID: 028_intent_learning_candidates
Revises: 027_agent_intent_scope
"""

import sqlalchemy as sa
from alembic import op

revision = "028_intent_learning_candidates"
down_revision = "027_agent_intent_scope"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "intent_learning_candidate",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column(
            "status",
            sa.String(length=20),
            nullable=False,
            server_default="pending",
        ),
        sa.Column("source_agent", sa.String(length=128), nullable=False),
        sa.Column("fingerprint", sa.String(length=64), nullable=False),
        sa.Column("normalized_pattern", sa.Text(), nullable=False),
        sa.Column(
            "examples_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'[]'::json"),
        ),
        sa.Column(
            "observed_route_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'{}'::json"),
        ),
        sa.Column(
            "model_names_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'[]'::json"),
        ),
        sa.Column(
            "occurrence_count",
            sa.Integer(),
            nullable=False,
            server_default="1",
        ),
        sa.Column(
            "proposal_confidence",
            sa.Float(),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "proposed_execution_mode",
            sa.String(length=24),
            nullable=False,
            server_default="agent_llm",
        ),
        sa.Column(
            "proposed_rule_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'{}'::json"),
        ),
        sa.Column("suggested_intent_id", sa.String(length=36), nullable=True),
        sa.Column("approved_intent_id", sa.String(length=36), nullable=True),
        sa.Column("reviewed_by", sa.String(length=128), nullable=True),
        sa.Column("review_note", sa.Text(), nullable=True),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "first_seen_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "last_seen_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.ForeignKeyConstraint(
            ["suggested_intent_id"],
            ["intent_rule.id"],
            ondelete="SET NULL",
        ),
        sa.ForeignKeyConstraint(
            ["approved_intent_id"],
            ["intent_rule.id"],
            ondelete="SET NULL",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_intent_learning_candidate_status_last_seen",
        "intent_learning_candidate",
        ["status", "last_seen_at"],
    )
    op.create_index(
        "ix_intent_learning_candidate_source_status",
        "intent_learning_candidate",
        ["source_agent", "status"],
    )
    op.create_index(
        "ix_intent_learning_candidate_fingerprint",
        "intent_learning_candidate",
        ["fingerprint"],
    )
    op.create_index(
        "uq_intent_learning_pending_fingerprint",
        "intent_learning_candidate",
        ["source_agent", "fingerprint"],
        unique=True,
        postgresql_where=sa.text("status = 'pending'"),
    )


def downgrade() -> None:
    op.drop_index(
        "uq_intent_learning_pending_fingerprint",
        table_name="intent_learning_candidate",
        if_exists=True,
    )
    op.drop_index(
        "ix_intent_learning_candidate_fingerprint",
        table_name="intent_learning_candidate",
        if_exists=True,
    )
    op.drop_index(
        "ix_intent_learning_candidate_source_status",
        table_name="intent_learning_candidate",
        if_exists=True,
    )
    op.drop_index(
        "ix_intent_learning_candidate_status_last_seen",
        table_name="intent_learning_candidate",
        if_exists=True,
    )
    op.drop_table("intent_learning_candidate")
