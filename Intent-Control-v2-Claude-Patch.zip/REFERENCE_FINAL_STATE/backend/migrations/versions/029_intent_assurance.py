"""Add Intent Control assurance, shadow mode, and regression cases.

Revision ID: 029_intent_assurance
Revises: 028_intent_learning_candidates
"""

import sqlalchemy as sa
from alembic import op

revision = "029_intent_assurance"
down_revision = "028_intent_learning_candidates"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "intent_rule",
        sa.Column(
            "shadow_mode",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )
    op.add_column(
        "intent_rule",
        sa.Column(
            "test_cases_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'[]'::json"),
        ),
    )
    op.create_check_constraint(
        "ck_intent_rule_single_lifecycle_state",
        "intent_rule",
        "NOT (enabled AND shadow_mode)",
    )
    op.create_index(
        "ix_intent_rule_shadow_priority",
        "intent_rule",
        ["shadow_mode", "priority"],
    )

    op.create_table(
        "intent_shadow_evaluation",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("intent_id", sa.String(length=36), nullable=True),
        sa.Column("intent_name", sa.String(length=128), nullable=False),
        sa.Column("source_agent", sa.String(length=128), nullable=False),
        sa.Column("query_hash", sa.String(length=64), nullable=False),
        sa.Column("query_summary", sa.Text(), nullable=True),
        sa.Column("confidence", sa.Float(), nullable=False),
        sa.Column(
            "matched_by_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'[]'::json"),
        ),
        sa.Column("predicted_decision", sa.String(length=24), nullable=False),
        sa.Column("predicted_target_agent", sa.String(length=128), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.ForeignKeyConstraint(
            ["intent_id"],
            ["intent_rule.id"],
            ondelete="SET NULL",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_intent_shadow_evaluation_created",
        "intent_shadow_evaluation",
        ["created_at"],
    )
    op.create_index(
        "ix_intent_shadow_evaluation_intent_created",
        "intent_shadow_evaluation",
        ["intent_id", "created_at"],
    )
    op.create_index(
        "ix_intent_shadow_evaluation_source_created",
        "intent_shadow_evaluation",
        ["source_agent", "created_at"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_intent_shadow_evaluation_source_created",
        table_name="intent_shadow_evaluation",
    )
    op.drop_index(
        "ix_intent_shadow_evaluation_intent_created",
        table_name="intent_shadow_evaluation",
    )
    op.drop_index(
        "ix_intent_shadow_evaluation_created",
        table_name="intent_shadow_evaluation",
    )
    op.drop_table("intent_shadow_evaluation")
    op.drop_index("ix_intent_rule_shadow_priority", table_name="intent_rule")
    op.drop_constraint(
        "ck_intent_rule_single_lifecycle_state",
        "intent_rule",
        type_="check",
    )
    op.drop_column("intent_rule", "test_cases_json")
    op.drop_column("intent_rule", "shadow_mode")
