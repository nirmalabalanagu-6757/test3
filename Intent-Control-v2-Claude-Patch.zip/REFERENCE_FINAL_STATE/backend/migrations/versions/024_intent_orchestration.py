"""Add dynamic multi-agent intent orchestration and execution metadata.

Revision ID: 024_intent_orchestration
Revises: 023_intent_control
"""

import sqlalchemy as sa
from alembic import op

revision = "024_intent_orchestration"
down_revision = "023_intent_control"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "intent_rule",
        sa.Column("orchestration_mode", sa.String(20), nullable=False, server_default="single"),
    )
    op.add_column(
        "intent_rule",
        sa.Column("workflow_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
    )
    op.add_column(
        "intent_rule",
        sa.Column("allow_multi_intent", sa.Boolean(), nullable=False, server_default=sa.false()),
    )
    op.add_column(
        "intent_rule",
        sa.Column("max_intents", sa.Integer(), nullable=False, server_default="1"),
    )
    op.add_column("intent_rule", sa.Column("aggregator_agent", sa.String(128), nullable=True))
    op.add_column(
        "intent_rule",
        sa.Column("execution_options_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
    )
    op.add_column(
        "intent_rule",
        sa.Column("workflow_version", sa.Integer(), nullable=False, server_default="1"),
    )

    op.create_table(
        "intent_execution_run",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("session_id", sa.String(128), nullable=True),
        sa.Column("user_id", sa.String(128), nullable=True),
        sa.Column("query_hash", sa.String(64), nullable=False),
        sa.Column("query_summary", sa.Text(), nullable=True),
        sa.Column("intent_names_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("orchestration_mode", sa.String(20), nullable=False),
        sa.Column("workflow_versions_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
        sa.Column("status", sa.String(20), nullable=False, server_default="running"),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("response_summary", sa.Text(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
    )
    op.create_index(
        "ix_intent_execution_run_session_started",
        "intent_execution_run",
        ["session_id", "started_at"],
    )
    op.create_index(
        "ix_intent_execution_run_status_started",
        "intent_execution_run",
        ["status", "started_at"],
    )

    op.create_table(
        "intent_execution_step",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(36),
            sa.ForeignKey("intent_execution_run.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("intent_name", sa.String(128), nullable=False),
        sa.Column("step_id", sa.String(128), nullable=False),
        sa.Column("agent_name", sa.String(128), nullable=False),
        sa.Column("allowed_tools_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("used_tools_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("output_summary", sa.Text(), nullable=True),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
    )
    op.create_index(
        "ix_intent_execution_step_run",
        "intent_execution_step",
        ["run_id", "started_at"],
    )
    op.create_index(
        "ix_intent_execution_step_agent",
        "intent_execution_step",
        ["agent_name", "started_at"],
    )


def downgrade() -> None:
    op.drop_index("ix_intent_execution_step_agent", table_name="intent_execution_step")
    op.drop_index("ix_intent_execution_step_run", table_name="intent_execution_step")
    op.drop_table("intent_execution_step")
    op.drop_index("ix_intent_execution_run_status_started", table_name="intent_execution_run")
    op.drop_index("ix_intent_execution_run_session_started", table_name="intent_execution_run")
    op.drop_table("intent_execution_run")

    op.drop_column("intent_rule", "workflow_version")
    op.drop_column("intent_rule", "execution_options_json")
    op.drop_column("intent_rule", "aggregator_agent")
    op.drop_column("intent_rule", "max_intents")
    op.drop_column("intent_rule", "allow_multi_intent")
    op.drop_column("intent_rule", "workflow_json")
    op.drop_column("intent_rule", "orchestration_mode")
