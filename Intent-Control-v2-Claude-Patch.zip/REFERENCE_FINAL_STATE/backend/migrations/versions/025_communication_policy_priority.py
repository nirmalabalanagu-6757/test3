"""Align communication policy priority with the runtime model.

Revision ID: 025_policy_priority
Revises: 024_intent_orchestration
"""

import sqlalchemy as sa
from alembic import op

revision = "025_policy_priority"
down_revision = "024_intent_orchestration"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "communication_policy",
        sa.Column("priority", sa.Integer(), nullable=False, server_default="0"),
    )
    op.create_index(
        "ix_communication_policy_lookup",
        "communication_policy",
        ["source_agent", "target_agent", "priority"],
    )


def downgrade() -> None:
    op.drop_index("ix_communication_policy_lookup", table_name="communication_policy")
    op.drop_column("communication_policy", "priority")
