"""Add agent-level Intent Control and per-rule access scope.

Revision ID: 027_agent_intent_scope
Revises: 026_action_templates
"""

import sqlalchemy as sa
from alembic import op

revision = "027_agent_intent_scope"
down_revision = "026_action_templates"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "agent_registry",
        sa.Column(
            "intent_control_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
    )
    op.create_index(
        "ix_agent_registry_intent_control",
        "agent_registry",
        ["intent_control_enabled", "lifecycle_status"],
    )
    op.add_column(
        "intent_rule",
        sa.Column(
            "allowed_source_agents_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'[]'::json"),
        ),
    )
    op.add_column(
        "intent_execution_run",
        sa.Column("source_agent", sa.String(length=128), nullable=True),
    )
    op.create_index(
        "ix_intent_execution_run_source_started",
        "intent_execution_run",
        ["source_agent", "started_at"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_intent_execution_run_source_started",
        table_name="intent_execution_run",
    )
    op.drop_column("intent_execution_run", "source_agent")
    op.drop_column("intent_rule", "allowed_source_agents_json")
    op.drop_index("ix_agent_registry_intent_control", table_name="agent_registry")
    op.drop_column("agent_registry", "intent_control_enabled")
