"""Add structural tool-call evidence for reviewed intent learning.

Revision ID: 031_intent_call_learning
Revises: 030_reconcile_schema_drift
"""

import sqlalchemy as sa
from alembic import op

revision = "031_intent_call_learning"
down_revision = "030_reconcile_schema_drift"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "intent_learning_candidate",
        sa.Column(
            "observation_json",
            sa.JSON(),
            nullable=False,
            server_default=sa.text("'{}'"),
        ),
    )


def downgrade() -> None:
    op.drop_column("intent_learning_candidate", "observation_json")
