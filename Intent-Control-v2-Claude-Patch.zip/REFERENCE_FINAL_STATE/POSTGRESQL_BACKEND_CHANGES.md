# PostgreSQL backend changes

This build makes PostgreSQL 15.12+ mandatory.

- Removed `aiosqlite` runtime dependency.
- Removed SQLite default URLs from backend, systemd, Alembic and environment templates.
- `DATABASE_URL` must use `postgresql+asyncpg://`.
- Backend validates PostgreSQL `server_version_num >= 150012`.
- systemd performs the same version/connectivity check before migrations.
- RHEL installer enables PostgreSQL 15 and refuses packages/servers older than 15.12.
- Local installation creates the `aiops` role/database with SCRAM-SHA-256.
- Dynamic tool credentials use PostgreSQL `pgcrypto` only.
- Built-in primary database backup uses real `pg_dump` custom format.
- Production schema lifecycle is Alembic-managed; FastAPI startup no longer runs `create_all()`.
# Intent Control database addition

Migration `023_intent_control` adds the `intent_rule` configuration table used
by the separate Admin Intent Control panel. It is an additive migration and does
not modify existing SSO, user, agent, tool, policy, or credential tables.

The table stores matching, routing, governance, parameter, and response-policy
configuration. External API/CSV/JSON/SQL result data is not stored by this
feature.

Migration `024_intent_orchestration` extends each rule with versioned dynamic
workflow configuration, multi-intent options, aggregation settings and runtime
limits. It also adds `intent_execution_run` and `intent_execution_step` for
operational trace metadata. Full external-system payloads are not stored.

Migration `025_policy_priority` aligns the original communication-policy table
with its runtime model by adding the missing priority column and lookup index.

Migration `026_action_templates` adds the versioned `action_template` registry
and records the action-template name/version on intent execution steps. The
registry stores tool contracts, schemas, policy, and rendering configuration;
it does not store credentials or complete execution payloads.

Migration `027_agent_intent_scope` adds the agent-level Intent Control switch,
per-rule allowed-source-agent scope, and source-agent metadata on intent runs.
It is additive and defaults existing agents to enabled; existing rules use the
safe default scope of Concierge plus their target agent.
