# Dynamic Intent Learning and Approval

## Purpose

Dynamic Intent Learning turns repeated, unmatched chat requests into reviewed,
database-backed Intent Control rules. It is generic: it uses Agent Registry,
Tool Registry, Action Template Registry, and runtime observations instead of
hardcoded backup, database, API, or connector logic.

For the latest individual-call capture, parameterized action matching and
dependency replay, see [Dynamic tool-call learning](intent-dynamic-workflows.md).

The system reuses an approved **execution plan**. It never caches or replays an
old business response. API, database, backup, CSV, and other source data remain
live on every execution.

## Runtime lifecycle

1. Intent Control checks enabled rules before an entry-agent LLM is called.
2. A matched rule executes its approved workflow.
3. An unmatched top-level request follows the normal agent path.
4. During the request, bounded call arguments/results are inspected in local
   memory. After the response, learning stores structural call evidence,
   routing metadata, model names and a redacted prompt example; raw call
   arguments and results are not saved as learning evidence.
5. Similar prompts for the same source agent and the same observed tool route
   are grouped into one pending candidate. Different tool routes remain
   separate so approval cannot silently broaden a connector binding.
6. The application proposes matching, source scope, target agents, tools,
   workflow, parameters, risk, confirmation, and response behavior.
7. An administrator reviews and approves or rejects the candidate in
   **Intent Control > Learning Queue**.
8. Approval validates all agents, tool assignments, Action Templates, workflow
   dependencies, policies, and schemas before creating an enabled Intent Rule.
9. Later similar prompts resolve deterministically before LLM routing.

## Similar-intent version proposals

Before proposing a new Intent Rule, learning compares the normalized prompt with
the examples and keywords of enabled intents available to the same source agent.
A route-compatible match must score at least **80%** and must remain in the same
operation family, such as read, update, backup, restore, or execute.

An 80% or higher match creates or updates one pending Learning Queue proposal
for the existing intent; it never creates a second Intent Rule. The proposal
uses the next workflow version (`v1` becomes `v2`, then `v3`) and copies the
complete current configuration before adding the new reviewed examples and
keywords. This includes workflow steps, connection references, response mode,
response template, response options, risk controls, parameters, and versioned
Action Template references.

Action Templates are referenced by immutable `name@version` identifiers. An
intent-version proposal preserves those references; it does not silently clone
or replace an Action Template. Administrators may deliberately select another
published Action Template version while reviewing the proposal.

Approval updates the same intent database record and is audited. Renaming a
similar-intent proposal to create a duplicate is blocked. Approval is also
blocked when the intent changed after the proposal was generated, requiring a
fresh review against the latest version. Matches below 80% remain independent
new-intent candidates.

For a single-tool step, the proposal stores that Tool Registry name in both
`connection_ref` and the one-item `tools` allowlist. Runtime resolution pins the
step to that exact registered connector. An Action Template must reference the
same tool or approval is blocked. The reference never contains credentials or
an endpoint; those remain in Tool Registry and credential rotation does not
require recreating the intent.

Learned rule proposals enable bounded multi-intent selection by default. Once
separate backup, database, API, or other intents are approved, one combined
prompt can select several high-confidence rules and execute their workflows
together. A single observation that actually used several agents is proposed
as one composite multi-agent workflow; administrators can split it during
review when separate reusable intents are preferable.

Workflow-internal agent calls bypass learning and intent matching to prevent
recursive execution. Disabling Intent Control on an agent disables matching,
execution eligibility, and learning capture for that agent.

## LLM behavior

Intent matching, prompt grouping, proposal generation, approval, and parameter
extraction are deterministic and do not call an LLM.

An approved route can still use an LLM for execution:

| Proposed path | Runtime behavior |
|---|---|
| `direct_action` | An active, assigned Action Template with `execution_mode=direct` invokes the tool without an execution LLM. |
| `agent_llm` | Matching is deterministic, but the target agent uses its LLM to interpret or execute the request. |
| `multi_agent` | A generated multi-agent plan is reviewed; any step without a direct Action Template uses that agent's LLM. |

For a completely no-LLM execution path, every workflow step must reference an
active direct Action Template and no LLM aggregator may be configured. The
Learning Queue labels this path as **Direct action — no execution LLM**.

The application does not automatically cache generated answers because backup
status, SQL data, API data, incidents, and operational state can become stale.

## Generic scenario support

The learning engine treats connectors uniformly. Scenario-specific behavior is
declared in registered metadata:

| Scenario | Dynamic contract |
|---|---|
| SQL | Tool plus a versioned SQL Action Template and input schema |
| REST or GraphQL | API connector plus JSON/text Action Template |
| Skywise | Skywise tool plus dataset/query Action Template |
| CSV | CSV-capable tool plus schema, column mapping, and limits |
| JSON | JSON tool plus payload template and input/output schemas |
| Ansible | Ansible tool plus approved inventory/template inputs |
| MCP | MCP tool registration plus action template |
| Python/function | Assigned function tool plus action template |
| Multi-agent | Complete captured calls become separate dependency-aware steps; legacy route-only observations use agent workflows |

Adding a future connector does not require changing intent matching. Register
the tool, assign it to an agent, and optionally publish a compatible Action
Template.

## Automatic direct-action selection

A captured-call proposal uses direct Action Templates when every observed call
completed successfully, its complete arguments match exactly one published
action, and its inputs map to request parameters, declared defaults, or unique
prior result fields. Repeated calls remain separate. Ambiguous or incomplete
observations retain agent execution for review.

For legacy observations without individual-call evidence, a proposal uses a
direct Action Template only when all of these checks pass:

- the observed execution used exactly one registered active tool for that step;
- the tool is assigned to the observed target agent;
- exactly one compatible active direct Action Template exists for the tool;
- the Action Template policy allows that agent;
- every required input has a default, maps to the complete user query, or has a
  schema pattern that can be extracted deterministically.

If any check fails, the proposal remains an agent-LLM step for administrator
review. The system never guesses credentials, target resources, SQL, API body
fields, or destructive parameters.

## Administrator procedure

1. In **Agent Registry**, enable **Intent Control** for agents that should
   participate and capture unmatched top-level prompts.
2. Exercise the application normally.
3. Open **Intent Control > Learning Queue**.
4. Review grouped examples, source agent, observed agents/tools, occurrence
   count, proposal confidence, and proposed execution path.
5. Select **Review** and inspect or edit the complete proposed rule JSON.
6. For no-LLM execution, select an active direct Action Template in every
   workflow step and verify its action input mappings.
7. Confirm source-agent scope, required parameters, risk classification, and
   confirmation requirements.
8. Select **Approve and activate**, or reject the candidate.
9. Use **Test Resolution** with a similar prompt and the correct source agent.
10. Verify actual executions in **Run History**.

## Data handling and security

- Complete tool/API/database responses are not stored by learning.
- Prompt examples are capped and common credential forms are redacted before
  storage, including Bearer values, passwords, API keys, tokens, secrets, and
  long token-like values.
- Candidate approval is restricted to administrators and audited.
- Write and execute risk discovered from tools or Action Templates enables
  confirmation by default.
- A Concierge-only observation cannot safely infer a specialized target. It is
  retained with an empty target and must be completed by an administrator.
- Rejected and approved candidates remain visible for traceability.

## Database and API

Migration `028_intent_learning_candidates` creates
`intent_learning_candidate`.

Administrator endpoints:

- `GET /api/intent-learning`
- `GET /api/intent-learning/{candidate_id}`
- `POST /api/intent-learning/{candidate_id}/approve`
- `POST /api/intent-learning/{candidate_id}/reject`

Apply the migration before starting the updated backend:

```bash
alembic -c backend/migrations/alembic.ini upgrade head
```

## Safe Skywise sample workflows

The repository includes an idempotent sample seeder:

```bash
python -m backend.scripts.seed_intent_workflow_samples
```

It creates two active, read-only Action Templates:

- `sample.skywise.db-relationships.read@1`
- `sample.skywise.finops-list.read@1`

It also creates two Intent Rules that remain **disabled by default**:

- `sample.skywise.database-dependencies` — one direct database relationship read;
- `sample.skywise.impact-and-cost` — parallel database relationship and FinOps reads.

Both rules use direct Action Templates and have no aggregator agent, so their
approved execution path does not call an LLM. The seeder does not create or
store a Skywise credential and never contacts Skywise. Before enabling a sample,
configure a valid Bearer credential, verify the registered tool assignments,
test the endpoint, and review its matching and response limits. Running the
seeder again is safe; existing sample records are reported and left unchanged.

## Troubleshooting

- **No candidate appears:** Confirm the source agent has Intent Control enabled,
  the request was unmatched, and it was a top-level chat request.
- **Candidate says Agent LLM execution:** Publish and assign a compatible direct
  Action Template, then edit or regenerate the proposal before approval.
- **Approval reports a missing target:** Concierge handled the request without a
  specialized downstream route; select the intended specialized agent.
- **Similar prompt still falls through:** Add representative examples or stable
  keywords, lower confidence only after review, and use Test Resolution to see
  candidate scores.
- **Rule matches but an LLM is shown:** Matching avoided the routing LLM, but at
  least one workflow step is still an agent-LLM step.
- **Connection reference is empty:** Regenerate the candidate with this version
  after invoking the tool successfully, or set `connection_ref` to the exact
  Tool Registry name and keep `tools` as a one-item list containing the same
  value. Approval rejects mismatched action-template/tool bindings.
