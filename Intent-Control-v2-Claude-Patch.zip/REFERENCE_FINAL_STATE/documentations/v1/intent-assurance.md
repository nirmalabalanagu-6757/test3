# Intent Assurance, Shadow Mode, and Regression Testing

## Purpose

Intent Assurance provides a safe promotion path for database-driven routing:

```text
Draft -> Shadow -> Active
```

- **Draft** is stored but ignored by runtime matching.
- **Shadow** evaluates matching and parameter extraction, records a prediction,
  and then allows the normal active-rule/Concierge path to continue. It never
  routes, invokes an agent, or calls a tool.
- **Active** can route. The API refuses activation when a blocking readiness
  check or configured regression case fails.

The `enabled` and `shadow_mode` database flags are mutually exclusive. The UI
presents them as one lifecycle selection so an invalid combined state cannot be
created.

## Readiness checks

The Assurance tab checks each rule against live registry configuration:

- required, fallback, aggregator, and allowed source agents;
- agent-level Intent Control switches;
- tool existence, active state, and agent assignment;
- connector endpoint, authentication, encrypted credential, OAuth, TLS, and
  Skywise bearer requirements;
- Action Template publication, allowed-agent policy, risk, and assignment;
- deterministic-only versus LLM-dependent workflow steps;
- overlapping keywords, examples, regex patterns, and source-agent scopes;
- every administrator-defined regression case.

**Blockers** prevent activation. **Warnings** describe operational state or
cost, such as an agent that is registered but not currently running, an LLM
step, disabled TLS verification, or missing regression coverage. Warnings do
not prevent activation.

Python-backed Skywise tools are considered credential-ready only when they have
an encrypted registry bearer credential or the backend runtime provides
`FOUNDRY_TOKEN`/`SKYWISE_TOKEN`. Values are never returned by the assurance API.

## Regression case format

Regression cases are synthetic inputs stored in `test_cases_json`. Running them
does not execute tools and does not call an LLM. Agent health is reported
separately so a temporarily stopped agent does not make deterministic matching
tests unstable.

```json
[
  {
    "name": "bounded Skywise read",
    "query": "List the first 25 database application relationships",
    "source_agent": "concierge",
    "parameters_json": {},
    "confirmed": false,
    "expected_decision": "route",
    "expected_target_agent": "database_agent",
    "expected_parameters_json": {"row_limit": 25}
  },
  {
    "name": "unrelated request",
    "query": "Show the latest backup status",
    "source_agent": "concierge",
    "parameters_json": {},
    "confirmed": false,
    "expected_decision": "no_match",
    "expected_target_agent": null,
    "expected_parameters_json": {}
  }
]
```

Supported expected decisions are `route`, `clarify`, `confirm`, `deny`,
`llm_fallback`, `no_match`, and `unavailable`. Expected parameters are compared
as a subset, so a case needs to declare only values important to that test.

Recommended coverage includes:

1. one exact or high-confidence positive route;
2. unrelated and negative-keyword requests;
3. each required parameter and default;
4. confirmation for write/execute workflows;
5. allowed and denied source agents;
6. likely overlaps with adjacent intents.

## Conflict behavior

Conflict detection compares only rules with an overlapping source-agent scope.
It reports shared keywords, similar examples, and identical regex patterns.
An exact cross-agent overlap with a live rule is a blocker because the same
request could route to different specialists. Lower-confidence or same-target
overlap is a warning for administrator review.

## Shadow data and security

`intent_shadow_evaluation` stores operational prediction metadata only:

- rule and source-agent identifiers;
- SHA-256 request hash;
- a maximum 512-character request preview with bearer tokens, common secret
  assignments, and long token-like values redacted;
- confidence, matching methods, predicted decision, and predicted target;
- timestamp.

No tool result, API response, SQL result, CSV content, or full workflow payload
is stored. Apply the deployment's normal retention policy to this table. Avoid
using real secrets in test cases even though runtime previews are redacted.

## API

All endpoints require the administrator role.

```text
GET  /api/intents/assurance
GET  /api/intents/{id}/readiness
POST /api/intents/{id}/regression/run
GET  /api/intents/shadow-evaluations?intent_id=&source_agent=&limit=100
```

Creating, updating, or importing an Active rule automatically runs readiness.
On failure, the API returns HTTP `422` with code
`INTENT_ACTIVATION_BLOCKED` and includes the full readiness report in
`error.details.readiness`.

## Deployment

Apply the additive migration before starting the updated backend:

```bash
alembic -c backend/migrations/alembic.ini upgrade head
```

Then restart the backend and rebuild/restart the frontend. Existing rules keep
their current enabled state; the migration does not silently activate, disable,
or convert them to Shadow. Existing SSO implementation and session handling are
unchanged.
