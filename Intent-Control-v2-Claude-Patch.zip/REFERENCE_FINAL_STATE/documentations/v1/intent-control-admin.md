# Intent Control Administrator Guide

Reusable SQL, API, Skywise, Ansible, JSON, CSV, MCP, and Python contracts are
managed in the **Action Templates** tab. See
[Universal Action Template Registry](action-template-registry.md). Intent
workflow steps reference published versions with `action_template` and provide
validated values through `action_inputs`.

## Purpose

Intent Control is a separate **Admin** panel for maintaining deterministic
routing rules. Rules are evaluated before the LLM Concierge. A controlled match
can route directly to a running specialist agent without spending tokens on an
LLM routing decision. If no rule matches, the existing Concierge behavior is
preserved.

Open **Dashboard → Admin → Intent Control**.

## Panel areas

### Rules

Lists every configured intent and shows its matching method, target agent,
allowed source agents, confidence threshold, governance classification,
response mode, and state. Administrators can create, edit, move between Draft,
Shadow and Active,
search, filter by target agent, and delete rules.

### Assurance

Shows activation readiness, configuration blockers, operational warnings,
matching conflicts, deterministic regression results, and recent shadow
predictions. See [Intent assurance](intent-assurance.md).

### Test Resolution

Runs the deterministic resolver without calling an LLM or invoking a tool. Use
it to verify confidence, extracted parameters, ambiguity behavior, and the
selected agent before enabling a rule. Select a **Source agent** to test the
same agent-level switch and access scope used at runtime.

### Run History

Shows every intent-controlled execution, participating agents, workflow steps,
allowed and used tools, attempts, status, duration and errors. Only operational
metadata and truncated summaries are retained; complete business payloads are
not stored. Runs record their source agent and can be filtered agent-wise.

### Import / Export

Exports a versioned JSON document and imports it on another deployment. Import
can reject duplicate names or update existing rules. Agent and tool references
are validated on import.

## Rule options

### Identity and lifecycle

- **Intent identifier:** Stable identifier such as `incident.search`.
- **Display name:** Human-friendly label.
- **Description:** Administrator notes and purpose.
- **Draft:** Stored configuration that is never evaluated at runtime.
- **Shadow:** Evaluated and measured, but never routes, invokes an agent, or
  calls a tool.
- **Active:** May route after all blocking readiness checks pass.
- **Priority:** Tie-breaker when matching confidence is equal.

### Matching

- **Hybrid:** Uses exact, keyword, regex, and example matching together.
- **Exact:** Requires a normalized exact keyword/example match.
- **Keywords:** Matches configured words or phrases.
- **Regular expression:** Uses administrator-defined Python-compatible regex.
- **Examples:** Uses deterministic lexical similarity; it does not call an LLM.
- **Keyword mode:** Require any or all positive keywords.
- **Negative keywords:** Exclude a rule when any configured negative term is
  present.
- **Minimum confidence:** A rule below its own threshold is not selected.
- **Ambiguity margin:** Treat the top two matches as ambiguous when their score
  difference is within this margin.

Ambiguity actions are:

- **Use LLM Concierge:** Preserve normal LLM routing.
- **Ask for clarification:** Return a choice between the leading intents.
- **Use fallback agent:** Route to the configured fallback.
- **Route best match:** Select the highest score despite the close result.
- **Deny:** Block the request.

### Routing and governance

- **Agent-level Intent Control:** Configure this under **Agent Registry → Edit
  Agent → Details**. When disabled on a source agent, deterministic matching is
  skipped and normal agent routing continues. When disabled on a target or a
  required workflow agent, its intent rules are excluded before matching. New
  intent-run prompt summaries are therefore not collected for disabled agents.
- **Allowed source agents:** Restricts which entry agents can see and invoke the
  rule. An empty list uses the safe default: `concierge` plus the target agent.
- **Target agent:** Must reference a registered specialized agent. At runtime it
  must be in the `running` state and have Intent Control enabled.
- **Fallback agent:** Used when configured for ambiguity or when the target is
  unavailable.
- **Tool allowlist:** Restricts the selected agent to a subset of its active,
  assigned tools. An empty list retains all of that agent's assigned tools.
- **Risk:** `read_only`, `write`, or `execute`.
- **Require confirmation:** Stops the route and returns a confirmation request
  until the resolver receives `confirmed=true`.

Intent Control does not bypass Tool Governance. A tool must still be active and
assigned to the selected agent.

### Dynamic workflow orchestration

- **Orchestration mode:** `single`, `sequential`, `parallel`, or `dag`.
- **Workflow steps:** A JSON array describing agents, tools, dependencies,
  mappings, conditions, timeouts, retries and fallbacks.
- **Multi-intent:** Allows one prompt to select multiple independently matched
  intents up to the configured maximum.
- **Aggregator agent:** Optional specialist used only to synthesize completed
  step results. Its tools are disabled during aggregation.
- **Execution controls:** Set maximum parallel steps, total steps, agents, total
  timeout and the multi-intent confidence floor.

An empty workflow preserves v1 behavior by creating one runtime step from the
target agent and the per-intent tool allowlist.

```json
[
  {
    "id": "fetch",
    "agent": "skywise-agent",
    "tools": ["fetch_skywise_data"],
    "timeout_sec": 120,
    "retry_count": 1
  },
  {
    "id": "correlate",
    "agent": "database-agent",
    "tools": ["query_database"],
    "depends_on": ["fetch"],
    "input_mapping": {"incidents": "steps.fetch"},
    "on_failure": "continue"
  }
]
```

Sequential mode automatically links steps that omit dependencies. Parallel
mode starts independent steps concurrently. DAG mode follows explicit
`depends_on` edges. Cycles and missing dependencies are rejected during save.

### Parameter extraction

Parameter configuration is JSON. Values supplied explicitly to the resolve API
take precedence. Otherwise, regex capture groups extract values from the user
request. Defaults are applied last.

```json
{
  "required": ["application_code"],
  "properties": {
    "application_code": {
      "type": "string",
      "pattern": "application\\s+([A-Za-z0-9_-]+)",
      "prompt": "What is the application code?"
    },
    "row_limit": {
      "type": "integer",
      "pattern": "(?:limit|rows?)\\s+(\\d+)",
      "default": 100
    }
  }
}
```

Supported coercion types are `string`, `integer`, `number`, and `boolean`. If a
required value is missing, the user receives the configured prompt and routing
does not continue.

### Response policy

Response behavior is maintained per intent rather than hard-coded globally:

- `auto`
- `direct`
- `template`
- `internal_summary`
- `llm_summary`
- `detailed`

The selected mode, template, options, and extracted parameters are passed into
the governed target agent's instruction. `response_options_json` can hold
connector-specific options such as format, columns, grouping, metrics, sorting,
or limits. There is no mandatory 1,000-row limit; administrators configure any
limits needed for the intent and target system.

Example options:

```json
{
  "format": "table",
  "group_by": ["status"],
  "metrics": [{"field": "incident_id", "operation": "count"}],
  "sort": [{"field": "count", "direction": "desc"}],
  "max_rows": 250
}
```

## Recommended rollout

1. Register and start the target specialist agent.
2. Register and assign the tools the agent may use.
3. Create the intent in Draft.
4. Add regression cases for positive, negative, ambiguous,
   missing-parameter, confirmation, and denied-source requests.
5. Move the intent to Shadow and exercise representative requests. Review
   predictions and matching conflicts in Assurance.
6. Test each permitted and denied source agent, then confirm the confidence
   threshold and tool allowlist.
7. Move the intent to Active. Blocking readiness failures prevent activation.
8. Review `delegation`, `interaction`, and `config_change` events in Audit Log.

Start with high-confidence operational intents. Leave `llm_fallback` enabled for
unmatched requests until deterministic coverage is proven.

## Connection-refused errors

`CONN_REFUSED`, `ECONNREFUSED`, and browser connection-refused messages indicate
that the frontend cannot reach the backend service; they are not intent names or
resolver decisions. Verify both listeners and backend health before changing an
intent rule:

```bash
curl -f http://127.0.0.1:8000/health
curl -I http://127.0.0.1:3000/dashboard/intents
```

The web client reports this condition explicitly as **Backend API is
unreachable** so it is not confused with a matched intent.
