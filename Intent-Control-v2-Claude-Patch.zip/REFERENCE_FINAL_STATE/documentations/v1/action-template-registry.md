# Universal Action Template Registry

The Action Template Registry separates intent matching from tool invocation.
An intent decides **what** the user requested; a versioned action template
defines **how** one registered tool receives validated arguments.

Open **Dashboard → Admin → Intent Control → Action Templates** to manage the
registry. Credentials are never stored in action templates. They remain in the
Tool Registry and continue to use its encrypted credential handling.

## Supported template types

- SQL
- REST and GraphQL
- Skywise
- Ansible/AWX
- JSON and CSV
- MCP
- Python

The type identifies validation and administration behavior. `tool_name` is the
action's connection reference and binds the template to one active registered
tool. The UI labels it **Connection reference (registered tool)**. It is a
stable Tool Registry name, not an endpoint or credential.

## Lifecycle and versions

Templates use a stable `name` plus an integer `version`, referenced as
`name@version`. Drafts are editable and deletable. Active and deprecated
versions are immutable; use **Clone Version** to create a new draft. Disabled
versions cannot be selected by Intent Control. A published or disabled version
cannot return to draft state.

Intent workflows should use explicit versions for reproducibility:

```json
{
  "id": "database",
  "agent": "database_agent",
  "connection_ref": "postgres_read_tool",
  "tools": ["postgres_read_tool"],
  "action_template": "postgres.health@2",
  "action_inputs": {
    "server": "parameters.server",
    "row_limit": 100
  }
}
```

`action_inputs` values can be literals or references to `query`,
`parameters.name`, or `steps.id`. The selected template's tool becomes the only
tool exposed by that workflow step.

## Execution modes

`agent` renders the validated action contract and gives it to the selected
agent. The agent can invoke only the template's tool.

`direct` resolves the registered tool callable and invokes it with validated
arguments without an LLM call. The runtime verifies that the tool is active and
assigned to the workflow agent, validates its Python signature, applies the
step timeout/retry policy, validates output, enforces row/byte limits, and
records an audit event.

## Template content

`input_schema_json` uses the supported JSON Schema subset: object properties,
required fields, primitive types, enum, pattern, minimum/maximum,
minLength/maxLength, defaults, and `additionalProperties: false`.

`template_text` and `payload_template_json` support strict placeholders:

```json
{
  "query_params": {
    "server": "{{server}}",
    "rowLimit": "{{row_limit}}"
  }
}
```

A placeholder occupying the complete JSON value preserves its original type.
Unresolved and undeclared placeholders fail before tool execution.

For direct text templates, `execution_options_json.text_argument` specifies the
tool function argument receiving the rendered text. For example, an SQL-backed
tool commonly uses `sql_query`.

## Governance

`policy_json` controls risk classification, confirmation, allowed agents,
allowed resources, maximum rows, and maximum response bytes. An intent cannot
use an action with a higher risk classification and must enable confirmation if
the action requires it.

Read-only SQL templates must contain one `SELECT` or `WITH` statement and are
rejected if mutation keywords are present. When `allowed_resources` is set,
tables referenced by `FROM` and `JOIN` must be allowlisted. Production database
accounts should still be read-only because application validation is defense in
depth, not a replacement for database permissions.

## Administration APIs

- `GET /api/action-templates`
- `POST /api/action-templates`
- `GET /api/action-templates/{id}`
- `PUT /api/action-templates/{id}`
- `DELETE /api/action-templates/{id}` (drafts only)
- `POST /api/action-templates/{id}/clone`
- `POST /api/action-templates/{id}/render`

The render endpoint validates and previews the contract without invoking its
tool. Use it before publishing and before referencing the version from an
intent.
