# Intent Control v2 Dynamic Orchestration

## Compatibility

Migration `024_intent_orchestration` is additive. A v1 rule with no
`workflow_json` is compiled at runtime into one `primary` step using its
existing `target_agent`, `fallback_agent`, and `allowed_tools_json`. No existing
rule must be rewritten.

Migration `025_policy_priority` adds the communication-policy priority column
required to enforce and order multi-agent delegation rules.

## Resolution model

Resolution remains deterministic and consumes no LLM tokens. The highest match
is selected by default. When that rule enables `allow_multi_intent`, every
candidate meeting its own confidence threshold and the configured
`multi_intent_min_confidence` can be selected, up to `max_intents`.

The resolver returns an immutable snapshot containing each intent's workflow
version, parameters, steps, response policy and execution controls. Runtime
changes affect the next request, not a workflow already in progress.

## Workflow step schema

| Field | Purpose |
|---|---|
| `id` | Unique step identifier inside the intent |
| `agent` | Registered specialized agent |
| `tools` | Optional per-step allowlist; empty uses all assigned active tools |
| `connection_ref` | Exact Tool Registry name for a single-tool step; runtime restricts the step to this connector |
| `depends_on` | Step IDs that must finish first |
| `prompt_template` | Optional task template supporting `{query}`, `{intent}`, `{step}`, `{context}` |
| `action_template` | Optional versioned reference such as `postgres.health@2` |
| `action_inputs` | Literal or mapped inputs from `query`, `parameters.name`, or `steps.id` |
| `input_mapping` | Maps named inputs from `query`, `parameters.name`, or `steps.id` |
| `condition` | Safe declarative condition; no executable expressions |
| `required` | Whether failure makes the intent fail |
| `timeout_sec` | Per-attempt timeout |
| `retry_count` | Retries before fallback/failure |
| `on_failure` | `stop`, `continue`, or `fallback` |
| `fallback_agent` | Agent used after primary retries |
| `output_key` | Portable name reserved for downstream result handling |

Supported conditions use `source`, `operator`, and `value`. Sources are
`parameters.name` or `steps.id.status/output`. Operators are `equals`,
`not_equals`, `contains`, and `exists`.

## Execution modes

- `single`: zero or one configured step.
- `sequential`: one step at a time; missing dependencies are linked in array order.
- `parallel`: all dependency-ready steps run concurrently up to the configured limit.
- `dag`: the same bounded scheduler follows explicit dependency edges.
- Multi-intent: selected intents run independently and concurrently, then their
  responses are combined.

Every dependency edge is checked against Communication Policy before the target
agent runs. Every tool call still passes Tool Governance, active-state, approval
and assignment checks. Fallback agents are separately policy-checked.

For repeatable tool calls, use the
[Universal Action Template Registry](action-template-registry.md). The resolver
embeds an immutable template snapshot and exposes only its configured tool.
Direct execution avoids an LLM call; agent-guided execution supplies the
validated contract to the selected agent.

When `connection_ref` is present, `tools` must contain exactly that one name.
For backward compatibility, a legacy one-tool step gets the same reference at
resolution time. If an Action Template is configured, its `tool_name` must
match the connection reference. Multi-tool steps continue to use their exact
`tools` allowlist and intentionally have no singular connection reference.

## Response processing

- `direct`: return a single step result unchanged.
- `template`: replace `{intent}`, `{query}`, and `{results}` in the configured template.
- `internal_summary`: deterministic attributed sections without an LLM call.
- `llm_summary` / `detailed`: use the optional aggregator agent.
- `auto`: direct for one step; attributed sections for several steps; use the
  aggregator when one is configured.

The aggregator receives no tools, preventing synthesis from starting additional
side effects.

## Execution controls

```json
{
  "max_parallel_steps": 4,
  "max_total_steps": 25,
  "max_agents": 10,
  "total_timeout_sec": 600,
  "continue_on_optional_failure": true,
  "multi_intent_min_confidence": 0.75
}
```

Schema limits prevent unbounded plans. Per-step and total timeouts are enforced.
Connectors must use idempotency keys for write or execute operations because
generic orchestration cannot safely infer whether two external calls are
equivalent.

## Stored data

`intent_execution_run` stores the query hash, a 512-character query summary,
intent names, workflow versions, status, timing, error and a truncated response
summary. `intent_execution_step` stores the agent, allowed/used tool names,
attempts, status, timing, error and a truncated output summary. Full API, SQL,
CSV, JSON, file or Ansible payloads are not persisted.

## Validation checklist

1. Upgrade to Alembic head.
2. Register/start every workflow and aggregator agent.
3. Register, approve, activate and assign every referenced tool.
4. Configure Communication Policy edges between dependent agents.
5. Test resolution before enabling the rule.
6. Test success, timeout, fallback, denied edge and optional-step failure paths.
7. Review Run History and Audit Log after execution.
