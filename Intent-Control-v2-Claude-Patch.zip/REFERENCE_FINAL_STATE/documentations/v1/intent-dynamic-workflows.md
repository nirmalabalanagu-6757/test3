# Dynamic tool-call learning — v1 deployment and administrator guide

This update learns individual successful calls, their registered connections,
request parameters and result dependencies. It proposes an executable workflow
for administrator review. Repeating a request fetches current data.

## What changes for an administrator

1. Register and assign the tool using the existing Tool Registry.
2. Publish a direct Action Template for each supported operation. Its rendered
   arguments must match what the tool actually accepts.
3. Enable Intent Control on participating agents and make a normal unmatched
   request that successfully uses the tools.
4. Open **Intent Control > Learning Queue > Review**. The new **Observed tool
   calls** section lists each call, connection, completion state, dependencies,
   matching action and the reason it is ready or still requires review.
5. Review the proposed workflow, parameters, source scope and response mode;
   approve when correct. Use **Test Resolution** for representative variants.
6. Make a real request and inspect **Run History**. Direct Action Templates use
   no execution LLM. Any configured agent step or LLM aggregator still does.

Existing approved rules are not automatically rewritten. A similar unmatched
request with a compatible observed route can propose a reviewed next version
of an older route-only intent. That proposal preserves its identity, source
scope and response configuration while showing the new workflow and parameters.
Different observed action plans are not grouped solely because their prompts
or tool names look alike. To recapture an already-matching old rule, an
administrator can place it in Shadow and exercise the intended request.

## Parameterized actions

Example direct Action Template payload:

```json
{
  "operation": "list_backups",
  "query_params": {
    "server": "{{server}}",
    "rowLimit": "{{row_limit}}"
  }
}
```

Example `input_schema_json`:

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["server"],
  "properties": {
    "server": {
      "type": "string",
      "pattern": "[A-Za-z0-9_-]+",
      "x-intent": {"extractor": "label", "aliases": ["server", "host"]}
    },
    "row_limit": {
      "type": "integer",
      "minimum": 1,
      "maximum": 1000,
      "default": 100,
      "x-intent": {"extractor": "label", "aliases": ["limit", "first", "top"]}
    }
  }
}
```

`Show backups for server APP01 limit 25` and
`Show backups for server APP02 limit 50` reuse one approved plan, passing the
current server and limit. This example's default of 100 is template
configuration, not a global row limit. Remove the default and omit the field
from the actual request when the API should decide. For optional pass-through
inputs, set `execution_options_json.include_unmapped_inputs` to true and use
the tool's actual argument names. An absent optional input is omitted, not sent
as null. A placeholder used unconditionally in a payload needs a value or
default; omission does not erase arbitrary required payload fields.

The compiler derives label extraction from schema property names; aliases can
be declared in `x-intent`. Supported extraction settings are:

| Setting | Behavior |
| --- | --- |
| `extractor: "label"` | Named values such as `server APP01`, `server=APP01`, or quoted values |
| `extractor: "enum"` | A declared enum value, optionally with a field label |
| `extractor: "date"` | ISO date labels and `today`, `yesterday`, `last N days` |
| `aliases` | Additional labels meaningful to this action |
| `pattern` | Optional extraction regex; keep the scalar validation regex in the schema's ordinary `pattern` |
| `date_role: "start" / "end" / "single"` | Which date a relative range supplies |
| `occurrence` | Zero-based position for separate calls using different occurrences of the same label |

Relative dates use the current UTC date. `Last N days` includes today and is
bounded to 1–366 days. Dates are recomputed on each run. Local time zones,
arbitrary natural-language dates and implicit follow-up conversation references
are not implemented by this update.

Invalid or ambiguous recognized parameters produce clarification. Optional
parameters with invalid explicit values are not silently replaced by defaults.
Parameters remain scoped to each call, so two requests to the same connector
can use different servers without overwriting each other.

## Repeated calls, parallel calls and dependencies

Each call gets a separate step even when its agent and tool were used earlier.
Calls observed together before any response remain independent. A later call
depends on the registered calls already completed when it started; this
conservatively preserves ordering instead of guessing additional parallelism.

If a downstream input uniquely matches a meaningful earlier result field and
was not explicitly supplied in the user's request, the proposal stores a
reference, for example:

```json
{
  "id": "call_2",
  "agent": "backup_agent",
  "connection_ref": "backup_api",
  "tools": ["backup_api"],
  "depends_on": ["call_1"],
  "action_template": "backup.list@1",
  "action_inputs": {
    "server_ids": {"$from_step": {"step": "call_1", "path": "/servers"}}
  }
}
```

`path` is a JSON pointer: `/servers`, `/rows/0/id`, or an empty string for the
complete result. Data is read from the current run. Unknown dependencies,
malformed pointers, missing fields and incompatible types stop the action.
Failed/skipped dependencies prevent dependent tool calls. Ambiguous equal
values in several output fields require administrator mapping.

SQL tools can use fixed SQL text with separately bound parameters. Automatic
learning does not generalize unrestricted SQL or Ansible text placeholders;
numeric or enumerated text substitutions are supported, otherwise map through
the tool's parameter interface or review the action manually. CSV tools can
reuse schema-mapped arguments; automatic inference of links inside raw CSV
text is not provided. A connector can expose parsed JSON for structured links.

## Action selection and incomplete evidence

Selection compares the complete rendered arguments against the observed call,
including constant operation, path/body fields and validated dynamic inputs.
It also checks active publication, connection assignment and allowed agents.
One exact match is required. Two equivalent published versions are ambiguous;
the compiler does not silently choose the newest version.

Failed, blocked, unfinished, unpaired or over-limit calls cannot produce a
direct replay proposal. If a complete direct workflow cannot be proved, the
candidate retains ordinary agent execution and shows structural evidence for
review. It does not automatically publish a new action template or recreate
an unknown operation. New connector kinds still require a registered adapter.

## Storage and limits

Call arguments and results are temporarily inspected in request-local memory.
They are not saved in `observation_json`. Persisted evidence contains call IDs,
registered agent/tool names, argument names, completion states, dependency
IDs, action references and review reasons. The existing redacted prompt
examples and existing audit/run summaries retain their existing behavior.

Capture is bounded to 100 calls, 256,000 bytes per value and 2,000,000 bytes per
request. A limit prevents automatic direct compilation for that observation.
Credentials remain in the existing Tool Registry; they are never copied into
learned bindings. This update does not edit SSO code or configuration.

## Database and deployment

Migration `031_intent_call_learning`, after `030_reconcile_schema_drift`, adds
one non-null JSON column with an empty-object default:

```sql
ALTER TABLE intent_learning_candidate
ADD COLUMN observation_json JSON DEFAULT '{}' NOT NULL;
```

Apply the additive migration with the application's Python environment before
starting the updated backend:

```bash
python -m alembic -c backend/migrations/alembic.ini upgrade head
cd frontend
npm ci
npm run build
```

For OCP, run the migration once through the deployment's normal migration job,
then deploy the rebuilt backend/frontend images. For a local checkout, restart
the backend process and refresh the frontend. No credentials or `.env` updates
are required for this feature.

For rollback, first export/review rules created or upgraded by this feature.
Older application versions do not understand `$from_step` / `$parameter`
bindings: disable those rules or restore their earlier exported definitions
before reverting application code. The additive column may remain present.
Only downgrade the database to `030_reconcile_schema_drift` when no later
migration depends on it; that removes the structural observation metadata.

## Verification

```bash
python -m pytest tests -q
# Optional: transaction-isolated tests against localhost PostgreSQL only
INTENT_TEST_LOCAL_DB=1 python -m pytest tests/test_intent_learning_database.py -q
cd frontend
npm test -- --run
npm run build
```

The workflow tests execute synthetic database and backup callables through the
real action renderer/orchestrator twice with different inputs. They assert
that downstream arguments come from fresh results and no LLM is invoked.
PostgreSQL tests exercise migration upgrade/downgrade and database-backed
capture, deduplication, approval, resolution and agent disablement. They use
temporary objects/transaction-isolated schemas and roll back all test data.
These checks do not contact the customer's Skywise, backup or Ansible systems.
