# AIOps4Cloud v1 Administration Documentation

- [Intent Control administrator guide](intent-control-admin.md)
- [Intent Control architecture and API](intent-control-architecture.md)
- [Intent Control v2 dynamic orchestration](intent-control-v2-orchestration.md)
- [Universal Action Template Registry](action-template-registry.md)
- [Dynamic intent learning and approval](intent-learning.md)
- [Dynamic tool-call learning, parameters and dependencies](intent-dynamic-workflows.md)
- [Intent assurance, shadow mode, and regression testing](intent-assurance.md)

These documents describe the database-driven Intent Control feature introduced
by migrations `023_intent_control` through `031_intent_call_learning`. Existing
authentication code is not changed by this feature.
