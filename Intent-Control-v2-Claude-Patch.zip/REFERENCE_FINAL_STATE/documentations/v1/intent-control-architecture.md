# Intent Control Architecture and API

## Runtime architecture

```text
Chat WebSocket
    |
    v
ChatService / AgentRunner
    |
    v
IntentControlService (PostgreSQL intent_rule)
    |-- exact / keyword / regex / example score
    |-- negative-term exclusion
    |-- confidence + ambiguity policy
    |-- parameter extraction
    |-- single / multi-intent selection
    |-- workflow and target availability
    |-- confirmation / risk metadata
    |
    |-- route ----------> Intent Orchestrator
    |                         |-- single / sequential / parallel / DAG
    |                         |-- per-step tools, mappings, conditions
    |                         |-- retries, timeout, fallback
    |                         |-- communication + tool governance
    |                         `-- internal/template/LLM aggregation
    |
    |-- clarify/deny --> Deterministic response
    |
    `-- no match / LLM fallback --> Existing ADK Concierge

Every run and workflow step --> intent_execution_run / intent_execution_step
Every matching shadow rule --> intent_shadow_evaluation (no execution)
Every delegation and governed tool call --> Existing Audit Log
```

This is a hybrid design. It does not replace the Concierge, agent registry,
communication policy, tool registry, assignment checks, or credential handling.
It adds a deterministic control plane before the existing LLM routing plane.

## Database

Migration `023_intent_control` creates `intent_rule`. Migration
`024_intent_orchestration` adds portable workflow fields and execution metadata
tables. Existing single-agent rules remain valid and execute as a generated
one-step workflow.

Important JSON columns keep the feature tool-agnostic:

- `keywords_json`
- `negative_keywords_json`
- `regex_patterns_json`
- `examples_json`
- `allowed_tools_json`
- `parameter_config_json`
- `response_options_json`
- `workflow_json`
- `execution_options_json`
- `test_cases_json`

Migration `029_intent_assurance` adds the mutually exclusive Draft/Shadow/Active
lifecycle, regression cases, activation readiness gates, and redacted shadow
prediction metadata. It does not modify SSO or authentication middleware.

The rule table stores configuration. Run and step tables store status, timing,
agent/tool names and truncated summaries. Complete API, CSV, JSON, Ansible or
SQL business payloads are not persisted by Intent Control.

## Matching scores

- Exact normalized match: `1.00`
- Regex match: `0.97`
- Keyword match: `0.55 + 0.40 × coverage`, capped at `0.95`
- Example similarity: deterministic token/sequence similarity, capped at `0.90`
- Parameterized example match: `0.96` for a learned rule with validated parameter extraction

The highest method score is used. Priority breaks equal scores. A rule must meet
its own `min_confidence`. Negative terms exclude the rule before scoring.

## REST API

All endpoints require the administrator role.

```text
GET    /api/intents
POST   /api/intents
GET    /api/intents/{id}
PUT    /api/intents/{id}
DELETE /api/intents/{id}
POST   /api/intents/resolve
GET    /api/intents/export
POST   /api/intents/import
GET    /api/intents/runs
GET    /api/intents/runs/{run_id}
GET    /api/intents/assurance
GET    /api/intents/{id}/readiness
POST   /api/intents/{id}/regression/run
GET    /api/intents/shadow-evaluations
```

### Test a resolution

```json
POST /api/intents/resolve
{
  "query": "show incidents application APP42 limit 25",
  "parameters": {},
  "confirmed": false
}
```

Possible decisions:

- `route`
- `clarify`
- `confirm`
- `deny`
- `llm_fallback`
- `no_match`
- `unavailable`

The result includes all selected intents, immutable workflow snapshots, target
agents, per-step tools, confidence, parameters, risk and response policy.

## Tool compatibility

Intent Control selects one or more agents and optionally narrows the tool set of
each workflow step. Tool invocation remains with the dynamic tool layer, so
rules are independent of transport and data format. Tools may be REST JSON/CSV,
SQL, Ansible/AWX, file exchange, MCP, Python, or another registered adapter.

## Token behavior

Deterministic matching and database lookup use no LLM tokens. A matched route
skips the Concierge routing call. The specialist agent may still use LLM tokens
to understand parameters, call tools, or produce its final answer. A `no_match`
or `llm_fallback` decision intentionally invokes the existing Concierge.

## Deployment

```bash
alembic -c backend/migrations/alembic.ini upgrade head
systemctl restart aiops.service
```

Verify:

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/api/intents
```

Rollback only when no later migration depends on this revision:

```bash
alembic -c backend/migrations/alembic.ini downgrade 023_intent_control
```

Downgrade removes v2 workflow/run fields and execution history while retaining
the original v1 intent rules. Export rules before downgrade.
