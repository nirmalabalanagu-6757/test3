# AIOps Governance Platform — RHEL 9 / Python 3.12 / PostgreSQL 15.12+

This package is the standalone RHEL 9 build of the AIOps Governance Platform.
It uses **PostgreSQL 15.12 or newer as the mandatory backend database**.
SQLite is not a runtime option and there is no SQLite fallback.

## Runtime architecture

```text
Browser
  |
  v
Nginx :80
  |-- /             -> React/Vite frontend
  |-- /api/*        -> FastAPI 127.0.0.1:8000
  `-- /api/chat/*   -> FastAPI WebSocket
                         |
                         v
                 PostgreSQL 15.12+
                    |    |    |
                    |    |    +-- audit / governance
                    |    +------- agent/tool registry
                    +------------ dynamic runtime state
```

## Supported platform

- RHEL 9.4+
- Python 3.12
- PostgreSQL **15.12+**
- SQLAlchemy async engine with `asyncpg`
- Alembic migrations
- Nginx + systemd
- React/Vite frontend

The included installer uses the RHEL PostgreSQL 15 module for a local database.
A remote/external PostgreSQL database is also supported when `DATABASE_URL`
points to it, but the application will refuse to start if its server version is
older than 15.12.

## Database configuration

The application requires:

```bash
DATABASE_URL=postgresql+asyncpg://aiops:<password>@127.0.0.1:5432/aiops
```

`backend/config.py`, `backend/database.py`, Alembic, systemd and the deployment
pre-check all enforce the PostgreSQL asyncpg URL. There is no default SQLite URL.

At startup the application checks `server_version_num` and requires at least
`150012` (PostgreSQL 15.12).

## Install

For a dedicated RHEL 9 VM:

```bash
sudo ./deploy/rhel9/install_vm.sh
```

The installer:

1. Enables the approved PostgreSQL 15 RHEL module.
2. Installs PostgreSQL client/server/contrib packages.
3. Rejects a PostgreSQL package older than 15.12.
4. Creates `/etc/aiops/aiops.env`.
5. For localhost deployments, initializes PostgreSQL and creates the `aiops`
   role/database using SCRAM authentication.
6. Enables `pgcrypto` for encrypted dynamic-tool credentials.
7. Builds the Python 3.12 virtual environment and frontend.
8. Validates PostgreSQL 15.12+ connectivity.
9. Runs Alembic migrations before FastAPI starts.

See [INSTALL_RHEL9_VM.md](INSTALL_RHEL9_VM.md) for details.

## Database backup

The built-in backup service uses a real PostgreSQL `pg_dump` custom-format
backup for the primary database. The default store name is:

```text
postgresql_main
```

There is no SQLite database backup path.

## Dynamic agent and tool runtime

This build retains the enhanced dynamic runtime:

- database-driven agent registration
- persistent agent-to-tool assignment
- REST tools with GET/POST/PUT/PATCH/DELETE
- dedicated Skywise API v2 Read Table registration with safe runtime query options
- API key, Bearer, Basic, Digest and OAuth2 client credentials
- MCP discovery and `tools/call`
- runtime cache invalidation after assignments/configuration changes
- active/lifecycle governance and audit records
- dynamic connector credentials encrypted with PostgreSQL `pgcrypto`

Existing Python-backed tools continue to work alongside database-defined REST
and MCP tools.

## Intent Control

Administrators can maintain deterministic intent routing under **Dashboard →
Admin → Intent Control**. Rules are stored in PostgreSQL and evaluated before
the LLM Concierge using exact, keyword, regular-expression, and example
matching. Rules support confidence and ambiguity controls, parameter extraction,
agent routing, per-intent tool allowlists, risk/confirmation settings, response
policies, live resolution testing, and JSON import/export.

Intent routing is agent-aware: each registered agent has an Intent Control
enable/disable switch, rules can restrict allowed source agents, the rule list
can be split by target agent, and run history records/filter its source agent.
An empty rule access list defaults to Concierge plus the target agent.

Unmatched requests continue through the existing Concierge. See
[`documentations/v1/intent-control-admin.md`](documentations/v1/intent-control-admin.md)
for administration and
[`documentations/v1/intent-control-architecture.md`](documentations/v1/intent-control-architecture.md)

Intent Control v2 adds multi-intent matching and database-configured single,
sequential, parallel and DAG workflows. Every step can select its own agent,
tool allowlist, dependencies, mappings, conditions, timeout, retry and fallback
behavior. Execution metadata is available in the Admin **Run History** tab.

[`documentations/v1/intent-control-v2-orchestration.md`](documentations/v1/intent-control-v2-orchestration.md)
for runtime/API details.

Intent workflows can reference versioned contracts from the **Universal Action
Template Registry**. Templates support SQL, REST, GraphQL, Skywise, Ansible,
JSON, CSV, MCP, and Python tools with JSON-schema input validation, governance
policies, immutable published versions, dry rendering, and optional direct tool
execution without an additional LLM call. See
[`documentations/v1/action-template-registry.md`](documentations/v1/action-template-registry.md).

## Authentication model

This standalone build retains the local VM administrator model:

- Username: `vm-admin`
- Role: `admin`

There is no SSO/JWT login in this build. Anyone who can reach the application
has administrator access, so keep it on a trusted network or put an approved
access-control layer in front of Nginx.

## Validation commands

```bash
python3.12 -m compileall backend agents
bash -n deploy/rhel9/install_vm.sh
bash -n app.sh

export DATABASE_URL='postgresql+asyncpg://aiops:<password>@127.0.0.1:5432/aiops'
python3.12 deploy/rhel9/check_postgresql.py
alembic -c backend/migrations/alembic.ini upgrade head
```

Health endpoint:

```bash
curl http://127.0.0.1:8000/health
```
