"""Governance callback implementations for ADK agent lifecycle hooks.

The ``policy_check_callback`` is fully integrated with the
:class:`~backend.services.communication_policy.CommunicationPolicyService`
to enforce directional allow/deny rules on agent-to-agent transfers.
Policy changes apply within seconds — no agent restart required.

The ``tool_governance_callback`` is fully integrated with the
:class:`~backend.services.tool_registry.ToolRegistryService` to enforce
that tools must be **active** and **assigned** to the invoking agent.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# before_agent_callback — communication policy enforcement
# ---------------------------------------------------------------------------

async def policy_check_callback(**kwargs: Any) -> Any:
    """Enforce communication policies before an agent-to-agent transfer.

    ADK 2.3.0 ``before_agent_callback`` — receives ``callback_context``
    as a keyword argument.  Returns ``None`` to allow or
    ``types.Content`` to block.
    """
    callback_context = kwargs.get("callback_context")
    source_agent = getattr(callback_context, "agent_name", "unknown") if callback_context else "unknown"
    target_agent = kwargs.get("agent_name", "unknown")

    try:
        from backend.database import async_session_factory
        from backend.services.audit_log import AuditLogService
        from backend.services.communication_policy import CommunicationPolicyService

        policy_service = CommunicationPolicyService()
        audit_service = AuditLogService()

        async with async_session_factory() as session:
            decision = await policy_service.check_policy(
                session, source_agent, target_agent
            )

            if decision.decision == "deny":
                # Log the violation
                await audit_service.append(
                    session,
                    "policy_violation",
                    source_agent=source_agent,
                    target_agent=target_agent,
                    details={
                        "action": "transfer_blocked",
                        "matched_rule_id": decision.matched_rule_id,
                        "reason": decision.reason,
                    },
                )
                await session.commit()

                logger.warning(
                    "policy_check: BLOCKED %s -> %s (%s)",
                    source_agent,
                    target_agent,
                    decision.reason,
                )
                from google.genai import types
                msg = (
                    f"Communication from '{source_agent}' to '{target_agent}' "
                    f"is denied by policy. {decision.reason}"
                )
                return types.Content(
                    role="model", parts=[types.Part(text=msg)]
                )

            logger.debug(
                "policy_check: ALLOWED %s -> %s (%s)",
                source_agent,
                target_agent,
                decision.reason,
            )
            return None  # allow

    except Exception:
        # If policy service is unavailable, fail open with a warning.
        logger.exception(
            "policy_check: error evaluating policy for %s -> %s; "
            "failing open (allowed)",
            source_agent,
            target_agent,
        )
        return None  # allow


# ---------------------------------------------------------------------------
# before_tool_callback — tool governance check
# ---------------------------------------------------------------------------

async def tool_governance_callback(**kwargs: Any) -> dict[str, Any] | None:
    """Verify a tool is active and assigned to the invoking agent.

    ADK 2.3.0 ``before_tool_callback`` — receives ``tool``, ``args``,
    and ``tool_context`` as keyword arguments.  Returns ``None`` to
    allow or a ``dict`` to block (used as the tool response).
    """
    tool_context = kwargs.get("tool_context")
    agent_name = getattr(tool_context, "agent_name", "unknown") if tool_context else "unknown"
    tool = kwargs.get("tool")
    tool_name = getattr(tool, "name", "") if tool else ""

    try:
        from backend.database import async_session_factory
        from backend.services.audit_log import AuditLogService
        from backend.services.tool_registry import ToolRegistryService

        registry = ToolRegistryService()
        audit = AuditLogService()

        async with async_session_factory() as session:
            authorized, reason = await registry.check_tool_authorized(
                session, tool_name, agent_name
            )

            if not authorized:
                logger.warning(
                    "tool_governance: BLOCKED agent=%s tool=%s reason=%s",
                    agent_name,
                    tool_name,
                    reason,
                )
                await audit.append(
                    session,
                    "policy_violation",
                    agent_name=agent_name,
                    tool_name=tool_name,
                    details={
                        "action": "tool_invocation_blocked",
                        "reason": reason,
                    },
                )
                await session.commit()
                return {"blocked": True, "reason": reason}

            # Record successful governance check
            await audit.append(
                session,
                "tool_invocation",
                agent_name=agent_name,
                tool_name=tool_name,
                details={
                    "action": "tool_invocation_allowed",
                },
            )
            await session.commit()

        logger.info(
            "tool_governance: ALLOWED agent=%s tool=%s",
            agent_name,
            tool_name,
        )
        from backend.services.intent_trace import record_tool_callback

        record_tool_callback(context=tool_context, tool=tool, arguments=kwargs.get("args"))
        return None  # allow

    except Exception as exc:
        # Dynamic/write-capable tools should not silently bypass governance.
        # Emergency fail-open can be enabled explicitly for legacy deployments.
        import os

        fail_open = os.getenv("AIOPS_GOVERNANCE_FAIL_OPEN", "false").strip().lower() in {"1", "true", "yes", "on"}
        logger.exception(
            "tool_governance: registry check failed for agent=%s tool=%s; fail_open=%s",
            agent_name,
            tool_name,
            fail_open,
        )
        if fail_open:
            return None
        return {
            "blocked": True,
            "reason": f"Tool governance service unavailable; invocation blocked: {exc}",
        }


# ---------------------------------------------------------------------------
# after_tool_callback — audit logging for tool invocations
# ---------------------------------------------------------------------------

async def audit_tool_callback(**kwargs: Any) -> None:
    """Record a tool invocation in the Audit Log.

    ADK 2.3.0 ``after_tool_callback`` — receives ``tool``, ``args``,
    ``tool_context``, and ``tool_response`` as keyword arguments.
    """
    tool_context = kwargs.get("tool_context")
    agent_name = getattr(tool_context, "agent_name", "unknown") if tool_context else "unknown"
    tool = kwargs.get("tool")
    tool_name = getattr(tool, "name", "") if tool else ""
    from backend.services.intent_trace import record_tool_callback

    record_tool_callback(context=tool_context, tool=tool, arguments=kwargs.get("args"),
                         response=kwargs.get("tool_response"), finished=True)
    logger.info(
        "audit_tool: agent=%s tool=%s",
        agent_name,
        tool_name,
    )
    # Increment tool usage counter
    try:
        from backend.database import async_session_factory
        from sqlalchemy import text
        async with async_session_factory() as session:
            await session.execute(
                text("UPDATE tool_registry SET invocation_count = invocation_count + 1 WHERE name = :name"),
                {"name": tool_name},
            )
            await session.commit()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# before_model_callback — token budget enforcement
# ---------------------------------------------------------------------------

async def token_budget_check_callback(**kwargs: Any) -> Any:
    """Check token budget before an LLM call.

    ADK 2.3.0 ``before_model_callback`` — receives ``callback_context``
    and ``llm_request`` as keyword arguments.  Returns ``None`` to allow
    or ``LlmResponse`` to block.
    """
    callback_context = kwargs.get("callback_context")
    agent_name = getattr(callback_context, "agent_name", "unknown") if callback_context else "unknown"

    try:
        from backend.database import async_session_factory
        from backend.services.token_manager import TokenManagerService

        token_service = TokenManagerService()

        async with async_session_factory() as session:
            allowed, daily_rem, monthly_rem, daily_pct, monthly_pct, warning = (
                await token_service.check_budget(session, agent_name)
            )

            if not allowed:
                logger.warning(
                    "token_budget_check: BLOCKED agent=%s daily_pct=%.1f%% monthly_pct=%.1f%% reason=%s",
                    agent_name, daily_pct, monthly_pct, warning,
                )
                from google.adk.models.llm_response import LlmResponse
                from google.genai import types
                msg = warning or f"Agent '{agent_name}' has exceeded its token budget."
                return LlmResponse(
                    content=types.Content(
                        role="model", parts=[types.Part(text=msg)]
                    ),
                )

            if warning:
                logger.warning(
                    "token_budget_check: WARNING agent=%s — %s",
                    agent_name, warning,
                )

            logger.debug(
                "token_budget_check: ALLOWED agent=%s daily_pct=%.1f%% monthly_pct=%.1f%%",
                agent_name, daily_pct, monthly_pct,
            )
            return None  # allow

    except Exception:
        # If the token service is unavailable, fail open to avoid
        # blocking agent operations due to infrastructure issues.
        logger.exception(
            "token_budget_check: error checking budget for agent=%s — allowing as fallback",
            agent_name,
        )
        return None  # allow


_VERTEX_MODEL_PREFIXES = (
    "publishers/google/models/",
    "publishers/anthropic/models/",
    "models/",
)


def _normalize_model_name(raw: str | None) -> str | None:
    """Strip Vertex AI resource-path prefixes to get the bare model name."""
    if not raw:
        return raw
    for prefix in _VERTEX_MODEL_PREFIXES:
        if raw.startswith(prefix):
            return raw[len(prefix):]
    return raw


# ---------------------------------------------------------------------------
# after_model_callback — token usage recording
# ---------------------------------------------------------------------------

def _extract_usage_from_metadata(usage_metadata: Any) -> tuple[int, int]:
    """Extract prompt and completion token counts from a usage metadata object.

    Handles multiple naming conventions across SDK versions:
    - google.genai: prompt_token_count, candidates_token_count
    - Anthropic adapter: prompt_token_count, candidates_token_count (SimpleNamespace)
    - Newer genai / dict: prompt_tokens, completion_tokens
    """
    if usage_metadata is None:
        return 0, 0

    if isinstance(usage_metadata, dict):
        prompt = (
            usage_metadata.get("prompt_token_count")
            or usage_metadata.get("prompt_tokens")
            or usage_metadata.get("input_tokens")
            or 0
        )
        completion = (
            usage_metadata.get("candidates_token_count")
            or usage_metadata.get("completion_tokens")
            or usage_metadata.get("output_tokens")
            or 0
        )
        return int(prompt), int(completion)

    prompt = (
        getattr(usage_metadata, "prompt_token_count", None)
        or getattr(usage_metadata, "prompt_tokens", None)
        or getattr(usage_metadata, "input_tokens", None)
        or 0
    )
    completion = (
        getattr(usage_metadata, "candidates_token_count", None)
        or getattr(usage_metadata, "completion_tokens", None)
        or getattr(usage_metadata, "output_tokens", None)
        or 0
    )
    return int(prompt), int(completion)


async def record_token_usage_callback(**kwargs: Any) -> None:
    """Record token usage after an LLM call.

    ADK 2.3.0 ``after_model_callback`` — receives ``callback_context``
    and ``llm_response`` as keyword arguments.  Returns ``None`` (does
    not modify the response).
    """
    callback_context = kwargs.get("callback_context")
    agent_name = getattr(callback_context, "agent_name", "unknown") if callback_context else "unknown"

    try:
        # Extract token counts from the LLM response metadata.
        # ADK passes the model response via kwargs; the exact structure
        # depends on the Gemini SDK version.
        llm_response = kwargs.get("llm_response") or kwargs.get("response")
        prompt_tokens = 0
        completion_tokens = 0
        model_name = None

        if llm_response is not None:
            usage_metadata = getattr(llm_response, "usage_metadata", None)
            prompt_tokens, completion_tokens = _extract_usage_from_metadata(usage_metadata)

            # Try dict-style access as fallback
            if prompt_tokens == 0 and completion_tokens == 0 and isinstance(llm_response, dict):
                usage = llm_response.get("usage_metadata", {})
                prompt_tokens, completion_tokens = _extract_usage_from_metadata(usage)

            # Model name: ADK LlmResponse uses model_version, not model
            model_name = _normalize_model_name(
                getattr(llm_response, "model", None)
                or getattr(llm_response, "model_version", None)
            )
            if model_name is None and isinstance(llm_response, dict):
                model_name = _normalize_model_name(
                    llm_response.get("model") or llm_response.get("model_version")
                )

        # If we could not extract tokens, still log a zero-usage record
        # so we at least track the call count.
        session_id = getattr(callback_context, "session_id", None)
        user_id = getattr(callback_context, "user_id", None)

        from backend.database import async_session_factory
        from backend.services.token_manager import TokenManagerService
        from sqlalchemy import text

        # ADK LlmResponse often lacks a model attribute — resolve from DB.
        # Try both the exact callback name and without "_agent" suffix,
        # since agent_definitions.py may register as e.g. "concierge"
        # while config.yaml names the ADK agent "concierge_agent".
        if not model_name and agent_name != "unknown":
            try:
                from sqlalchemy import select as sa_select
                from backend.models.agent import AgentRegistry

                candidates = [agent_name]
                if agent_name.endswith("_agent"):
                    candidates.append(agent_name[: -len("_agent")])

                async with async_session_factory() as db:
                    for candidate in candidates:
                        result = await db.execute(
                            sa_select(AgentRegistry.model_config_json).where(AgentRegistry.name == candidate)
                        )
                        row = result.scalar_one_or_none()
                        if row:
                            cfg = row.strip()
                            if cfg.startswith("{") and cfg.endswith("}"):
                                import json
                                model_name = json.loads(cfg).get("model")
                            else:
                                model_name = cfg
                            break
            except Exception:
                pass

        token_service = TokenManagerService()

        async with async_session_factory() as session:
            await token_service.record_usage(
                session,
                agent_name=agent_name,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                model=model_name,
                session_id=session_id,
                user_id=user_id,
            )

            if model_name:
                await session.execute(
                    text("UPDATE llm_model_registry SET invocation_count = invocation_count + 1 WHERE name = :name"),
                    {"name": model_name},
                )

            await session.commit()

        logger.info(
            "record_token_usage: agent=%s prompt=%d completion=%d model=%s",
            agent_name, prompt_tokens, completion_tokens, model_name,
        )

    except Exception:
        # Never let usage recording failures break agent execution.
        logger.exception(
            "record_token_usage: error recording usage for agent=%s",
            agent_name,
        )
