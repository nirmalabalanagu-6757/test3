import { useState, useRef, useEffect } from "react";
import { Routes, Route, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "./auth/AuthContext";
import ChatPage from "./pages/ChatPage";
import CockpitPage from "./pages/CockpitPage";
import DashboardPage from "./pages/DashboardPage";

const PAGES = [
  { key: "chat", label: "Chat", path: "/chat" },
  { key: "cockpit", label: "Cockpit", path: "/cockpit" },
  { key: "dashboard", label: "Dashboard", path: "/dashboard" },
] as const;

function useClickOutside(ref: React.RefObject<HTMLElement | null>, onClose: () => void) {
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [ref, onClose]);
}

function PageSwitcher({ currentPage }: { currentPage: string }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  useClickOutside(ref, () => setOpen(false));

  const active = PAGES.find(p => p.key === currentPage) ?? PAGES[0];

  return (
    <div ref={ref} className="page-switcher">
      <button className="page-switcher-btn" onClick={() => setOpen(o => !o)}>
        {active.label}
        <span className="page-switcher-arrow">{open ? "▴" : "▾"}</span>
      </button>
      {open && (
        <div className="profile-dropdown">
          {PAGES.filter(p => p.key !== currentPage).map(p => (
            <button key={p.key} className="profile-dropdown-item" onClick={() => { setOpen(false); navigate(p.path); }}>
              {p.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ProfileMenu({ user }: { user: { username: string; display_name: string; role: string } | null }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref, () => setOpen(false));

  const displayName = user?.display_name || user?.username || "?";
  const nameParts = displayName.split(/\s+/);
  const initials = nameParts.length >= 2
    ? (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase()
    : displayName.slice(0, 2).toUpperCase();

  return (
    <div ref={ref} className="profile-menu">
      <button className="profile-avatar" onClick={() => setOpen(o => !o)} title={displayName}>
        {initials}
      </button>
      {open && (
        <div className="profile-dropdown">
          <div className="profile-dropdown-header">
            <div className="profile-dropdown-name">{displayName}</div>
            <div className="profile-dropdown-role">{user?.role}</div>
          </div>
        </div>
      )}
    </div>
  );
}

function App() {
  const { user } = useAuth();
  const location = useLocation();

  const currentPage = location.pathname.startsWith("/dashboard") ? "dashboard"
    : location.pathname.startsWith("/cockpit") ? "cockpit"
    : "chat";

  return (
    <div className="app">
      <nav className="app-nav">
        <img src="/airbus-logo.svg" alt="Airbus" className="app-logo" />
        <span className="app-title">Public &amp; Private Cloud - AI Agent Platform</span>
        <PageSwitcher currentPage={currentPage} />
        <ProfileMenu user={user} />
      </nav>
      <main className="app-main">
        <Routes>
          <Route path="/" element={<Navigate to="/chat" replace />} />
          <Route path="/chat" element={<ChatPage />} />
          <Route path="/chat/:agentName" element={<ChatPage />} />
          <Route path="/cockpit" element={<CockpitPage />} />
          <Route path="/dashboard" element={<Navigate to="/dashboard/agents" replace />} />
          <Route path="/dashboard/kpis" element={<DashboardPage />} />
          <Route path="/dashboard/agents" element={<DashboardPage />} />
          <Route path="/dashboard/documents" element={<DashboardPage />} />
          <Route path="/dashboard/audit" element={<DashboardPage />} />
          <Route path="/dashboard/tools" element={<DashboardPage />} />
          <Route path="/dashboard/models" element={<DashboardPage />} />
          <Route path="/dashboard/policies" element={<DashboardPage />} />
          <Route path="/dashboard/metrics" element={<DashboardPage />} />
          <Route path="/dashboard/tokens" element={<DashboardPage />} />
          <Route path="/dashboard/notifications" element={<DashboardPage />} />
          <Route path="/dashboard/config" element={<DashboardPage />} />
          <Route path="/dashboard/docs" element={<DashboardPage />} />
          <Route path="/dashboard/backup" element={<DashboardPage />} />
          <Route path="/dashboard/users" element={<DashboardPage />} />
          <Route path="/dashboard/intents" element={<DashboardPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
