import { afterEach, describe, expect, it, vi } from "vitest";

import { apiGet } from "./client";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("API client error classification", () => {
  it("returns JSON for a successful API response", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ status: "healthy" }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }),
      ),
    );

    await expect(apiGet<{ status: string }>("/health")).resolves.toEqual({ status: "healthy" });
  });

  it("classifies a network refusal as backend connectivity, not an intent match", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));

    await expect(apiGet("/intents")).rejects.toMatchObject({
      status: 0,
      message: expect.stringContaining("service connectivity problem, not an Intent Control match"),
    });
  });

  it("classifies proxy gateway errors as backend connectivity", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response("connect ECONNREFUSED 127.0.0.1:8000", { status: 503 })),
    );

    await expect(apiGet("/intents")).rejects.toMatchObject({
      status: 503,
      message: expect.stringContaining("Backend API is unreachable"),
    });
  });

  it("preserves a normal API validation error", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response("Invalid request body", { status: 400 })),
    );

    await expect(apiGet("/intents")).rejects.toEqual({
      status: 400,
      message: "Invalid request body",
    });
  });
});
