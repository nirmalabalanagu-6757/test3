/** REST API client for the standalone VM build. */

export const API_BASE = import.meta.env.VITE_API_BASE_URL || "/api";

export interface ApiError {
  status: number;
  message: string;
}

function defaultHeaders(): Record<string, string> {
  return { Accept: "application/json" };
}

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text();
    if (
      [502, 503, 504].includes(res.status) ||
      /(?:econnrefused|connection refused|failed to proxy)/i.test(body)
    ) {
      throw {
        status: res.status,
        message: "Backend API is unreachable (connection refused or service stopped). This is a service connectivity problem, not an Intent Control match.",
      } satisfies ApiError;
    }
    throw { status: res.status, message: body || res.statusText } satisfies ApiError;
  }
  if (res.status === 204 || res.headers.get("content-length") === "0") {
    return undefined as T;
  }
  return res.json() as Promise<T>;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  try {
    const res = await fetch(`${API_BASE}${path}`, init);
    return handleResponse<T>(res);
  } catch (error) {
    if (typeof error === "object" && error && "status" in error) throw error;
    throw {
      status: 0,
      message: "Backend API is unreachable (connection refused or service stopped). This is a service connectivity problem, not an Intent Control match.",
    } satisfies ApiError;
  }
}

export async function apiGet<T>(path: string): Promise<T> {
  return request<T>(path, { headers: defaultHeaders() });
}

export async function apiPost<T>(path: string, body?: unknown): Promise<T> {
  return request<T>(path, {
    method: "POST",
    headers: { ...defaultHeaders(), "Content-Type": "application/json" },
    body: body != null ? JSON.stringify(body) : undefined,
  });
}

export async function apiPut<T>(path: string, body?: unknown): Promise<T> {
  return request<T>(path, {
    method: "PUT",
    headers: { ...defaultHeaders(), "Content-Type": "application/json" },
    body: body != null ? JSON.stringify(body) : undefined,
  });
}

export async function apiPatch<T>(path: string, body?: unknown): Promise<T> {
  return request<T>(path, {
    method: "PATCH",
    headers: { ...defaultHeaders(), "Content-Type": "application/json" },
    body: body != null ? JSON.stringify(body) : undefined,
  });
}

export async function apiDelete<T = void>(path: string): Promise<T> {
  return request<T>(path, {
    method: "DELETE",
    headers: defaultHeaders(),
  });
}
