/**
 * AgentRegistryTable — Agent list with lifecycle controls and edit modal.
 *
 * Requirements 9.1, 9.3, 9.5, 1.4
 */

import { useEffect, useState, useCallback, useRef, useMemo } from "react";
import { API_BASE, apiGet, apiPost, apiPut, apiDelete } from "../../api/client";
import { type SortState, toggleSort, sorted, SortIndicator } from "../../utils/tableSort";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface Agent {
  name: string;
  display_name: string | null;
  description: string | null;
  instruction: string | null;
  product: string;
  agent_type: string;
  model_config_json: string | null;
  allow_world_knowledge: boolean;
  intent_control_enabled: boolean;
  reasoning_enabled: boolean | null;
  lifecycle_status: string;
  last_health_check: string | null;
  last_health_result: string | null;
  last_used_at: string | null;
  registered_at: string;
  updated_at: string;
}

interface AgentListResponse { agents: Agent[]; count: number; }

/* ------------------------------------------------------------------ */
/* Styles                                                              */
/* ------------------------------------------------------------------ */

const REFRESH_INTERVAL = 10_000;

const th: React.CSSProperties = {
  textAlign: "left", padding: "0.5rem 0.75rem", borderBottom: "2px solid var(--color-border)",
  color: "var(--color-text-muted)", fontWeight: 600, fontSize: "0.6875rem", textTransform: "uppercase",
  letterSpacing: "0.05em", whiteSpace: "nowrap", cursor: "pointer", userSelect: "none",
};
const td: React.CSSProperties = { padding: "0.5rem 0.75rem", borderBottom: "1px solid var(--color-border)", verticalAlign: "middle" };

const btn: React.CSSProperties = {
  padding: "0.3rem 0.625rem", borderRadius: "0.25rem", border: "1px solid var(--color-border)",
  background: "var(--color-surface)", cursor: "pointer", fontSize: "0.75rem", fontWeight: 500, color: "var(--color-text)",
};
const btnPrimary: React.CSSProperties = { ...btn, background: "var(--color-primary)", color: "var(--color-on-primary)", border: "1px solid var(--color-primary)" };
const input: React.CSSProperties = {
  padding: "0.375rem 0.625rem", border: "1px solid var(--color-border)", borderRadius: "0.25rem",
  fontSize: "0.8125rem", background: "var(--color-bg)", color: "var(--color-text)", width: "100%", boxSizing: "border-box" as const,
};
const overlay: React.CSSProperties = {
  position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center",
  justifyContent: "center", zIndex: 1000, padding: "2rem",
};
const modal: React.CSSProperties = {
  background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: "0.5rem",
  width: "100%", maxWidth: "520px", overflow: "hidden",
};
const modalHeader: React.CSSProperties = {
  display: "flex", justifyContent: "space-between", alignItems: "center", padding: "1rem 1.25rem",
  borderBottom: "1px solid var(--color-border)",
};
const modalBody: React.CSSProperties = { padding: "1.25rem" };
const modalFooter: React.CSSProperties = {
  display: "flex", gap: "0.5rem", justifyContent: "flex-end", padding: "0.75rem 1.25rem",
  borderTop: "1px solid var(--color-border)",
};

function statusColor(s: string): string {
  switch (s.toLowerCase()) {
    case "running": return "var(--color-success)";
    case "stopped": case "deregistered": return "var(--color-error)";
    case "degraded": return "var(--color-warning)";
    case "registered": return "var(--color-primary)";
    default: return "var(--color-text-muted)";
  }
}

function formatTs(ts: string | null): string {
  return ts ? new Date(ts).toLocaleString() : "--";
}

/* ------------------------------------------------------------------ */
/* Edit Modal                                                          */
/* ------------------------------------------------------------------ */

const tabBtn = (active: boolean): React.CSSProperties => ({
  padding: "0.375rem 0.75rem", borderRadius: "0.25rem", border: "1px solid var(--color-border)",
  background: active ? "var(--color-primary)" : "var(--color-surface)",
  color: active ? "var(--color-on-primary)" : "var(--color-text-muted)",
  cursor: "pointer", fontSize: "0.75rem", fontWeight: 600,
});
const labelSm: React.CSSProperties = {
  display: "block", fontSize: "0.6875rem", fontWeight: 600, color: "var(--color-text-muted)", marginBottom: "0.25rem",
};

function Tip({ text }: { text: string }) {
  const [show, setShow] = useState(false);
  return (
    <span
      style={{ position: "relative", display: "inline-block", marginLeft: "0.25rem", cursor: "help", verticalAlign: "middle" }}
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      <span style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        width: "14px", height: "14px", borderRadius: "50%", fontSize: "0.625rem", fontWeight: 700,
        background: "var(--color-border)", color: "var(--color-text-muted)", lineHeight: 1, userSelect: "none",
      }}>?</span>
      {show && (
        <span style={{
          position: "absolute", bottom: "calc(100% + 6px)", left: "50%", transform: "translateX(-50%)",
          background: "var(--color-text)", color: "var(--color-bg)", fontSize: "0.6875rem", lineHeight: 1.45,
          padding: "0.5rem 0.625rem", borderRadius: "0.375rem", width: "260px", zIndex: 10,
          whiteSpace: "pre-line", boxShadow: "0 4px 12px rgba(0,0,0,0.25)", pointerEvents: "none",
        }}>{text}</span>
      )}
    </span>
  );
}

interface AvailableModel { name: string; provider: string; status: string; }

interface ReasoningConfig {
  enabled: boolean;
  budget_tokens: number;
  max_output_tokens: number;
  temperature: number;
}

const DEFAULT_REASONING: ReasoningConfig = { enabled: false, budget_tokens: 8192, max_output_tokens: 8192, temperature: 0.7 };

function parseReasoningConfig(yaml: string): ReasoningConfig {
  const block = yaml.match(/reasoning_config:\s*\n((?:\s+\w+:.*\n?)*)/);
  if (!block) return { ...DEFAULT_REASONING };
  const txt = block[1];
  const enabled = /enabled:\s*(true|false)/.exec(txt);
  const budget = /budget_tokens:\s*(\d+)/.exec(txt);
  const maxOut = /max_output_tokens:\s*(\d+)/.exec(txt);
  const temp = /temperature:\s*([\d.]+)/.exec(txt);
  return {
    enabled: enabled ? enabled[1] === "true" : false,
    budget_tokens: budget ? parseInt(budget[1], 10) : 8192,
    max_output_tokens: maxOut ? parseInt(maxOut[1], 10) : 8192,
    temperature: temp ? parseFloat(temp[1]) : 0.7,
  };
}

function updateReasoningInYaml(yaml: string, rc: ReasoningConfig): string {
  const block =
    `reasoning_config:\n` +
    `  enabled: ${rc.enabled}\n` +
    `  budget_tokens: ${rc.budget_tokens}\n` +
    `  max_output_tokens: ${rc.max_output_tokens}\n` +
    `  temperature: ${rc.temperature}\n`;

  const existing = yaml.match(/reasoning_config:\s*\n((?:\s+\w+:.*\n?)*)/);
  if (existing) {
    return yaml.replace(/reasoning_config:\s*\n((?:\s+\w+:.*\n?)*)/, block);
  }
  const modelLine = yaml.match(/^model:.*$/m);
  if (modelLine) {
    return yaml.replace(/^(model:.*\n)/m, `$1${block}`);
  }
  return yaml + "\n" + block;
}

function EditAgentModal({ agent, modelName, onClose, onSaved }: { agent: Agent; modelName: string | null; onClose: () => void; onSaved: () => void }) {
  const [tab, setTab] = useState<"details" | "instructions" | "config">("details");
  const [displayName, setDisplayName] = useState(agent.display_name ?? "");
  const [description, setDescription] = useState(agent.description ?? "");
  const [product, setProduct] = useState(agent.product);
  const [agentType, setAgentType] = useState(agent.agent_type);
  const [selectedModel, setSelectedModel] = useState(modelName ?? "");
  const [allowWorldKnowledge, setAllowWorldKnowledge] = useState(agent.allow_world_knowledge ?? false);
  const [intentControlEnabled, setIntentControlEnabled] = useState(agent.intent_control_enabled ?? true);
  const [availableModels, setAvailableModels] = useState<AvailableModel[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Instruction state
  const [instruction, setInstruction] = useState(agent.instruction ?? "");
  const [instructionOriginal] = useState(agent.instruction ?? "");
  const [instructionSaved, setInstructionSaved] = useState(false);

  // YAML config state
  const [yamlContent, setYamlContent] = useState<string | null>(null);
  const [yamlOriginal, setYamlOriginal] = useState<string | null>(null);
  const [yamlLoading, setYamlLoading] = useState(false);
  const [yamlError, setYamlError] = useState<string | null>(null);

  // Reasoning config state (parsed from YAML)
  const [reasoning, setReasoning] = useState<ReasoningConfig>({ ...DEFAULT_REASONING });
  const [reasoningOriginal, setReasoningOriginal] = useState<ReasoningConfig>({ ...DEFAULT_REASONING });

  // Fetch available models from the model registry
  useEffect(() => {
    apiGet<{ models: AvailableModel[] }>("/models?status=active")
      .then((data) => setAvailableModels(data.models))
      .catch(() => { /* ignore */ });
  }, []);

  // Eagerly fetch YAML on modal open (needed for reasoning controls on Details tab)
  useEffect(() => {
    if (yamlContent !== null) return;
    setYamlLoading(true); setYamlError(null);
    fetch(`${API_BASE}/agents/${encodeURIComponent(agent.name)}/config?_t=${Date.now()}`, {
      headers: { Accept: "text/plain" },
      cache: "no-store",
    })
      .then(async (res) => {
        if (!res.ok) throw new Error(res.status === 404 ? "No config file found for this agent" : `Error ${res.status}`);
        const text = await res.text();
        setYamlContent(text);
        setYamlOriginal(text);
        const rc = parseReasoningConfig(text);
        setReasoning(rc);
        setReasoningOriginal(rc);
      })
      .catch((e) => setYamlError(e.message))
      .finally(() => setYamlLoading(false));
  }, [agent.name, yamlContent]);

  const reasoningChanged =
    reasoning.enabled !== reasoningOriginal.enabled ||
    reasoning.budget_tokens !== reasoningOriginal.budget_tokens ||
    reasoning.max_output_tokens !== reasoningOriginal.max_output_tokens ||
    reasoning.temperature !== reasoningOriginal.temperature;

  const handleSaveDetails = async () => {
    setSaving(true); setError(null);
    try {
      if (reasoningChanged && !yamlContent) {
        throw new Error("Cannot save reasoning config — agent has no config file on disk");
      }

      await apiPut(`/agents/${encodeURIComponent(agent.name)}`, {
        display_name: displayName.trim() || null,
        description: description || null,
        product: product || undefined,
        agent_type: agentType || undefined,
        allow_world_knowledge: allowWorldKnowledge,
        intent_control_enabled: intentControlEnabled,
        ...(selectedModel && selectedModel !== modelName ? { model_config_json: selectedModel } : {}),
      });

      if (reasoningChanged && yamlContent) {
        const updatedYaml = updateReasoningInYaml(yamlContent, reasoning);
        const res = await fetch(`${API_BASE}/agents/${encodeURIComponent(agent.name)}/config`, {
          method: "PUT",
          headers: {
            "Content-Type": "text/plain",
          },
          body: updatedYaml,
        });
        if (!res.ok) throw new Error(`Failed to save reasoning config (${res.status})`);
        const savedYaml = await res.text();
        setYamlContent(savedYaml);
        setYamlOriginal(savedYaml);
        setReasoningOriginal({ ...reasoning });
      }

      onSaved();
    } catch (e: unknown) {
      const err = e as { message?: string };
      setError(err?.message ?? "Failed to save");
    } finally { setSaving(false); }
  };

  const handleSaveInstruction = async () => {
    setSaving(true); setError(null); setInstructionSaved(false);
    try {
      await apiPut(`/agents/${encodeURIComponent(agent.name)}`, {
        instruction: instruction.trim() || null,
      });
      setInstructionSaved(true);
      setTimeout(() => setInstructionSaved(false), 5000);
      onSaved();
    } catch (e: unknown) {
      const err = e as { message?: string };
      setError(err?.message ?? "Failed to save instruction");
    } finally { setSaving(false); }
  };

  const handleSaveYaml = async () => {
    if (yamlContent === null) return;
    setSaving(true); setYamlError(null);
    try {
      const res = await fetch(`${API_BASE}/agents/${encodeURIComponent(agent.name)}/config`, {
        method: "PUT",
        headers: {
          "Content-Type": "text/plain",
        },
        body: yamlContent,
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setYamlOriginal(yamlContent);
      onSaved();
    } catch (e: unknown) {
      const err = e as { message?: string };
      setYamlError(err?.message ?? "Failed to save config");
    } finally { setSaving(false); }
  };

  const yamlDirty = yamlContent !== null && yamlContent !== yamlOriginal;

  return (
    <div style={overlay} onClick={onClose}>
      <div style={{ ...modal, maxWidth: "640px", maxHeight: "90vh", display: "flex", flexDirection: "column" }} onClick={(e) => e.stopPropagation()}>
        <div style={modalHeader}>
          <div>
            <div style={{ fontWeight: 600, fontSize: "1rem" }}>Edit Agent</div>
            <div style={{ fontSize: "0.75rem", color: "var(--color-text-muted)", marginTop: "0.125rem" }}>{agent.name}</div>
          </div>
          <button onClick={onClose} style={{ ...btn, fontSize: "1rem", lineHeight: 1, padding: "0.25rem 0.5rem" }}>&times;</button>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: "0.25rem", padding: "0.75rem 1.25rem 0", flexShrink: 0 }}>
          <button style={tabBtn(tab === "details")} onClick={() => setTab("details")}>Details</button>
          <button style={tabBtn(tab === "instructions")} onClick={() => setTab("instructions")}>Instructions</button>
          <button style={tabBtn(tab === "config")} onClick={() => setTab("config")}>Config YAML</button>
        </div>

        <div style={{ ...modalBody, overflow: "auto", flex: 1 }}>
          {tab === "details" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.875rem" }}>
              <div>
                <label style={labelSm}>Name</label>
                <input style={{ ...input, opacity: 0.5 }} value={agent.name} disabled title="Name cannot be changed (primary key)" />
              </div>
              <div>
                <label style={labelSm}>Display Name</label>
                <input style={input} value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Human-friendly name (optional)" />
              </div>
              <div>
                <label style={labelSm}>Description</label>
                <textarea
                  style={{ ...input, minHeight: "80px", resize: "vertical" as const, fontFamily: "inherit" }}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Agent description"
                />
              </div>
              <div style={{ display: "flex", gap: "0.75rem" }}>
                <div style={{ flex: 1 }}>
                  <label style={labelSm}>Product</label>
                  <input style={input} value={product} onChange={(e) => setProduct(e.target.value)} placeholder="e.g. database" />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={labelSm}>Type</label>
                  <select style={input} value={agentType} onChange={(e) => setAgentType(e.target.value)}>
                    <option value="specialized">specialized</option>
                    <option value="concierge">concierge</option>
                  </select>
                </div>
              </div>
              <div style={{ display: "flex", gap: "0.75rem" }}>
                <div style={{ flex: 1 }}>
                  <label style={labelSm}>Model</label>
                  <select style={input} value={selectedModel} onChange={(e) => setSelectedModel(e.target.value)}>
                    {!selectedModel && <option value="">-- Select model --</option>}
                    {availableModels.map((m) => (
                      <option key={m.name} value={m.name}>{m.name} ({m.provider})</option>
                    ))}
                    {selectedModel && !availableModels.some((m) => m.name === selectedModel) && (
                      <option value={selectedModel}>{selectedModel} (unregistered)</option>
                    )}
                  </select>
                </div>
                <div style={{ flex: 1 }}>
                  <label style={labelSm}>Status</label>
                  <input style={{ ...input, opacity: 0.5 }} value={agent.lifecycle_status} disabled title="Use lifecycle buttons to change status" />
                </div>
              </div>
              <div style={{
                background: "rgba(99, 102, 241, 0.04)",
                border: "1px solid var(--color-border)",
                borderRadius: "0.375rem",
                padding: "0.75rem 1rem",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "1rem",
                marginTop: "0.25rem"
              }}>
                <div>
                  <div style={{ fontSize: "0.8125rem", fontWeight: 600, color: "var(--color-text)" }}>
                    Allow World Knowledge
                    <Tip text={"Controls whether the agent can answer general-knowledge questions outside its domain.\n\nEnable: the agent uses its training data for broader questions (history, geography, general facts). Good for FAQ or general-purpose agents.\nDisable: the agent strictly refuses out-of-scope questions and only uses its RAG documents. Better for specialized agents where off-topic answers could be misleading.\n\nTradeoff: broader helpfulness vs. tighter domain focus and fewer hallucinations outside the agent's expertise."} />
                  </div>
                  <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.125rem", lineHeight: 1.3 }}>
                    Skip strict out-of-scope domain limits and allow general questions (history, geography, general facts) using training weights.
                  </div>
                </div>
                <label style={{
                  position: "relative",
                  display: "inline-block",
                  width: "40px",
                  height: "20px",
                  flexShrink: 0,
                  cursor: "pointer"
                }}>
                  <input
                    type="checkbox"
                    checked={allowWorldKnowledge}
                    onChange={(e) => setAllowWorldKnowledge(e.target.checked)}
                    style={{ opacity: 0, width: 0, height: 0 }}
                  />
                  <span style={{
                    position: "absolute",
                    inset: 0,
                    backgroundColor: allowWorldKnowledge ? "var(--color-primary)" : "var(--color-text-muted)",
                    transition: "0.3s",
                    borderRadius: "20px"
                  }} />
                  <span style={{
                    position: "absolute",
                    content: '""',
                    height: "14px",
                    width: "14px",
                    left: "3px",
                    bottom: "3px",
                    backgroundColor: "var(--color-surface-raised)",
                    transition: "0.3s",
                    borderRadius: "50%",
                    transform: allowWorldKnowledge ? "translateX(20px)" : "translateX(0)"
                  }} />
                </label>
              </div>
              <div style={{
                background: "rgba(245, 158, 11, 0.05)",
                border: "1px solid var(--color-border)",
                borderRadius: "0.375rem",
                padding: "0.75rem 1rem",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "1rem",
              }}>
                <div>
                  <div style={{ fontSize: "0.8125rem", fontWeight: 600, color: "var(--color-text)" }}>
                    Intent Control
                    <Tip text={"Enable: this agent may originate or receive deterministic intent workflows. Unmatched top-level prompts are grouped in the Learning Queue; matched executions appear in Intent Run History.\nDisable: its rules are excluded, no learning candidates are captured, and prompts use the normal agent path."} />
                  </div>
                  <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.125rem", lineHeight: 1.3 }}>
                    Agent-level kill switch for intent matching, execution, and prompt capture.
                  </div>
                </div>
                <input
                  aria-label="Enable Intent Control"
                  type="checkbox"
                  checked={intentControlEnabled}
                  onChange={(e) => setIntentControlEnabled(e.target.checked)}
                />
              </div>
              {/* Reasoning / Thinking Mode */}
              <div style={{
                background: "rgba(99, 102, 241, 0.04)",
                border: "1px solid var(--color-border)",
                borderRadius: "0.375rem",
                padding: "0.75rem 1rem",
                marginTop: "0.25rem"
              }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem" }}>
                  <div>
                    <div style={{ fontSize: "0.8125rem", fontWeight: 600, color: "var(--color-text)" }}>
                      Reasoning / Thinking Mode
                      <Tip text={"When enabled, the agent thinks step-by-step before answering — improving accuracy on complex tasks like multi-step calculations, code analysis, and troubleshooting.\n\nEnable for: agents handling complex logic, debugging, or data analysis.\nDisable for: simple FAQ or routing agents where speed matters more.\n\nTradeoff: better accuracy but higher latency and token cost per request."} />
                    </div>
                    <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.125rem", lineHeight: 1.3 }}>
                      Enable extended thinking for deeper reasoning (Gemini thinking, Claude extended thinking).
                    </div>
                  </div>
                  <label style={{
                    position: "relative",
                    display: "inline-block",
                    width: "40px",
                    height: "20px",
                    flexShrink: 0,
                    cursor: (yamlLoading || !yamlContent) ? "not-allowed" : "pointer",
                    opacity: (yamlLoading || !yamlContent) ? 0.5 : 1,
                  }}>
                    <input
                      type="checkbox"
                      checked={reasoning.enabled}
                      disabled={yamlLoading || !yamlContent}
                      onChange={(e) => setReasoning({ ...reasoning, enabled: e.target.checked })}
                      style={{ opacity: 0, width: 0, height: 0 }}
                    />
                    <span style={{
                      position: "absolute",
                      inset: 0,
                      backgroundColor: reasoning.enabled ? "var(--color-primary)" : "var(--color-text-muted)",
                      transition: "0.3s",
                      borderRadius: "20px"
                    }} />
                    <span style={{
                      position: "absolute",
                      content: '""',
                      height: "14px",
                      width: "14px",
                      left: "3px",
                      bottom: "3px",
                      backgroundColor: "var(--color-surface-raised)",
                      transition: "0.3s",
                      borderRadius: "50%",
                      transform: reasoning.enabled ? "translateX(20px)" : "translateX(0)"
                    }} />
                  </label>
                </div>
                {reasoning.enabled && (
                  <div style={{ display: "flex", gap: "0.625rem", marginTop: "0.75rem" }}>
                    <div style={{ flex: 1 }}>
                      <label style={labelSm}>
                        Thinking Budget
                        <Tip text={"Max tokens the model can use for internal reasoning before producing a visible answer.\n\nIncrease (e.g. 16384): deeper analysis for complex problems — better accuracy on multi-step tasks.\nDecrease (e.g. 2048): faster responses, lower cost — sufficient for straightforward questions.\n\nTypical range: 4096 (light) to 16384 (deep). Higher values increase latency and cost linearly."} />
                      </label>
                      <input
                        type="number"
                        style={input}
                        value={reasoning.budget_tokens}
                        min={1024}
                        step={1024}
                        onChange={(e) => setReasoning({ ...reasoning, budget_tokens: parseInt(e.target.value, 10) || 0 })}
                      />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={labelSm}>
                        Max Output Tokens
                        <Tip text={"Maximum length of the agent's visible response (excluding thinking tokens).\n\nIncrease (e.g. 16384): allows longer, more detailed answers — useful for code generation or thorough explanations.\nDecrease (e.g. 2048): forces concise responses — good for quick-answer agents.\n\nMust be >= thinking budget when reasoning is on. Too low may cause truncated answers."} />
                      </label>
                      <input
                        type="number"
                        style={input}
                        value={reasoning.max_output_tokens}
                        min={1024}
                        step={1024}
                        onChange={(e) => setReasoning({ ...reasoning, max_output_tokens: parseInt(e.target.value, 10) || 0 })}
                      />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={labelSm}>
                        Temperature
                        <Tip text={"Controls randomness in the agent's responses.\n\nLow (0.0-0.3): deterministic, consistent answers — best for factual lookups, structured data, and repeatable results.\nMedium (0.4-0.7): balanced creativity — good for troubleshooting and general assistance.\nHigh (0.8-1.0): more creative and varied — useful for brainstorming, but may produce less accurate answers.\n\nNote: Claude ignores this when thinking is enabled (API requirement)."} />
                      </label>
                      <input
                        type="number"
                        style={input}
                        value={reasoning.temperature}
                        min={0}
                        max={1}
                        step={0.1}
                        onChange={(e) => setReasoning({ ...reasoning, temperature: parseFloat(e.target.value) || 0 })}
                      />
                    </div>
                  </div>
                )}
                {yamlError && !yamlContent && (
                  <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.5rem", fontStyle: "italic" }}>
                    Config file not available — reasoning settings will not be saved.
                  </div>
                )}
              </div>
              <div>
                <label style={labelSm}>Registered</label>
                <input style={{ ...input, opacity: 0.5 }} value={formatTs(agent.registered_at)} disabled />
              </div>
              {error && <p style={{ color: "var(--color-error)", fontSize: "0.8125rem" }}>{error}</p>}
            </div>
          )}

          {tab === "instructions" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
              <div>
                <div style={{ fontSize: "0.8125rem", fontWeight: 600, color: "var(--color-text)" }}>Agent System Instruction</div>
                <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.25rem", lineHeight: 1.4 }}>
                  Defines how this agent behaves — its role, domain expertise, response style, and constraints.
                  Changes take effect immediately on save — no restart needed.
                </div>
              </div>
              <textarea
                style={{
                  ...input,
                  minHeight: "300px",
                  fontFamily: "'SF Mono', 'Fira Code', 'Cascadia Code', monospace",
                  fontSize: "0.8125rem",
                  lineHeight: 1.5,
                  resize: "vertical" as const,
                  whiteSpace: "pre-wrap",
                  tabSize: 2,
                }}
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                spellCheck={false}
                placeholder="Enter system instruction for this agent..."
              />
              {instruction !== instructionOriginal && (
                <div style={{ fontSize: "0.6875rem", color: "var(--color-warning)", fontWeight: 600 }}>Unsaved changes</div>
              )}
              {instructionSaved && (
                <div style={{ fontSize: "0.75rem", color: "var(--color-success)", fontWeight: 600 }}>
                  Saved. Changes take effect on the agent's next invocation.
                </div>
              )}
              {error && tab === "instructions" && <p style={{ color: "var(--color-error)", fontSize: "0.8125rem" }}>{error}</p>}
            </div>
          )}

          {tab === "config" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
              <div style={{ fontSize: "0.75rem", color: "var(--color-text-muted)" }}>
                Agent configuration YAML file (on-disk reference). The Instructions tab above takes precedence over the instruction field in this file.
              </div>
              {yamlLoading && <p style={{ color: "var(--color-text-muted)", fontSize: "0.8125rem" }}>Loading config...</p>}
              {yamlError && <p style={{ color: "var(--color-error)", fontSize: "0.8125rem" }}>{yamlError}</p>}
              {yamlContent !== null && (
                <textarea
                  style={{
                    ...input,
                    minHeight: "320px",
                    fontFamily: "'SF Mono', 'Fira Code', 'Cascadia Code', monospace",
                    fontSize: "0.8125rem",
                    lineHeight: 1.5,
                    resize: "vertical" as const,
                    whiteSpace: "pre",
                    tabSize: 2,
                  }}
                  value={yamlContent}
                  onChange={(e) => setYamlContent(e.target.value)}
                  spellCheck={false}
                />
              )}
              {yamlDirty && (
                <div style={{ fontSize: "0.6875rem", color: "var(--color-warning)", fontWeight: 600 }}>Unsaved changes</div>
              )}
            </div>
          )}
        </div>

        <div style={modalFooter}>
          <button style={btn} onClick={onClose}>Cancel</button>
          {tab === "details" && (
            <button style={btnPrimary} onClick={handleSaveDetails} disabled={saving}>{saving ? "Saving..." : "Save Details"}</button>
          )}
          {tab === "instructions" && (
            <button style={btnPrimary} onClick={handleSaveInstruction} disabled={saving || instruction === instructionOriginal}>{saving ? "Saving..." : "Save Instructions"}</button>
          )}
          {tab === "config" && yamlContent !== null && (
            <button style={btnPrimary} onClick={handleSaveYaml} disabled={saving || !yamlDirty}>{saving ? "Saving..." : "Save Config"}</button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Action dropdown menu                                                */
/* ------------------------------------------------------------------ */

interface MenuItem {
  label: string;
  color?: string;
  onClick: () => void;
  separator?: boolean;
}

function ActionMenu({ items }: { items: MenuItem[] }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  return (
    <div ref={ref} style={{ position: "relative", display: "inline-block" }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          padding: "0.25rem 0.5rem", borderRadius: "0.25rem", border: "1px solid var(--color-border)",
          background: open ? "var(--color-bg)" : "transparent", cursor: "pointer",
          fontSize: "1rem", lineHeight: 1, color: "var(--color-text-muted)", letterSpacing: "0.1em",
        }}
        title="Actions"
      >
        &middot;&middot;&middot;
      </button>
      {open && (
        <div style={{
          position: "absolute", right: 0, top: "calc(100% + 4px)", zIndex: 50,
          background: "var(--color-surface)", border: "1px solid var(--color-border)",
          borderRadius: "0.375rem", boxShadow: "0 4px 12px rgba(0,0,0,0.3)",
          minWidth: "140px", overflow: "hidden",
        }}>
          {items.map((item, i) => (
            <div key={i}>
              {item.separator && i > 0 && <div style={{ borderTop: "1px solid var(--color-border)", margin: "0.25rem 0" }} />}
              <button
                onClick={() => { setOpen(false); item.onClick(); }}
                style={{
                  display: "block", width: "100%", textAlign: "left", padding: "0.4rem 0.75rem",
                  border: "none", background: "transparent", cursor: "pointer",
                  fontSize: "0.75rem", color: item.color ?? "var(--color-text)",
                  fontWeight: 500,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(0,32,91,0.1)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
              >
                {item.label}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Register Modal                                                      */
/* ------------------------------------------------------------------ */

interface RegistryTool { name: string; description: string | null; lifecycle_status: string; }

function RegisterAgentModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [name, setName] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [description, setDescription] = useState("");
  const [instruction, setInstruction] = useState("");
  const [product, setProduct] = useState("");
  const [agentType, setAgentType] = useState("specialized");
  const [selectedModel, setSelectedModel] = useState("");
  const [allowWorldKnowledge, setAllowWorldKnowledge] = useState(false);
  const [intentControlEnabled, setIntentControlEnabled] = useState(true);
  const [reasoning, setReasoning] = useState<ReasoningConfig>({ ...DEFAULT_REASONING });
  const [startImmediately, setStartImmediately] = useState(true);
  const [models, setModels] = useState<AvailableModel[]>([]);
  const [tools, setTools] = useState<RegistryTool[]>([]);
  const [selectedTools, setSelectedTools] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      apiGet<{ models: AvailableModel[] }>("/models?status=active"),
      apiGet<{ tools: RegistryTool[] }>("/tools?lifecycle_status=active"),
    ]).then(([modelData, toolData]) => {
      setModels(modelData.models);
      setTools(toolData.tools);
      const first = modelData.models[0]?.name ?? "";
      setSelectedModel(first);
    }).catch(() => setError("Failed to load models or tools"));
  }, []);

  const toggleTool = (toolName: string) => {
    setSelectedTools((current) => current.includes(toolName)
      ? current.filter((name) => name !== toolName)
      : [...current, toolName]);
  };

  const handleCreate = async () => {
    if (!name.trim() || !product.trim()) {
      setError("Agent name and product are required");
      return;
    }
    if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(name.trim())) {
      setError("Agent name must start with a letter and contain only letters, numbers, and underscores");
      return;
    }
    setSaving(true); setError(null);
    try {
      await apiPost("/agents", {
        name: name.trim(),
        display_name: displayName.trim() || null,
        description: description.trim() || null,
        instruction: instruction.trim() || null,
        product: product.trim(),
        agent_type: agentType,
        model_config_json: selectedModel || null,
        reasoning_config_json: reasoning,
        allow_world_knowledge: allowWorldKnowledge,
        intent_control_enabled: intentControlEnabled,
        tools: selectedTools,
        start_immediately: startImmediately,
      });
      onCreated();
    } catch (e: any) {
      setError(e?.message ?? "Agent registration failed");
    } finally { setSaving(false); }
  };

  return (
    <div style={overlay} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{ ...modal, maxWidth: "720px", maxHeight: "90vh", display: "flex", flexDirection: "column" }}>
        <div style={modalHeader}>
          <div>
            <strong>Register Dynamic Agent</strong>
            <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.2rem" }}>
              No Python agent module or application restart is required.
            </div>
          </div>
          <button style={btn} onClick={onClose}>&times;</button>
        </div>
        <div style={{ ...modalBody, overflow: "auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
            <label style={labelSm}>Agent Name *
              <input style={input} value={name} onChange={(e) => setName(e.target.value)} placeholder="oracle_dba_agent" />
            </label>
            <label style={labelSm}>Display Name
              <input style={input} value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Oracle DBA Agent" />
            </label>
            <label style={labelSm}>Product *
              <input style={input} value={product} onChange={(e) => setProduct(e.target.value)} placeholder="oracle-database" />
            </label>
            <label style={labelSm}>Agent Type
              <select style={input} value={agentType} onChange={(e) => setAgentType(e.target.value)}>
                <option value="specialized">Specialized</option>
                <option value="concierge">Concierge</option>
              </select>
            </label>
            <label style={{ ...labelSm, gridColumn: "1 / -1" }}>Description
              <input style={input} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Used by Concierge to decide when to route requests to this agent" />
            </label>
            <label style={{ ...labelSm, gridColumn: "1 / -1" }}>Model
              <select style={input} value={selectedModel} onChange={(e) => setSelectedModel(e.target.value)}>
                <option value="">Default model</option>
                {models.map((model) => <option key={model.name} value={model.name}>{model.name} ({model.provider})</option>)}
              </select>
            </label>
            <label style={{ ...labelSm, gridColumn: "1 / -1" }}>System Instruction
              <textarea
                style={{ ...input, minHeight: "150px", resize: "vertical", fontFamily: "monospace" }}
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                placeholder="Describe the agent's role, boundaries, and how it should use its assigned tools..."
              />
            </label>
          </div>

          <div style={{
            background: "rgba(99, 102, 241, 0.04)",
            border: "1px solid var(--color-border)",
            borderRadius: "0.375rem",
            padding: "0.75rem 1rem",
            marginTop: "1rem",
          }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem" }}>
              <div>
                <div style={{ fontSize: "0.8125rem", fontWeight: 600, color: "var(--color-text)" }}>
                  Reasoning / Thinking Mode
                  <Tip text={"When enabled, the agent uses additional thinking tokens before answering. This can improve complex analysis and troubleshooting, with higher latency and token usage."} />
                </div>
                <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.125rem" }}>
                  Enable deeper reasoning for supported Gemini and Claude models.
                </div>
              </div>
              <label style={{ position: "relative", display: "inline-block", width: "40px", height: "20px", flexShrink: 0, cursor: "pointer" }}>
                <input
                  aria-label="Enable reasoning mode"
                  type="checkbox"
                  checked={reasoning.enabled}
                  onChange={(e) => setReasoning({ ...reasoning, enabled: e.target.checked })}
                  style={{ opacity: 0, width: 0, height: 0 }}
                />
                <span style={{
                  position: "absolute", inset: 0,
                  backgroundColor: reasoning.enabled ? "var(--color-primary)" : "var(--color-text-muted)",
                  transition: "0.3s", borderRadius: "20px",
                }} />
                <span style={{
                  position: "absolute", height: "14px", width: "14px", left: "3px", bottom: "3px",
                  backgroundColor: "var(--color-surface-raised)", transition: "0.3s", borderRadius: "50%",
                  transform: reasoning.enabled ? "translateX(20px)" : "translateX(0)",
                }} />
              </label>
            </div>
            {reasoning.enabled && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.625rem", marginTop: "0.75rem" }}>
                <label style={labelSm}>
                  Thinking Budget
                  <input
                    aria-label="Thinking Budget"
                    type="number"
                    style={input}
                    value={reasoning.budget_tokens}
                    min={1024}
                    step={1024}
                    onChange={(e) => setReasoning({ ...reasoning, budget_tokens: parseInt(e.target.value, 10) || 0 })}
                  />
                </label>
                <label style={labelSm}>
                  Max Output Tokens
                  <input
                    aria-label="Max Output Tokens"
                    type="number"
                    style={input}
                    value={reasoning.max_output_tokens}
                    min={1024}
                    step={1024}
                    onChange={(e) => setReasoning({ ...reasoning, max_output_tokens: parseInt(e.target.value, 10) || 0 })}
                  />
                </label>
                <label style={labelSm}>
                  Temperature
                  <input
                    aria-label="Reasoning Temperature"
                    type="number"
                    style={input}
                    value={reasoning.temperature}
                    min={0}
                    max={1}
                    step={0.1}
                    onChange={(e) => setReasoning({ ...reasoning, temperature: parseFloat(e.target.value) || 0 })}
                  />
                </label>
              </div>
            )}
          </div>

          <div style={{ marginTop: "1rem" }}>
            <div style={{ fontSize: "0.75rem", fontWeight: 600, marginBottom: "0.4rem" }}>Assign Active Tools</div>
            <div style={{ border: "1px solid var(--color-border)", borderRadius: "0.25rem", maxHeight: "170px", overflow: "auto", padding: "0.375rem" }}>
              {tools.length === 0 && <div style={{ fontSize: "0.75rem", color: "var(--color-text-muted)" }}>No active tools available.</div>}
              {tools.map((tool) => (
                <label key={tool.name} style={{ display: "flex", gap: "0.5rem", alignItems: "flex-start", padding: "0.35rem", fontSize: "0.75rem", cursor: "pointer" }}>
                  <input type="checkbox" checked={selectedTools.includes(tool.name)} onChange={() => toggleTool(tool.name)} />
                  <span><strong>{tool.name}</strong>{tool.description ? <span style={{ color: "var(--color-text-muted)" }}> — {tool.description}</span> : null}</span>
                </label>
              ))}
            </div>
          </div>

          <div style={{ display: "flex", gap: "1.25rem", marginTop: "1rem", fontSize: "0.75rem" }}>
            <label style={{ display: "flex", gap: "0.4rem", alignItems: "center" }}>
              <input type="checkbox" checked={allowWorldKnowledge} onChange={(e) => setAllowWorldKnowledge(e.target.checked)} />
              Allow world knowledge
            </label>
            <label style={{ display: "flex", gap: "0.4rem", alignItems: "center" }} title="Allow this agent to originate or receive deterministic intent routing">
              <input type="checkbox" checked={intentControlEnabled} onChange={(e) => setIntentControlEnabled(e.target.checked)} />
              Enable Intent Control
            </label>
            <label style={{ display: "flex", gap: "0.4rem", alignItems: "center" }}>
              <input type="checkbox" checked={startImmediately} onChange={(e) => setStartImmediately(e.target.checked)} />
              Start immediately
            </label>
          </div>
          {error && <p style={{ color: "var(--color-error)", fontSize: "0.8125rem" }}>{error}</p>}
        </div>
        <div style={modalFooter}>
          <button style={btn} onClick={onClose}>Cancel</button>
          <button style={btnPrimary} onClick={handleCreate} disabled={saving}>{saving ? "Registering..." : (startImmediately ? "Register & Start" : "Register Agent")}</button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Main component                                                      */
/* ------------------------------------------------------------------ */

/**
 * Derive a display model name from the registry's `model_config_json` field.
 * The value may be either a plain model name ("local-qwen-coder", written by
 * self-registering agents) or a JSON object string
 * ('{"model":"gemini-2.5-flash","provider":"vertex-ai"}', written by the
 * platform's seeded core agents). Returns null when no model is recorded.
 */
function parseModelName(raw: string | null): string | null {
  if (!raw) return null;
  const trimmed = raw.trim();
  if (trimmed.startsWith("{")) {
    try {
      const obj = JSON.parse(trimmed);
      return typeof obj.model === "string" && obj.model ? obj.model : null;
    } catch { return null; }
  }
  return trimmed || null;
}

type AgentSortKey = "name" | "product" | "agent_type" | "lifecycle_status" | "last_used_at";

export default function AgentRegistryTable() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [, setActionLoading] = useState<string | null>(null);
  const [editAgent, setEditAgent] = useState<Agent | null>(null);
  const [showRegister, setShowRegister] = useState(false);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortState<AgentSortKey>>({ key: "name", dir: "asc" });

  const filtered = useMemo(() => {
    if (!search.trim()) return agents;
    const q = search.toLowerCase();
    return agents.filter(
      (a) => a.name.toLowerCase().includes(q) || (a.display_name ?? "").toLowerCase().includes(q) || a.product.toLowerCase().includes(q) || (a.description ?? "").toLowerCase().includes(q)
    );
  }, [agents, search]);

  const sortedAgents = useMemo(() => sorted(filtered, sort.key, sort.dir), [filtered, sort]);

  const fetchAgents = useCallback(async () => {
    try {
      const data = await apiGet<AgentListResponse>("/agents");
      setAgents(data.agents);
      setError(null);
    } catch { setError("Failed to load agents"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchAgents(); const id = setInterval(fetchAgents, REFRESH_INTERVAL); return () => clearInterval(id); }, [fetchAgents]);

  async function handleAction(name: string, action: "start" | "stop" | "reload" | "deregister") {
    setActionLoading(`${name}:${action}`);
    try {
      if (action === "deregister") await apiDelete(`/agents/${encodeURIComponent(name)}`);
      else await apiPost(`/agents/${encodeURIComponent(name)}/${action}`);
      await fetchAgents();
    } catch { await fetchAgents(); } finally { setActionLoading(null); }
  }

  function menuItems(agent: Agent): MenuItem[] {
    const dead = agent.lifecycle_status.toLowerCase() === "deregistered";
    if (dead) return [];

    const running = agent.lifecycle_status.toLowerCase() === "running";
    const items: MenuItem[] = [
      { label: "Edit", onClick: () => setEditAgent(agent) },
    ];

    if (running) {
      items.push({ label: "Reload", onClick: () => handleAction(agent.name, "reload") });
      items.push({ label: "Stop", color: "var(--color-warning)", onClick: () => handleAction(agent.name, "stop"), separator: true });
    } else {
      items.push({ label: "Start", color: "var(--color-success)", onClick: () => handleAction(agent.name, "start"), separator: true });
    }

    items.push({
      label: "Deregister",
      color: "var(--color-error)",
      separator: true,
      onClick: () => { if (window.confirm(`Deregister "${agent.display_name ?? agent.name}"?`)) handleAction(agent.name, "deregister"); },
    });

    return items;
  }

  if (loading) return <p style={{ color: "var(--color-text-muted)" }}>Loading agents...</p>;
  if (error) return <p style={{ color: "var(--color-error)" }}>{error}</p>;

  return (
    <div>
      <div style={{ display: "flex", gap: "0.75rem", alignItems: "center", marginBottom: "1rem" }}>
        <div style={{ position: "relative", flex: 1, maxWidth: "360px" }}>
          <input
            style={{ ...input, paddingLeft: "2rem" }}
            placeholder="Search agents..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span style={{ position: "absolute", left: "0.625rem", top: "50%", transform: "translateY(-50%)", color: "var(--color-text-muted)", fontSize: "0.875rem", pointerEvents: "none" }}>&#x1F50D;</span>
        </div>
        <span style={{ fontSize: "0.75rem", color: "var(--color-text-muted)" }}>
          {filtered.length} of {agents.length} agent{agents.length !== 1 ? "s" : ""}
        </span>
        <button style={btnPrimary} onClick={() => setShowRegister(true)}>+ Register Agent</button>
      </div>

      {filtered.length === 0 ? (
        <p style={{ color: "var(--color-text-muted)", padding: "1rem 0" }}>
          {search ? "No agents match your search." : "No agents registered."}
        </p>
      ) : (
      <div style={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: "0.375rem", overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.8125rem" }}>
        <thead>
          <tr>
            {([["name", "Name"], ["product", "Product"], ["agent_type", "Type"]] as [AgentSortKey, string][]).map(([k, label]) => (
              <th key={k} style={th} onClick={() => setSort(p => toggleSort(p, k))}>
                {label}<SortIndicator active={sort.key === k} dir={sort.dir} />
              </th>
            ))}
            <th style={{ ...th, cursor: "default" }}>Model</th>
            <th style={{ ...th, cursor: "default" }} title="World Knowledge / Reasoning / Intent Control">W/R/I</th>
            {([["lifecycle_status", "Status"], ["last_used_at", "Last Used"]] as [AgentSortKey, string][]).map(([k, label]) => (
              <th key={k} style={th} onClick={() => setSort(p => toggleSort(p, k))}>
                {label}<SortIndicator active={sort.key === k} dir={sort.dir} />
              </th>
            ))}
            <th style={{ ...th, width: "50px", textAlign: "center", cursor: "default" }}></th>
          </tr>
        </thead>
        <tbody>
          {sortedAgents.map((agent) => {
            const dead = agent.lifecycle_status.toLowerCase() === "deregistered";
            return (
              <tr key={agent.name} style={{ opacity: dead ? 0.4 : 1 }}>
                <td style={td}>
                  <strong>{agent.display_name ?? agent.name}</strong>
                  {agent.description && (
                    <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.125rem", maxWidth: "260px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {agent.description}
                    </div>
                  )}
                </td>
                <td style={td}>
                  <span style={{ padding: "0.125rem 0.5rem", borderRadius: "0.25rem", fontSize: "0.6875rem", background: "var(--color-bg)", border: "1px solid var(--color-border)" }}>
                    {agent.product}
                  </span>
                </td>
                <td style={td}>{agent.agent_type}</td>
                <td style={{ ...td, fontSize: "0.75rem", color: "var(--color-text-muted)" }}>{parseModelName(agent.model_config_json) ?? "--"}</td>
                <td style={{ ...td, whiteSpace: "nowrap" }}>
                  {agent.allow_world_knowledge && (
                    <span title="World Knowledge enabled" style={{
                      display: "inline-block", padding: "0.0625rem 0.375rem", borderRadius: "0.1875rem",
                      fontSize: "0.625rem", fontWeight: 700, background: "rgba(99, 102, 241, 0.12)",
                      color: "var(--color-primary)", marginRight: "0.25rem", letterSpacing: "0.02em",
                    }}>W</span>
                  )}
                  {agent.reasoning_enabled && (
                    <span title="Reasoning enabled" style={{
                      display: "inline-block", padding: "0.0625rem 0.375rem", borderRadius: "0.1875rem",
                      fontSize: "0.625rem", fontWeight: 700, background: "rgba(16, 185, 129, 0.12)",
                      color: "var(--color-success)", letterSpacing: "0.02em",
                    }}>R</span>
                  )}
                  {agent.intent_control_enabled && (
                    <span title="Intent Control enabled" style={{
                      display: "inline-block", padding: "0.0625rem 0.375rem", borderRadius: "0.1875rem",
                      fontSize: "0.625rem", fontWeight: 700, background: "rgba(245, 158, 11, 0.12)",
                      color: "var(--color-warning)", marginLeft: "0.25rem", letterSpacing: "0.02em",
                    }}>I</span>
                  )}
                  {!agent.allow_world_knowledge && !agent.reasoning_enabled && !agent.intent_control_enabled && (
                    <span style={{ color: "var(--color-text-muted)", fontSize: "0.6875rem" }}>--</span>
                  )}
                </td>
                <td style={td}>
                  <span style={{ color: statusColor(agent.lifecycle_status), fontWeight: 600 }}>
                    {agent.lifecycle_status}
                  </span>
                </td>
                <td style={{ ...td, fontSize: "0.6875rem", color: "var(--color-text-muted)" }}>
                  {formatTs(agent.last_used_at)}
                </td>
                <td style={{ ...td, textAlign: "center" }}>
                  {!dead && <ActionMenu items={menuItems(agent)} />}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      </div>
      )}

      {showRegister && (
        <RegisterAgentModal
          onClose={() => setShowRegister(false)}
          onCreated={() => { setShowRegister(false); fetchAgents(); }}
        />
      )}

      {editAgent && (
        <EditAgentModal
          agent={editAgent}
          modelName={parseModelName(editAgent.model_config_json)}
          onClose={() => setEditAgent(null)}
          onSaved={() => { setEditAgent(null); fetchAgents(); }}
        />
      )}
    </div>
  );
}
