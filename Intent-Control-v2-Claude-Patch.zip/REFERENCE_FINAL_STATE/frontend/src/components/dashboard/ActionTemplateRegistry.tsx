import { useCallback, useEffect, useMemo, useState } from "react";
import { apiDelete, apiGet, apiPost, apiPut } from "../../api/client";

type TemplateType = "sql" | "rest" | "graphql" | "skywise" | "ansible" | "json" | "csv" | "mcp" | "python";
type ExecutionMode = "agent" | "direct";
type LifecycleStatus = "draft" | "active" | "deprecated" | "disabled";

interface ActionTemplate {
  id: string;
  name: string;
  version: number;
  display_name: string | null;
  description: string | null;
  template_type: TemplateType;
  tool_name: string;
  execution_mode: ExecutionMode;
  template_text: string | null;
  payload_template_json: Record<string, unknown> | unknown[] | null;
  input_schema_json: Record<string, unknown>;
  output_schema_json: Record<string, unknown>;
  policy_json: Record<string, unknown>;
  execution_options_json: Record<string, unknown>;
  lifecycle_status: LifecycleStatus;
  created_at: string;
  updated_at: string;
}

interface FormState {
  name: string;
  version: number;
  displayName: string;
  description: string;
  templateType: TemplateType;
  toolName: string;
  executionMode: ExecutionMode;
  lifecycleStatus: LifecycleStatus;
  templateText: string;
  payloadTemplate: string;
  inputSchema: string;
  outputSchema: string;
  policy: string;
  executionOptions: string;
}

const panelStyle: React.CSSProperties = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-md)",
  padding: "1rem",
};
const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "0.4rem 0.55rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-bg)",
  color: "var(--color-text)",
  fontSize: "0.8rem",
};
const buttonStyle: React.CSSProperties = {
  padding: "0.35rem 0.7rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-surface)",
  color: "var(--color-text)",
  cursor: "pointer",
  fontSize: "0.75rem",
};
const primaryButton: React.CSSProperties = {
  ...buttonStyle,
  background: "var(--color-primary)",
  borderColor: "var(--color-primary)",
  color: "var(--color-on-primary)",
};
const gridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))",
  gap: "0.7rem",
};

const EMPTY_FORM: FormState = {
  name: "",
  version: 1,
  displayName: "",
  description: "",
  templateType: "rest",
  toolName: "",
  executionMode: "agent",
  lifecycleStatus: "draft",
  templateText: "",
  payloadTemplate: "{}",
  inputSchema: JSON.stringify({ type: "object", required: [], properties: {}, additionalProperties: false }, null, 2),
  outputSchema: "{}",
  policy: JSON.stringify({
    risk_classification: "read_only",
    requires_confirmation: false,
    allowed_agents: [],
    allowed_resources: [],
    max_rows: 1000,
    max_response_bytes: 2000000,
  }, null, 2),
  executionOptions: JSON.stringify({
    text_argument: "query",
    include_unmapped_inputs: false,
    strict_tool_arguments: true,
  }, null, 2),
};

function parseObject(value: string, label: string): Record<string, unknown> {
  const parsed = JSON.parse(value || "{}");
  if (!parsed || Array.isArray(parsed) || typeof parsed !== "object") {
    throw new Error(`${label} must be a JSON object`);
  }
  return parsed as Record<string, unknown>;
}

function parsePayload(value: string): Record<string, unknown> | unknown[] | null {
  if (!value.trim()) return null;
  const parsed = JSON.parse(value);
  if (parsed !== null && typeof parsed !== "object") {
    throw new Error("Payload template must be a JSON object, array, or null");
  }
  return parsed as Record<string, unknown> | unknown[] | null;
}

function messageFromError(error: unknown): string {
  if (typeof error === "object" && error && "message" in error) {
    const raw = String((error as { message: unknown }).message);
    try {
      const body = JSON.parse(raw);
      return body?.error?.message || body?.detail || raw;
    } catch {
      return raw;
    }
  }
  return "Unexpected error";
}

function Field({ label, help, children }: { label: string; help?: string; children: React.ReactNode }) {
  return <label><span style={{ display: "block", marginBottom: "0.25rem", color: "var(--color-text-muted)", fontSize: "0.7rem", fontWeight: 600 }}>{label}</span>{children}{help && <span style={{ display: "block", marginTop: "0.2rem", color: "var(--color-text-muted)", fontSize: "0.64rem" }}>{help}</span>}</label>;
}

function fromTemplate(template: ActionTemplate): FormState {
  return {
    name: template.name,
    version: template.version,
    displayName: template.display_name || "",
    description: template.description || "",
    templateType: template.template_type,
    toolName: template.tool_name,
    executionMode: template.execution_mode,
    lifecycleStatus: template.lifecycle_status,
    templateText: template.template_text || "",
    payloadTemplate: JSON.stringify(template.payload_template_json ?? {}, null, 2),
    inputSchema: JSON.stringify(template.input_schema_json || {}, null, 2),
    outputSchema: JSON.stringify(template.output_schema_json || {}, null, 2),
    policy: JSON.stringify(template.policy_json || {}, null, 2),
    executionOptions: JSON.stringify(template.execution_options_json || {}, null, 2),
  };
}

function TemplateEditor({
  template,
  tools,
  onClose,
  onSaved,
}: {
  template: ActionTemplate | null;
  tools: string[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<FormState>(() => template ? fromTemplate(template) : { ...EMPTY_FORM, toolName: tools[0] || "" });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const immutable = Boolean(template && template.lifecycle_status !== "draft");
  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((current) => ({ ...current, [key]: value }));

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      if (template && immutable) {
        await apiPut(`/action-templates/${template.id}`, {
          display_name: form.displayName || null,
          description: form.description || null,
          lifecycle_status: form.lifecycleStatus,
        });
      } else {
        const payload = {
          name: form.name,
          version: form.version,
          display_name: form.displayName || null,
          description: form.description || null,
          template_type: form.templateType,
          tool_name: form.toolName,
          execution_mode: form.executionMode,
          lifecycle_status: form.lifecycleStatus,
          template_text: form.templateText || null,
          payload_template_json: parsePayload(form.payloadTemplate),
          input_schema_json: parseObject(form.inputSchema, "Input schema"),
          output_schema_json: parseObject(form.outputSchema, "Output schema"),
          policy_json: parseObject(form.policy, "Policy"),
          execution_options_json: parseObject(form.executionOptions, "Execution options"),
        };
        if (template) await apiPut(`/action-templates/${template.id}`, payload);
        else await apiPost("/action-templates", payload);
      }
      onSaved();
    } catch (e) {
      setError(messageFromError(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 1400, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}>
      <div style={{ width: "min(1050px, 97vw)", maxHeight: "92vh", overflow: "auto", padding: "1rem", background: "var(--color-bg)", borderRadius: "var(--radius-md)", boxShadow: "var(--shadow-6)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}><h3 style={{ margin: 0, fontSize: "1rem" }}>{template ? `Edit ${template.name}@${template.version}` : "New Action Template"}</h3><button style={buttonStyle} onClick={onClose}>Close</button></div>
        {immutable && <p style={{ padding: "0.55rem", background: "var(--color-surface-raised)", color: "var(--color-warning)", fontSize: "0.72rem" }}>Published versions are immutable. Metadata and lifecycle can be changed here; use Clone Version to change execution behavior.</p>}
        <div style={{ ...gridStyle, marginTop: "0.8rem" }}>
          <Field label="Template identifier" help="Stable name, for example postgres.health"><input style={inputStyle} disabled={Boolean(template)} value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
          <Field label="Version"><input style={inputStyle} type="number" min={1} disabled={Boolean(template)} value={form.version} onChange={(e) => set("version", Number(e.target.value))} /></Field>
          <Field label="Display name"><input style={inputStyle} value={form.displayName} onChange={(e) => set("displayName", e.target.value)} /></Field>
          <Field label="Lifecycle"><select style={inputStyle} value={form.lifecycleStatus} onChange={(e) => set("lifecycleStatus", e.target.value as LifecycleStatus)}>{!immutable && <option value="draft">Draft</option>}<option value="active">Active</option><option value="deprecated">Deprecated</option><option value="disabled">Disabled</option></select></Field>
        </div>
        <Field label="Description"><textarea style={{ ...inputStyle, minHeight: "55px" }} value={form.description} onChange={(e) => set("description", e.target.value)} /></Field>
        <div style={{ ...gridStyle, marginTop: "0.7rem" }}>
          <Field label="Template type"><select disabled={immutable} style={inputStyle} value={form.templateType} onChange={(e) => { const value = e.target.value as TemplateType; set("templateType", value); if (value === "sql") set("executionOptions", JSON.stringify({ text_argument: "sql_query", include_unmapped_inputs: false, strict_tool_arguments: true }, null, 2)); }}><option value="sql">SQL</option><option value="rest">REST</option><option value="graphql">GraphQL</option><option value="skywise">Skywise</option><option value="ansible">Ansible/AWX</option><option value="json">JSON</option><option value="csv">CSV</option><option value="mcp">MCP</option><option value="python">Python</option></select></Field>
          <Field label="Connection reference (registered tool)" help="This Tool Registry name is the connector executed by the action; credentials remain in Tool Registry."><select disabled={immutable} style={inputStyle} value={form.toolName} onChange={(e) => set("toolName", e.target.value)}><option value="">Select a tool</option>{tools.map((tool) => <option key={tool}>{tool}</option>)}</select></Field>
          <Field label="Execution mode" help="Direct bypasses an LLM; agent mode provides the validated contract to the agent"><select disabled={immutable} style={inputStyle} value={form.executionMode} onChange={(e) => set("executionMode", e.target.value as ExecutionMode)}><option value="agent">Agent guided</option><option value="direct">Direct tool call</option></select></Field>
        </div>
        <div style={{ ...gridStyle, marginTop: "0.7rem" }}>
          <Field label="Text template" help="Use {{name}} placeholders declared in the input schema"><textarea disabled={immutable} style={{ ...inputStyle, minHeight: "190px", fontFamily: "var(--font-family-mono)" }} value={form.templateText} onChange={(e) => set("templateText", e.target.value)} placeholder="SELECT * FROM approved_table WHERE server = '{{server}}'" /></Field>
          <Field label="Payload template (JSON)" help="Rendered object becomes tool arguments"><textarea disabled={immutable} style={{ ...inputStyle, minHeight: "190px", fontFamily: "var(--font-family-mono)" }} value={form.payloadTemplate} onChange={(e) => set("payloadTemplate", e.target.value)} /></Field>
        </div>
        <div style={{ ...gridStyle, marginTop: "0.7rem" }}>
          <Field label="Input JSON Schema"><textarea disabled={immutable} style={{ ...inputStyle, minHeight: "220px", fontFamily: "var(--font-family-mono)" }} value={form.inputSchema} onChange={(e) => set("inputSchema", e.target.value)} /></Field>
          <Field label="Output JSON Schema"><textarea disabled={immutable} style={{ ...inputStyle, minHeight: "220px", fontFamily: "var(--font-family-mono)" }} value={form.outputSchema} onChange={(e) => set("outputSchema", e.target.value)} /></Field>
        </div>
        <div style={{ ...gridStyle, marginTop: "0.7rem" }}>
          <Field label="Governance policy (JSON)" help="Risk, confirmation, allowed agents/resources and response limits"><textarea disabled={immutable} style={{ ...inputStyle, minHeight: "210px", fontFamily: "var(--font-family-mono)" }} value={form.policy} onChange={(e) => set("policy", e.target.value)} /></Field>
          <Field label="Execution options (JSON)" help="text_argument maps a text template to the tool function argument"><textarea disabled={immutable} style={{ ...inputStyle, minHeight: "210px", fontFamily: "var(--font-family-mono)" }} value={form.executionOptions} onChange={(e) => set("executionOptions", e.target.value)} /></Field>
        </div>
        {error && <p role="alert" style={{ color: "var(--color-error)", fontSize: "0.78rem" }}>{error}</p>}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: "0.5rem", marginTop: "0.8rem" }}><button style={buttonStyle} onClick={onClose}>Cancel</button><button style={primaryButton} disabled={saving} onClick={save}>{saving ? "Saving..." : "Save template"}</button></div>
      </div>
    </div>
  );
}

function RenderTester({ template, onClose }: { template: ActionTemplate; onClose: () => void }) {
  const [inputs, setInputs] = useState("{}");
  const [query, setQuery] = useState("");
  const [result, setResult] = useState<unknown>(null);
  const [error, setError] = useState<string | null>(null);
  const render = async () => {
    setError(null);
    try {
      setResult(await apiPost(`/action-templates/${template.id}/render`, { inputs: parseObject(inputs, "Inputs"), query, step_outputs: {} }));
    } catch (e) { setError(messageFromError(e)); }
  };
  return <div style={{ position: "fixed", inset: 0, zIndex: 1450, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}><div style={{ width: "min(760px, 96vw)", maxHeight: "90vh", overflow: "auto", ...panelStyle }}><div style={{ display: "flex", justifyContent: "space-between" }}><h3 style={{ margin: 0 }}>Render {template.name}@{template.version}</h3><button style={buttonStyle} onClick={onClose}>Close</button></div><p style={{ color: "var(--color-text-muted)", fontSize: "0.7rem" }}>Validates and renders the contract only. It does not invoke the tool.</p><Field label="Inputs (JSON)"><textarea style={{ ...inputStyle, minHeight: "150px", fontFamily: "var(--font-family-mono)" }} value={inputs} onChange={(e) => setInputs(e.target.value)} /></Field><Field label="Optional original query"><textarea style={{ ...inputStyle, minHeight: "60px" }} value={query} onChange={(e) => setQuery(e.target.value)} /></Field><button style={{ ...primaryButton, marginTop: "0.6rem" }} onClick={render}>Validate and render</button>{error && <p role="alert" style={{ color: "var(--color-error)" }}>{error}</p>}{result !== null && <pre style={{ marginTop: "0.7rem", padding: "0.7rem", overflow: "auto", background: "var(--color-surface-raised)", fontSize: "0.68rem" }}>{JSON.stringify(result, null, 2)}</pre>}</div></div>;
}

export default function ActionTemplateRegistry() {
  const [templates, setTemplates] = useState<ActionTemplate[]>([]);
  const [tools, setTools] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | LifecycleStatus>("all");
  const [editor, setEditor] = useState<ActionTemplate | "new" | null>(null);
  const [tester, setTester] = useState<ActionTemplate | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [templateData, toolData] = await Promise.all([
        apiGet<{ action_templates: ActionTemplate[] }>("/action-templates"),
        apiGet<{ tools: { name: string }[] }>("/tools"),
      ]);
      setTemplates(templateData.action_templates);
      setTools(toolData.tools.map((tool) => tool.name));
      setError(null);
    } catch (e) { setError(messageFromError(e)); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);
  const filtered = useMemo(() => templates.filter((template) => {
    const matchesText = !search || `${template.name} ${template.display_name || ""} ${template.tool_name} ${template.template_type}`.toLowerCase().includes(search.toLowerCase());
    return matchesText && (status === "all" || template.lifecycle_status === status);
  }), [templates, search, status]);

  const clone = async (template: ActionTemplate) => {
    try { await apiPost(`/action-templates/${template.id}/clone`, {}); await load(); }
    catch (e) { setError(messageFromError(e)); }
  };
  const remove = async (template: ActionTemplate) => {
    if (!window.confirm(`Delete draft '${template.name}@${template.version}'?`)) return;
    try { await apiDelete(`/action-templates/${template.id}`); await load(); }
    catch (e) { setError(messageFromError(e)); }
  };

  if (loading) return <p style={{ color: "var(--color-text-muted)" }}>Loading Action Templates...</p>;
  return <div style={panelStyle}>
    <div style={{ display: "flex", justifyContent: "space-between", gap: "0.7rem", flexWrap: "wrap", marginBottom: "0.75rem" }}><div><h3 style={{ margin: 0, fontSize: "0.95rem" }}>Universal Action Template Registry</h3><span style={{ color: "var(--color-text-muted)", fontSize: "0.68rem" }}>Versioned, credential-free contracts for SQL, APIs, Skywise, Ansible, JSON, CSV, MCP and Python tools.</span></div><button style={primaryButton} onClick={() => setEditor("new")}>+ New action template</button></div>
    <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.7rem" }}><input style={{ ...inputStyle, maxWidth: "340px" }} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search template, type or tool" /><select style={{ ...inputStyle, width: "160px" }} value={status} onChange={(e) => setStatus(e.target.value as typeof status)}><option value="all">All states</option><option value="draft">Draft</option><option value="active">Active</option><option value="deprecated">Deprecated</option><option value="disabled">Disabled</option></select><span style={{ alignSelf: "center", color: "var(--color-text-muted)", fontSize: "0.72rem" }}>{filtered.length} templates</span></div>
    {error && <p role="alert" style={{ color: "var(--color-error)" }}>{error}</p>}
    <div style={{ overflowX: "auto" }}><table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.75rem" }}><thead><tr>{["Template", "Type", "Connection reference", "Execution", "Risk", "State", "Actions"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.5rem", borderBottom: "2px solid var(--color-border)", color: "var(--color-text-muted)" }}>{heading}</th>)}</tr></thead><tbody>{filtered.map((template) => <tr key={template.id}><td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}><strong>{template.display_name || template.name}</strong><div style={{ color: "var(--color-text-muted)", fontSize: "0.65rem" }}>{template.name}@{template.version}</div></td><td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{template.template_type}</td><td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{template.tool_name}</td><td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{template.execution_mode}</td><td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{String(template.policy_json.risk_classification || "read_only")}{template.policy_json.requires_confirmation === true && <div style={{ color: "var(--color-warning)", fontSize: "0.64rem" }}>confirmation</div>}</td><td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{template.lifecycle_status}</td><td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}><button style={buttonStyle} onClick={() => setEditor(template)}>Edit</button> <button style={buttonStyle} onClick={() => setTester(template)}>Test</button> <button style={buttonStyle} onClick={() => void clone(template)}>Clone Version</button>{template.lifecycle_status === "draft" && <> <button style={{ ...buttonStyle, color: "var(--color-error)" }} onClick={() => void remove(template)}>Delete</button></>}</td></tr>)}{filtered.length === 0 && <tr><td colSpan={7} style={{ padding: "1.5rem", textAlign: "center", color: "var(--color-text-muted)" }}>No action templates match the filter.</td></tr>}</tbody></table></div>
    {editor && <TemplateEditor template={editor === "new" ? null : editor} tools={tools} onClose={() => setEditor(null)} onSaved={() => { setEditor(null); void load(); }} />}
    {tester && <RenderTester template={tester} onClose={() => setTester(null)} />}
  </div>;
}
