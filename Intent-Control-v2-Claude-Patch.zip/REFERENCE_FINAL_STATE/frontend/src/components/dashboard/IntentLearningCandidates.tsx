import { useCallback, useState } from "react";
import { apiGet, apiPost } from "../../api/client";
import { useDeferredLoad } from "../../hooks/useDeferredLoad";

type CandidateStatus = "pending" | "approved" | "rejected";
type ExecutionMode = "direct_action" | "agent_llm" | "multi_agent";

interface IntentLearningCandidate {
  id: string;
  status: CandidateStatus;
  source_agent: string;
  normalized_pattern: string;
  examples_json: string[];
  observed_route_json: Record<string, string[]>;
  model_names_json: string[];
  occurrence_count: number;
  proposal_confidence: number;
  proposed_execution_mode: ExecutionMode;
  proposed_rule_json: Record<string, unknown>;
  observation_json?: {
    complete?: boolean;
    direct_ready?: boolean;
    unobserved_agents?: string[];
    calls?: {
      id: string;
      agent: string;
      tool: string;
      status: string;
      argument_names: string[];
      depends_on: string[];
      action_template?: string;
      matching_actions?: string[];
      reason: string;
    }[];
  };
  suggested_intent_id: string | null;
  approved_intent_id: string | null;
  reviewed_by: string | null;
  review_note: string | null;
  first_seen_at: string;
  last_seen_at: string;
}

const panelStyle: React.CSSProperties = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-md)",
  padding: "1rem",
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "0.4rem 0.55rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-bg)",
  color: "var(--color-text)",
  fontSize: "0.8125rem",
};

const buttonStyle: React.CSSProperties = {
  padding: "0.35rem 0.7rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-surface)",
  color: "var(--color-text)",
  cursor: "pointer",
  fontSize: "0.75rem",
};

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function modeLabel(mode: ExecutionMode): { label: string; color: string } {
  if (mode === "direct_action") {
    return { label: "Direct action — no execution LLM", color: "var(--color-success)" };
  }
  if (mode === "multi_agent") {
    return { label: "Workflow — review LLM steps", color: "var(--color-warning)" };
  }
  return { label: "Agent LLM execution", color: "var(--color-warning)" };
}

export default function IntentLearningCandidates({
  agents,
  onApproved,
}: {
  agents: string[];
  onApproved: () => void;
}) {
  const [status, setStatus] = useState<CandidateStatus>("pending");
  const [sourceAgent, setSourceAgent] = useState("all");
  const [candidates, setCandidates] = useState<IntentLearningCandidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviewing, setReviewing] = useState<IntentLearningCandidate | null>(null);
  const [ruleJson, setRuleJson] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const source = sourceAgent === "all" ? "" : `&source_agent=${encodeURIComponent(sourceAgent)}`;
      const data = await apiGet<{ candidates: IntentLearningCandidate[] }>(
        `/intent-learning?status=${status}&limit=500${source}`,
      );
      setCandidates(data.candidates);
      setError(null);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [sourceAgent, status]);

  useDeferredLoad(load);

  const openReview = (candidate: IntentLearningCandidate) => {
    setReviewing(candidate);
    setRuleJson(JSON.stringify(candidate.proposed_rule_json, null, 2));
    setNote("");
    setError(null);
  };

  const approve = async () => {
    if (!reviewing) return;
    setSaving(true);
    try {
      const parsed = JSON.parse(ruleJson) as Record<string, unknown>;
      await apiPost(`/intent-learning/${reviewing.id}/approve`, {
        rule: parsed,
        note: note.trim() || null,
      });
      setReviewing(null);
      await load();
      onApproved();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const reject = async (candidate: IntentLearningCandidate) => {
    if (!window.confirm("Reject this learned intent candidate?")) return;
    try {
      await apiPost(`/intent-learning/${candidate.id}/reject`, { note: null });
      await load();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  return (
    <div style={panelStyle}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "0.75rem", flexWrap: "wrap" }}>
        <div>
          <h3 style={{ margin: 0, fontSize: "0.95rem" }}>Dynamic Learning Queue</h3>
          <p style={{ margin: "0.3rem 0 0.75rem", color: "var(--color-text-muted)", fontSize: "0.72rem", maxWidth: "850px" }}>
            Unmatched top-level prompts from agents with Intent Control enabled are grouped here. Approval stores a reusable live execution plan and pins each single-tool step to its observed Tool Registry connection; previous business responses are never cached. A route-compatible match of 80% or higher proposes the next version of the existing intent instead of creating a duplicate. Review the generated rule and execution path before approving it.
          </p>
        </div>
        <button style={buttonStyle} onClick={() => void load()}>Refresh</button>
      </div>
      <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
        <select style={{ ...inputStyle, width: "160px" }} value={status} onChange={(event) => setStatus(event.target.value as CandidateStatus)}>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <select style={{ ...inputStyle, width: "210px" }} value={sourceAgent} onChange={(event) => setSourceAgent(event.target.value)}>
          <option value="all">All source agents</option>
          {agents.map((agent) => <option key={agent}>{agent}</option>)}
        </select>
        <span style={{ alignSelf: "center", color: "var(--color-text-muted)", fontSize: "0.75rem" }}>{candidates.length} candidates</span>
      </div>
      {error && <p role="alert" style={{ color: "var(--color-error)", fontSize: "0.8rem" }}>{error}</p>}
      {loading ? <p style={{ color: "var(--color-text-muted)" }}>Loading candidates...</p> : (
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.75rem" }}>
            <thead>
              <tr>{["Observed request", "Source / route", "Execution", "Seen", "Last observed", "Actions"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.5rem", borderBottom: "2px solid var(--color-border)", color: "var(--color-text-muted)", whiteSpace: "nowrap" }}>{heading}</th>)}</tr>
            </thead>
            <tbody>
              {candidates.map((candidate) => {
                const mode = modeLabel(candidate.proposed_execution_mode);
                const proposedName = String(candidate.proposed_rule_json.name || candidate.suggested_intent_id || "intent");
                const proposedVersion = Number(candidate.proposed_rule_json.workflow_version || 1);
                return (
                  <tr key={candidate.id}>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", minWidth: "280px" }}>
                      <strong>{candidate.examples_json[0] || candidate.normalized_pattern}</strong>
                      {candidate.suggested_intent_id && <div style={{ color: "var(--color-primary)", fontSize: "0.68rem", marginTop: "0.2rem" }}>{Math.round(candidate.proposal_confidence * 100)}% similar - proposes updating {proposedName} to workflow v{proposedVersion}; no duplicate intent will be created</div>}
                      {candidate.examples_json.length > 1 && <details><summary style={{ cursor: "pointer", color: "var(--color-primary)", fontSize: "0.68rem" }}>{candidate.examples_json.length} grouped examples</summary><ul>{candidate.examples_json.map((example) => <li key={example}>{example}</li>)}</ul></details>}
                    </td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>
                      <strong>{candidate.source_agent}</strong>
                      <div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{Object.entries(candidate.observed_route_json).map(([agent, tools]) => `${agent}: ${tools.join(", ") || "no observed tool"}`).join(" | ")}</div>
                      {Object.values(candidate.observed_route_json).some((tools) => tools.length > 0) && <div style={{ color: "var(--color-primary)", fontSize: "0.64rem", marginTop: "0.18rem" }}>Connection captured from actual tool execution</div>}
                    </td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", color: mode.color }}>
                      {mode.label}
                      <div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{candidate.suggested_intent_id ? "intent similarity" : "proposal confidence"} {candidate.proposal_confidence.toFixed(2)}</div>
                    </td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{candidate.occurrence_count}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}>{new Date(candidate.last_seen_at).toLocaleString()}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}>
                      {candidate.status === "pending" ? <><button style={buttonStyle} onClick={() => openReview(candidate)}>Review</button> <button style={{ ...buttonStyle, color: "var(--color-error)" }} onClick={() => void reject(candidate)}>Reject</button></> : <span>{candidate.status}{candidate.approved_intent_id ? ` · ${candidate.approved_intent_id}` : ""}</span>}
                    </td>
                  </tr>
                );
              })}
              {candidates.length === 0 && <tr><td colSpan={6} style={{ padding: "1.5rem", textAlign: "center", color: "var(--color-text-muted)" }}>No candidates in this state.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {reviewing && (
        <div style={{ marginTop: "1rem", paddingTop: "1rem", borderTop: "1px solid var(--color-border)" }}>
          <h4 style={{ margin: "0 0 0.35rem" }}>{reviewing.suggested_intent_id ? `Review workflow v${Number(reviewing.proposed_rule_json.workflow_version || 1)} update` : "Review proposed rule"}</h4>
          <p style={{ margin: "0 0 0.6rem", color: "var(--color-text-muted)", fontSize: "0.72rem" }}>{reviewing.suggested_intent_id ? "This updates the existing intent after approval. Its access scope and response settings are preserved. Review the complete proposed workflow, parameter mappings and versioned actions, including any upgrade from agent execution to direct actions." : "Edit any matching, scope, workflow, parameter, risk, or response setting. Approval validates all referenced agents, tools and Action Templates before activation."}</p>
          {!!reviewing.observation_json?.calls?.length && (
            <div style={{ ...panelStyle, marginBottom: "0.75rem" }}>
              <strong style={{ fontSize: "0.8rem" }}>Observed tool calls</strong>
              <p style={{ fontSize: "0.72rem", color: "var(--color-text-muted)" }}>
                {reviewing.observation_json.direct_ready
                  ? "Each call matches one published action. Request parameters and earlier results are read again on every execution."
                  : "Some calls need review before direct execution is possible. The proposal uses agent execution until the action mappings are complete."}
                {reviewing.observation_json.complete === false && " Capture reached a limit or a response could not be paired with its call."}
                {!!reviewing.observation_json.unobserved_agents?.length && ` Agents without observed tool calls: ${reviewing.observation_json.unobserved_agents.join(", ")}. Review their work before replacing the agent workflow.`}
              </p>
              <ol style={{ paddingLeft: "1.2rem", fontSize: "0.75rem" }}>
                {reviewing.observation_json.calls.map((call) => (
                  <li key={call.id} style={{ marginBottom: "0.6rem" }}>
                    <strong>{call.id}: {call.agent} → {call.tool}</strong> · {call.status}
                    <div>After: {call.depends_on.join(", ") || "no earlier calls"}</div>
                    <div>Action: {call.action_template || "Review required"}</div>
                    <div style={{ color: "var(--color-text-muted)" }}>{call.reason}</div>
                    {(call.matching_actions?.length ?? 0) > 1 && <div>Matching actions: {call.matching_actions?.join(", ")}</div>}
                    <div style={{ color: "var(--color-text-muted)" }}>Inputs: {call.argument_names.join(", ") || "none"}</div>
                  </li>
                ))}
              </ol>
            </div>
          )}
          <textarea style={{ ...inputStyle, minHeight: "360px", fontFamily: "var(--font-family-mono)" }} value={ruleJson} onChange={(event) => setRuleJson(event.target.value)} />
          <input style={{ ...inputStyle, marginTop: "0.5rem" }} value={note} onChange={(event) => setNote(event.target.value)} placeholder="Optional approval note" />
          <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.65rem" }}>
            <button style={{ ...buttonStyle, background: "var(--color-primary)", color: "var(--color-on-primary)" }} disabled={saving} onClick={() => void approve()}>{saving ? "Approving..." : reviewing.suggested_intent_id ? `Approve as workflow v${Number(reviewing.proposed_rule_json.workflow_version || 1)}` : "Approve and activate"}</button>
            <button style={buttonStyle} disabled={saving} onClick={() => setReviewing(null)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}
