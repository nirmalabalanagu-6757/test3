import { useCallback, useMemo, useRef, useState } from "react";
import { apiDelete, apiGet, apiPost, apiPut } from "../../api/client";
import { useDeferredLoad } from "../../hooks/useDeferredLoad";
import ActionTemplateRegistry from "./ActionTemplateRegistry";
import IntentLearningCandidates from "./IntentLearningCandidates";

type MatchStrategy = "hybrid" | "exact" | "keywords" | "regex" | "examples";
type AmbiguityAction = "llm_fallback" | "clarify" | "fallback" | "deny" | "route_best";
type ResponseMode = "auto" | "direct" | "template" | "internal_summary" | "llm_summary" | "detailed";
type OrchestrationMode = "single" | "sequential" | "parallel" | "dag";
type IntentLifecycle = "draft" | "shadow" | "active";

interface WorkflowStep {
  id: string;
  agent: string;
  tools?: string[];
  connection_ref?: string | null;
  depends_on?: string[];
  prompt_template?: string | null;
  action_template?: string | null;
  action_inputs?: Record<string, unknown>;
  input_mapping?: Record<string, unknown>;
  condition?: Record<string, unknown>;
  required?: boolean;
  timeout_sec?: number;
  retry_count?: number;
  on_failure?: "stop" | "continue" | "fallback";
  fallback_agent?: string | null;
  output_key?: string | null;
}

interface IntentRule {
  id: string;
  name: string;
  display_name: string | null;
  description: string | null;
  enabled: boolean;
  shadow_mode: boolean;
  priority: number;
  match_strategy: MatchStrategy;
  keyword_mode: "any" | "all";
  keywords_json: string[];
  negative_keywords_json: string[];
  regex_patterns_json: string[];
  examples_json: string[];
  min_confidence: number;
  ambiguity_margin: number;
  ambiguity_action: AmbiguityAction;
  target_agent: string;
  fallback_agent: string | null;
  allowed_source_agents_json: string[];
  allowed_tools_json: string[];
  orchestration_mode: OrchestrationMode;
  workflow_json: WorkflowStep[];
  allow_multi_intent: boolean;
  max_intents: number;
  aggregator_agent: string | null;
  execution_options_json: Record<string, unknown>;
  workflow_version: number;
  parameter_config_json: Record<string, unknown>;
  risk_classification: "read_only" | "write" | "execute";
  requires_confirmation: boolean;
  response_mode: ResponseMode;
  response_template: string | null;
  response_options_json: Record<string, unknown>;
  test_cases_json: Record<string, unknown>[];
  created_at: string;
  updated_at: string;
}

interface IntentExecutionStep {
  id: string;
  intent_name: string;
  step_id: string;
  agent_name: string;
  action_template_name: string | null;
  action_template_version: number | null;
  allowed_tools_json: string[];
  used_tools_json: string[];
  status: string;
  attempts: number;
  error: string | null;
  duration_ms: number | null;
}

interface IntentExecutionRun {
  id: string;
  source_agent: string | null;
  query_summary: string | null;
  intent_names_json: string[];
  orchestration_mode: string;
  workflow_versions_json: Record<string, number>;
  status: string;
  error: string | null;
  started_at: string;
  duration_ms: number | null;
  steps: IntentExecutionStep[];
}

interface AssuranceCheck {
  code: string;
  severity: "info" | "warning" | "blocker";
  message: string;
}

interface RegressionResult {
  name: string;
  passed: boolean;
  expected_decision: string;
  actual_decision: string;
  expected_target_agent: string | null;
  actual_target_agent: string | null;
  message: string;
  confidence: number;
}

interface IntentConflict {
  intent_id: string;
  intent_name: string;
  other_intent_id: string;
  other_intent_name: string;
  severity: "info" | "warning" | "blocker";
  score: number;
  reasons: string[];
}

interface ReadinessReport {
  intent_id: string;
  intent_name: string;
  lifecycle_state: IntentLifecycle;
  status: "ready" | "warning" | "blocked";
  ready_to_activate: boolean;
  checks: AssuranceCheck[];
  regression_results: RegressionResult[];
  conflicts: IntentConflict[];
}

interface AssuranceData {
  reports: ReadinessReport[];
  conflicts: IntentConflict[];
  count: number;
}

interface ShadowEvaluation {
  id: string;
  intent_name: string;
  source_agent: string;
  query_hash: string;
  query_summary: string | null;
  confidence: number;
  matched_by_json: string[];
  predicted_decision: string;
  predicted_target_agent: string | null;
  created_at: string;
}

interface FormState {
  name: string;
  displayName: string;
  description: string;
  lifecycle: IntentLifecycle;
  priority: number;
  matchStrategy: MatchStrategy;
  keywordMode: "any" | "all";
  keywords: string;
  negativeKeywords: string;
  regexPatterns: string;
  examples: string;
  minConfidence: number;
  ambiguityMargin: number;
  ambiguityAction: AmbiguityAction;
  targetAgent: string;
  fallbackAgent: string;
  allowedSourceAgents: string[];
  allowedTools: string[];
  orchestrationMode: OrchestrationMode;
  workflowJson: string;
  allowMultiIntent: boolean;
  maxIntents: number;
  aggregatorAgent: string;
  executionOptions: string;
  parameterConfig: string;
  riskClassification: "read_only" | "write" | "execute";
  requiresConfirmation: boolean;
  responseMode: ResponseMode;
  responseTemplate: string;
  responseOptions: string;
  testCases: string;
}

const EMPTY_FORM: FormState = {
  name: "",
  displayName: "",
  description: "",
  lifecycle: "draft",
  priority: 100,
  matchStrategy: "hybrid",
  keywordMode: "any",
  keywords: "",
  negativeKeywords: "",
  regexPatterns: "",
  examples: "",
  minConfidence: 0.7,
  ambiguityMargin: 0.1,
  ambiguityAction: "llm_fallback",
  targetAgent: "",
  fallbackAgent: "",
  allowedSourceAgents: [],
  allowedTools: [],
  orchestrationMode: "single",
  workflowJson: "[]",
  allowMultiIntent: false,
  maxIntents: 1,
  aggregatorAgent: "",
  executionOptions: JSON.stringify({
    max_parallel_steps: 4,
    max_total_steps: 25,
    max_agents: 10,
    total_timeout_sec: 600,
    continue_on_optional_failure: true,
    multi_intent_min_confidence: 0.75,
  }, null, 2),
  parameterConfig: "{\n  \"required\": [],\n  \"properties\": {}\n}",
  riskClassification: "read_only",
  requiresConfirmation: false,
  responseMode: "auto",
  responseTemplate: "",
  responseOptions: "{}",
  testCases: JSON.stringify([
    {
      name: "positive route",
      query: "Replace with a representative user request",
      source_agent: "concierge",
      parameters_json: {},
      confirmed: false,
      expected_decision: "route",
      expected_target_agent: null,
      expected_parameters_json: {},
    },
    {
      name: "unrelated request",
      query: "An unrelated request that must not match",
      source_agent: "concierge",
      parameters_json: {},
      confirmed: false,
      expected_decision: "no_match",
      expected_target_agent: null,
      expected_parameters_json: {},
    },
  ], null, 2),
};

const panelStyle: React.CSSProperties = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-md)",
  padding: "1rem",
};
const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "0.4rem 0.55rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-bg)",
  color: "var(--color-text)",
  fontSize: "0.8125rem",
};
const labelStyle: React.CSSProperties = {
  display: "block",
  marginBottom: "0.25rem",
  color: "var(--color-text-muted)",
  fontSize: "0.72rem",
  fontWeight: 600,
};
const buttonStyle: React.CSSProperties = {
  padding: "0.35rem 0.7rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-surface)",
  color: "var(--color-text)",
  cursor: "pointer",
  fontSize: "0.75rem",
  fontWeight: 500,
};
const primaryButton: React.CSSProperties = {
  ...buttonStyle,
  background: "var(--color-primary)",
  color: "var(--color-on-primary)",
  border: "1px solid var(--color-primary)",
};
const gridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))",
  gap: "0.75rem",
};

function lines(value: string): string[] {
  return value.split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
}

function parseObject(value: string, label: string): Record<string, unknown> {
  const parsed = JSON.parse(value || "{}");
  if (!parsed || Array.isArray(parsed) || typeof parsed !== "object") {
    throw new Error(`${label} must be a JSON object`);
  }
  return parsed as Record<string, unknown>;
}

function parseArray(value: string, label: string): unknown[] {
  const parsed = JSON.parse(value || "[]");
  if (!Array.isArray(parsed)) throw new Error(`${label} must be a JSON array`);
  return parsed;
}

function messageFromError(error: unknown): string {
  if (typeof error === "object" && error && "message" in error) {
    const raw = String((error as { message: unknown }).message);
    try {
      const body = JSON.parse(raw);
      return body?.error?.message || body?.detail || raw;
    } catch {
      return raw;
    }
  }
  return "Unexpected error";
}

function fromRule(rule: IntentRule): FormState {
  return {
    name: rule.name,
    displayName: rule.display_name || "",
    description: rule.description || "",
    lifecycle: rule.enabled ? "active" : rule.shadow_mode ? "shadow" : "draft",
    priority: rule.priority,
    matchStrategy: rule.match_strategy,
    keywordMode: rule.keyword_mode,
    keywords: rule.keywords_json.join("\n"),
    negativeKeywords: rule.negative_keywords_json.join("\n"),
    regexPatterns: rule.regex_patterns_json.join("\n"),
    examples: rule.examples_json.join("\n"),
    minConfidence: rule.min_confidence,
    ambiguityMargin: rule.ambiguity_margin,
    ambiguityAction: rule.ambiguity_action,
    targetAgent: rule.target_agent,
    fallbackAgent: rule.fallback_agent || "",
    allowedSourceAgents: rule.allowed_source_agents_json || [],
    allowedTools: rule.allowed_tools_json,
    orchestrationMode: rule.orchestration_mode || "single",
    workflowJson: JSON.stringify(rule.workflow_json || [], null, 2),
    allowMultiIntent: rule.allow_multi_intent || false,
    maxIntents: rule.max_intents || 1,
    aggregatorAgent: rule.aggregator_agent || "",
    executionOptions: JSON.stringify(rule.execution_options_json || {}, null, 2),
    parameterConfig: JSON.stringify(rule.parameter_config_json || {}, null, 2),
    riskClassification: rule.risk_classification,
    requiresConfirmation: rule.requires_confirmation,
    responseMode: rule.response_mode,
    responseTemplate: rule.response_template || "",
    responseOptions: JSON.stringify(rule.response_options_json || {}, null, 2),
    testCases: JSON.stringify(rule.test_cases_json || [], null, 2),
  };
}

function Field({ label, help, children }: { label: string; help?: string; children: React.ReactNode }) {
  return (
    <label>
      <span style={labelStyle}>{label}</span>
      {children}
      {help && <span style={{ display: "block", marginTop: "0.2rem", color: "var(--color-text-muted)", fontSize: "0.65rem" }}>{help}</span>}
    </label>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section style={{ borderTop: "1px solid var(--color-border)", paddingTop: "0.9rem", marginTop: "0.9rem" }}>
      <h4 style={{ margin: "0 0 0.65rem", fontSize: "0.875rem" }}>{title}</h4>
      {children}
    </section>
  );
}

function RuleEditor({
  rule,
  agents,
  sourceAgents,
  tools,
  onClose,
  onSaved,
}: {
  rule: IntentRule | null;
  agents: string[];
  sourceAgents: string[];
  tools: string[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<FormState>(() => rule ? fromRule(rule) : { ...EMPTY_FORM, targetAgent: agents[0] || "" });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((current) => ({ ...current, [key]: value }));

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      const payload = {
        name: form.name,
        display_name: form.displayName || null,
        description: form.description || null,
        enabled: form.lifecycle === "active",
        shadow_mode: form.lifecycle === "shadow",
        priority: form.priority,
        match_strategy: form.matchStrategy,
        keyword_mode: form.keywordMode,
        keywords_json: lines(form.keywords),
        negative_keywords_json: lines(form.negativeKeywords),
        regex_patterns_json: lines(form.regexPatterns),
        examples_json: lines(form.examples),
        min_confidence: form.minConfidence,
        ambiguity_margin: form.ambiguityMargin,
        ambiguity_action: form.ambiguityAction,
        target_agent: form.targetAgent,
        fallback_agent: form.fallbackAgent || null,
        allowed_source_agents_json: form.allowedSourceAgents,
        allowed_tools_json: form.allowedTools,
        orchestration_mode: form.orchestrationMode,
        workflow_json: parseArray(form.workflowJson, "Workflow definition"),
        allow_multi_intent: form.allowMultiIntent,
        max_intents: form.allowMultiIntent ? form.maxIntents : 1,
        aggregator_agent: form.aggregatorAgent || null,
        execution_options_json: parseObject(form.executionOptions, "Execution options"),
        parameter_config_json: parseObject(form.parameterConfig, "Parameter configuration"),
        risk_classification: form.riskClassification,
        requires_confirmation: form.requiresConfirmation,
        response_mode: form.responseMode,
        response_template: form.responseTemplate || null,
        response_options_json: parseObject(form.responseOptions, "Response options"),
        test_cases_json: parseArray(form.testCases, "Regression cases"),
      };
      if (rule) await apiPut(`/intents/${rule.id}`, payload);
      else await apiPost("/intents", payload);
      onSaved();
    } catch (e) {
      setError(messageFromError(e));
    } finally {
      setSaving(false);
    }
  };

  const toggleTool = (name: string) => {
    set("allowedTools", form.allowedTools.includes(name)
      ? form.allowedTools.filter((item) => item !== name)
      : [...form.allowedTools, name]);
  };

  const toggleSourceAgent = (name: string) => {
    set("allowedSourceAgents", form.allowedSourceAgents.includes(name)
      ? form.allowedSourceAgents.filter((item) => item !== name)
      : [...form.allowedSourceAgents, name]);
  };

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 1300, background: "rgba(0,0,0,0.35)", display: "flex", justifyContent: "center", alignItems: "center", padding: "1rem" }}>
      <div style={{ width: "min(1000px, 96vw)", maxHeight: "92vh", overflow: "auto", background: "var(--color-bg)", borderRadius: "var(--radius-md)", boxShadow: "var(--shadow-6)", padding: "1rem" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <h3 style={{ margin: 0, fontSize: "1rem" }}>{rule ? `Edit ${rule.name}` : "New Intent Rule"}</h3>
          <button style={buttonStyle} onClick={onClose}>Close</button>
        </div>

        <Section title="Identity and lifecycle">
          <div style={gridStyle}>
            <Field label="Intent identifier" help="Stable name such as incident.search">
              <input style={inputStyle} value={form.name} onChange={(e) => set("name", e.target.value)} />
            </Field>
            <Field label="Display name">
              <input style={inputStyle} value={form.displayName} onChange={(e) => set("displayName", e.target.value)} />
            </Field>
            <Field label="Priority" help="Higher priority wins when confidence is equal">
              <input style={inputStyle} type="number" min={0} value={form.priority} onChange={(e) => set("priority", Number(e.target.value))} />
            </Field>
            <Field label="Lifecycle" help="Draft does nothing. Shadow predicts and records without routing. Active can route only after readiness checks pass.">
              <select style={inputStyle} value={form.lifecycle} onChange={(e) => set("lifecycle", e.target.value as IntentLifecycle)}>
                <option value="draft">Draft</option>
                <option value="shadow">Shadow (observe only)</option>
                <option value="active">Active</option>
              </select>
            </Field>
          </div>
          <Field label="Description">
            <textarea style={{ ...inputStyle, minHeight: "60px" }} value={form.description} onChange={(e) => set("description", e.target.value)} />
          </Field>
        </Section>

        <Section title="Matching and ambiguity">
          <div style={gridStyle}>
            <Field label="Match strategy">
              <select style={inputStyle} value={form.matchStrategy} onChange={(e) => set("matchStrategy", e.target.value as MatchStrategy)}>
                <option value="hybrid">Hybrid</option><option value="exact">Exact</option><option value="keywords">Keywords</option>
                <option value="regex">Regular expression</option><option value="examples">Examples</option>
              </select>
            </Field>
            <Field label="Keyword mode">
              <select style={inputStyle} value={form.keywordMode} onChange={(e) => set("keywordMode", e.target.value as "any" | "all")}>
                <option value="any">Any keyword</option><option value="all">All keywords</option>
              </select>
            </Field>
            <Field label="Minimum confidence">
              <input style={inputStyle} type="number" min={0} max={1} step={0.01} value={form.minConfidence} onChange={(e) => set("minConfidence", Number(e.target.value))} />
            </Field>
            <Field label="Ambiguity margin" help="Difference allowed between the top two candidates">
              <input style={inputStyle} type="number" min={0} max={1} step={0.01} value={form.ambiguityMargin} onChange={(e) => set("ambiguityMargin", Number(e.target.value))} />
            </Field>
            <Field label="Ambiguous request action">
              <select style={inputStyle} value={form.ambiguityAction} onChange={(e) => set("ambiguityAction", e.target.value as AmbiguityAction)}>
                <option value="llm_fallback">Use LLM Concierge</option><option value="clarify">Ask for clarification</option>
                <option value="fallback">Use fallback agent</option><option value="route_best">Route best match</option><option value="deny">Deny</option>
              </select>
            </Field>
          </div>
          <div style={{ ...gridStyle, marginTop: "0.75rem" }}>
            <Field label="Positive keywords" help="One keyword or phrase per line"><textarea style={{ ...inputStyle, minHeight: "90px" }} value={form.keywords} onChange={(e) => set("keywords", e.target.value)} /></Field>
            <Field label="Negative keywords" help="Any match excludes this intent"><textarea style={{ ...inputStyle, minHeight: "90px" }} value={form.negativeKeywords} onChange={(e) => set("negativeKeywords", e.target.value)} /></Field>
            <Field label="Regular expressions" help="One Python-compatible expression per line"><textarea style={{ ...inputStyle, minHeight: "90px", fontFamily: "var(--font-family-mono)" }} value={form.regexPatterns} onChange={(e) => set("regexPatterns", e.target.value)} /></Field>
            <Field label="Example requests" help="One representative user request per line"><textarea style={{ ...inputStyle, minHeight: "90px" }} value={form.examples} onChange={(e) => set("examples", e.target.value)} /></Field>
          </div>
        </Section>

        <Section title="Routing and governance">
          <div style={gridStyle}>
            <Field label="Target agent">
              <select style={inputStyle} value={form.targetAgent} onChange={(e) => set("targetAgent", e.target.value)}>
                <option value="">Select an agent</option>{agents.map((agent) => <option key={agent}>{agent}</option>)}
              </select>
            </Field>
            <Field label="Fallback agent">
              <select style={inputStyle} value={form.fallbackAgent} onChange={(e) => set("fallbackAgent", e.target.value)}>
                <option value="">None</option>{agents.filter((a) => a !== form.targetAgent).map((agent) => <option key={agent}>{agent}</option>)}
              </select>
            </Field>
            <Field label="Risk classification">
              <select style={inputStyle} value={form.riskClassification} onChange={(e) => set("riskClassification", e.target.value as FormState["riskClassification"])}>
                <option value="read_only">Read only</option><option value="write">Write</option><option value="execute">Execute</option>
              </select>
            </Field>
            <label style={{ display: "flex", alignItems: "center", gap: "0.45rem", paddingTop: "1.25rem" }}>
              <input type="checkbox" checked={form.requiresConfirmation} onChange={(e) => set("requiresConfirmation", e.target.checked)} /> Require confirmation
            </label>
          </div>
          <div style={{ marginTop: "0.75rem" }}>
            <span style={labelStyle}>Allowed source agents</span>
            <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap", maxHeight: "120px", overflow: "auto", padding: "0.5rem", border: "1px solid var(--color-border)", borderRadius: "var(--radius-sm)" }}>
              {sourceAgents.map((agent) => (
                <label key={agent} style={{ display: "flex", gap: "0.3rem", alignItems: "center", fontSize: "0.75rem" }}>
                  <input type="checkbox" checked={form.allowedSourceAgents.includes(agent)} onChange={() => toggleSourceAgent(agent)} /> {agent}
                </label>
              ))}
            </div>
            <span style={{ color: "var(--color-text-muted)", fontSize: "0.65rem" }}>
              Restricts which entry agents may invoke this intent. Leave empty for the safe default: Concierge plus the target agent.
            </span>
          </div>
          <div style={{ marginTop: "0.75rem" }}>
            <span style={labelStyle}>Per-intent tool allowlist</span>
            <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap", maxHeight: "120px", overflow: "auto", padding: "0.5rem", border: "1px solid var(--color-border)", borderRadius: "var(--radius-sm)" }}>
              {tools.length === 0 ? <span style={{ color: "var(--color-text-muted)", fontSize: "0.75rem" }}>No tools registered.</span> : tools.map((tool) => (
                <label key={tool} style={{ display: "flex", gap: "0.3rem", alignItems: "center", fontSize: "0.75rem" }}>
                  <input type="checkbox" checked={form.allowedTools.includes(tool)} onChange={() => toggleTool(tool)} /> {tool}
                </label>
              ))}
            </div>
            <span style={{ color: "var(--color-text-muted)", fontSize: "0.65rem" }}>Leave empty to use all active tools already assigned to the target agent.</span>
          </div>
        </Section>

        <Section title="Dynamic multi-agent workflow">
          <div style={gridStyle}>
            <Field label="Orchestration mode" help="Single, ordered, concurrent, or dependency-driven execution">
              <select style={inputStyle} value={form.orchestrationMode} onChange={(e) => set("orchestrationMode", e.target.value as OrchestrationMode)}>
                <option value="single">Single agent</option>
                <option value="sequential">Sequential agents</option>
                <option value="parallel">Parallel agents</option>
                <option value="dag">Dependency graph (DAG)</option>
              </select>
            </Field>
            <Field label="Aggregator agent" help="Optional final synthesis agent; it receives no tools">
              <select style={inputStyle} value={form.aggregatorAgent} onChange={(e) => set("aggregatorAgent", e.target.value)}>
                <option value="">Internal aggregation</option>
                {agents.map((agent) => <option key={agent}>{agent}</option>)}
              </select>
            </Field>
            <Field label="Maximum matched intents" help="Used only when multi-intent resolution is enabled">
              <input style={inputStyle} type="number" min={1} max={10} disabled={!form.allowMultiIntent} value={form.maxIntents} onChange={(e) => set("maxIntents", Number(e.target.value))} />
            </Field>
            <label style={{ display: "flex", alignItems: "center", gap: "0.45rem", paddingTop: "1.25rem" }}>
              <input type="checkbox" checked={form.allowMultiIntent} onChange={(e) => set("allowMultiIntent", e.target.checked)} /> Resolve multiple intents from one prompt
            </label>
          </div>
          <div style={{ ...gridStyle, marginTop: "0.75rem" }}>
            <Field label="Workflow steps (JSON array)" help="connection_ref pins a single step to the exact Tool Registry connection used during learning. Leave [] to route through the target agent's LLM. To execute without an LLM, reference an active action_template whose execution mode is direct.">
              <textarea style={{ ...inputStyle, minHeight: "250px", fontFamily: "var(--font-family-mono)" }} value={form.workflowJson} onChange={(e) => set("workflowJson", e.target.value)} />
            </Field>
            <Field label="Execution controls (JSON)" help="Limits parallelism, agents, steps, total timeout and multi-intent confidence.">
              <textarea style={{ ...inputStyle, minHeight: "250px", fontFamily: "var(--font-family-mono)" }} value={form.executionOptions} onChange={(e) => set("executionOptions", e.target.value)} />
            </Field>
          </div>
          <details style={{ marginTop: "0.6rem", fontSize: "0.72rem" }}>
            <summary style={{ cursor: "pointer", color: "var(--color-primary)" }}>Workflow JSON example</summary>
            <pre style={{ overflow: "auto", padding: "0.65rem", background: "var(--color-surface-raised)", borderRadius: "var(--radius-sm)" }}>{JSON.stringify([
              { id: "fetch", agent: form.targetAgent || "data-agent", connection_ref: "registered-tool-name", tools: ["registered-tool-name"], action_template: "approved.action@1", action_inputs: { server: "parameters.server" }, timeout_sec: 120, retry_count: 1 },
              { id: "analyze", agent: form.aggregatorAgent || form.targetAgent || "analysis-agent", tools: [], depends_on: ["fetch"], input_mapping: { source: "steps.fetch" } },
            ], null, 2)}</pre>
          </details>
        </Section>

        <Section title="Runtime parameters">
          <Field label="Parameter extraction configuration (JSON)" help={'Supports required[], properties.<name>.pattern/type/default/prompt'}>
            <textarea style={{ ...inputStyle, minHeight: "150px", fontFamily: "var(--font-family-mono)" }} value={form.parameterConfig} onChange={(e) => set("parameterConfig", e.target.value)} />
          </Field>
        </Section>

        <Section title="Regression safety cases">
          <Field label="Test cases (JSON array)" help="Activation runs these synthetic requests without calling an LLM or executing tools. Include positive, unrelated, ambiguous, missing-parameter, and confirmation cases as applicable.">
            <textarea style={{ ...inputStyle, minHeight: "240px", fontFamily: "var(--font-family-mono)" }} value={form.testCases} onChange={(e) => set("testCases", e.target.value)} />
          </Field>
        </Section>

        <Section title="Response policy">
          <div style={gridStyle}>
            <Field label="Response mode">
              <select style={inputStyle} value={form.responseMode} onChange={(e) => set("responseMode", e.target.value as ResponseMode)}>
                <option value="auto">Auto</option><option value="direct">Direct</option><option value="template">Template</option>
                <option value="internal_summary">Internal summary</option><option value="llm_summary">LLM summary</option><option value="detailed">Detailed analysis</option>
              </select>
            </Field>
            <Field label="Response options (JSON)" help="Optional limits, grouping, columns, sorting, or format">
              <textarea style={{ ...inputStyle, minHeight: "90px", fontFamily: "var(--font-family-mono)" }} value={form.responseOptions} onChange={(e) => set("responseOptions", e.target.value)} />
            </Field>
          </div>
          <Field label="Response template" help="Required only for template mode">
            <textarea style={{ ...inputStyle, minHeight: "80px", fontFamily: "var(--font-family-mono)" }} value={form.responseTemplate} onChange={(e) => set("responseTemplate", e.target.value)} />
          </Field>
        </Section>

        {error && <p role="alert" style={{ color: "var(--color-error)", fontSize: "0.8rem", marginTop: "0.75rem" }}>{error}</p>}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: "0.5rem", marginTop: "1rem" }}>
          <button style={buttonStyle} onClick={onClose}>Cancel</button>
          <button style={primaryButton} disabled={saving} onClick={save}>{saving ? "Saving..." : "Save intent"}</button>
        </div>
      </div>
    </div>
  );
}

function ResolutionTester({ agents }: { agents: string[] }) {
  const [query, setQuery] = useState("");
  const [sourceAgent, setSourceAgent] = useState("concierge");
  const [parameters, setParameters] = useState("{}");
  const [confirmed, setConfirmed] = useState(false);
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);

  const test = async () => {
    setError(null);
    try {
      const resolved = await apiPost<Record<string, unknown>>("/intents/resolve", {
        query,
        source_agent: sourceAgent,
        parameters: parseObject(parameters, "Parameters"),
        confirmed,
      });
      setResult(resolved);
    } catch (e) {
      setError(messageFromError(e));
    }
  };

  return (
    <div style={panelStyle}>
      <h3 style={{ margin: "0 0 0.3rem", fontSize: "0.95rem" }}>Test Resolution</h3>
      <p style={{ margin: "0 0 0.75rem", color: "var(--color-text-muted)", fontSize: "0.72rem" }}>Resolution itself never calls an LLM and runs before any enabled entry agent. Runtime execution still calls an LLM unless every workflow step uses an active direct Action Template and no LLM aggregator is configured.</p>
      <Field label="Source agent" help="Tests the same per-agent access and enable/disable controls used at runtime.">
        <select style={{ ...inputStyle, marginBottom: "0.65rem" }} value={sourceAgent} onChange={(e) => setSourceAgent(e.target.value)}>
          {agents.map((agent) => <option key={agent}>{agent}</option>)}
        </select>
      </Field>
      <Field label="User request"><textarea style={{ ...inputStyle, minHeight: "75px" }} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Show open incidents for the master branch" /></Field>
      <div style={{ ...gridStyle, marginTop: "0.65rem" }}>
        <Field label="Supplied parameters (JSON)"><textarea style={{ ...inputStyle, minHeight: "75px", fontFamily: "var(--font-family-mono)" }} value={parameters} onChange={(e) => setParameters(e.target.value)} /></Field>
        <label style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}><input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} /> Treat request as confirmed</label>
      </div>
      <button style={{ ...primaryButton, marginTop: "0.75rem" }} disabled={!query.trim()} onClick={test}>Resolve intent</button>
      {error && <p role="alert" style={{ color: "var(--color-error)", fontSize: "0.8rem" }}>{error}</p>}
      {result && <pre style={{ marginTop: "0.75rem", padding: "0.75rem", overflow: "auto", background: "var(--color-surface-raised)", borderRadius: "var(--radius-sm)", fontSize: "0.7rem" }}>{JSON.stringify(result, null, 2)}</pre>}
    </div>
  );
}

function RunHistory({ agents }: { agents: string[] }) {
  const [runs, setRuns] = useState<IntentExecutionRun[]>([]);
  const [sourceFilter, setSourceFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const source = sourceFilter === "all" ? "" : `&source_agent=${encodeURIComponent(sourceFilter)}`;
      const data = await apiGet<{ runs: IntentExecutionRun[] }>(`/intents/runs?limit=100${source}`);
      setRuns(data.runs);
      setError(null);
    } catch (e) {
      setError(messageFromError(e));
    } finally {
      setLoading(false);
    }
  }, [sourceFilter]);

  useDeferredLoad(load);
  if (loading) return <p style={{ color: "var(--color-text-muted)" }}>Loading execution runs...</p>;

  return (
    <div style={panelStyle}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.7rem" }}>
        <div><h3 style={{ margin: 0, fontSize: "0.95rem" }}>Workflow Run History</h3><span style={{ color: "var(--color-text-muted)", fontSize: "0.68rem" }}>Agent and tool metadata only; complete business payloads are not persisted.</span></div>
        <div style={{ display: "flex", gap: "0.5rem" }}>
          <select style={{ ...inputStyle, width: "180px" }} value={sourceFilter} onChange={(e) => setSourceFilter(e.target.value)}>
            <option value="all">All source agents</option>
            {agents.map((agent) => <option key={agent}>{agent}</option>)}
          </select>
          <button style={buttonStyle} onClick={() => void load()}>Refresh</button>
        </div>
      </div>
      {error && <p role="alert" style={{ color: "var(--color-error)" }}>{error}</p>}
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.75rem" }}>
          <thead><tr>{["Started", "Intents", "Mode", "Status", "Steps", "Duration", "Details"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.5rem", borderBottom: "2px solid var(--color-border)", color: "var(--color-text-muted)" }}>{heading}</th>)}</tr></thead>
          <tbody>
            {runs.map((run) => (
              <tr key={run.id}>
                <td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}>{new Date(run.started_at).toLocaleString()}</td>
                <td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}><strong>{run.intent_names_json.join(", ")}</strong><div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>source: {run.source_agent || "legacy"}</div><div style={{ color: "var(--color-text-muted)", maxWidth: "280px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{run.query_summary}</div></td>
                <td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{run.orchestration_mode}</td>
                <td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{run.status}</td>
                <td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{run.steps.length}</td>
                <td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>{run.duration_ms == null ? "—" : `${run.duration_ms} ms`}</td>
                <td style={{ padding: "0.5rem", borderBottom: "1px solid var(--color-border)" }}>
                  <details><summary style={{ cursor: "pointer", color: "var(--color-primary)" }}>Inspect</summary><pre style={{ maxWidth: "620px", maxHeight: "260px", overflow: "auto", padding: "0.5rem", background: "var(--color-surface-raised)" }}>{JSON.stringify(run, null, 2)}</pre></details>
                </td>
              </tr>
            ))}
            {runs.length === 0 && <tr><td colSpan={7} style={{ padding: "1.5rem", textAlign: "center", color: "var(--color-text-muted)" }}>No intent-controlled executions have been recorded.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AssurancePanel({ data, onRefresh }: { data: AssuranceData; onRefresh: () => Promise<void> }) {
  const [evaluations, setEvaluations] = useState<ShadowEvaluation[]>([]);
  const [running, setRunning] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadShadow = useCallback(async () => {
    try {
      const result = await apiGet<{ evaluations: ShadowEvaluation[] }>("/intents/shadow-evaluations?limit=100");
      setEvaluations(result.evaluations);
      setError(null);
    } catch (e) {
      setError(messageFromError(e));
    }
  }, []);

  useDeferredLoad(loadShadow);

  const runRegression = async (intentId: string) => {
    setRunning(intentId);
    setError(null);
    try {
      await apiPost(`/intents/${intentId}/regression/run`);
      await onRefresh();
    } catch (e) {
      setError(messageFromError(e));
    } finally {
      setRunning(null);
    }
  };

  const statusColor = (status: ReadinessReport["status"]) => status === "blocked"
    ? "var(--color-error)"
    : status === "warning" ? "var(--color-warning)" : "var(--color-success)";
  const ready = data.reports.filter((report) => report.status === "ready").length;
  const warnings = data.reports.filter((report) => report.status === "warning").length;
  const blocked = data.reports.filter((report) => report.status === "blocked").length;

  return (
    <div style={{ display: "grid", gap: "0.75rem" }}>
      <div style={panelStyle}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: "0.75rem", flexWrap: "wrap" }}>
          <div>
            <h3 style={{ margin: 0, fontSize: "0.95rem" }}>Intent Assurance</h3>
            <p style={{ margin: "0.25rem 0 0", color: "var(--color-text-muted)", fontSize: "0.72rem" }}>Activation is blocked only for unsafe configuration, credential, assignment, conflict, or regression failures. Shadow rules never route or execute.</p>
          </div>
          <button style={buttonStyle} onClick={() => { void onRefresh(); void loadShadow(); }}>Refresh</button>
        </div>
        <div style={{ display: "flex", gap: "1rem", marginTop: "0.75rem", fontSize: "0.8rem" }}>
          <span style={{ color: "var(--color-success)" }}>{ready} ready</span>
          <span style={{ color: "var(--color-warning)" }}>{warnings} warnings</span>
          <span style={{ color: "var(--color-error)" }}>{blocked} blocked</span>
          <span>{data.conflicts.length} conflict(s)</span>
          <span>{evaluations.length} recent shadow match(es)</span>
        </div>
        {error && <p role="alert" style={{ color: "var(--color-error)" }}>{error}</p>}
      </div>

      {data.reports.map((report) => (
        <details key={report.intent_id} style={panelStyle} open={report.status === "blocked"}>
          <summary style={{ cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.75rem" }}>
            <span><strong>{report.intent_name}</strong> <span style={{ color: "var(--color-text-muted)" }}>· {report.lifecycle_state}</span></span>
            <span style={{ color: statusColor(report.status), textTransform: "uppercase", fontSize: "0.7rem", fontWeight: 700 }}>{report.status}</span>
          </summary>
          <div style={{ marginTop: "0.75rem", display: "grid", gap: "0.55rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: "0.5rem", flexWrap: "wrap" }}>
              <span style={{ fontSize: "0.72rem", color: "var(--color-text-muted)" }}>{report.ready_to_activate ? "May be activated" : "Activation blocked until blockers are fixed"}</span>
              <button style={buttonStyle} disabled={running === report.intent_id} onClick={() => void runRegression(report.intent_id)}>{running === report.intent_id ? "Running..." : "Run regression"}</button>
            </div>
            {report.checks.map((check, index) => (
              <div key={`${check.code}-${index}`} style={{ borderLeft: `3px solid ${check.severity === "blocker" ? "var(--color-error)" : check.severity === "warning" ? "var(--color-warning)" : "var(--color-success)"}`, paddingLeft: "0.55rem", fontSize: "0.72rem" }}>
                <strong>{check.code}</strong>: {check.message}
              </div>
            ))}
            {report.regression_results.length > 0 && (
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.72rem", marginTop: "0.35rem" }}>
                <thead><tr>{["Regression", "Expected", "Actual", "Result"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.4rem", borderBottom: "1px solid var(--color-border)" }}>{heading}</th>)}</tr></thead>
                <tbody>{report.regression_results.map((result) => <tr key={result.name}><td style={{ padding: "0.4rem" }}>{result.name}</td><td>{result.expected_decision}</td><td>{result.actual_decision}</td><td style={{ color: result.passed ? "var(--color-success)" : "var(--color-error)" }}>{result.message}</td></tr>)}</tbody>
              </table>
            )}
          </div>
        </details>
      ))}

      <div style={panelStyle}>
        <h3 style={{ margin: "0 0 0.55rem", fontSize: "0.9rem" }}>Recent shadow predictions</h3>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.72rem" }}>
            <thead><tr>{["Time", "Intent", "Source", "Prediction", "Confidence", "Redacted request"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.4rem", borderBottom: "1px solid var(--color-border)" }}>{heading}</th>)}</tr></thead>
            <tbody>
              {evaluations.map((item) => <tr key={item.id}><td style={{ padding: "0.4rem", whiteSpace: "nowrap" }}>{new Date(item.created_at).toLocaleString()}</td><td>{item.intent_name}</td><td>{item.source_agent}</td><td>{item.predicted_decision}</td><td>{item.confidence.toFixed(2)}</td><td>{item.query_summary || item.query_hash.slice(0, 12)}</td></tr>)}
              {evaluations.length === 0 && <tr><td colSpan={6} style={{ padding: "1rem", textAlign: "center", color: "var(--color-text-muted)" }}>No shadow matches recorded. Put a rule in Shadow and send representative requests.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default function IntentControlManager() {
  const [intents, setIntents] = useState<IntentRule[]>([]);
  const [agents, setAgents] = useState<string[]>([]);
  const [sourceAgents, setSourceAgents] = useState<string[]>(["concierge"]);
  const [tools, setTools] = useState<string[]>([]);
  const [assurance, setAssurance] = useState<AssuranceData>({ reports: [], conflicts: [], count: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editor, setEditor] = useState<IntentRule | "new" | null>(null);
  const [tab, setTab] = useState<"rules" | "assurance" | "learning" | "actions" | "test" | "runs" | "import">("rules");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | IntentLifecycle>("all");
  const [agentFilter, setAgentFilter] = useState("all");
  const [importData, setImportData] = useState("");
  const [replaceExisting, setReplaceExisting] = useState(false);
  const [importResult, setImportResult] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const [intentData, agentData, toolData, assuranceData] = await Promise.all([
        apiGet<{ intents: IntentRule[] }>("/intents"),
        apiGet<{ agents: { name: string; agent_type: string; intent_control_enabled: boolean }[] }>("/agents"),
        apiGet<{ tools: { name: string }[] }>("/tools"),
        apiGet<AssuranceData>("/intents/assurance"),
      ]);
      setIntents(intentData.intents);
      setAgents(agentData.agents.filter((agent) => agent.agent_type === "specialized").map((agent) => agent.name));
      setSourceAgents(agentData.agents.map((agent) => agent.name));
      setTools(toolData.tools.map((tool) => tool.name));
      setAssurance(assuranceData);
      setError(null);
    } catch (e) {
      setError(messageFromError(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useDeferredLoad(load);

  const filtered = useMemo(() => intents.filter((intent) => {
    const matchesText = !search || `${intent.name} ${intent.display_name || ""} ${intent.target_agent}`.toLowerCase().includes(search.toLowerCase());
    const lifecycle: IntentLifecycle = intent.enabled ? "active" : intent.shadow_mode ? "shadow" : "draft";
    const matchesStatus = status === "all" || lifecycle === status;
    const matchesAgent = agentFilter === "all" || intent.target_agent === agentFilter;
    return matchesText && matchesStatus && matchesAgent;
  }), [intents, search, status, agentFilter]);

  const setLifecycle = async (intent: IntentRule, lifecycle: IntentLifecycle) => {
    try { await apiPut(`/intents/${intent.id}`, { enabled: lifecycle === "active", shadow_mode: lifecycle === "shadow" }); await load(); }
    catch (e) { setError(messageFromError(e)); }
  };

  const remove = async (intent: IntentRule) => {
    if (!window.confirm(`Delete intent '${intent.name}'?`)) return;
    try { await apiDelete(`/intents/${intent.id}`); await load(); }
    catch (e) { setError(messageFromError(e)); }
  };

  const exportRules = async () => {
    try {
      const exported = await apiGet<{ data: string }>("/intents/export");
      const url = URL.createObjectURL(new Blob([exported.data], { type: "application/json" }));
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "intent-control-v4.json";
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (e) { setError(messageFromError(e)); }
  };

  const importRules = async () => {
    setImportResult(null);
    try {
      const result = await apiPost<{ imported: number; updated: number; errors: string[] }>("/intents/import", { data: importData, replace_existing: replaceExisting });
      setImportResult(`Imported ${result.imported}; updated ${result.updated}; errors ${result.errors.length}${result.errors.length ? `: ${result.errors.join(" | ")}` : ""}`);
      await load();
    } catch (e) { setImportResult(messageFromError(e)); }
  };

  const tabButton = (key: typeof tab, label: string) => (
    <button style={{ ...buttonStyle, ...(tab === key ? primaryButton : {}) }} onClick={() => setTab(key)}>{label}</button>
  );

  if (loading) return <p style={{ color: "var(--color-text-muted)" }}>Loading Intent Control...</p>;

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "0.75rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
        <div style={{ display: "flex", gap: "0.35rem", flexWrap: "wrap" }}>{tabButton("rules", "Rules")}{tabButton("assurance", "Assurance")}{tabButton("learning", "Learning Queue")}{tabButton("actions", "Action Templates")}{tabButton("test", "Test Resolution")}{tabButton("runs", "Run History")}{tabButton("import", "Import / Export")}</div>
        {tab === "rules" && <button style={primaryButton} onClick={() => setEditor("new")}>+ New intent</button>}
      </div>
      {error && <p role="alert" style={{ color: "var(--color-error)", marginBottom: "0.75rem" }}>{error}</p>}

      {tab === "rules" && (
        <div style={panelStyle}>
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
            <input style={{ ...inputStyle, maxWidth: "320px" }} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search intent or agent" />
            <select style={{ ...inputStyle, width: "150px" }} value={status} onChange={(e) => setStatus(e.target.value as typeof status)}><option value="all">All states</option><option value="active">Active</option><option value="shadow">Shadow</option><option value="draft">Draft</option></select>
            <select style={{ ...inputStyle, width: "190px" }} value={agentFilter} onChange={(e) => setAgentFilter(e.target.value)}><option value="all">All target agents</option>{agents.map((agent) => <option key={agent}>{agent}</option>)}</select>
            <span style={{ alignSelf: "center", color: "var(--color-text-muted)", fontSize: "0.75rem" }}>{filtered.length} of {intents.length} rules</span>
          </div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.78rem" }}>
              <thead><tr>{["Intent", "Matching", "Route", "Access", "Confidence", "Governance", "Response", "State", "Actions"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.5rem", borderBottom: "2px solid var(--color-border)", color: "var(--color-text-muted)", whiteSpace: "nowrap" }}>{heading}</th>)}</tr></thead>
              <tbody>
                {filtered.map((intent) => (
                  <tr key={intent.id}>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}><strong>{intent.display_name || intent.name}</strong><div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.name} · priority {intent.priority}</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.match_strategy}<div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.keywords_json.length} keywords · {intent.examples_json.length} examples · {intent.regex_patterns_json.length} regex</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}><strong>{intent.workflow_json.length ? `${intent.workflow_json.length} workflow steps` : intent.target_agent}</strong><div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.orchestration_mode} · workflow v{intent.workflow_version}{intent.allow_multi_intent ? ` · up to ${intent.max_intents} intents` : ""}</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.allowed_source_agents_json.length ? intent.allowed_source_agents_json.join(", ") : "Concierge + target"}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.min_confidence.toFixed(2)}<div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.ambiguity_action}</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.risk_classification}{intent.requires_confirmation && <div style={{ color: "var(--color-warning)", fontSize: "0.66rem" }}>confirmation</div>}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.response_mode}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>
                      <select
                        aria-label={`Lifecycle for ${intent.name}`}
                        style={{ ...inputStyle, width: "105px", color: intent.enabled ? "var(--color-success)" : intent.shadow_mode ? "var(--color-warning)" : "var(--color-text-muted)" }}
                        value={intent.enabled ? "active" : intent.shadow_mode ? "shadow" : "draft"}
                        onChange={(e) => void setLifecycle(intent, e.target.value as IntentLifecycle)}
                      >
                        <option value="draft">Draft</option><option value="shadow">Shadow</option><option value="active">Active</option>
                      </select>
                      {(() => {
                        const report = assurance.reports.find((item) => item.intent_id === intent.id);
                        return report ? <div style={{ marginTop: "0.25rem", color: report.status === "blocked" ? "var(--color-error)" : report.status === "warning" ? "var(--color-warning)" : "var(--color-success)", fontSize: "0.64rem" }}>{report.status}</div> : null;
                      })()}
                    </td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}><button style={buttonStyle} onClick={() => setEditor(intent)}>Edit</button> <button style={{ ...buttonStyle, color: "var(--color-error)" }} onClick={() => remove(intent)}>Delete</button></td>
                  </tr>
                ))}
                {filtered.length === 0 && <tr><td colSpan={9} style={{ padding: "1.5rem", textAlign: "center", color: "var(--color-text-muted)" }}>No intent rules match the current filter.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "assurance" && <AssurancePanel data={assurance} onRefresh={load} />}

      {tab === "test" && <ResolutionTester agents={sourceAgents} />}

      {tab === "learning" && <IntentLearningCandidates agents={sourceAgents} onApproved={() => void load()} />}

      {tab === "actions" && <ActionTemplateRegistry />}

      {tab === "runs" && <RunHistory agents={sourceAgents} />}

      {tab === "import" && (
        <div style={panelStyle}>
          <h3 style={{ margin: "0 0 0.6rem", fontSize: "0.95rem" }}>Portable Intent Configuration</h3>
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
            <button style={buttonStyle} onClick={exportRules}>Export JSON</button>
            <button style={buttonStyle} onClick={() => fileRef.current?.click()}>Load JSON file</button>
            <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={async (e) => { const file = e.target.files?.[0]; if (file) setImportData(await file.text()); }} />
            <label style={{ display: "flex", gap: "0.35rem", alignItems: "center", fontSize: "0.75rem" }}><input type="checkbox" checked={replaceExisting} onChange={(e) => setReplaceExisting(e.target.checked)} /> Replace rules with the same name</label>
          </div>
          <textarea style={{ ...inputStyle, minHeight: "300px", fontFamily: "var(--font-family-mono)" }} value={importData} onChange={(e) => setImportData(e.target.value)} placeholder='{"version":4,"intents":[]}' />
          <button style={{ ...primaryButton, marginTop: "0.65rem" }} disabled={!importData.trim()} onClick={importRules}>Import configuration</button>
          {importResult && <p style={{ marginTop: "0.6rem", fontSize: "0.75rem" }}>{importResult}</p>}
        </div>
      )}

      {editor && <RuleEditor rule={editor === "new" ? null : editor} agents={agents} sourceAgents={sourceAgents} tools={tools} onClose={() => setEditor(null)} onSaved={() => { setEditor(null); void load(); }} />}
    </div>
  );
}
