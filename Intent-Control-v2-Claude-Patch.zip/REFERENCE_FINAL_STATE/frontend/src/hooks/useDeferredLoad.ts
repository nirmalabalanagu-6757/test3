import { useEffect } from "react";

/**
 * Run an asynchronous data loader after React has committed the component.
 *
 * Deferring by one task keeps state changes out of the synchronous effect body
 * and lets React cancel a not-yet-started load when the component unmounts or
 * the loader dependency changes.
 */
export function useDeferredLoad(load: () => Promise<void>): void {
  useEffect(() => {
    const timer = window.setTimeout(() => {
      void load();
    }, 0);

    return () => window.clearTimeout(timer);
  }, [load]);
}
