"""Tests for versioned action-template validation and rendering."""

import pytest
from pydantic import ValidationError

from backend.schemas.action_template import (
    ActionTemplateCreate,
    ActionTemplateExecutionOptions,
    ActionTemplatePolicy,
    ResolvedActionTemplate,
)
from backend.services.action_template import (
    ActionTemplateConfigurationError,
    ActionTemplateService,
)


def _snapshot(**overrides) -> ResolvedActionTemplate:
    values = {
        "id": "action-1",
        "reference": "backup.failures@2",
        "name": "backup.failures",
        "version": 2,
        "template_type": "rest",
        "tool_name": "fetch_backup_data",
        "execution_mode": "direct",
        "template_text": None,
        "payload_template_json": {
            "query_params": {
                "server": "{{server}}",
                "rowLimit": "{{row_limit}}",
            }
        },
        "input_schema_json": {
            "type": "object",
            "required": ["server"],
            "additionalProperties": False,
            "properties": {
                "server": {"type": "string", "pattern": r"[A-Za-z0-9_-]+"},
                "row_limit": {
                    "type": "integer",
                    "default": 100,
                    "minimum": 1,
                    "maximum": 1000,
                },
            },
        },
        "output_schema_json": {},
        "policy": ActionTemplatePolicy(),
        "execution_options": ActionTemplateExecutionOptions(),
        "checksum": "checksum",
    }
    values.update(overrides)
    return ResolvedActionTemplate(**values)


def test_direct_text_template_requires_explicit_tool_argument():
    with pytest.raises(ValidationError, match="text_argument"):
        ActionTemplateCreate(
            name="postgres.health",
            template_type="sql",
            tool_name="database_query",
            execution_mode="direct",
            template_text="SELECT 1",
        )


def test_render_applies_defaults_preserves_types_and_builds_tool_arguments():
    rendered = ActionTemplateService.render_snapshot(
        _snapshot(),
        inputs={"server": "APP01"},
        query="failed backups for APP01",
    )

    assert rendered.validated_inputs == {"server": "APP01", "row_limit": 100}
    assert rendered.tool_arguments == {
        "query_params": {"server": "APP01", "rowLimit": 100}
    }


def test_render_rejects_missing_unknown_and_malformed_inputs():
    snapshot = _snapshot()
    with pytest.raises(ActionTemplateConfigurationError, match="Missing required"):
        ActionTemplateService.render_snapshot(snapshot, inputs={})
    with pytest.raises(ActionTemplateConfigurationError, match="Unknown action inputs"):
        ActionTemplateService.render_snapshot(
            snapshot, inputs={"server": "APP01", "unexpected": True}
        )
    with pytest.raises(ActionTemplateConfigurationError, match="required pattern"):
        ActionTemplateService.render_snapshot(
            snapshot, inputs={"server": "APP01'; DROP TABLE jobs;--"}
        )


def test_read_only_sql_rejects_mutation_and_non_allowlisted_resources():
    policy = ActionTemplatePolicy(allowed_resources=["approved_table"])
    ActionTemplateService._validate_sql(
        "SELECT id FROM approved_table LIMIT 100", policy
    )
    with pytest.raises(ActionTemplateConfigurationError, match="mutation"):
        ActionTemplateService._validate_sql(
            "WITH changed AS (DELETE FROM approved_table RETURNING id) SELECT * FROM changed",
            policy,
        )
    with pytest.raises(ActionTemplateConfigurationError, match="allowlist"):
        ActionTemplateService._validate_sql("SELECT * FROM secret_table", policy)


def test_output_schema_validation_is_enforced():
    schema = {
        "type": "object",
        "required": ["status"],
        "properties": {"status": {"type": "string", "enum": ["ok", "failed"]}},
    }
    ActionTemplateService.validate_output({"status": "ok"}, schema)
    with pytest.raises(ActionTemplateConfigurationError, match="must be one of"):
        ActionTemplateService.validate_output({"status": "unknown"}, schema)
