"""Execution tests for dynamic multi-agent intent workflows."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from backend.schemas.action_template import (
    ActionTemplateExecutionOptions,
    ActionTemplatePolicy,
    ResolvedActionTemplate,
)
from backend.schemas.intent import (
    IntentDecision,
    IntentExecutionOptions,
    IntentWorkflowStep,
    ResolvedIntent,
    ResolvedWorkflowStep,
)
from backend.services.intent_orchestrator import IntentOrchestrator


class _MemoryOrchestrator(IntentOrchestrator):
    def __init__(self) -> None:
        self.finished: tuple[str, str] | None = None

    async def _create_run(self, *args: Any, **kwargs: Any) -> None:
        return None

    async def _finish_run(
        self,
        run_id: str,
        status: str,
        response: str,
        error: str | None,
        duration_ms: int,
    ) -> None:
        self.finished = (status, response)

    async def _start_step(self, *args: Any, **kwargs: Any) -> str:
        return "step-record"

    async def _record_skipped_step(self, *args: Any, **kwargs: Any) -> None:
        return None

    async def _finish_step(self, *args: Any, **kwargs: Any) -> None:
        return None

    async def _authorize_step(self, *args: Any, **kwargs: Any) -> tuple[bool, str]:
        return True, "allowed"


class _SourceTrackingOrchestrator(_MemoryOrchestrator):
    def __init__(self) -> None:
        super().__init__()
        self.authorized_sources: list[str] = []

    async def _authorize_step(
        self,
        *args: Any,
        source_agent: str = "concierge",
        **kwargs: Any,
    ) -> tuple[bool, str]:
        self.authorized_sources.append(source_agent)
        return True, "allowed"


def _resolved(
    name: str,
    steps: list[IntentWorkflowStep],
    *,
    mode: str = "sequential",
    response_mode: str = "internal_summary",
    aggregator: str | None = None,
) -> ResolvedIntent:
    return ResolvedIntent(
        intent_id=f"id-{name}",
        intent_name=name,
        confidence=0.95,
        orchestration_mode=mode,
        workflow_version=1,
        workflow_steps=steps,
        aggregator_agent=aggregator,
        response_mode=response_mode,
        execution_options=IntentExecutionOptions(total_timeout_sec=10),
    )


def _decision(*intents: ResolvedIntent) -> IntentDecision:
    return IntentDecision(
        decision="route",
        intent_id=intents[0].intent_id,
        intent_name=intents[0].intent_name,
        target_agent=intents[0].workflow_steps[0].agent,
        reason="test",
        selected_intents=list(intents),
        orchestration_mode="multi" if len(intents) > 1 else intents[0].orchestration_mode,
    )


@pytest.mark.asyncio
async def test_entry_agent_is_used_for_first_workflow_policy_edge():
    orchestrator = _SourceTrackingOrchestrator()

    async def invoke_agent(**kwargs: Any):
        return "backup is healthy", {}, "model"

    intent = _resolved(
        "backup.status",
        [IntentWorkflowStep(id="fetch", agent="backup_agent")],
        response_mode="direct",
    )
    decision = _decision(intent).model_copy(update={"source_agent": "backup_agent"})

    result = await orchestrator.execute(
        decision,
        session_id="session",
        user_id="user",
        user_message="show backup status",
        invoke_agent=invoke_agent,
    )

    assert result.status == "completed"
    assert orchestrator.authorized_sources == ["backup_agent"]


@pytest.mark.asyncio
async def test_connection_ref_reuses_only_the_captured_tool():
    calls: list[dict[str, Any]] = []

    async def invoke_agent(**kwargs: Any):
        calls.append(kwargs)
        return "backup is healthy", {"backup_agent": ["fetch_backups"]}, "model"

    intent = _resolved(
        "backup.status",
        [
            ResolvedWorkflowStep(
                id="fetch",
                agent="backup_agent",
                connection_ref="fetch_backups",
            )
        ],
        response_mode="direct",
    )
    result = await _MemoryOrchestrator().execute(
        _decision(intent),
        session_id="session",
        user_id="user",
        user_message="show backup status",
        invoke_agent=invoke_agent,
    )

    assert result.status == "completed"
    assert len(calls) == 1
    assert calls[0]["allowed_tool_names"] == ["fetch_backups"]
    assert calls[0]["intent_context"]["connection_ref"] == "fetch_backups"


@pytest.mark.asyncio
async def test_sequential_steps_receive_dependency_results():
    calls: list[tuple[str, str]] = []

    async def invoke_agent(**kwargs: Any):
        calls.append((kwargs["agent_name"], kwargs["user_message"]))
        return f"output-{kwargs['agent_name']}", {kwargs["agent_name"]: ["tool"]}, "model"

    intent = _resolved(
        "incident.analysis",
        [
            IntentWorkflowStep(id="fetch", agent="fetch_agent", tools=["fetch"]),
            IntentWorkflowStep(
                id="analyze",
                agent="analysis_agent",
                tools=["analyze"],
                depends_on=["fetch"],
            ),
        ],
    )
    result = await _MemoryOrchestrator().execute(
        _decision(intent),
        session_id="session",
        user_id="user",
        user_message="analyze incidents",
        invoke_agent=invoke_agent,
    )

    assert result.status == "completed"
    assert [name for name, _ in calls] == ["fetch_agent", "analysis_agent"]
    assert "output-fetch_agent" in calls[1][1]
    assert result.tools == {
        "fetch_agent": ["tool"],
        "analysis_agent": ["tool"],
    }


@pytest.mark.asyncio
async def test_parallel_multi_intent_combines_agents_and_tools():
    started: set[str] = set()
    release = asyncio.Event()

    async def invoke_agent(**kwargs: Any):
        started.add(kwargs["agent_name"])
        if len(started) == 2:
            release.set()
        await asyncio.wait_for(release.wait(), timeout=1)
        name = kwargs["agent_name"]
        return f"result-{name}", {name: [f"tool-{name}"]}, "model"

    first = _resolved(
        "incident.search",
        [IntentWorkflowStep(id="incident", agent="incident_agent")],
        mode="parallel",
    )
    second = _resolved(
        "backup.search",
        [IntentWorkflowStep(id="backup", agent="backup_agent")],
        mode="parallel",
    )
    result = await _MemoryOrchestrator().execute(
        _decision(first, second),
        session_id="session",
        user_id="user",
        user_message="incident and backup",
        invoke_agent=invoke_agent,
    )

    assert result.status == "completed"
    assert started == {"incident_agent", "backup_agent"}
    assert "## incident.search" in result.response
    assert "## backup.search" in result.response
    assert set(result.tools) == {"incident_agent", "backup_agent"}


@pytest.mark.asyncio
async def test_step_retry_then_fallback_agent():
    agents: list[str] = []

    async def invoke_agent(**kwargs: Any):
        agents.append(kwargs["agent_name"])
        if kwargs["agent_name"] == "primary":
            raise RuntimeError("primary unavailable")
        return "fallback-result", {"fallback": ["safe_tool"]}, "model"

    intent = _resolved(
        "fallback.intent",
        [
            IntentWorkflowStep(
                id="work",
                agent="primary",
                retry_count=1,
                on_failure="fallback",
                fallback_agent="fallback",
            )
        ],
    )
    result = await _MemoryOrchestrator().execute(
        _decision(intent),
        session_id="session",
        user_id="user",
        user_message="run",
        invoke_agent=invoke_agent,
    )

    assert result.status == "completed"
    assert agents == ["primary", "primary", "fallback"]
    assert result.response == "### work — fallback\n\nfallback-result"


@pytest.mark.asyncio
async def test_aggregator_is_invoked_without_tools():
    calls: list[dict[str, Any]] = []

    async def invoke_agent(**kwargs: Any):
        calls.append(kwargs)
        if kwargs["agent_name"] == "summary_agent":
            return "combined", {"summary_agent": []}, "summary-model"
        return "raw", {kwargs["agent_name"]: ["fetch"]}, "worker-model"

    intent = _resolved(
        "summarized.intent",
        [IntentWorkflowStep(id="fetch", agent="worker")],
        response_mode="llm_summary",
        aggregator="summary_agent",
    )
    result = await _MemoryOrchestrator().execute(
        _decision(intent),
        session_id="session",
        user_id="user",
        user_message="summarize",
        invoke_agent=invoke_agent,
    )

    assert result.response == "combined"
    assert calls[-1]["agent_name"] == "summary_agent"
    assert calls[-1]["allowed_tool_names"] == []


@pytest.mark.asyncio
async def test_false_condition_skips_optional_step():
    calls = 0

    async def invoke_agent(**kwargs: Any):
        nonlocal calls
        calls += 1
        return "unexpected", {}, "model"

    intent = _resolved(
        "conditional.intent",
        [
            IntentWorkflowStep(
                id="conditional",
                agent="agent",
                required=False,
                condition={
                    "source": "parameters.enabled",
                    "operator": "equals",
                    "value": True,
                },
            )
        ],
    )
    result = await _MemoryOrchestrator().execute(
        _decision(intent),
        session_id="session",
        user_id="user",
        user_message="run",
        invoke_agent=invoke_agent,
    )

    assert calls == 0
    assert result.status == "completed"
    assert "no successful step results" in result.response


@pytest.mark.asyncio
async def test_direct_action_template_bypasses_agent_llm():
    class _DirectOrchestrator(_MemoryOrchestrator):
        def __init__(self) -> None:
            super().__init__()
            self.direct_calls = 0

        async def _invoke_action_template(self, **kwargs: Any):
            self.direct_calls += 1
            return "deterministic-result", {kwargs["agent_name"]: ["safe_tool"]}, "action-template"

    action = ResolvedActionTemplate(
        id="action",
        reference="safe.action@1",
        name="safe.action",
        version=1,
        template_type="python",
        tool_name="safe_tool",
        execution_mode="direct",
        input_schema_json={"type": "object"},
        policy=ActionTemplatePolicy(),
        execution_options=ActionTemplateExecutionOptions(),
        checksum="checksum",
    )
    intent = _resolved(
        "direct.intent",
        [
            ResolvedWorkflowStep(
                id="execute",
                agent="worker",
                tools=["safe_tool"],
                resolved_action=action,
            )
        ],
        response_mode="direct",
    )
    agent_calls = 0

    async def invoke_agent(**kwargs: Any):
        nonlocal agent_calls
        agent_calls += 1
        return "unexpected", {}, "model"

    orchestrator = _DirectOrchestrator()
    result = await orchestrator.execute(
        _decision(intent),
        session_id="session",
        user_id="user",
        user_message="run safe action",
        invoke_agent=invoke_agent,
    )

    assert result.response == "deterministic-result"
    assert result.model == "action-template"
    assert orchestrator.direct_calls == 1
    assert agent_calls == 0
