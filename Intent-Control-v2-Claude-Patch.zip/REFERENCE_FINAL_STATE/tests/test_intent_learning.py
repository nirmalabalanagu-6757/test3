"""Tests for approval-gated, connector-agnostic intent learning."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest

from backend.models.action_template import ActionTemplate
from backend.models.agent import AgentRegistry
from backend.models.intent import IntentLearningCandidate, IntentRule
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.schemas.intent import IntentRuleCreate
from backend.services.intent_learning import (
    IntentLearningCandidateStateError,
    IntentLearningService,
)


class _ScalarView:
    def __init__(self, items: list[Any]) -> None:
        self._items = items

    def all(self) -> list[Any]:
        return list(self._items)


class _Result:
    def __init__(self, items: list[Any] | None = None, rows: list[Any] | None = None) -> None:
        self._items = items or []
        self._rows = rows or []

    def scalars(self) -> _ScalarView:
        return _ScalarView(self._items)

    def all(self) -> list[Any]:
        return list(self._rows)

    def scalar_one_or_none(self) -> Any | None:
        return self._items[0] if self._items else None


class _LearningSession:
    def __init__(
        self,
        *,
        agents: list[AgentRegistry],
        tools: list[ToolRegistry] | None = None,
        templates: list[ActionTemplate] | None = None,
        assignments: list[tuple[str, str]] | None = None,
        candidates: list[IntentLearningCandidate] | None = None,
        rules: list[IntentRule] | None = None,
    ) -> None:
        self.agents = agents
        self.tools = tools or []
        self.templates = templates or []
        self.assignments = assignments or []
        self.candidates = candidates or []
        self.rules = rules or []

    async def execute(
        self,
        statement: Any,
        parameters: dict[str, Any] | None = None,
    ) -> _Result:
        if not hasattr(statement, "column_descriptions"):
            return _Result()
        entities = {item.get("entity") for item in statement.column_descriptions if item.get("entity")}
        if AgentRegistry in entities:
            return _Result(self.agents)
        if ToolRegistry in entities:
            return _Result(self.tools)
        if ActionTemplate in entities:
            return _Result(self.templates)
        if ToolAgentAssignment in entities:
            return _Result(rows=self.assignments)
        if IntentLearningCandidate in entities:
            return _Result([item for item in self.candidates if item.status == "pending"])
        if IntentRule in entities:
            return _Result([item for item in self.rules if item.enabled])
        return _Result()

    async def scalar(self, statement: Any) -> Any | None:
        entities = {item.get("entity") for item in statement.column_descriptions if item.get("entity")}
        if IntentLearningCandidate in entities:
            return next(
                (item for item in self.candidates if item.status == "pending"),
                None,
            )
        if ActionTemplate in entities:
            return self.templates[0] if self.templates else None
        return None

    async def get(self, model: Any, key: str) -> Any | None:
        if model is IntentLearningCandidate:
            return next((item for item in self.candidates if item.id == key), None)
        if model is IntentRule:
            return next((item for item in self.rules if item.id == key), None)
        return None

    def add(self, value: Any) -> None:
        if isinstance(value, IntentLearningCandidate):
            self.candidates.append(value)

    async def flush(self) -> None:
        for index, candidate in enumerate(self.candidates, start=1):
            if candidate.id is None:
                candidate.id = f"candidate-{index}"


def _agent(name: str, *, enabled: bool = True) -> AgentRegistry:
    return AgentRegistry(
        name=name,
        product="operations",
        agent_type="specialized",
        lifecycle_status="running",
        intent_control_enabled=enabled,
        allow_world_knowledge=False,
        health_check_interval_sec=60,
        consecutive_health_failures=0,
    )


def _tool(name: str, *, connector_type: str = "generic_rest") -> ToolRegistry:
    return ToolRegistry(
        name=name,
        tool_type="function",
        risk_classification="read_only",
        lifecycle_status="active",
        connector_type=connector_type,
        auth_type="none",
        http_method="GET",
        request_format="json",
        response_format="json",
        file_field_name="file",
        timeout_sec=15,
        retry_count=1,
        max_response_bytes=2_000_000,
        verify_tls=True,
        version=1,
        invocation_count=0,
    )


def _direct_template(
    tool_name: str,
    *,
    name: str = "backup.status.action",
    template_type: str = "json",
    allowed_agent: str = "backup_agent",
) -> ActionTemplate:
    return ActionTemplate(
        name=name,
        version=1,
        template_type=template_type,
        tool_name=tool_name,
        execution_mode="direct",
        input_schema_json={
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
        output_schema_json={},
        policy_json={
            "risk_classification": "read_only",
            "allowed_agents": [allowed_agent],
        },
        execution_options_json={},
        lifecycle_status="active",
    )


@pytest.mark.asyncio
async def test_unmatched_prompt_builds_direct_generic_action_proposal():
    tool = _tool("fetch_backups")
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[tool],
        templates=[_direct_template(tool.name)],
        assignments=[("backup_agent", tool.name)],
    )

    candidate = await IntentLearningService().observe(
        session,
        source_agent="backup-agent",
        query="Show backup status Authorization=Bearer-should-not-be-stored",
        contributing_agents={"backup_agent": [tool.name]},
        model_name="gemini-test",
    )

    assert candidate is not None
    assert candidate.status == "pending"
    assert candidate.proposed_execution_mode == "direct_action"
    assert "Bearer-should-not-be-stored" not in candidate.examples_json[0]
    assert candidate.proposed_rule_json["allowed_source_agents_json"] == ["backup_agent"]
    step = candidate.proposed_rule_json["workflow_json"][0]
    assert step["connection_ref"] == tool.name
    assert step["tools"] == [tool.name]
    assert step["action_template"] == "backup.status.action@1"
    assert candidate.proposed_rule_json["workflow_json"][0]["action_inputs"] == {"query": "query"}
    assert candidate.proposed_rule_json["allow_multi_intent"] is True
    assert candidate.proposed_rule_json["max_intents"] == 5
    assert "response" not in candidate.proposed_rule_json


@pytest.mark.parametrize(
    ("connector_type", "template_type"),
    [
        ("postgresql", "sql"),
        ("generic_rest", "json"),
        ("skywise", "json"),
        ("csv", "csv"),
        ("ansible", "ansible"),
        ("mcp", "json"),
        ("python", "json"),
    ],
)
@pytest.mark.asyncio
async def test_direct_proposal_is_connector_agnostic(
    connector_type: str,
    template_type: str,
):
    tool = _tool("portable_operation", connector_type=connector_type)
    template = _direct_template(
        tool.name,
        name="portable.operation",
        template_type=template_type,
        allowed_agent="portable_agent",
    )
    session = _LearningSession(
        agents=[_agent("portable_agent")],
        tools=[tool],
        templates=[template],
        assignments=[("portable_agent", tool.name)],
    )

    candidate = await IntentLearningService().observe(
        session,
        source_agent="portable_agent",
        query=f"run portable {connector_type} operation",
        contributing_agents={"portable_agent": [tool.name]},
        model_name="model-a",
    )

    assert candidate is not None
    assert candidate.proposed_execution_mode == "direct_action"
    step = candidate.proposed_rule_json["workflow_json"][0]
    assert step["action_template"] == "portable.operation@1"
    assert step["connection_ref"] == tool.name
    assert step["tools"] == [tool.name]


@pytest.mark.asyncio
async def test_agent_llm_proposal_pins_observed_connection_without_template():
    tool = _tool("fetch_backups")
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[tool],
        assignments=[("backup_agent", tool.name)],
    )

    candidate = await IntentLearningService().observe(
        session,
        source_agent="backup_agent",
        query="show backup status",
        contributing_agents={"backup_agent": [tool.name]},
        model_name="model-a",
    )

    assert candidate is not None
    assert candidate.proposed_execution_mode == "agent_llm"
    step = candidate.proposed_rule_json["workflow_json"][0]
    assert step["connection_ref"] == tool.name
    assert step["tools"] == [tool.name]
    assert "action_template" not in step


@pytest.mark.asyncio
async def test_observed_multi_agent_route_builds_dynamic_parallel_workflow():
    database_tool = _tool("query_inventory", connector_type="postgresql")
    backup_tool = _tool("read_backup_status", connector_type="generic_rest")
    session = _LearningSession(
        agents=[
            _agent("operations_agent"),
            _agent("database_agent"),
            _agent("backup_agent"),
        ],
        tools=[database_tool, backup_tool],
        templates=[
            _direct_template(
                database_tool.name,
                name="inventory.query",
                template_type="sql",
                allowed_agent="database_agent",
            ),
            _direct_template(
                backup_tool.name,
                name="backup.read",
                allowed_agent="backup_agent",
            ),
        ],
        assignments=[
            ("database_agent", database_tool.name),
            ("backup_agent", backup_tool.name),
        ],
    )

    candidate = await IntentLearningService().observe(
        session,
        source_agent="operations_agent",
        query="compare inventory with current backup status",
        contributing_agents={
            "database_agent": [database_tool.name],
            "backup_agent": [backup_tool.name],
        },
        model_name="model-a",
    )

    assert candidate is not None
    proposal = candidate.proposed_rule_json
    assert candidate.proposed_execution_mode == "direct_action"
    assert proposal["orchestration_mode"] == "parallel"
    assert proposal["response_mode"] == "internal_summary"
    assert [step["agent"] for step in proposal["workflow_json"]] == [
        "database_agent",
        "backup_agent",
    ]


@pytest.mark.asyncio
async def test_same_prompt_with_different_tools_creates_separate_candidates():
    first_tool = _tool("fetch_backups_primary")
    second_tool = _tool("fetch_backups_secondary")
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[first_tool, second_tool],
    )
    service = IntentLearningService()

    first = await service.observe(
        session,
        source_agent="backup_agent",
        query="show backup status",
        contributing_agents={"backup_agent": [first_tool.name]},
        model_name="model-a",
    )
    second = await service.observe(
        session,
        source_agent="backup_agent",
        query="show backup status",
        contributing_agents={"backup_agent": [second_tool.name]},
        model_name="model-a",
    )

    assert first is not second
    assert len(session.candidates) == 2
    assert first.observed_route_json == {"backup_agent": [first_tool.name]}
    assert second.observed_route_json == {"backup_agent": [second_tool.name]}


@pytest.mark.asyncio
async def test_similar_observations_group_into_one_candidate():
    session = _LearningSession(agents=[_agent("backup_agent")])
    service = IntentLearningService()

    first = await service.observe(
        session,
        source_agent="backup_agent",
        query="show backup status for server 10",
        contributing_agents={"backup_agent": []},
        model_name="model-a",
    )
    second = await service.observe(
        session,
        source_agent="backup_agent",
        query="show backup status for server 20",
        contributing_agents={"backup_agent": []},
        model_name="model-a",
    )

    assert first is second
    assert second is not None
    assert second.occurrence_count == 2
    assert len(second.examples_json) == 2
    assert len(session.candidates) == 1


@pytest.mark.asyncio
async def test_agent_kill_switch_disables_learning_capture():
    session = _LearningSession(agents=[_agent("backup_agent", enabled=False)])

    candidate = await IntentLearningService().observe(
        session,
        source_agent="backup_agent",
        query="show backup status",
        contributing_agents={"backup_agent": []},
        model_name="model-a",
    )

    assert candidate is None
    assert session.candidates == []


@pytest.mark.asyncio
async def test_concierge_only_observation_requires_manual_specialized_target():
    concierge = _agent("concierge")
    concierge.agent_type = "concierge"
    session = _LearningSession(agents=[concierge])

    candidate = await IntentLearningService().observe(
        session,
        source_agent="concierge",
        query="explain an uncategorized operational request",
        contributing_agents={"concierge": []},
        model_name="model-a",
    )

    assert candidate is not None
    assert candidate.observed_route_json == {}
    assert candidate.proposed_rule_json["target_agent"] == ""
    assert candidate.proposed_rule_json["workflow_json"] == []
    assert candidate.proposal_confidence <= 0.40


@pytest.mark.asyncio
async def test_related_rule_with_different_tool_is_not_extended():
    original_tool = _tool("fetch_backups_primary")
    observed_tool = _tool("fetch_backups_secondary")
    rule_data = IntentRuleCreate(
        name="backup.status",
        target_agent="backup_agent",
        keywords_json=["backup", "status"],
        examples_json=["show backup status"],
        allowed_source_agents_json=["backup_agent"],
        allowed_tools_json=[original_tool.name],
        workflow_json=[
            {
                "id": "fetch",
                "agent": "backup_agent",
                "tools": [original_tool.name],
            }
        ],
    )
    existing = IntentRule(id="intent-existing", **rule_data.model_dump(mode="json"))
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[original_tool, observed_tool],
        rules=[existing],
    )

    candidate = await IntentLearningService().observe(
        session,
        source_agent="backup_agent",
        query="show backup status",
        contributing_agents={"backup_agent": [observed_tool.name]},
        model_name="model-a",
    )

    assert candidate is not None
    assert candidate.suggested_intent_id is None
    step = candidate.proposed_rule_json["workflow_json"][0]
    assert step["connection_ref"] == observed_tool.name


@pytest.mark.asyncio
async def test_near_miss_proposes_next_version_of_existing_approved_intent():
    tool = _tool("fetch_backups")
    template = _direct_template(tool.name)
    template.id = "template-backup-status-v1"
    rule_data = IntentRuleCreate(
        name="backup.status",
        target_agent="backup_agent",
        keywords_json=["backup", "status"],
        examples_json=["show backup status"],
        allowed_source_agents_json=["backup_agent"],
        allowed_tools_json=[tool.name],
        workflow_json=[
            {
                "id": "fetch",
                "agent": "backup_agent",
                "tools": [tool.name],
                "connection_ref": tool.name,
                "action_template": f"{template.name}@{template.version}",
                "action_inputs": {"query": "query"},
            }
        ],
        workflow_version=1,
        response_mode="template",
        response_template="Backup result: {results}",
        response_options_json={"max_rows": 100},
        min_confidence=0.99,
    )
    existing = IntentRule(id="intent-existing", **rule_data.model_dump(mode="json"))
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[tool],
        templates=[template],
        assignments=[("backup_agent", tool.name)],
        rules=[existing],
    )
    service = IntentLearningService()

    candidate = await service.observe(
        session,
        source_agent="backup_agent",
        query="show current backup status",
        contributing_agents={"backup_agent": [tool.name]},
        model_name="model-a",
    )

    assert candidate is not None
    assert candidate.suggested_intent_id == existing.id
    assert candidate.proposal_confidence >= 0.80
    assert candidate.proposed_rule_json["name"] == existing.name
    assert candidate.proposed_rule_json["workflow_version"] == 2
    assert candidate.proposed_rule_json["response_mode"] == "template"
    assert candidate.proposed_rule_json["response_template"] == "Backup result: {results}"
    assert candidate.proposed_rule_json["response_options_json"] == {"max_rows": 100}
    assert candidate.proposed_rule_json["workflow_json"][0]["action_template"] == (
        f"{template.name}@{template.version}"
    )
    assert "show current backup status" in candidate.proposed_rule_json["examples_json"]

    service._intents.update_rule = AsyncMock(return_value=existing)
    service._audit.append = AsyncMock()
    reviewed, approved = await service.approve(
        session,
        candidate.id,
        reviewed_by="admin",
    )

    assert approved is existing
    assert reviewed.approved_intent_id == existing.id
    service._intents.update_rule.assert_awaited_once()
    update = service._intents.update_rule.await_args.args[2]
    assert update.workflow_version == 2
    assert update.response_template == "Backup result: {results}"
    assert update.workflow_json[0].action_template == f"{template.name}@{template.version}"


@pytest.mark.asyncio
async def test_below_eighty_percent_similarity_stays_a_new_intent_candidate():
    existing_data = IntentRuleCreate(
        name="backup.status",
        target_agent="backup_agent",
        keywords_json=["backup", "status"],
        examples_json=["show backup status"],
        allowed_source_agents_json=["backup_agent"],
        min_confidence=0.99,
    )
    existing = IntentRule(id="intent-existing", **existing_data.model_dump(mode="json"))
    session = _LearningSession(agents=[_agent("backup_agent")], rules=[existing])

    candidate = await IntentLearningService().observe(
        session,
        source_agent="backup_agent",
        query="list detailed historical backup failures grouped by application",
        contributing_agents={"backup_agent": []},
        model_name="model-a",
    )

    assert candidate is not None
    assert candidate.suggested_intent_id is None
    assert candidate.proposed_rule_json["name"] != existing.name
    assert candidate.proposed_rule_json["workflow_version"] == 1


@pytest.mark.asyncio
async def test_similar_intent_approval_cannot_create_duplicate_name():
    existing_data = IntentRuleCreate(
        name="backup.status",
        target_agent="backup_agent",
        keywords_json=["backup", "status"],
        examples_json=["show backup status"],
        allowed_source_agents_json=["backup_agent"],
        workflow_version=1,
    )
    existing = IntentRule(id="intent-existing", **existing_data.model_dump(mode="json"))
    candidate = IntentLearningCandidate(
        id="candidate-version",
        status="pending",
        source_agent="backup_agent",
        fingerprint="b" * 64,
        normalized_pattern="show current backup status",
        examples_json=["show current backup status"],
        observed_route_json={},
        model_names_json=["model-a"],
        occurrence_count=1,
        proposal_confidence=0.90,
        proposed_execution_mode="agent_llm",
        proposed_rule_json=existing_data.model_dump(mode="json"),
        suggested_intent_id=existing.id,
    )
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        candidates=[candidate],
        rules=[existing],
    )
    duplicate = existing_data.model_copy(
        update={"name": "backup.status.copy", "workflow_version": 2}
    )

    with pytest.raises(IntentLearningCandidateStateError, match="cannot create a duplicate"):
        await IntentLearningService().approve(
            session,
            candidate.id,
            reviewed_by="admin",
            rule=duplicate,
        )


@pytest.mark.asyncio
async def test_similar_intent_approval_rejects_stale_version():
    existing_data = IntentRuleCreate(
        name="backup.status",
        target_agent="backup_agent",
        keywords_json=["backup", "status"],
        examples_json=["show backup status"],
        allowed_source_agents_json=["backup_agent"],
        workflow_version=2,
    )
    existing = IntentRule(id="intent-existing", **existing_data.model_dump(mode="json"))
    candidate = IntentLearningCandidate(
        id="candidate-stale",
        status="pending",
        source_agent="backup_agent",
        fingerprint="c" * 64,
        normalized_pattern="show current backup status",
        examples_json=["show current backup status"],
        observed_route_json={},
        model_names_json=["model-a"],
        occurrence_count=1,
        proposal_confidence=0.90,
        proposed_execution_mode="agent_llm",
        proposed_rule_json=existing_data.model_dump(mode="json"),
        suggested_intent_id=existing.id,
    )
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        candidates=[candidate],
        rules=[existing],
    )

    with pytest.raises(IntentLearningCandidateStateError, match="workflow version 3"):
        await IntentLearningService().approve(
            session,
            candidate.id,
            reviewed_by="admin",
            rule=existing_data,
        )


@pytest.mark.asyncio
async def test_approval_activates_validated_rule_and_marks_candidate():
    candidate = IntentLearningCandidate(
        id="candidate-1",
        status="pending",
        source_agent="backup_agent",
        fingerprint="a" * 64,
        normalized_pattern="show backup status",
        examples_json=["show backup status"],
        observed_route_json={"backup_agent": []},
        model_names_json=["model-a"],
        occurrence_count=2,
        proposal_confidence=0.7,
        proposed_execution_mode="agent_llm",
        proposed_rule_json={},
    )
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        candidates=[candidate],
    )
    service = IntentLearningService()
    created = IntentRule(
        id="intent-1",
        name="backup.status",
        target_agent="backup_agent",
    )
    service._intents.create_rule = AsyncMock(return_value=created)
    service._audit.append = AsyncMock()
    rule = IntentRuleCreate(
        name="backup.status",
        target_agent="backup_agent",
        keywords_json=["backup", "status"],
        examples_json=["show backup status"],
        allowed_source_agents_json=["backup_agent"],
    )

    reviewed, intent = await service.approve(
        session,
        candidate.id,
        reviewed_by="admin",
        rule=rule,
        note="verified",
    )

    assert intent is created
    assert reviewed.status == "approved"
    assert reviewed.approved_intent_id == "intent-1"
    assert reviewed.reviewed_by == "admin"
    assert reviewed.review_note == "verified"
