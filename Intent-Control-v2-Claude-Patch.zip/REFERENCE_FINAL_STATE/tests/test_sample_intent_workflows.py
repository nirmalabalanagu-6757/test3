"""Executable checks for the disabled Skywise Intent Control samples."""

from __future__ import annotations

import json
from typing import Any

import pytest

from backend.models.action_template import ActionTemplate
from backend.models.intent import IntentRule
from backend.schemas.action_template import ResolvedActionTemplate
from backend.schemas.intent import (
    IntentDecision,
    ResolvedIntent,
    ResolvedWorkflowStep,
)
from backend.services.action_template import ActionTemplateService
from backend.services.intent_control import IntentControlService
from backend.services.intent_orchestrator import IntentOrchestrator
from backend.startup_config.intent_workflow_samples import (
    sample_action_templates,
    sample_intent_rules,
)


def _snapshots() -> dict[str, ResolvedActionTemplate]:
    snapshots: dict[str, ResolvedActionTemplate] = {}
    for index, data in enumerate(sample_action_templates(), start=1):
        model = ActionTemplate(
            id=f"sample-template-{index}",
            **data.model_dump(mode="json"),
        )
        snapshot = ActionTemplateService.snapshot(model)
        snapshots[snapshot.reference] = snapshot
    return snapshots


def _resolved_sample(name: str, parameters: dict[str, Any]) -> ResolvedIntent:
    rule = next(item for item in sample_intent_rules() if item.name == name)
    snapshots = _snapshots()
    steps = [
        ResolvedWorkflowStep(
            **step.model_dump(mode="json"),
            resolved_action=snapshots[str(step.action_template)],
        )
        for step in rule.workflow_json
    ]
    return ResolvedIntent(
        intent_id=f"id-{rule.name}",
        intent_name=rule.name,
        confidence=1.0,
        orchestration_mode=rule.orchestration_mode,
        workflow_version=rule.workflow_version,
        workflow_steps=steps,
        aggregator_agent=rule.aggregator_agent,
        extracted_parameters=parameters,
        response_mode=rule.response_mode,
        response_template=rule.response_template,
        response_options=rule.response_options_json,
        execution_options=rule.execution_options_json,
    )


def _decision(intent: ResolvedIntent) -> IntentDecision:
    return IntentDecision(
        decision="route",
        source_agent="concierge",
        intent_id=intent.intent_id,
        intent_name=intent.intent_name,
        target_agent=intent.workflow_steps[0].agent,
        confidence=1.0,
        reason="sample workflow test",
        selected_intents=[intent],
        orchestration_mode=intent.orchestration_mode,
    )


class _SampleOrchestrator(IntentOrchestrator):
    def __init__(self) -> None:
        self.direct_calls: list[tuple[str, dict[str, Any]]] = []

    async def _create_run(self, *args: Any, **kwargs: Any) -> None:
        return None

    async def _finish_run(self, *args: Any, **kwargs: Any) -> None:
        return None

    async def _start_step(self, *args: Any, **kwargs: Any) -> str:
        return "sample-step-record"

    async def _finish_step(self, *args: Any, **kwargs: Any) -> None:
        return None

    async def _record_skipped_step(self, *args: Any, **kwargs: Any) -> None:
        return None

    async def _authorize_step(self, *args: Any, **kwargs: Any) -> tuple[bool, str]:
        return True, "sample test allowed"

    async def _invoke_action_template(self, **kwargs: Any):
        step = kwargs["step"]
        action = step.resolved_action
        rendered = self._render_action(
            kwargs["intent"],
            step,
            kwargs["user_message"],
            kwargs["previous"],
        )
        self.direct_calls.append((action.tool_name, rendered.tool_arguments))
        if action.tool_name == "fetch_skywise_db_relationships":
            payload = {
                "data": [{"database": "sample-db", "application": "sample-app"}],
                "total_count": 1,
                "query_timestamp": "2026-01-01T00:00:00Z",
            }
        else:
            payload = {
                "items": [{"product": "sample-product", "cost": 42}],
                "total_count": 1,
                "object_type": rendered.tool_arguments["object_type"],
                "query_timestamp": "2026-01-01T00:00:00Z",
            }
        ActionTemplateService.validate_output(payload, action.output_schema_json)
        return (
            json.dumps(payload, sort_keys=True),
            {kwargs["agent_name"]: [action.tool_name]},
            "action-template",
        )


def test_samples_are_disabled_and_use_only_direct_actions():
    templates = sample_action_templates()
    rules = sample_intent_rules()

    assert len(templates) == 2
    assert len(rules) == 2
    assert all(template.execution_mode == "direct" for template in templates)
    assert all(template.lifecycle_status == "active" for template in templates)
    assert all(rule.enabled is False for rule in rules)
    assert all(rule.shadow_mode is False for rule in rules)
    assert all(len(rule.test_cases_json) >= 2 for rule in rules)
    assert all(rule.aggregator_agent is None for rule in rules)
    assert all(step.action_template for rule in rules for step in rule.workflow_json)


def test_sample_parameter_extraction_is_deterministic():
    data = sample_intent_rules()[0]
    rule = IntentRule(id="sample-rule", **data.model_dump(mode="json"))

    extracted, missing = IntentControlService._extract_parameters(
        rule,
        "Show Skywise fields database,application limit 12",
        {},
    )

    assert missing == []
    assert extracted["row_limit"] == 12
    assert extracted["columns"] == "database,application"
    assert extracted["object_type"] == "showback_item"


def test_action_template_rendering_produces_typed_tool_arguments():
    snapshots = _snapshots()
    action = snapshots["sample.skywise.db-relationships.read@1"]

    rendered = ActionTemplateService.render_snapshot(
        action,
        inputs={"columns": "database,application", "row_limit": 15},
        query="show dependencies",
    )

    assert rendered.tool_arguments == {
        "columns": "database,application",
        "row_limit": 15,
    }


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "intent_name, expected_tools",
    [
        (
            "sample.skywise.database-dependencies",
            {"fetch_skywise_db_relationships"},
        ),
        (
            "sample.skywise.impact-and-cost",
            {
                "fetch_skywise_db_relationships",
                "fetch_skywise_finops_for_cloud",
            },
        ),
    ],
)
async def test_sample_workflow_executes_mocked_live_reads_without_llm(
    intent_name: str,
    expected_tools: set[str],
):
    intent = _resolved_sample(
        intent_name,
        {
            "columns": "database,application",
            "row_limit": 10,
            "object_type": "showback_item",
            "properties": "product,cost",
        },
    )
    agent_calls = 0

    async def invoke_agent(**kwargs: Any):
        nonlocal agent_calls
        agent_calls += 1
        raise AssertionError("A direct sample workflow must not invoke an LLM agent")

    orchestrator = _SampleOrchestrator()
    result = await orchestrator.execute(
        _decision(intent),
        session_id="sample-session",
        user_id="sample-user",
        user_message="Show sample Skywise data",
        invoke_agent=invoke_agent,
    )

    assert result.status == "completed"
    assert agent_calls == 0
    assert {tool for tool, _ in orchestrator.direct_calls} == expected_tools
    assert set(result.tools) == {step.agent for step in intent.workflow_steps}
    assert all(arguments["row_limit"] == 10 for _, arguments in orchestrator.direct_calls)
