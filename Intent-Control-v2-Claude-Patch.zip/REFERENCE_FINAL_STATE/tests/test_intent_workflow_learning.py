"""Executable learned plans: capture -> compile -> resolve -> fresh tool calls."""

import asyncio
import json
from datetime import date
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from pydantic import ValidationError

from backend.models.action_template import ActionTemplate
from backend.models.intent import IntentRule
from backend.schemas.intent import IntentDecision, IntentRuleCreate, ResolvedIntent, ResolvedWorkflowStep
from backend.services.action_template import ActionTemplateService
from backend.services.intent_control import IntentControlService
from backend.services.intent_orchestrator import IntentOrchestrator
from backend.services.intent_parameters import extract_parameters, parameterized_example
from backend.services.intent_trace import ToolCallTrace, capture_tool_calls, record_tool_event
from backend.services.intent_workflow_learning import compile_workflow, template_inputs
from backend.utils.intent_bindings import step_value


def action(name="backup.list", tool="backup_api", *, payload=None, properties=None, required=None, **changes):
    values = {
        "id": f"id-{name}",
        "name": name,
        "version": 1,
        "tool_name": tool,
        "template_type": "json",
        "execution_mode": "direct",
        "lifecycle_status": "active",
        "template_text": None,
        "payload_template_json": payload if payload is not None else {"operation": "list", "server": "{{server}}"},
        "input_schema_json": {
            "type": "object",
            "properties": properties
            if properties is not None
            else {"server": {"type": "string", "pattern": "[A-Za-z0-9_-]+"}},
            "required": required if required is not None else ["server"],
            "additionalProperties": False,
        },
        "output_schema_json": {},
        "policy_json": {},
        "execution_options_json": {},
    }
    values.update(changes)
    return ActionTemplate(**values)


def compile_trace(trace, templates, query):
    route = {}
    for call in trace.calls:
        route.setdefault(call.agent, []).append(call.tool)
    return compile_workflow(
        trace,
        route=route,
        templates=templates,
        assignments={(agent, tool) for agent, tools in route.items() for tool in tools},
        query=query,
    )


def one_call(arguments=None, output=None):
    trace = ToolCallTrace()
    trace.call("backup_agent", "backup_api", arguments or {"operation": "list", "server": "APP01"}, "a")
    trace.response("backup_agent", "backup_api", output if output is not None else {"jobs": []}, "a")
    return trace


def rule_for(learned, query):
    return IntentRuleCreate(
        name="learned.backup",
        target_agent=learned.steps[0]["agent"],
        examples_json=[query],
        workflow_json=learned.steps,
        orchestration_mode="dag" if len(learned.steps) > 1 else "single",
        parameter_config_json=learned.parameters,
        response_mode="direct",
        min_confidence=0.9,
    )


def test_selects_exact_operation_not_first_template_on_shared_connection():
    read = action()
    delete = action("backup.delete", payload={"operation": "delete", "server": "{{server}}"})
    learned = compile_trace(one_call(), [delete, read], "Show backups for server APP01")
    assert learned.direct
    assert learned.steps[0]["action_template"] == "backup.list@1"
    assert learned.steps[0]["connection_ref"] == "backup_api"
    rule = rule_for(learned, "Show backups for server APP01")
    model = IntentRule(**rule.model_dump(mode="json"))
    query = "Show backups for server DIFFERENT_SERVER"
    matched = IntentControlService._score_rule(model, query)
    assert matched.score >= 0.9
    assert "parameterized_example" in matched.matched_by
    parameters, missing = IntentControlService._extract_parameters(model, query, {})
    assert parameters["call_1_server"] == "DIFFERENT_SERVER"
    assert not missing
    assert "APP01" not in json.dumps(learned.steps)
    assert "APP01" not in json.dumps(learned.evidence)


def test_identical_templates_and_unextractable_resource_require_review():
    duplicate = action("another.list")
    learned = compile_trace(one_call(), [action(), duplicate], "Show backups for server APP01")
    assert not learned.direct
    assert "Multiple actions" in learned.evidence["calls"][0]["reason"]
    unresolved = compile_trace(one_call(), [action()], "Show backups")
    assert not unresolved.direct
    assert (
        "manual" in unresolved.evidence["calls"][0]["reason"].lower()
        or "mapping" in unresolved.evidence["calls"][0]["reason"]
    )


def test_repeated_same_tool_calls_keep_arguments_order_and_scoped_parameters():
    trace = one_call()
    trace.call("backup_agent", "backup_api", {"operation": "list", "server": "APP02"}, "b")
    trace.response("backup_agent", "backup_api", {"jobs": []}, "b")
    query = "Compare backups for server APP01 and server APP02"
    learned = compile_trace(trace, [action()], query)
    assert learned.direct
    assert len(learned.steps) == 2
    assert learned.steps[1]["depends_on"] == ["call_1"]
    rule_for(learned, query)
    params, missing = extract_parameters(learned.parameters, "Compare backups for server NEW01 and server NEW02", {})
    assert not missing
    assert params == {"call_1_server": "NEW01", "call_2_server": "NEW02"}


def test_optional_limit_preserves_api_default_and_can_be_overridden():
    template = action(
        payload={},
        properties={
            "server": {"type": "string"},
            "rowLimit": {"type": "integer", "minimum": 1, "maximum": 1000},
        },
        execution_options_json={"include_unmapped_inputs": True},
    )
    learned = compile_trace(one_call({"server": "APP01"}), [template], "Show backups for server APP01")
    assert learned.direct
    params, missing = extract_parameters(learned.parameters, "Show backups for server APP02 limit 25", {})
    assert not missing
    assert params["call_1_rowLimit"] == 25
    _, invalid = extract_parameters(learned.parameters, "Show backups for server APP02 limit 5000", {})
    assert invalid == ["call_1_rowLimit"]
    params, _ = extract_parameters(learned.parameters, "Show backups for server APP02", {})
    assert "call_1_rowLimit" not in params
    resolved = IntentOrchestrator._resolve_action_value(learned.steps[0]["action_inputs"], params, {}, "")
    rendered = ActionTemplateService.render_snapshot(ActionTemplateService.snapshot(template), inputs=resolved)
    assert rendered.tool_arguments == {"server": "APP02"}


def test_relative_dates_are_recomputed_and_ambiguous_values_clarify():
    config = {
        "required": ["start", "end"],
        "properties": {
            "start": {"type": "string", "format": "date", "x-intent": {"extractor": "date", "date_role": "start"}},
            "end": {"type": "string", "format": "date", "x-intent": {"extractor": "date", "date_role": "end"}},
        },
    }
    values, missing = extract_parameters(config, "Show failed backups during last 7 days", {}, today=date(2026, 9, 21))
    assert values == {"start": "2026-09-15", "end": "2026-09-21"}
    assert not missing
    tomorrow, _ = extract_parameters(config, "Show failed backups yesterday", {}, today=date(2026, 9, 22))
    assert tomorrow == {"start": "2026-09-21", "end": "2026-09-21"}
    assert parameterized_example("Show failed backups yesterday", config) == parameterized_example(
        "Show failed backups during last 7 days".replace(" during", ""), config
    )
    _, missing = extract_parameters(config, "Show backups today and yesterday", {}, today=date(2026, 9, 21))
    assert set(missing) == {"start", "end"}


@pytest.mark.parametrize(
    "output",
    [{"error": "bad request"}, {"success": False}, {"blocked": True}, {"status_code": 401}, "HTTP 500 unavailable"],
)
def test_failed_calls_cannot_become_direct_plans(output):
    learned = compile_trace(one_call(output=output), [action()], "Show backups for server APP01")
    assert not learned.direct
    assert learned.evidence["calls"][0]["status"] == "failed"


def test_pending_truncated_and_uncorrelated_observations_cannot_replay():
    trace = ToolCallTrace()
    trace.call("backup_agent", "backup_api", {"operation": "list", "server": "APP01"})
    trace.call("backup_agent", "backup_api", {"operation": "list", "server": "APP02"})
    trace.response("backup_agent", "backup_api", {"jobs": []})
    assert trace.incomplete
    assert not compile_trace(trace, [action()], "Show backups for server APP01 and server APP02").direct
    trace = one_call()
    trace.MAX_VALUE_BYTES = 1
    trace.call("backup_agent", "backup_api", {"server": "APP02"})
    assert not compile_trace(trace, [action()], "Show backups for server APP01").direct


def test_no_secret_or_business_result_persistence():
    trace = one_call(output={"business_secret": "PRIVATE_RESULT", "password": "PASSWORD"})
    learned = compile_trace(trace, [action()], "Show backups for server APP01")
    stored = json.dumps({"steps": learned.steps, "parameters": learned.parameters, "evidence": learned.evidence})
    assert all(value not in stored for value in ["APP01", "PRIVATE_RESULT", "PASSWORD"])
    trace = one_call({"operation": "list", "server": "APP01", "authorization": "Bearer SECRET"})
    learned = compile_trace(trace, [action()], "Show backups for server APP01")
    assert not learned.direct
    assert "Bearer SECRET" not in json.dumps(learned.evidence)


@pytest.mark.asyncio
async def test_request_capture_is_isolated_and_correlates_responses_out_of_order():
    async def capture(server):
        with capture_tool_calls() as trace:
            for index in [1, 2]:
                record_tool_event(
                    "backup_agent",
                    SimpleNamespace(
                        function_call=SimpleNamespace(name="backup_api", id=str(index), args={"server": server}),
                        function_response=None,
                    ),
                )
            await asyncio.sleep(0)
            for index in [2, 1]:
                part = SimpleNamespace(
                    function_call=None,
                    function_response=SimpleNamespace(name="backup_api", id=str(index), response={"jobs": [index]}),
                )
                record_tool_event("backup_agent", part)
                record_tool_event("backup_agent", part)  # callback + event delivery is idempotent
            return trace

    first, second = await asyncio.gather(capture("APP01"), capture("APP02"))
    assert all(call.arguments["server"] == "APP01" for call in first.calls)
    assert all(call.arguments["server"] == "APP02" for call in second.calls)
    assert first.calls[0].output == {"jobs": [1]}
    assert not first.incomplete
    assert all(not call.predecessors for call in first.calls)


def test_bindings_reject_missing_dependencies_and_bad_paths():
    learned = compile_trace(one_call(), [action()], "Show backups for server APP01")
    learned.steps[0]["action_inputs"] = {"server": {"$from_step": {"step": "unknown", "path": "/id"}}}
    with pytest.raises(ValidationError, match="declared workflow dependency"):
        rule_for(learned, "Show backups for server APP01")
    with pytest.raises(ValueError, match="missing"):
        step_value({"fetch": '{"rows": []}'}, {"step": "fetch", "path": "/rows/0/id"})
    assert step_value({"fetch": '{"a/b": {"~id": 42}}'}, {"step": "fetch", "path": "/a~1b/~0id"}) == 42


def test_sql_can_learn_bound_parameters_without_interpolating_resource_names():
    sql = action(
        "db.health",
        "sql_connection",
        payload={
            "sql_query": "SELECT status FROM servers WHERE name = :server",
            "parameters": {"server": "{{server}}"},
        },
        template_type="sql",
    )
    arguments = {"sql_query": "SELECT status FROM servers WHERE name = :server", "parameters": {"server": "APP01"}}
    assert template_inputs(sql, arguments, "Show server APP01") == {"server": "APP01"}
    unsafe = action(
        template_type="sql",
        template_text="SELECT * FROM servers WHERE name = '{{server}}'",
        payload={},
        execution_options_json={"text_argument": "sql_query"},
    )
    assert (
        template_inputs(unsafe, {"sql_query": "SELECT * FROM servers WHERE name = 'APP01'"}, "Show server APP01")
        is None
    )


@pytest.mark.asyncio
async def test_learned_dependency_executes_against_fresh_results_without_llm(monkeypatch):
    lookup = action(
        "database.servers",
        "database_api",
        payload={"application": "{{application}}"},
        properties={"application": {"type": "string"}},
        required=["application"],
    )
    backups = action(
        payload={"servers": "{{server_ids}}"},
        properties={"server_ids": {"type": "array", "items": {"type": "string"}}},
        required=["server_ids"],
    )
    trace = ToolCallTrace()
    trace.call("database_agent", "database_api", {"application": "APP01"}, "db")
    trace.response("database_agent", "database_api", {"servers": ["old-server"]}, "db")
    trace.call("backup_agent", "backup_api", {"servers": ["old-server"]}, "backup")
    trace.response("backup_agent", "backup_api", {"failed": 1}, "backup")
    query = "Check backups for application APP01"
    learned = compile_trace(trace, [lookup, backups], query)
    assert learned.direct
    assert learned.steps[1]["action_inputs"]["server_ids"] == {"$from_step": {"step": "call_1", "path": "/servers"}}
    rule_for(learned, query)
    observed = []

    async def database_api(application):
        observed.append(("database", application))
        return {"servers": [f"{application}-live-server"]}

    async def backup_api(servers):
        observed.append(("backup", servers))
        return {"failed": 2}

    session = AsyncMock()
    context = AsyncMock()
    context.__aenter__.return_value = session
    monkeypatch.setattr("backend.database.async_session_factory", lambda: context)
    monkeypatch.setattr(ActionTemplateService, "validate_for_agent", AsyncMock())
    monkeypatch.setattr("backend.services.audit_log.AuditLogService.append", AsyncMock())
    monkeypatch.setattr(
        "backend.services.tool_loader.get_tool_callable_async",
        AsyncMock(side_effect=lambda db, name: {"database_api": database_api, "backup_api": backup_api}[name]),
    )
    orchestrator = IntentOrchestrator()
    for name in ["_create_run", "_finish_run", "_start_step", "_finish_step", "_record_skipped_step"]:
        monkeypatch.setattr(orchestrator, name, AsyncMock(return_value="record"))
    monkeypatch.setattr(orchestrator, "_authorize_step", AsyncMock(return_value=(True, "allowed")))
    llm = AsyncMock(side_effect=AssertionError("No LLM should run"))
    templates = {"database.servers@1": lookup, "backup.list@1": backups}
    for application in ["APP02", "APP03"]:
        request = f"Check backups for application {application}"
        parameters, missing = extract_parameters(learned.parameters, request, {})
        assert not missing
        intent = ResolvedIntent(
            intent_id="intent",
            intent_name="learned.backup",
            confidence=0.96,
            orchestration_mode="dag",
            workflow_version=1,
            workflow_steps=[
                ResolvedWorkflowStep(
                    **step, resolved_action=ActionTemplateService.snapshot(templates[step["action_template"]])
                )
                for step in learned.steps
            ],
            extracted_parameters=parameters,
            response_mode="direct",
        )
        decision = IntentDecision(decision="route", reason="learned", selected_intents=[intent])
        result = await orchestrator.execute(
            decision, session_id="session", user_id="user", user_message=request, invoke_agent=llm
        )
        assert result.status == "completed"
    assert observed == [
        ("database", "APP02"),
        ("backup", ["APP02-live-server"]),
        ("database", "APP03"),
        ("backup", ["APP03-live-server"]),
    ]
    llm.assert_not_awaited()


@pytest.mark.asyncio
async def test_queue_groups_parameter_variations_but_separates_different_operations():
    from test_intent_learning import _agent, _LearningSession, _tool

    from backend.services.intent_learning import IntentLearningService

    read, remove = action(), action("backup.delete", payload={"operation": "delete", "server": "{{server}}"})
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[_tool("backup_api")],
        templates=[read, remove],
        assignments=[("backup_agent", "backup_api")],
    )
    service = IntentLearningService()
    first = await service.observe(
        session,
        source_agent="backup_agent",
        query="Show backups for server APP01",
        contributing_agents={"backup_agent": ["backup_api"]},
        tool_trace=one_call(),
    )
    second = await service.observe(
        session,
        source_agent="backup_agent",
        query="Show backups for server APP02",
        tool_trace=one_call({"operation": "list", "server": "APP02"}),
    )
    assert first is second
    assert first.occurrence_count == 2
    assert first.proposed_execution_mode == "direct_action"
    assert first.observation_json["direct_ready"]
    approved = IntentRule(
        id="existing", **IntentRuleCreate.model_validate(first.proposed_rule_json).model_dump(mode="json")
    )
    session.rules.append(approved)
    first.status = "approved"
    version = await service.observe(
        session,
        source_agent="backup_agent",
        query="Show backups for server APP03",
        tool_trace=one_call({"operation": "list", "server": "APP03"}),
    )
    assert version.suggested_intent_id == "existing"
    assert version.proposed_rule_json["workflow_version"] == 2
    deleted = await service.observe(
        session,
        source_agent="backup_agent",
        query="Show backups for server APP01",
        tool_trace=one_call({"operation": "delete", "server": "APP01"}),
    )
    assert deleted is not version
    assert deleted.suggested_intent_id is None


@pytest.mark.asyncio
async def test_incomplete_capture_falls_back_to_agent_plan_without_guessed_actions():
    from test_intent_learning import _agent, _LearningSession, _tool

    from backend.services.intent_learning import IntentLearningService

    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[_tool("backup_api")],
        templates=[action()],
        assignments=[("backup_agent", "backup_api")],
    )
    trace = one_call()
    trace.incomplete = True
    candidate = await IntentLearningService().observe(
        session, source_agent="backup_agent", query="Show backups for server APP01", tool_trace=trace
    )
    assert candidate.proposed_execution_mode == "agent_llm"
    assert all("action_template" not in step for step in candidate.proposed_rule_json["workflow_json"])
    assert not candidate.observation_json["direct_ready"]


@pytest.mark.asyncio
async def test_chat_passes_request_trace_to_learning_and_does_not_leak_it(monkeypatch):
    from test_intent_learning import _agent

    from backend.schemas.chat import ChatMessage
    from backend.services.chat import ChatService
    from backend.services.intent_learning import IntentLearningService

    chat = ChatService()
    chat.check_agent_available = AsyncMock(return_value=_agent("backup_agent"))
    chat.get_or_create_session = AsyncMock(return_value=("session", 1))
    chat._audit.append = AsyncMock()
    chat._token_mgr.get_session_latest_usage = AsyncMock(return_value=(0, 0))
    observed = AsyncMock()
    monkeypatch.setattr(IntentLearningService, "observe", observed)

    async def invoke(*args, **kwargs):
        record_tool_event(
            "backup_agent",
            SimpleNamespace(
                function_response=None,
                function_call=SimpleNamespace(id="call", name="backup_api", args={"server": "APP01"}),
            ),
        )
        record_tool_event(
            "backup_agent",
            SimpleNamespace(
                function_call=None,
                function_response=SimpleNamespace(id="call", name="backup_api", response={"jobs": []}),
            ),
        )
        return "No failures", {"backup_agent": ["backup_api"]}, None

    chat.invoke_agent = invoke
    response = await chat.handle_message(
        AsyncMock(), "backup_agent", ChatMessage(content="Show backups for server APP01", user_id="user")
    )
    assert response.content == "No failures"
    captured = observed.await_args.kwargs["tool_trace"]
    assert len(captured.calls) == 1
    assert captured.calls[0].status == "completed"
    record_tool_event(
        "backup_agent",
        SimpleNamespace(
            function_response=None, function_call=SimpleNamespace(id="unrelated", name="backup_api", args={})
        ),
    )
    assert len(captured.calls) == 1


@pytest.mark.asyncio
async def test_legacy_agent_intent_gets_reviewed_workflow_upgrade_without_duplicate():
    from test_intent_control import _rule
    from test_intent_learning import _agent, _LearningSession, _tool

    from backend.services.intent_learning import IntentLearningService

    original = _rule(
        name="backup.list",
        target_agent="backup_agent",
        allowed_tools_json=["backup_api"],
        allowed_source_agents_json=["backup_agent"],
        keywords_json=["backups"],
        examples_json=["Show backups for server APP01"],
        response_mode="template",
        response_template="Current backups: {results}",
    )
    session = _LearningSession(
        agents=[_agent("backup_agent")],
        tools=[_tool("backup_api")],
        templates=[action()],
        assignments=[("backup_agent", "backup_api")],
        rules=[original],
    )
    candidate = await IntentLearningService().observe(
        session,
        source_agent="backup_agent",
        query="Show backups for server APP02",
        tool_trace=one_call({"operation": "list", "server": "APP02"}),
    )
    assert candidate.suggested_intent_id == original.id
    assert candidate.proposed_execution_mode == "direct_action"
    assert candidate.proposed_rule_json["workflow_version"] == 2
    assert candidate.proposed_rule_json["workflow_json"][0]["action_template"] == "backup.list@1"
    assert candidate.proposed_rule_json["response_template"] == original.response_template
    assert original.workflow_json == []  # approval has not happened


def test_parallel_calls_and_ambiguous_dependency_evidence():
    trace = ToolCallTrace()
    for number in [1, 2]:
        trace.call("backup_agent", "backup_api", {"operation": "list", "server": f"APP0{number}"}, str(number))
    for number in [1, 2]:
        trace.response("backup_agent", "backup_api", {"jobs": []}, str(number))
    learned = compile_trace(trace, [action()], "Compare server APP01 and server APP02")
    assert learned.direct
    assert learned.steps[0]["depends_on"] == learned.steps[1]["depends_on"] == []
    trace.call("backup_agent", "backup_api", {"operation": "list", "server": "unknown"}, "3")
    trace.calls[0].output = {"primary": "unknown", "secondary": "unknown"}
    trace.response("backup_agent", "backup_api", {"jobs": []}, "3")
    learned = compile_trace(trace, [action()], "Compare server APP01 and server APP02")
    assert not learned.direct
    assert "Several prior result fields" in learned.evidence["calls"][2]["reason"]


def test_data_binding_types_are_checked_recursively():
    from backend.services.action_template import ActionTemplateConfigurationError

    template = action(
        payload={"ids": "{{ids}}"},
        properties={"ids": {"type": "array", "items": {"type": "integer"}, "minItems": 1}},
        required=["ids"],
    )
    with pytest.raises(ActionTemplateConfigurationError, match="integer"):
        ActionTemplateService.render_snapshot(ActionTemplateService.snapshot(template), inputs={"ids": ["wrong"]})
    with pytest.raises(ActionTemplateConfigurationError, match="items"):
        ActionTemplateService.render_snapshot(ActionTemplateService.snapshot(template), inputs={"ids": []})


def test_agent_without_observed_calls_is_not_silently_removed_from_plan():
    learned = compile_workflow(
        one_call(),
        route={"backup_agent": ["backup_api"], "analysis_agent": []},
        templates=[action()],
        assignments={("backup_agent", "backup_api")},
        query="Show backups for server APP01",
    )
    assert not learned.direct
    assert learned.evidence["unobserved_agents"] == ["analysis_agent"]


def test_invalid_relative_range_does_not_use_a_default():
    config = {
        "properties": {
            "start": {
                "type": "string",
                "format": "date",
                "default": "2026-01-01",
                "x-intent": {"extractor": "date", "date_role": "start"},
            }
        }
    }
    values, missing = extract_parameters(config, "Show last 999 days", {}, today=date(2026, 9, 21))
    assert "start" not in values
    assert missing == ["start"]


def test_runner_failure_invalidates_completed_partial_trace():
    from backend.services.intent_trace import invalidate_tool_trace

    with capture_tool_calls() as trace:
        trace.call("backup_agent", "backup_api", {"operation": "list", "server": "APP01"}, "first")
        trace.response("backup_agent", "backup_api", {"jobs": []}, "first")
        invalidate_tool_trace()
        assert not compile_trace(trace, [action()], "Show backups for server APP01").direct
