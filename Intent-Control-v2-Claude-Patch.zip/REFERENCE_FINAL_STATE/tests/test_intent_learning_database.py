"""Local PostgreSQL integration tests with transaction-isolated test objects.

Set INTENT_TEST_LOCAL_DB=1 to run. Existing application data is never modified.
"""

import importlib
import os
import uuid

import pytest
from alembic.migration import MigrationContext
from alembic.operations import Operations
from sqlalchemy import inspect, text
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from backend.config import settings
from backend.database import Base
from backend.models.agent import AgentRegistry
from backend.models.tool import ToolAgentAssignment
from backend.services.intent_control import IntentControlService
from backend.services.intent_learning import IntentLearningService

pytestmark = [
    pytest.mark.asyncio,
    pytest.mark.skipif(
        os.getenv("INTENT_TEST_LOCAL_DB") != "1",
        reason="Opt-in local PostgreSQL integration test",
    ),
]


def local_engine():
    assert make_url(settings.database_url).host in {"localhost", "127.0.0.1", "::1"}
    return create_async_engine(settings.database_url)


async def test_migration_preserves_old_rows_and_round_trips():
    migration = importlib.import_module("backend.migrations.versions.031_intent_call_learning")
    engine = local_engine()
    try:
        async with engine.connect() as connection:
            transaction = await connection.begin()
            try:
                # Temp tables shadow public tables only within this connection.
                await connection.execute(text("CREATE TEMP TABLE intent_learning_candidate (id text PRIMARY KEY)"))
                await connection.execute(text("INSERT INTO intent_learning_candidate VALUES ('old-candidate')"))

                def run_upgrade(sync_connection):
                    with Operations.context(MigrationContext.configure(sync_connection)):
                        migration.upgrade()

                await connection.run_sync(run_upgrade)
                row = (
                    await connection.execute(text("SELECT id, observation_json FROM intent_learning_candidate"))
                ).one()
                assert row == ("old-candidate", {})

                def run_downgrade(sync_connection):
                    with Operations.context(MigrationContext.configure(sync_connection)):
                        migration.downgrade()
                    columns = inspect(sync_connection).get_columns("intent_learning_candidate")
                    assert [column["name"] for column in columns] == ["id"]

                await connection.run_sync(run_downgrade)
                assert (
                    await connection.execute(text("SELECT id FROM intent_learning_candidate"))
                ).scalar_one() == "old-candidate"
            finally:
                if transaction.is_active:
                    await transaction.rollback()
    finally:
        await engine.dispose()


async def test_real_database_capture_approval_resolution_and_agent_disable():
    from test_intent_learning import _agent, _tool
    from test_intent_workflow_learning import action, one_call

    engine = local_engine()
    schema = "intent_test_" + uuid.uuid4().hex
    try:
        async with engine.connect() as connection:
            transaction = await connection.begin()
            try:
                await connection.execute(text(f'CREATE SCHEMA "{schema}"'))
                connection = await connection.execution_options(schema_translate_map={None: schema})
                await connection.run_sync(Base.metadata.create_all)
                async with AsyncSession(bind=connection, expire_on_commit=False) as session:
                    session.add_all([_agent("backup_agent"), _tool("backup_api"), action()])
                    await session.flush()
                    session.add(ToolAgentAssignment(agent_name="backup_agent", tool_name="backup_api"))
                    await session.flush()
                    learning = IntentLearningService()
                    first = await learning.observe(
                        session,
                        source_agent="backup_agent",
                        query="Show backups for server APP01",
                        tool_trace=one_call(),
                    )
                    second = await learning.observe(
                        session,
                        source_agent="backup_agent",
                        query="Show backups for server APP02",
                        tool_trace=one_call({"operation": "list", "server": "APP02"}),
                    )
                    assert first.id == second.id
                    assert second.occurrence_count == 2
                    _, intent = await learning.approve(session, second.id, reviewed_by="local-test")
                    assert intent.enabled
                    result = await IntentControlService().resolve(
                        session, "Show backups for server APP03", source_agent="backup_agent"
                    )
                    assert result.decision == "route"
                    assert result.extracted_parameters["call_1_server"] == "APP03"
                    assert result.selected_intents[0].workflow_steps[0].resolved_action.reference == "backup.list@1"
                    agent = await session.get(AgentRegistry, "backup_agent")
                    agent.intent_control_enabled = False
                    await session.flush()
                    result = await IntentControlService().resolve(
                        session, "Show backups for server APP03", source_agent="backup_agent"
                    )
                    assert result.decision == "no_match"
            finally:
                if transaction.is_active:
                    await transaction.rollback()
    finally:
        await engine.dispose()
