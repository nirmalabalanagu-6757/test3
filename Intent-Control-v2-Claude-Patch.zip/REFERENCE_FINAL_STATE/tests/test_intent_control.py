"""Unit tests for deterministic, database-driven Intent Control."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from backend.models.agent import AgentRegistry
from backend.models.intent import IntentRule, IntentShadowEvaluation
from backend.schemas.agent import AgentCreate, AgentUpdate
from backend.schemas.intent import (
    IntentDecision,
    IntentRegressionCase,
    IntentRuleCreate,
    IntentWorkflowStep,
)
from backend.services.intent_assurance import IntentAssuranceService
from backend.services.intent_control import IntentControlService


def _rule(**overrides):
    values = {
        "id": "intent-1",
        "name": "incident.search",
        "display_name": "Search incidents",
        "description": "Find operational incidents",
        "enabled": True,
        "shadow_mode": False,
        "priority": 100,
        "match_strategy": "hybrid",
        "keyword_mode": "any",
        "keywords_json": ["incident", "open incidents"],
        "negative_keywords_json": ["delete incident"],
        "regex_patterns_json": [],
        "examples_json": ["show open incidents"],
        "min_confidence": 0.70,
        "ambiguity_margin": 0.10,
        "ambiguity_action": "llm_fallback",
        "target_agent": "incident_agent",
        "fallback_agent": None,
        "allowed_source_agents_json": [],
        "allowed_tools_json": ["fetch_incidents"],
        "orchestration_mode": "single",
        "workflow_json": [],
        "allow_multi_intent": False,
        "max_intents": 1,
        "aggregator_agent": None,
        "execution_options_json": {},
        "workflow_version": 1,
        "parameter_config_json": {},
        "risk_classification": "read_only",
        "requires_confirmation": False,
        "response_mode": "auto",
        "response_template": None,
        "response_options_json": {},
        "test_cases_json": [],
    }
    values.update(overrides)
    return IntentRule(**values)


class _ScalarResult:
    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows


class _FakeSession:
    def __init__(self, rules, agents):
        self.rules = rules
        self.agents = agents
        self.added = []

    async def execute(self, _statement):
        return _ScalarResult(self.rules)

    async def get(self, model, key):
        if model is AgentRegistry:
            return self.agents.get(key)
        if model is IntentRule:
            return next((rule for rule in self.rules if rule.id == key), None)
        return None

    def add(self, item):
        self.added.append(item)


def _agent(
    name: str,
    status: str = "running",
    *,
    intent_control_enabled: bool = True,
) -> AgentRegistry:
    return AgentRegistry(
        name=name,
        product="operations",
        agent_type="specialized",
        lifecycle_status=status,
        allow_world_knowledge=False,
        intent_control_enabled=intent_control_enabled,
        health_check_interval_sec=60,
        consecutive_health_failures=0,
    )


def test_keyword_match_and_negative_exclusion():
    rule = _rule()
    match = IntentControlService._score_rule(rule, "Please show the open incidents")
    assert match is not None
    assert match.score >= 0.70
    assert any(label.startswith("keywords") for label in match.matched_by)

    blocked = IntentControlService._score_rule(rule, "delete incident INC-1")
    assert blocked is None


def test_regex_and_exact_matches_are_high_confidence():
    regex_rule = _rule(
        match_strategy="regex",
        keywords_json=[],
        examples_json=[],
        regex_patterns_json=[r"INC-\d+"],
    )
    regex_match = IntentControlService._score_rule(regex_rule, "lookup INC-204")
    assert regex_match is not None
    assert regex_match.score == pytest.approx(0.97)

    exact_rule = _rule(match_strategy="exact", keywords_json=[], examples_json=["show incidents"])
    exact_match = IntentControlService._score_rule(exact_rule, "  SHOW   incidents ")
    assert exact_match is not None
    assert exact_match.score == pytest.approx(1.0)


def test_schema_rejects_incomplete_strategy_and_template():
    with pytest.raises(ValidationError):
        IntentRuleCreate(
            name="bad.intent",
            match_strategy="regex",
            keywords_json=["bad"],
            target_agent="incident_agent",
        )


def test_schema_enforces_one_lifecycle_state():
    with pytest.raises(ValidationError, match="active and in shadow mode"):
        IntentRuleCreate(
            name="bad.lifecycle",
            enabled=True,
            shadow_mode=True,
            keywords_json=["bad"],
            target_agent="incident_agent",
        )

    shadow = IntentRuleCreate(
        name="safe.shadow",
        enabled=False,
        shadow_mode=True,
        keywords_json=["incident"],
        target_agent="incident_agent",
    )
    assert shadow.shadow_mode is True
    assert shadow.enabled is False


def test_agent_intent_control_schema_defaults_and_update():
    created = AgentCreate(
        name="scope_agent",
        product="operations",
        agent_type="specialized",
    )
    assert created.intent_control_enabled is True
    assert AgentUpdate(intent_control_enabled=False).intent_control_enabled is False

    with pytest.raises(ValidationError):
        IntentRuleCreate(
            name="bad.template",
            keywords_json=["incident"],
            target_agent="incident_agent",
            response_mode="template",
        )


@pytest.mark.asyncio
async def test_resolve_extracts_parameters_and_routes():
    rule = _rule(
        parameter_config_json={
            "required": ["row_limit"],
            "properties": {
                "row_limit": {
                    "type": "integer",
                    "pattern": r"(?:limit|rows?)\s+(\d+)",
                    "prompt": "How many rows should be returned?",
                }
            },
        }
    )
    service = IntentControlService()
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})

    decision = await service.resolve(session, "show incidents limit 25")
    assert decision.decision == "route"
    assert decision.target_agent == "incident_agent"
    assert decision.extracted_parameters == {"row_limit": 25}
    assert decision.allowed_tools == ["fetch_incidents"]


@pytest.mark.asyncio
async def test_missing_parameter_requests_clarification():
    rule = _rule(
        parameter_config_json={
            "required": ["dataset"],
            "properties": {"dataset": {"prompt": "Which dataset should be used?"}},
        }
    )
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})
    decision = await IntentControlService().resolve(session, "show incidents")
    assert decision.decision == "clarify"
    assert decision.missing_parameters == ["dataset"]
    assert decision.clarification_prompt == "Which dataset should be used?"


@pytest.mark.asyncio
async def test_confirmation_and_unavailable_target_are_enforced():
    rule = _rule(requires_confirmation=True, risk_classification="execute")
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})
    service = IntentControlService()

    pending = await service.resolve(session, "show incidents")
    assert pending.decision == "confirm"

    session.agents["incident_agent"].lifecycle_status = "stopped"
    unavailable = await service.resolve(session, "show incidents", confirmed=True)
    assert unavailable.decision == "unavailable"


@pytest.mark.asyncio
async def test_ambiguity_action_clarifies_between_close_matches():
    first = _rule(id="one", name="incident.search", ambiguity_action="clarify")
    second = _rule(
        id="two",
        name="incident.report",
        target_agent="report_agent",
        keywords_json=["incident"],
        examples_json=["show incident report"],
        priority=90,
    )
    session = _FakeSession(
        [first, second],
        {
            "incident_agent": _agent("incident_agent"),
            "report_agent": _agent("report_agent"),
        },
    )
    decision = await IntentControlService().resolve(session, "incident")
    assert decision.decision == "clarify"
    assert len(decision.candidates) == 2
    assert "Did you mean" in (decision.clarification_prompt or "")


@pytest.mark.asyncio
async def test_agent_level_disable_bypasses_intent_matching():
    rule = _rule()
    session = _FakeSession(
        [rule],
        {
            "concierge": _agent("concierge", intent_control_enabled=False),
            "incident_agent": _agent("incident_agent"),
        },
    )

    decision = await IntentControlService().resolve(
        session,
        "show incidents",
        source_agent="concierge",
    )

    assert decision.decision == "no_match"
    assert "disabled for source agent" in decision.reason
    assert decision.candidates == []


@pytest.mark.asyncio
async def test_disabled_target_agent_rules_are_excluded_before_scoring():
    rule = _rule()
    session = _FakeSession(
        [rule],
        {"incident_agent": _agent("incident_agent", intent_control_enabled=False)},
    )

    decision = await IntentControlService().resolve(session, "show incidents")

    assert decision.decision == "no_match"
    assert decision.candidates == []


@pytest.mark.asyncio
async def test_intent_access_is_restricted_by_source_agent():
    rule = _rule(allowed_source_agents_json=["incident_agent"])
    session = _FakeSession(
        [rule],
        {
            "concierge": _agent("concierge"),
            "incident_agent": _agent("incident_agent"),
            "backup_agent": _agent("backup_agent"),
        },
    )
    service = IntentControlService()

    denied = await service.resolve(session, "show incidents", source_agent="backup_agent")
    allowed = await service.resolve(session, "show incidents", source_agent="incident_agent")

    assert denied.decision == "no_match"
    assert denied.candidates == []
    assert allowed.decision == "route"
    assert allowed.source_agent == "incident_agent"


@pytest.mark.asyncio
async def test_empty_access_scope_defaults_to_concierge_and_target_only():
    rule = _rule(allowed_source_agents_json=[])
    session = _FakeSession(
        [rule],
        {
            "concierge": _agent("concierge"),
            "incident_agent": _agent("incident_agent"),
            "backup_agent": _agent("backup_agent"),
        },
    )
    service = IntentControlService()

    assert (await service.resolve(session, "show incidents", source_agent="concierge")).decision == "route"
    assert (await service.resolve(session, "show incidents", source_agent="incident_agent")).decision == "route"
    assert (await service.resolve(session, "show incidents", source_agent="backup_agent")).decision == "no_match"


@pytest.mark.asyncio
async def test_export_version_includes_agent_access_scope():
    rule = _rule(allowed_source_agents_json=["concierge"])
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})

    exported = await IntentControlService().export_rules(session)

    assert '"version": 4' in exported
    assert '"allowed_source_agents_json": [' in exported
    assert '"concierge"' in exported


@pytest.mark.asyncio
async def test_shadow_rule_records_prediction_without_becoming_active():
    rule = _rule(enabled=False, shadow_mode=True)
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})

    await IntentControlService()._record_shadow_evaluations(
        session,
        "show open incidents",
        parameters={},
        confirmed=False,
        source_agent="concierge",
    )

    assert len(session.added) == 1
    observation = session.added[0]
    assert isinstance(observation, IntentShadowEvaluation)
    assert observation.predicted_decision == "route"
    assert observation.predicted_target_agent == "incident_agent"
    assert observation.query_hash


def test_conflict_detection_blocks_exact_cross_agent_overlap():
    first = _rule(id="one", name="incident.search", target_agent="incident_agent")
    second = _rule(
        id="two",
        name="incident.competing",
        target_agent="backup_agent",
        examples_json=["show open incidents"],
        enabled=True,
    )

    conflict = IntentAssuranceService.conflict_between(first, second)

    assert conflict is not None
    assert conflict.severity == "blocker"
    assert conflict.score >= 0.95


def test_regression_comparison_checks_decision_target_and_parameters():
    case = IntentRegressionCase(
        name="bounded read",
        query="show incidents limit 25",
        expected_decision="route",
        expected_target_agent="incident_agent",
        expected_parameters_json={"row_limit": 25},
    )
    decision = IntentDecision(
        decision="route",
        source_agent="concierge",
        target_agent="incident_agent",
        confidence=0.95,
        reason="matched",
        extracted_parameters={"row_limit": 25},
    )

    result = IntentAssuranceService.compare_case(case, decision)

    assert result.passed is True
    assert result.message == "Passed"


@pytest.mark.asyncio
async def test_readiness_blocks_a_failing_configured_regression():
    rule = _rule(
        enabled=False,
        allowed_tools_json=[],
        test_cases_json=[
            {
                "name": "must route",
                "query": "completely unrelated request",
                "expected_decision": "route",
                "expected_target_agent": "incident_agent",
            }
        ],
    )
    session = _FakeSession(
        [rule],
        {
            "concierge": _agent("concierge"),
            "incident_agent": _agent("incident_agent"),
        },
    )

    report = await IntentAssuranceService().readiness(
        session,
        rule,
        all_rules=[rule],
    )

    assert report.status == "blocked"
    assert report.ready_to_activate is False
    assert report.regression_results[0].passed is False
    assert any(check.code == "regression.failed" for check in report.checks)


def test_connection_ref_pins_exactly_one_registered_tool():
    inferred = IntentWorkflowStep(
        id="fetch",
        agent="backup_agent",
        tools=["fetch_backups"],
    )
    assert inferred.connection_ref == "fetch_backups"

    explicit = IntentWorkflowStep(
        id="fetch",
        agent="backup_agent",
        connection_ref="fetch_backups",
    )
    assert explicit.tools == ["fetch_backups"]

    with pytest.raises(ValidationError, match="connection_ref must be its only allowed tool"):
        IntentWorkflowStep(
            id="fetch",
            agent="backup_agent",
            tools=["fetch_backups", "other_tool"],
            connection_ref="fetch_backups",
        )


def test_schema_rejects_workflow_cycles_and_unknown_dependencies():
    with pytest.raises(ValidationError, match="unknown dependencies"):
        IntentRuleCreate(
            name="bad.workflow",
            keywords_json=["workflow"],
            target_agent="incident_agent",
            orchestration_mode="dag",
            workflow_json=[
                IntentWorkflowStep(
                    id="fetch",
                    agent="incident_agent",
                    depends_on=["missing"],
                )
            ],
        )

    with pytest.raises(ValidationError, match="contain a cycle"):
        IntentRuleCreate(
            name="cyclic.workflow",
            keywords_json=["workflow"],
            target_agent="incident_agent",
            orchestration_mode="dag",
            workflow_json=[
                IntentWorkflowStep(id="one", agent="incident_agent", depends_on=["two"]),
                IntentWorkflowStep(id="two", agent="report_agent", depends_on=["one"]),
            ],
        )


@pytest.mark.asyncio
async def test_multi_intent_resolution_builds_independent_workflow_snapshots():
    incident = _rule(
        id="incident",
        allow_multi_intent=True,
        max_intents=2,
        orchestration_mode="parallel",
        workflow_json=[
            {
                "id": "fetch",
                "agent": "incident_agent",
                "tools": ["fetch_incidents"],
            }
        ],
    )
    backup = _rule(
        id="backup",
        name="backup.search",
        target_agent="backup_agent",
        keywords_json=["backup"],
        examples_json=[],
        allowed_tools_json=["fetch_backups"],
        workflow_json=[
            {
                "id": "check",
                "agent": "backup_agent",
                "tools": ["fetch_backups"],
            }
        ],
    )
    session = _FakeSession(
        [incident, backup],
        {
            "incident_agent": _agent("incident_agent"),
            "backup_agent": _agent("backup_agent"),
        },
    )

    decision = await IntentControlService().resolve(
        session, "show incident and open incidents and backup status"
    )

    assert decision.decision == "route"
    assert decision.orchestration_mode == "multi"
    assert [item.intent_name for item in decision.selected_intents] == [
        "incident.search",
        "backup.search",
    ]
    assert decision.selected_intents[0].workflow_steps[0].tools == ["fetch_incidents"]
    assert decision.selected_intents[1].workflow_steps[0].agent == "backup_agent"
