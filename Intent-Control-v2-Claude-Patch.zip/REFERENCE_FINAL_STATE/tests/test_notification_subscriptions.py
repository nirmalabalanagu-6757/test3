"""Regression tests for notification subscription ownership."""

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from backend.models.notification import NotificationSubscription
from backend.routers import notifications
from backend.schemas.notification import SubscriptionCreate


@pytest.mark.asyncio
async def test_create_subscription_uses_stable_user_id(monkeypatch: pytest.MonkeyPatch) -> None:
    """Creation must use the same identity key as list, update, and delete."""
    subscription = NotificationSubscription(
        id="subscription-1",
        user_id="user-123",
        channel_type="dashboard",
        event_type="*",
        severity="*",
        enabled=True,
        created_at=datetime.now(UTC),
    )
    service = SimpleNamespace(subscribe=AsyncMock(return_value=subscription))
    monkeypatch.setattr(notifications, "_service", service)
    session = SimpleNamespace(commit=AsyncMock())
    user = SimpleNamespace(user_id="user-123", username="display-name")

    response = await notifications.create_subscription(
        SubscriptionCreate(channel_type="dashboard"),
        user=user,
        session=session,
    )

    service.subscribe.assert_awaited_once_with(
        session,
        user_id="user-123",
        channel_type="dashboard",
        event_type="*",
        severity="*",
    )
    session.commit.assert_awaited_once()
    assert response.user_id == "user-123"
