"""Runtime integration tests for agent-scoped Intent Control."""

from unittest.mock import AsyncMock

import pytest

from backend.schemas.intent import (
    IntentDecision,
    IntentExecutionOptions,
    ResolvedIntent,
    ResolvedWorkflowStep,
)
from backend.services.agent_runner import AgentRunnerService
from backend.services.intent_orchestrator import OrchestrationResult, intent_orchestrator


@pytest.mark.asyncio
async def test_specialized_entry_agent_checks_intent_before_llm(monkeypatch):
    runner = AgentRunnerService()
    resolved = ResolvedIntent(
        intent_id="backup-intent-id",
        intent_name="backup.status",
        confidence=0.95,
        orchestration_mode="single",
        workflow_version=1,
        workflow_steps=[ResolvedWorkflowStep(id="fetch", agent="backup_agent")],
        response_mode="direct",
        execution_options=IntentExecutionOptions(total_timeout_sec=10),
    )
    decision = IntentDecision(
        decision="route",
        source_agent="backup_agent",
        intent_id=resolved.intent_id,
        intent_name=resolved.intent_name,
        target_agent="backup_agent",
        confidence=resolved.confidence,
        reason="matched approved backup intent",
        selected_intents=[resolved],
    )
    resolve_intent = AsyncMock(return_value=decision)
    execute_intent = AsyncMock(
        return_value=OrchestrationResult(
            run_id="run-1",
            status="completed",
            response="backup is healthy",
            tools={"backup_agent": ["fetch_backups"]},
            model="action-template",
        )
    )
    monkeypatch.setattr(runner, "_resolve_controlled_intent", resolve_intent)
    monkeypatch.setattr(intent_orchestrator, "execute", execute_intent)

    response, tools, model = await runner.invoke_with_runner(
        agent_name="backup_agent",
        session_id="session-1",
        user_id="user-1",
        user_message="show backup status",
    )

    resolve_intent.assert_awaited_once_with(
        source_agent="backup_agent",
        session_id="session-1",
        user_id="user-1",
        user_message="show backup status",
    )
    execute_intent.assert_awaited_once()
    assert response == "backup is healthy"
    assert model == "action-template"
    assert tools["intent_control"] == ["backup.status", "run:run-1"]
