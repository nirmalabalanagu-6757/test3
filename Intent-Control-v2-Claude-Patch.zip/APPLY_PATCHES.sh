#!/usr/bin/env bash
set -Eeuo pipefail

if [[ "${1:-}" != "--confirm" || "$#" -ne 1 ]]; then
  echo "Usage (from target repository): bash /path/to/APPLY_PATCHES.sh --confirm"
  echo "Creates a backup branch and a new patch branch. No DB migration or deployment."
  echo "Divergent/Claude-merged targets must use the semantic integration guide."
  exit 2
fi
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[[ -n "$REPO_ROOT" ]] || { echo "ERROR: run from inside the target Git repository."; exit 1; }
cd "$REPO_ROOT"
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "ERROR: tracked changes exist. Preserve them before continuing."
  exit 1
fi
if [[ -d "$(git rev-parse --git-path rebase-apply)" || -d "$(git rev-parse --git-path rebase-merge)" ]]; then
  echo "ERROR: finish or deliberately abort the existing am/rebase operation first."
  exit 1
fi
mapfile -t PATCHES < <(find "$SCRIPT_DIR" -maxdepth 1 -type f -name '*.patch' -print | sort)
[[ "${#PATCHES[@]}" -eq 7 ]] || { echo "ERROR: expected exactly seven root patch files."; exit 1; }
ORIGINAL_HEAD="$(git rev-parse HEAD)"
# Recognized original source commits only. A semantic merge has a different hash.
case "$ORIGINAL_HEAD" in
  9f9f182f733a2b371630982771ed68d323b9cb15) NEXT=0 ;;
  51af8c5be49622c0fba07c36f71c8dcdf5627d4e) NEXT=1 ;;
  980417ba167296a64cfb26b8b3e17f0c641eeca1) NEXT=2 ;;
  8caa12160d30b46edd51dc2f7ffff7b9ba5ddfba) NEXT=3 ;;
  45d873ba63e9c5f671e3cb63fa761d2d41f78b2a) NEXT=4 ;;
  afc12a3d3ff31cdc5ce7b9a6f958f28e27298d4a) NEXT=5 ;;
  9b49179667055e6ea603d515ac1678c514fa266a) NEXT=6 ;;
  c2c58699c39a5a5263ead65398caac8b37a1df38) echo "Latest source update already present."; exit 0 ;;
  *) echo "STOP: this is not a recognized exact source revision."
     echo "Use CLAUDE_SONNET_4_6_PROMPT.txt to integrate missing behavior semantically."
     exit 1 ;;
esac
ORIGINAL_BRANCH="$(git symbolic-ref --quiet --short HEAD || true)"
STAMP="$(date +%Y%m%d%H%M%S)-$$"
BACKUP_BRANCH="backup/intent-control-v2-$STAMP"
PATCH_BRANCH="codex/intent-control-v2-claude-$STAMP"
git branch "$BACKUP_BRANCH" "$ORIGINAL_HEAD"
git switch -c "$PATCH_BRANCH"
echo "Original branch: ${ORIGINAL_BRANCH:-detached-head}"
echo "Original commit: $ORIGINAL_HEAD"
echo "Backup branch: $BACKUP_BRANCH"
echo "Patch branch: $PATCH_BRANCH"
for ((i=NEXT; i<${#PATCHES[@]}; i++)); do
  echo "Applying $(basename "${PATCHES[i]}")"
  if ! git am --3way "${PATCHES[i]}"; then
    echo "STOP: patch conflict. No automatic rollback, force-apply or reset performed."
    echo "Inspect status, then run 'git am --abort' to leave this failed am operation."
    echo "Use the Claude guide for semantic integration. Backup: $BACKUP_BRANCH"
    exit 1
  fi
done
echo "Source patches applied. NOT yet migrated, deployed or verified."
echo "Run: bash \"$SCRIPT_DIR/VERIFY_PATCH.sh\""
echo "Before source merge, return with: git switch \"$BACKUP_BRANCH\""
echo "For deployed rollback, read ROLLBACK-GUIDE.md first (new bindings need review)."
