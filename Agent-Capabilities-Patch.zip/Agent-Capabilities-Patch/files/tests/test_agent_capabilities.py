"""Offline tests: real relational queries in SQLite, no app database or paid APIs."""

import httpx
import pytest
from fastapi import FastAPI, HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from backend.database import get_session
from backend.middleware.auth import get_current_user
from backend.models.agent import AgentRegistry
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.models.user import User
from backend.routers.agent_capabilities import router
from backend.services.agent_capabilities import (
    AgentCapabilitiesNotFoundError,
    capability_for_tool,
    get_agent_capabilities,
    public_text,
)


@pytest.fixture
def db():
    engine = create_engine("sqlite://")
    for table in (AgentRegistry.__table__, ToolRegistry.__table__, ToolAgentAssignment.__table__):
        table.create(engine)
    with Session(engine) as session:
        session.add(AgentRegistry(
            name="backup", display_name="Backup Agent", product="ops", agent_type="specialized",
            lifecycle_status="running", instruction="PRIVATE SYSTEM INSTRUCTION",
        ))
        session.add(AgentRegistry(name="backup_agent", product="ops", agent_type="specialized"))
        session.flush()

        class Adapter:
            calls = 0

            async def get(self, model, key):
                self.calls += 1
                return session.get(model, key)

            async def execute(self, statement):
                self.calls += 1
                return session.execute(statement)

        yield session, Adapter()
    engine.dispose()


def user(role="user", active=True):
    return User(user_id="tester", username="tester", role=role, active=active)


def tool(name="backup_lookup", **kwargs):
    values = dict(
        name=name, description="Check backup status for an application or server.",
        tool_type="api_connector", lifecycle_status="active", risk_classification="read_only",
        input_schema_json={},
    )
    values.update(kwargs)
    return ToolRegistry(**values)


def assign(session, item, agent="backup"):
    session.add(item)
    session.flush()
    session.add(ToolAgentAssignment(tool_name=item.name, agent_name=agent))
    session.flush()


@pytest.mark.parametrize("tool_type", ["function", "mcp", "api_connector"])
async def test_universal_tools_are_projected_without_invocation(db, tool_type):
    session, adapter = db
    item = tool(tool_type=tool_type)
    assign(session, item)
    result = await get_agent_capabilities(adapter, "backup", user())
    assert result.display_name == "Backup Agent"
    assert result.capabilities[0].title.startswith("Check backup status")
    assert result.capabilities[0].kind == "read"
    assert adapter.calls == 2
    assert item.last_invocation_at is None
    assert not session.dirty


async def test_query_excludes_unassigned_disabled_and_deduplicates_aliases(db):
    session, adapter = db
    assign(session, tool("active"))
    session.add(ToolAgentAssignment(tool_name="active", agent_name="backup_agent"))
    assign(session, tool("disabled", lifecycle_status="disabled"))
    assign(session, tool("pending", lifecycle_status="pending_approval"))
    session.add(tool("unassigned"))
    session.flush()
    result = await get_agent_capabilities(adapter, "backup", user())
    assert [card.tool_name for card in result.capabilities] == ["active"]
    session.get(ToolRegistry, "active").lifecycle_status = "disabled"
    session.flush()
    assert not (await get_agent_capabilities(adapter, "backup", user())).capabilities


async def test_no_invented_capabilities_or_instruction_disclosure(db):
    _, adapter = db
    result = await get_agent_capabilities(adapter, "backup", user())
    assert not result.capabilities
    assert "No active tool capabilities" in result.notice
    assert "PRIVATE" not in result.model_dump_json()


@pytest.mark.parametrize("status", ["registered", "starting", "stopped", "degraded"])
async def test_unavailable_agents_do_not_advertise_tools(db, status):
    session, adapter = db
    session.get(AgentRegistry, "backup").lifecycle_status = status
    assign(session, tool())
    result = await get_agent_capabilities(adapter, "backup", user())
    assert not result.available and not result.capabilities
    assert adapter.calls == 1


async def test_missing_and_deregistered_agents(db):
    session, adapter = db
    with pytest.raises(AgentCapabilitiesNotFoundError):
        await get_agent_capabilities(adapter, "missing", user())
    session.get(AgentRegistry, "backup").lifecycle_status = "deregistered"
    with pytest.raises(AgentCapabilitiesNotFoundError):
        await get_agent_capabilities(adapter, "backup", user())


def test_explicit_public_copy_examples_and_risk():
    item = tool(risk_classification="execute", input_schema_json={"x-agent-capability": {
        "title": "Launch approved maintenance jobs", "summary": "Run approved automation for selected hosts.",
        "examples": ["Prepare a maintenance job for my selected hosts.", "Prepare a maintenance job for my selected hosts."],
    }})
    card = capability_for_tool(item, user())
    assert card.kind == "action"
    assert card.title == "Launch approved maintenance jobs"
    assert len(card.examples) == 1


@pytest.mark.parametrize("metadata", [None, [], {"visible": False}, {"visible": "true"},
    {"allowed_roles": "user"}, {"allowed_roles": []}, {"allowed_roles": [12]}])
def test_invalid_or_hidden_metadata_fails_closed(metadata):
    assert capability_for_tool(tool(input_schema_json={"x-agent-capability": metadata}), user()) is None


def test_role_visibility_and_inactive_user():
    item = tool(input_schema_json={"x-agent-capability": {"allowed_roles": ["admin"]}})
    assert capability_for_tool(item, user()) is None
    assert capability_for_tool(item, user("admin")) is not None
    assert capability_for_tool(item, user("admin", False)) is None


def test_private_configuration_never_serialized():
    item = tool(
        credential_encrypted="PRIVATE-CREDENTIAL", api_endpoint="https://private.example",
        extra_headers_json='{"Authorization":"PRIVATE-HEADER"}',
        request_template_json={"password": "PRIVATE-PASSWORD"},
        detail_description="PRIVATE-INTERNAL-DOC",
        input_schema_json={"properties": {"password": {"default": "PRIVATE-DEFAULT"}}},
    )
    body = capability_for_tool(item, user()).model_dump_json()
    assert "PRIVATE" not in body and "private.example" not in body


@pytest.mark.parametrize("text", ["Bearer abc.def", "api_key=abc", "password: abc", "token=abc",
    "https://internal.example", "<script>alert(1)</script>", "-----BEGIN PRIVATE KEY-----"])
def test_public_text_rejects_obvious_secrets_and_markup(text):
    assert public_text(text) == ""


def test_bounded_plain_text_and_fallback():
    card = capability_for_tool(tool(description=None, risk_classification="unexpected"), user())
    assert card.title == "Use backup lookup" and card.kind == "unknown"
    assert len(public_text("word " * 1000)) <= 320


async def test_endpoint_contract_authentication_and_no_store(db):
    session, adapter = db
    assign(session, tool())
    app = FastAPI()
    app.include_router(router)
    app.dependency_overrides[get_session] = lambda: adapter
    app.dependency_overrides[get_current_user] = lambda: user()
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/api/agents/backup/capabilities")
        assert response.status_code == 200
        assert response.headers["cache-control"] == "private, no-store"
        assert "Cookie" in response.headers["vary"]
        assert response.json()["capabilities"][0]["tool_name"] == "backup_lookup"
        assert (await client.get("/api/agents/missing/capabilities")).status_code == 404
        app.dependency_overrides[get_current_user] = lambda: user(active=False)
        assert (await client.get("/api/agents/backup/capabilities")).status_code == 403

        def unauthenticated():
            raise HTTPException(401, "Authentication required")

        app.dependency_overrides[get_current_user] = unauthenticated
        assert (await client.get("/api/agents/backup/capabilities")).status_code == 401
