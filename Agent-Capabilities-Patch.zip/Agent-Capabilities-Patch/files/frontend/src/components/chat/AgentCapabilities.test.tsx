import { act } from "react";
import { createRoot } from "react-dom/client";
import type { Root } from "react-dom/client";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { apiGet } from "../../api/client";
import AgentCapabilities from "./AgentCapabilities";
import ChatInterface from "./ChatInterface";

const sockets = vi.hoisted(() => ({ send: vi.fn(), disconnect: vi.fn() }));
vi.mock("../../api/client", () => ({ apiGet: vi.fn() }));
vi.mock("../../api/websocket", () => ({
  buildWSUrl: (path: string) => path,
  WSClient: class {
    options: { onOpen: () => void };
    constructor(options: { onOpen: () => void }) { this.options = options; }
    connect() { this.options.onOpen(); }
    disconnect() { sockets.disconnect(); }
    send(data: unknown) { sockets.send(data); }
  },
}));

let root: Root;
let container: HTMLDivElement;
const choose = vi.fn();
const payload = (agent = "backup", count = 1) => ({
  agent_name: agent, display_name: `${agent} agent`, available: true, notice: "Configured active tools.",
  capabilities: Array.from({ length: count }, (_, i) => ({
    tool_name: `tool_${i}`, title: `${agent} capability ${i}`, summary: "Check configured records.",
    kind: i ? "action" : "read", examples: [`Show ${agent} records ${i}`],
  })),
});

beforeEach(() => {
  vi.useFakeTimers();
  vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true);
  Element.prototype.scrollIntoView = vi.fn();
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
  vi.mocked(apiGet).mockResolvedValue(payload());
});
afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.resetAllMocks();
});
async function render(agent = "backup", disabled = false) {
  await act(async () => root.render(<AgentCapabilities agentName={agent} onChooseExample={choose} disabled={disabled} />));
}

it("automatically displays capabilities on selection without a prompt", async () => {
  await render();
  expect(apiGet).toHaveBeenCalledWith("/agents/backup/capabilities");
  expect(container.textContent).toContain("What backup agent can help you with");
  expect(container.textContent).toContain("View information");
  expect(choose).not.toHaveBeenCalled();
});

it("shows more than four tools on demand and labels actions", async () => {
  vi.mocked(apiGet).mockResolvedValue(payload("backup", 20));
  await render();
  expect(container.querySelectorAll("li")).toHaveLength(4);
  const more = [...container.querySelectorAll("button")].find(b => b.textContent === "Show all 20 capabilities")!;
  await act(async () => more.click());
  expect(container.querySelectorAll("li")).toHaveLength(20);
  expect(container.textContent).toContain("Can change systems");
});

it("clicking an example only fills ChatInterface input; it never sends or executes", async () => {
  await act(async () => root.render(<ChatInterface agentName="backup" />));
  await act(async () => container.querySelector<HTMLButtonElement>('button[aria-label^="Draft example"]')!.click());
  expect(container.querySelector("textarea")!.value).toBe("Show backup records 0");
  expect(sockets.send).not.toHaveBeenCalled();
  expect(container.querySelectorAll(".chat-markdown")).toHaveLength(0);
  await act(async () => container.querySelector<HTMLButtonElement>('button[title="Send message"]')!.click());
  expect(sockets.send).toHaveBeenCalledTimes(1);
  expect(sockets.send).toHaveBeenCalledWith({ content: "Show backup records 0" });
});

it("does not let example clicks overwrite a pending request", async () => {
  await render("backup", true);
  expect(container.querySelector<HTMLButtonElement>('button[aria-label^="Draft example"]')!.disabled).toBe(true);
});

it("clears old capabilities and ignores a late response after switching agent", async () => {
  let finish!: (value: ReturnType<typeof payload>) => void;
  vi.mocked(apiGet).mockImplementationOnce(() => new Promise(resolve => { finish = resolve; }));
  await render("backup");
  vi.mocked(apiGet).mockResolvedValue(payload("incident"));
  await render("incident");
  await act(async () => finish(payload("backup")));
  expect(container.textContent).toContain("incident capability");
  expect(container.textContent).not.toContain("backup capability");
});

it("refreshes assignment changes and hides stale cards on failure", async () => {
  await render();
  vi.mocked(apiGet).mockResolvedValue({ ...payload(), capabilities: [], notice: "No active tools." });
  await act(async () => vi.advanceTimersByTimeAsync(60_000));
  expect(container.textContent).toContain("No active tools.");
  expect(container.querySelectorAll("li")).toHaveLength(0);
  vi.mocked(apiGet).mockRejectedValue(new Error("403"));
  await act(async () => window.dispatchEvent(new Event("focus")));
  expect(container.textContent).toContain("Capabilities could not be loaded");
  expect(container.textContent).not.toContain("No active tools.");
});

it("handles unavailable agents and retries without fabricating capabilities", async () => {
  vi.mocked(apiGet).mockRejectedValue(new Error("offline"));
  await render();
  expect(container.querySelectorAll("li")).toHaveLength(0);
  vi.mocked(apiGet).mockResolvedValue({ ...payload(), available: false, notice: "Agent is stopped." });
  await act(async () => container.querySelector<HTMLButtonElement>("button")!.click());
  expect(container.textContent).toContain("Agent is stopped.");
  expect(container.querySelectorAll("li")).toHaveLength(0);
});

it("renders metadata as text rather than HTML and stops background refresh on unmount", async () => {
  const result = payload();
  result.capabilities[0].title = "<img src=x onerror=alert(1)>";
  vi.mocked(apiGet).mockResolvedValue(result);
  await render();
  expect(container.querySelector("img")).toBeNull();
  await act(async () => root.render(null));
  const count = vi.mocked(apiGet).mock.calls.length;
  await act(async () => vi.advanceTimersByTimeAsync(120_000));
  expect(apiGet).toHaveBeenCalledTimes(count);
});
