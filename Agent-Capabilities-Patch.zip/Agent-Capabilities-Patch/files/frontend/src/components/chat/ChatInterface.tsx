import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { WSClient, buildWSUrl } from "../../api/websocket";
import AgentCapabilities from "./AgentCapabilities";

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp?: string;
  session_id?: string;
  contributing_agents?: Record<string, string[]>;
  model_name?: string;
  model_settings?: Record<string, unknown>;
}

interface ChatResponse {
  type: string;
  agent_name: string;
  session_id: string;
  content: string;
  turn_index: number;
  timestamp: string;
  contributing_agents?: Record<string, string[]>;
  model_name?: string;
  model_settings?: Record<string, unknown>;
  context_used_tokens?: number;
  context_window_tokens?: number;
}

interface AgentOption {
  value: string;
  label: string;
}

interface ChatInterfaceProps {
  agentName: string;
  agentOptions?: AgentOption[];
  onAgentChange?: (name: string) => void;
}

function MessageInfoTooltip({
  modelName,
  modelSettings,
  contributingAgents,
}: {
  modelName?: string;
  modelSettings?: Record<string, unknown>;
  contributingAgents?: Record<string, string[]>;
}) {
  const [visible, setVisible] = useState(false);

  const reasoning = modelSettings?.reasoning as Record<string, unknown> | undefined;

  return (
    <span
      style={{ position: "absolute", bottom: 4, right: 4 }}
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
    >
      <span
        style={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          width: 16,
          height: 16,
          borderRadius: "50%",
          fontSize: "0.55rem",
          fontWeight: 700,
          background: "var(--color-surface)",
          color: "var(--color-text-muted)",
          border: "1px solid var(--color-text-muted)",
          cursor: "default",
          lineHeight: 1,
          opacity: 0.6,
          userSelect: "none",
        }}
      >
        ?
      </span>
      {visible && (
        <div
          style={{
            position: "absolute",
            bottom: "calc(100% + 6px)",
            right: 0,
            width: 260,
            padding: "0.625rem 0.75rem",
            borderRadius: "0.5rem",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
            fontSize: "0.7rem",
            lineHeight: 1.5,
            color: "var(--color-text)",
            zIndex: 200,
            textAlign: "left",
          }}
        >
          {modelName && (
            <div style={{ marginBottom: "0.375rem" }}>
              <span style={{ fontWeight: 600 }}>Model: </span>
              {modelName}
            </div>
          )}
          {modelSettings && Object.keys(modelSettings).length > 0 && (
            <div style={{ marginBottom: "0.375rem" }}>
              <span style={{ fontWeight: 600 }}>Settings: </span>
              {modelSettings.temperature != null && (
                <span>temp {String(modelSettings.temperature)}</span>
              )}
              {modelSettings.max_output_tokens != null && (
                <span>{modelSettings.temperature != null ? ", " : ""}max {String(modelSettings.max_output_tokens)} tokens</span>
              )}
              {reasoning && (
                <span>
                  {(modelSettings.temperature != null || modelSettings.max_output_tokens != null) ? ", " : ""}
                  reasoning {reasoning.enabled ? "on" : "off"}
                  {reasoning.enabled && reasoning.budget_tokens ? ` (${String(reasoning.budget_tokens)} budget)` : ""}
                </span>
              )}
              {modelSettings.allow_world_knowledge != null && (
                <span>
                  {(modelSettings.temperature != null || modelSettings.max_output_tokens != null || reasoning) ? ", " : ""}
                  world knowledge {modelSettings.allow_world_knowledge ? "on" : "off"}
                </span>
              )}
            </div>
          )}
          {contributingAgents && Object.keys(contributingAgents).length > 0 && (
            <div>
              <span style={{ fontWeight: 600 }}>Agents: </span>
              {Object.entries(contributingAgents)
                .map(([agent, tools]) =>
                  tools.length > 0 ? `${agent} (${tools.join(", ")})` : agent
                )
                .join(", ")}
            </div>
          )}
        </div>
      )}
    </span>
  );
}

function ChatInterface({ agentName, agentOptions, onAgentChange }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [connected, setConnected] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [contextUsed, setContextUsed] = useState<number | null>(null);
  const [contextWindow, setContextWindow] = useState<number | null>(null);
  const wsRef = useRef<WSClient | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, waiting, scrollToBottom]);

  useEffect(() => {
    const ws = new WSClient({
      url: buildWSUrl(`/api/chat/${agentName}`),
      onMessage: (data) => {
        const response = data as ChatResponse;
        if (response.session_id) {
          setSessionId(response.session_id);
        }
        if (response.context_used_tokens != null) {
          setContextUsed(response.context_used_tokens);
        }
        if (response.context_window_tokens != null) {
          setContextWindow(response.context_window_tokens);
        }
        const msg: ChatMessage = {
          role: "assistant",
          content: response.content,
          timestamp: response.timestamp,
          session_id: response.session_id,
          contributing_agents: response.contributing_agents,
          model_name: response.model_name,
          model_settings: response.model_settings,
        };
        setMessages((prev) => [...prev, msg]);
        setWaiting(false);
      },
      onOpen: () => setConnected(true),
      onClose: () => { setConnected(false); setWaiting(false); },
    });
    ws.connect();
    wsRef.current = ws;

    return () => {
      ws.disconnect();
    };
  }, [agentName]);

  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed || !connected) return;

    const userMsg: ChatMessage = {
      role: "user",
      content: trimmed,
      timestamp: new Date().toISOString(),
      session_id: sessionId ?? undefined,
    };
    setMessages((prev) => [...prev, userMsg]);
    setWaiting(true);
    wsRef.current?.send({
      content: trimmed,
      ...(sessionId && { session_id: sessionId }),
    });
    setInput("");
  };

  const handleClear = () => {
    setMessages([]);
    setSessionId(null);
    setContextUsed(null);
    setContextWindow(null);
    setWaiting(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const hasRealData = contextUsed != null && contextWindow != null && contextWindow > 0;

  const contextPercent = useMemo(() => {
    if (hasRealData) {
      return Math.min(Math.round((contextUsed / contextWindow) * 100), 100);
    }
    const totalChars = messages.reduce((sum, m) => sum + m.content.length, 0);
    const estimatedTokens = totalChars / 4;
    return Math.min(Math.round((estimatedTokens / 128_000) * 100), 100);
  }, [hasRealData, contextUsed, contextWindow, messages]);

  const contextColor = contextPercent < 50
    ? "var(--color-success, #22c55e)"
    : contextPercent < 80
      ? "var(--color-warning, #f59e0b)"
      : "var(--color-danger, #ef4444)";

  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div
        style={{
          flex: 1,
          overflowY: "auto",
          background: "var(--color-surface)",
          borderRadius: "0.5rem",
          padding: "1rem",
          border: "1px solid var(--color-border)",
        }}
      >
        <AgentCapabilities
          key={agentName}
          agentName={agentName}
          onChooseExample={setInput}
          disabled={waiting}
        />
        {messages.map((msg, i) => (
          <div
            key={`${msg.role}-${msg.timestamp ?? i}-${i}`}
            style={{
              marginBottom: "0.75rem",
              textAlign: msg.role === "user" ? "right" : "left",
            }}
          >
            {msg.role === "user" ? (
              <span
                style={{
                  display: "inline-block",
                  padding: "0.5rem 0.75rem",
                  borderRadius: "0.5rem",
                  background: "var(--color-primary)",
                  color: "var(--color-on-primary)",
                  maxWidth: "80%",
                  textAlign: "left",
                  whiteSpace: "pre-wrap",
                }}
              >
                {msg.content}
              </span>
            ) : (
              <div
                className="chat-markdown"
                style={{
                  display: "inline-block",
                  padding: "0.5rem 0.75rem",
                  borderRadius: "0.5rem",
                  background: "var(--color-border)",
                  color: "var(--color-text)",
                  maxWidth: "80%",
                  textAlign: "left",
                  position: "relative",
                }}
              >
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {msg.content}
                </ReactMarkdown>
                {(msg.model_name || (msg.contributing_agents && Object.keys(msg.contributing_agents).length > 0)) && (
                  <MessageInfoTooltip
                    modelName={msg.model_name}
                    modelSettings={msg.model_settings}
                    contributingAgents={msg.contributing_agents}
                  />
                )}
              </div>
            )}
          </div>
        ))}
        {waiting && (
          <div style={{ marginBottom: "0.75rem", textAlign: "left" }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "4px",
                padding: "0.625rem 0.875rem",
                borderRadius: "0.5rem",
                background: "var(--color-border)",
              }}
            >
              <span className="typing-dot" style={{ animationDelay: "0s" }} />
              <span className="typing-dot" style={{ animationDelay: "0.15s" }} />
              <span className="typing-dot" style={{ animationDelay: "0.3s" }} />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div style={{ display: "flex", alignItems: "stretch", gap: "0.5rem", marginTop: "0.75rem" }}>
        {agentOptions && onAgentChange && (
          <select
            value={agentName}
            onChange={(e) => onAgentChange(e.target.value)}
            style={{
              padding: "0 0.625rem",
              borderRadius: "0.5rem",
              border: "1px solid var(--color-border)",
              background: "var(--color-surface)",
              color: "var(--color-text)",
              fontSize: "0.875rem",
              minWidth: "140px",
            }}
          >
            {agentOptions.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        )}
        <div
          style={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            borderRadius: "0.5rem",
            border: "1px solid var(--color-border)",
            background: "var(--color-surface)",
            padding: "0 0.375rem 0 0",
          }}
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={connected ? "Type a message..." : "Connecting..."}
            disabled={!connected}
            rows={1}
            style={{
              flex: 1,
              padding: "0.625rem 0.75rem",
              border: "none",
              background: "transparent",
              color: "var(--color-text)",
              resize: "none",
              fontFamily: "inherit",
              fontSize: "0.875rem",
              outline: "none",
            }}
          />
          <button
            onClick={handleSend}
            disabled={!connected || !input.trim()}
            title="Send message"
            style={{
              width: "2rem",
              height: "2rem",
              borderRadius: "0.375rem",
              border: "none",
              background: !connected || !input.trim() ? "transparent" : "var(--color-primary)",
              color: !connected || !input.trim() ? "var(--color-text-muted)" : "var(--color-on-primary)",
              cursor: !connected || !input.trim() ? "default" : "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              opacity: !connected || !input.trim() ? 0.4 : 1,
              transition: "background 0.15s, opacity 0.15s",
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 2 11 13" />
              <path d="M22 2 15 22 11 13 2 9z" />
            </svg>
          </button>
        </div>
        <div
          style={{ position: "relative", display: "flex", alignItems: "center" }}
          onMouseEnter={() => setShowTooltip(true)}
          onMouseLeave={() => setShowTooltip(false)}
        >
          <button
            onClick={handleClear}
            disabled={messages.length === 0}
            title=""
            style={{
              width: "2.5rem",
              height: "2.5rem",
              borderRadius: "50%",
              border: `2px solid ${messages.length === 0 ? "var(--color-border)" : contextColor}`,
              background: "var(--color-surface)",
              cursor: messages.length === 0 ? "default" : "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              position: "relative",
              opacity: messages.length === 0 ? 0.5 : 1,
              transition: "border-color 0.3s, opacity 0.15s",
            }}
          >
            <svg width="40" height="40" viewBox="0 0 40 40" style={{ position: "absolute", top: -2, left: -2 }}>
              <circle
                cx="20" cy="20" r="17"
                fill="none"
                stroke="var(--color-border)"
                strokeWidth="3"
                opacity="0.2"
              />
              {contextPercent > 0 && (
                <circle
                  cx="20" cy="20" r="17"
                  fill="none"
                  stroke={contextColor}
                  strokeWidth="3"
                  strokeDasharray={`${(contextPercent / 100) * 106.8} 106.8`}
                  strokeLinecap="round"
                  transform="rotate(-90 20 20)"
                  style={{ transition: "stroke-dasharray 0.3s, stroke 0.3s" }}
                />
              )}
            </svg>
            <span style={{
              fontSize: "0.6rem",
              fontWeight: 600,
              color: messages.length === 0 ? "var(--color-text-muted)" : contextColor,
              zIndex: 1,
              lineHeight: 1,
              transition: "color 0.3s",
            }}>
              {contextPercent}%
            </span>
          </button>
          {showTooltip && (
            <div style={{
              position: "absolute",
              bottom: "calc(100% + 8px)",
              right: 0,
              width: "280px",
              padding: "0.75rem",
              borderRadius: "0.5rem",
              background: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
              fontSize: "0.75rem",
              lineHeight: 1.5,
              color: "var(--color-text)",
              zIndex: 100,
            }}>
              <div style={{ fontWeight: 600, marginBottom: "0.375rem" }}>
                Context Window Usage: {hasRealData ? "" : "~"}{contextPercent}%
                {hasRealData && (
                  <span style={{ fontWeight: 400, fontSize: "0.7rem", color: "var(--color-text-muted)", marginLeft: "0.25rem" }}>
                    ({(contextUsed).toLocaleString()} / {(contextWindow).toLocaleString()} tokens)
                  </span>
                )}
              </div>
              <div style={{ color: "var(--color-text-muted)" }}>
                The context window is the amount of conversation history the AI can process at once. As it fills up, the agent may lose track of earlier messages and produce less accurate responses.
              </div>
              <div style={{ marginTop: "0.375rem", color: "var(--color-text-muted)" }}>
                {contextPercent < 50
                  ? "Plenty of room. No action needed."
                  : contextPercent < 80
                    ? "Getting full. Consider resetting soon if the conversation drifts."
                    : "Nearly full. Reset recommended to maintain response quality."}
              </div>
              <div style={{
                marginTop: "0.5rem",
                paddingTop: "0.375rem",
                borderTop: "1px solid var(--color-border)",
                fontWeight: 500,
              }}>
                Click to reset the conversation.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ChatInterface;
