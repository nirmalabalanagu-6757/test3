"""Capability discovery: authenticated, read-only, independent of model/SSO provider."""

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import get_current_user
from backend.models.user import User
from backend.schemas.agent_capabilities import AgentCapabilitiesResponse
from backend.services.agent_capabilities import AgentCapabilitiesNotFoundError, get_agent_capabilities

router = APIRouter(prefix="/api/agents", tags=["agents"])


@router.get("/{name}/capabilities", response_model=AgentCapabilitiesResponse)
async def agent_capabilities(
    name: str,
    response: Response,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(get_current_user),
) -> AgentCapabilitiesResponse:
    response.headers["Cache-Control"] = "private, no-store"
    response.headers["Vary"] = "Authorization, Cookie"
    if not user.active:
        raise HTTPException(status_code=403, detail="Account is inactive")
    try:
        return await get_agent_capabilities(session, name, user)
    except AgentCapabilitiesNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Agent not found") from exc
