"""Read-only capability projection from active, assigned tool metadata.

No LLM, tool invocation, credential decryption, session creation or schema migration.
An optional input-schema extension, x-agent-capability, supplies public wording.
Its allowed_roles controls *visibility only*, never execution authorization.
Deployments with additional per-user tool ACLs must apply the same ACL here.
"""

import re

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import AgentRegistry
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.models.user import User
from backend.schemas.agent_capabilities import AgentCapability, AgentCapabilitiesResponse


class AgentCapabilitiesNotFoundError(Exception):
    pass


def public_text(value: object, limit: int = 320) -> str:
    """Plain, bounded public copy; reject obvious credentials and executable markup.

This is defense in depth, not a DLP guarantee. Administrators must only enter
public-facing text in descriptions and the capability metadata extension.
"""
    if not isinstance(value, str):
        return ""
    if re.search(
        r"(?i)bearer\s+\S+|(?:password|api[_ -]?key|token|secret)\s*[:=]|"
        r"https?://|-----BEGIN |<[^>]+>|[A-Za-z0-9_-]{48,}", value
    ):
        return ""
    return " ".join(value.split())[:limit].strip()


def capability_for_tool(tool: ToolRegistry, user: User) -> AgentCapability | None:
    if not user.active or tool.lifecycle_status != "active":
        return None
    schema = tool.input_schema_json if isinstance(tool.input_schema_json, dict) else {}
    metadata = schema.get("x-agent-capability", {})
    # Malformed visibility metadata must not broaden access.
    if not isinstance(metadata, dict) or metadata.get("visible", True) is not True:
        return None
    roles = metadata.get("allowed_roles")
    if "allowed_roles" in metadata and (
        not isinstance(roles, list)
        or not all(isinstance(role, str) for role in roles)
        or user.role not in roles
    ):
        return None

    # Never use system instructions, raw input defaults, request templates,
    # detailed docstrings, endpoint URLs or decrypted credentials as public copy.
    description = public_text(tool.description)
    title = public_text(metadata.get("title"), 120)
    if not title:
        title = (description.split("\n", 1)[0][:120] if description else
                 "Use " + public_text(tool.name.replace("_", " ").replace("-", " "), 100))
    summary = public_text(metadata.get("summary")) or description or "An assigned tool is available for this agent."
    kind = {"read_only": "read", "write": "action", "execute": "action"}.get(
        tool.risk_classification, "unknown"
    )
    supplied = metadata.get("examples", [])
    examples = []
    if isinstance(supplied, list):
        for example in supplied[:3]:
            cleaned = public_text(example, 240)
            if cleaned and cleaned not in examples:
                examples.append(cleaned)
    if not examples:
        # Safe generic starter: does not invent entities, parameter values,
        # job support, dry-run availability or successful operation outcomes.
        examples = [f"I need help with: {title.rstrip('.')}."]
    return AgentCapability(
        tool_name=tool.name, title=title, summary=summary, kind=kind, examples=examples
    )


async def get_agent_capabilities(
    session: AsyncSession, agent_name: str, user: User
) -> AgentCapabilitiesResponse:
    agent = await session.get(AgentRegistry, agent_name)
    if agent is None or agent.lifecycle_status == "deregistered":
        raise AgentCapabilitiesNotFoundError(agent_name)
    display_name = public_text(agent.display_name, 128) or agent.name
    if not user.active or agent.lifecycle_status != "running":
        return AgentCapabilitiesResponse(
            agent_name=agent.name, display_name=display_name, available=False,
            notice="This agent is not currently available. Capabilities will appear when it is running.",
        )

    # Match the names supported by the runtime's active-tool loader. Reading
    # authorization through check_tool_authorized would update invocation time;
    # this projection deliberately performs only two read-only DB operations.
    candidates = {agent.name, agent.name.replace("-", "_")}
    if not agent.name.endswith("_agent"):
        candidates.add(f"{agent.name}_agent")
    result = await session.execute(
        select(ToolRegistry)
        .join(ToolAgentAssignment, ToolAgentAssignment.tool_name == ToolRegistry.name)
        .where(
            ToolAgentAssignment.agent_name.in_(candidates),
            ToolRegistry.lifecycle_status == "active",
        )
        .order_by(ToolRegistry.name)
    )
    cards = []
    for tool in result.scalars().unique().all():
        card = capability_for_tool(tool, user)
        if card is not None:
            cards.append(card)
    notice = (
        "Based on active tool assignments. Availability and execution permissions are checked when you make a request."
        if cards else "No active tool capabilities are available to display for this agent and your account."
    )
    return AgentCapabilitiesResponse(
        agent_name=agent.name, display_name=display_name, available=True,
        capabilities=cards, notice=notice,
    )
