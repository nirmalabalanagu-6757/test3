"""Public, model-independent capability cards. Never include connector secrets."""

from pydantic import BaseModel, Field


class AgentCapability(BaseModel):
    tool_name: str
    title: str
    summary: str
    kind: str  # read | action | unknown; classification is not execution authorization
    examples: list[str] = Field(default_factory=list)


class AgentCapabilitiesResponse(BaseModel):
    agent_name: str
    display_name: str
    available: bool
    capabilities: list[AgentCapability] = Field(default_factory=list)
    notice: str
