#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
target="${1:?Usage: bash apply.sh /path/to/application-repository}"
git -C "$target" apply --check "$package_dir/changes.patch"
git -C "$target" apply "$package_dir/changes.patch"
echo 'Source patch applied. Run tests, rebuild frontend, and deploy/restart through your existing process.'
