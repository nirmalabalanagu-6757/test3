# Claude Sonnet 4.6 / any coding model — semantic merge contract

Read this package as proposed application code, not authorization to change deployment, SSO or credentials. Inspect the target repository before editing. Do not claim a successful merge or tests without executing and reporting them.

## Before / after

Before: agent selection has a generic empty-chat prompt; tool metadata is not projected into a capability panel. After: selecting an agent automatically retrieves a read-only capability description and displays business outcomes plus draft examples. Existing chat execution is unchanged.

## Required integration

1. Inspect agent/tool/assignment/user model names, lifecycle values and runtime alias resolution. Adapt imports and queries to the actual target, not invented schema. No migration is required for the provided source; optional metadata uses existing input_schema_json.
2. Add the three new backend modules. Reuse the target's existing authenticated current-user and request-scoped database-session dependencies. Never copy authentication bypasses. Preserve tenant and user ACLs; this baseline has assignment/lifecycle checks and optional display-role filtering only. If stronger target ACLs exist, reuse their read-only policy evaluation before returning a card.
3. Confirm the router is registered once: this source auto-discovers backend.routers modules. If the target uses explicit registrations, add one include_router entry without replacing main.py.
4. Add the React component and CSS. Use the target's authenticated API client. Merge only the import and panel placement into ChatInterface; do not overwrite its SSO, message handling, streaming or existing enhancements. onChooseExample sets the draft input only. Disabled state follows existing waiting state.
5. Preserve agent switching, empty state, failures, stale-request protection, polling cleanup and safe plain-text rendering. Do not send panel text into model history. Do not call tools, decrypt secrets, create extra database sessions or call an LLM while displaying capabilities.
6. Add/adapt both test files. Execute focused tests, full frontend tests and production build. Add target-specific permission tests if adapting permissions. Report failed/skipped checks and outstanding deployment work clearly.

## Acceptance criteria

- Automatic visible capability panel for selected running agent.
- Active assigned tools only, respecting target user/tenant visibility policy.
- No credentials, endpoints, private instructions or raw input defaults in response.
- Universal metadata projection for API, MCP and function tools; no invented operations.
- Read/action/unknown badges reflect stored risk, not guessed behavior.
- Examples fill a draft; no websocket send or tool call before explicit Send.
- No stale cards after agent changes; no extra invocation/audit writes from reading cards.
- No SSO, intent, database schema, connector execution or credential-file changes.

If changes.patch does not apply cleanly, use files/ as reference for a minimal semantic merge. Do not force-apply, reset the repository, replace unrelated files or blindly regenerate the feature. Stop and report unknown authorization/schema mappings rather than guessing. Runtime model can be Claude or another provider: this panel is application code and does not depend on model instructions.
