# Agent capabilities patch — v1

When a running agent is selected, show what its active assigned tools can help with. Examples fill the composer only; they never send a message or execute a tool. The panel refreshes on focus and every 60 seconds while visible. It supports all registry tool types through common metadata, without an LLM call.

## Apply (Git Bash or Linux)

Back up or commit your working copy first. Extract this ZIP outside your repository. From the extracted package run:

```bash
bash apply.sh /path/to/application-repository
```

The script checks every patch hunk before applying. It does not install dependencies, migrate databases, commit, push or restart services. If checks fail, STOP: use the semantic merge guide, never force replacement of shared files. Source baseline: bce5f47926c86fb73b48ee3258b47f602f265d37 with existing unrelated working changes excluded.

To undo these exact changes:

```bash
bash rollback.sh /path/to/application-repository
```

Rollback checks before reversing. Subsequent edits can prevent reversal; preserve them and merge manually. New feature files are removed on successful reversal and remain recoverable from this ZIP. Rebuild/redeploy after applying or reversing. No database changes are involved.

## Public capability metadata

By default the panel uses a tool's public description and risk classification. It does not infer operations from column names or private agent instructions. To provide better business wording, extend the existing tool input schema without removing its properties:

```json
{
  "type": "object",
  "properties": {},
  "x-agent-capability": {
    "title": "Check backup status",
    "summary": "Find recent backup results for a server.",
    "examples": ["Show the latest backup for my server"],
    "visible": true,
    "allowed_roles": ["admin", "user"]
  }
}
```

All extension fields are optional. Only enter public text. Examples are limited to three per tool. Visibility roles restrict display only; they are NOT execution authorization. Existing execution checks remain necessary. If the target has tenant/user-specific tool permissions beyond roles and assignments, apply that same policy to this endpoint before deployment. Do not publish capabilities a user cannot access.

The card indicates configured capability, not a live endpoint health check. Unknown risk is marked for review. The feature does not add an action-confirmation engine, dynamically execute code, or validate every example against every remote API. Missing business metadata falls back to a generic starter.

## Verification and deployment

Run backend `python -m pytest tests/test_agent_capabilities.py -q` in the application's configured environment. Run frontend `npm test` and `npm run build`. Rebuild your normal backend/frontend images and roll them out through the existing OCP pipeline; do not introduce RHEL service commands into OCP.

Verify with real SSO users: select agent; confirm only allowed active assigned tools; click an example and verify no execution until Send; switch agents rapidly; disable/unassign a tool and wait for refresh; check unavailable/error states. Existing backend auto-discovers routers; other targets must register the new router. Preserve the existing authenticated API client and get_current_user dependency.

Tested in isolated local source copy: 29 backend feature tests; 29 frontend tests across seven suites (eight new tests); production TypeScript/Vite build successful, with a bundle-size warning. Backend uses SQLite tests, endpoint authentication is mocked. Live OCP/SSO, remote tools and production PostgreSQL were not tested. No model-specific runtime dependency is introduced; successful merges across arbitrary codebases cannot be guaranteed.
