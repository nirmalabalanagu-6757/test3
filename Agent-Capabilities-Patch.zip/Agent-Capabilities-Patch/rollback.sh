#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
target="${1:?Usage: bash rollback.sh /path/to/application-repository}"
git -C "$target" apply --reverse --check "$package_dir/changes.patch"
git -C "$target" apply --reverse "$package_dir/changes.patch"
echo 'Source patch reversed. Rebuild and redeploy using your existing process.'
