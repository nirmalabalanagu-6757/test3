# Agent Conversation & Tools — v1

This package adds per-agent controls for guided required-input collection, relevant-tool selection and live execution progress. The automatic capability panel from the preceding patch is included as an optional prerequisite. Features start disabled; an administrator enables each feature for each agent. No new production packages or database migrations are needed in the source application.

## Choose one patch

- Already have Agent-Capabilities-Patch: use changes.patch (incremental).
- Have neither feature: use combined.patch (includes the capability panel).
- Target is a Claude-merged or otherwise different codebase: use CLAUDE_SONNET_4_6_MERGE.md and merge the feature hunks into existing code. Do not overwrite shared files.

Do not apply both patches. Save or back up your working copy first. In Git Bash or Linux:

```bash
bash apply.sh /path/to/application incremental
# OR, if the earlier capability feature is absent:
bash apply.sh /path/to/application combined
```

The script checks every hunk before applying and does not commit, push, install packages or restart services. If checks fail, stop and use semantic merge instructions. The patch baseline is the source at bce5f47926c86fb73b48ee3258b47f602f265d37 plus the earlier capability feature and pre-existing local changes; those unrelated changes are excluded from feature diffs.

## Where to find the UI

Open Agent Registry, open an agent's Actions menu, choose Conversation & Tools. The controls are independent for every agent:

1. Collect missing required inputs: validates common tool-schema constraints and stops invalid calls; chat shows a form to prepare a reply. Review and Send continues the normal conversation. Already supplied inputs remain in the ADK conversation history. Model choice of inputs still requires testing on your actual prompts.
2. Select relevant tools: choose a maximum shortlist size and always-include tool names. Preview uses SAVED settings without calling a tool or a model. Selection matches tool names/descriptions locally, not embeddings. Uncertain matches and very short follow-ups retain all tools. Dependencies can exceed the shortlist size.
3. Show execution progress: choose status-only or status with tool names. Chat shows selection, running, needs-input, completed and failed states. Final responses include the trace; progress messages are not added to model/chat history as answers. Status timings are elapsed times within the request, not a promise of remote job completion.

Public capability overrides let this agent show more useful titles, descriptions and examples for its assigned tools. Enter public text only. Tool assignment and existing execution authorization remain enforced separately.

## Storage and dependencies

Settings use existing configuration rows: key agent.conversation.<agent-name>, environment from APP_ENV. Updates use existing configuration audit logging. No changes to agent_registry columns or tool tables. Existing FastAPI, Pydantic, SQLAlchemy, ADK, httpx and React are used. No AnythingLLM/Ruflo plugins, embedding service or additional runtime packages are introduced.

Progress is request-local and delivered on the same authenticated WebSocket as chat; it does not use shared process histories, poll the database or create database sessions. It covers tool calls in the normal ADK chat path. A remote tool that returns a job ID is complete as a tool call; tracking the remote job requires an existing status tool. Direct text-only fallback paths cannot execute or report tools. Existing intent routing behavior has not been changed by this feature.

## Multi-step tool dependencies

If a shortlisted tool requires another tool for later steps, keep that tool always included or declare the dependency in the existing input schema extension:

```json
{
  "type": "object",
  "properties": {"server": {"type": "string"}},
  "required": ["server"],
  "x-agent-capability": {"requires_tools": ["get_job_details"]}
}
```

Dependencies only expand to active tools assigned to that agent. Do not set a shortlist smaller than all operations needed by your scenarios without declaring dependencies. Native routing tools may remain available outside the registry shortlist to preserve existing routing.

## Validation limits

Guidance validates required fields, common primitive types, nested objects, enums, minimum string length and numeric bounds. It does not implement all JSON Schema features (such as refs, combinators, patterns or array-item validation). Connector and service-side validation remains necessary. Stored credentials are never requested through the guidance form. Descriptions and enum labels must be public; sanitization is defense in depth rather than a comprehensive sensitive-data scanner.

Rebuild frontend and backend images, then deploy with your existing OCP pipeline. The package preserves your target's SSO/authentication code. Router auto-discovery is present in the source; targets using explicit router registration must include the new routers.

## Rollback

```bash
bash rollback.sh /path/to/application incremental
# Use combined instead only if that was the patch you applied.
```

Rollback checks before reversing and refuses incompatible edits. It removes new feature files; they remain recoverable from this ZIP. It preserves unrelated source changes. Configuration rows are left in place and ignored by the prior version; no destructive database cleanup is performed. Rebuild/redeploy afterward.

See TEST_REPORT.txt and PATCH_SUMMARY.txt for verification and per-file actions. Live OCP/SSO, real Claude billing/credentials and your remote APIs were not tested by the offline suite.
