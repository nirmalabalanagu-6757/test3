#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
target="${1:?Usage: bash apply.sh /path/to/repository [incremental|combined]}"
mode="${2:-incremental}"
case "$mode" in
  incremental) patch_file="$package_dir/changes.patch" ;;
  combined) patch_file="$package_dir/combined.patch" ;;
  *) echo 'Choose incremental or combined.' >&2; exit 2 ;;
esac
git -C "$target" apply --check "$patch_file"
git -C "$target" apply "$patch_file"
echo 'Patch applied. Run tests, rebuild frontend/backend images and deploy through your normal process.'
