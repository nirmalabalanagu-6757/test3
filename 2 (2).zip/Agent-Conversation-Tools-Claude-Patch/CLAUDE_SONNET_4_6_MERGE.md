# Claude Sonnet 4.6 implementation contract

Merge this application feature into the target repository after inspecting its actual code. The patch is compatible with the source application's Claude adapter; it does not require Claude-specific prompt parsing. Never claim 100% compatibility across arbitrary codebases. Run tests and report the actual outcome.

## Before and after

Previously: capability display was available but per-agent conversational input collection, request-specific tool exposure and live tool-step events were absent. Now: an admin enables the three features separately; missing required tool inputs stop execution, a focused tool set can be presented to the model, and execution events appear in chat.

## Required merge sequence

1. Read README.md, PATCH_SUMMARY.txt, manifest.json and the chosen patch completely. Check whether the preceding capability feature is already present. New files are supplied in files/. Integrations for shared files are supplied as patch hunks; they must be merged into existing implementations.
2. Map AgentRegistry, ToolRegistry, ToolAgentAssignment, Configuration, APP_ENV and their field names to the target. Use the existing configuration table for JSON settings. Do not add a new table or reuse reasoning/model settings. If the target lacks this configuration store, report the concrete storage difference and adapt explicitly.
3. Register the new backend router once. Keep target authentication, session dependencies, tenant policies and admin role checks. NEVER replace SSO with VM-local identity code. The ZIP does not include authentication modules or a full WebSocket router. Its router diff only passes the existing socket's JSON-send callback into ChatService.
4. Integrate prepare_tools into the governed-agent builder after active tool loading and before building the model agent. Pass the current request query down to child agents. Apply any existing hard allowed-tool restrictions first. Filter descriptions as well as function declarations. Preserve native routing tools. Include instruction/tool/subagent fingerprints in the runner cache key so settings and shortlist changes are used on the next request.
5. Preserve existing governance callbacks. After authorization succeeds, run the request-local input/progress hook; blocked calls must not execute. Add completion hooks after tool responses. When the turn has missing-input guidance, the before-model callback returns a deterministic clarification instead of consuming another model call. Preserve all existing budget/policy checks for calls that do reach the provider.
6. Scope conversation_turn around the actual model/tool invocation in ChatService, reset it even on failure, and finalize unresolved steps. Pass a progress sender from the EXISTING authenticated WebSocket handler. Existing callers can omit this optional argument and still receive the final trace. Keep session identity and ownership checks from the target unchanged.
7. Extend the final response schema with execution_run_id, execution_steps and input_guidance. On the frontend recognize execution_progress before treating incoming data as a chat answer. Progress cannot clear waiting or enter model history. Keep the final response handling, existing authentication API client and WebSocket setup.
8. Add Conversation & Tools to each agent's Actions menu. Use the existing authenticated API functions. Settings apply on the next request; the feature toggles default to off. Preview reads SAVED settings and executes nothing. Missing-input forms draft a reply only, requiring the existing Send action.
9. Run the provided feature tests, relevant connector/runner regressions and frontend production build. Fix integration differences instead of deleting assertions or replacing the target app with sample code. Report live tests and mocks separately.

## Required invariants

- Selection never grants tool access and never adds an unassigned registered dependency.
- Configuration persists independently for every agent and environment; only admins write it.
- Authorization runs before schema guidance and execution.
- A needs_input result corresponds to a tool NOT being executed.
- No credentials, raw tool arguments or raw results are included in progress events.
- Two parallel calls and two concurrent conversations have separate IDs and statuses.
- A started call with no result is not marked completed.
- A disconnected socket does not automatically retry a system-changing action.
- Settings and current tool subsets participate in runner caching.
- No new memory feature, intent matching change, connector replacement or authentication bypass is part of this patch.

## Test evidence

The suite runs the real ADK Runner and the existing Anthropic adapter using the claude-sonnet-4-6 model identifier, with mocked HTTP provider replies. It checks missing-input blocking, deterministic clarification without another model request, and a successful follow-up tool call. This demonstrates integration behavior, not a successful paid call to the live model.

If the target uses a different orchestration framework or callback signature, adapt the named integration points and add an equivalent end-to-end test. Do not copy a signature without checking it. Do not overwrite shared files to resolve conflicts. Preserve the target's existing features and SSO.
