#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
target="${1:?Usage: bash rollback.sh /path/to/repository [incremental|combined]}"
mode="${2:-incremental}"
case "$mode" in
  incremental) patch_file="$package_dir/changes.patch" ;;
  combined) patch_file="$package_dir/combined.patch" ;;
  *) echo 'Choose incremental or combined.' >&2; exit 2 ;;
esac
git -C "$target" apply --reverse --check "$patch_file"
git -C "$target" apply --reverse "$patch_file"
echo 'Exact source changes reversed. Rebuild and redeploy through your normal process.'
