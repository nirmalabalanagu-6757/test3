"""Validated per-agent conversation controls and public runtime events."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class CapabilityCopy(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field("", max_length=120)
    summary: str = Field("", max_length=320)
    examples: list[str] = Field(default_factory=list, max_length=3)


class AgentConversationSettings(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    guided_inputs_enabled: bool = False
    tool_selection_enabled: bool = False
    max_tools: int = Field(8, ge=1, le=64)
    always_include_tools: list[str] = Field(default_factory=list, max_length=64)
    progress_enabled: bool = False
    progress_detail: Literal["summary", "tools"] = "tools"
    capability_overrides: dict[str, CapabilityCopy] = Field(default_factory=dict, max_length=128)


class ToolSelectionPreview(BaseModel):
    query: str = Field(..., min_length=1, max_length=4000)
