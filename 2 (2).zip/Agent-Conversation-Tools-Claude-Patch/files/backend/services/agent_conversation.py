"""Metadata selection and schema validation; no LLM/embedding calls or new dependencies."""

import inspect
import logging
import re
from typing import Any

from sqlalchemy import select

from backend.config import settings
from backend.models.config_model import Configuration
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.schemas.agent_conversation import AgentConversationSettings
from backend.services.agent_capabilities import public_text

logger = logging.getLogger(__name__)
_STOP = {"a", "an", "the", "please", "can", "you", "i", "me", "my", "for", "of", "to", "and", "is", "it", "with"}
_SENSITIVE = re.compile(r"password|credential|secret|authorization|api.?key|access.?token", re.IGNORECASE)


async def load_settings(db: Any, agent: str) -> AgentConversationSettings:
    record = await db.get(Configuration, (f"agent.conversation.{agent}", settings.app_env))
    if not record or not record.value:
        return AgentConversationSettings()
    # Invalid configuration is reported instead of silently enabling features.
    return AgentConversationSettings.model_validate_json(record.value)


async def assigned_tools(db: Any, agent: str) -> list[ToolRegistry]:
    aliases = {agent, agent.replace("-", "_")}
    if not agent.endswith("_agent"):
        aliases.add(f"{agent}_agent")
    result = await db.execute(
        select(ToolRegistry)
        .join(ToolAgentAssignment, ToolAgentAssignment.tool_name == ToolRegistry.name)
        .where(ToolAgentAssignment.agent_name.in_(aliases), ToolRegistry.lifecycle_status == "active")
        .order_by(ToolRegistry.name)
    )
    return list(result.scalars().unique().all())


def words(text: str) -> set[str]:
    return {w.rstrip("s") for w in re.findall(r"[a-z0-9]+", text.casefold()) if w not in _STOP and len(w) > 1}


def select_tools(rows: list[ToolRegistry], query: str, profile: AgentConversationSettings) -> dict:
    names = {row.name for row in rows}
    terms = words(query)
    if not profile.tool_selection_enabled or len(rows) <= profile.max_tools:
        return {"selected_tools": sorted(names), "reason": "All assigned tools fit the configured limit."}
    scores = {}
    for row in rows:
        schema = row.input_schema_json if isinstance(row.input_schema_json, dict) else {}
        meta = schema.get("x-agent-capability", {})
        meta = meta if isinstance(meta, dict) else {}
        public_copy = profile.capability_overrides.get(row.name)
        text = " ".join(
            [
                row.name,
                row.description or "",
                str(meta.get("title", "")),
                str(meta.get("summary", "")),
                public_copy.summary if public_copy else "",
            ]
        )
        scores[row.name] = len(terms & words(text)) + 2 * len(terms & words(row.name))
    ranking = sorted(names, key=lambda name: (-scores[name], name))
    # A short follow-up or an unrecognised paraphrase must retain access to tools.
    if len(terms) < 2 or not ranking or scores[ranking[0]] == 0:
        return {"selected_tools": sorted(names), "reason": "Uncertain match or short follow-up; retained all tools."}
    selected = set(profile.always_include_tools) & names
    if len(selected) >= profile.max_tools and ranking[0] not in selected:
        return {
            "selected_tools": sorted(names),
            "reason": "Pinned tools fill the shortlist; retained all tools for this request.",
        }
    remaining = profile.max_tools - len(selected)
    unpinned = [name for name in ranking if name not in selected]
    if (
        remaining > 0
        and len(unpinned) > remaining
        and scores[unpinned[remaining - 1]] > 0
        and (scores[unpinned[remaining - 1]] == scores[unpinned[remaining]])
    ):
        return {"selected_tools": sorted(names), "reason": "Several tools match equally; retained all tools."}
    for name in ranking:
        if len(selected) >= profile.max_tools:
            break
        selected.add(name)
    # Explicit dependency declarations preserve multi-step workflows. The configured
    # limit is a shortlist budget, not permission to drop mandatory dependencies.
    by_name = {row.name: row for row in rows}
    pending = list(selected)
    while pending:
        schema = by_name[pending.pop()].input_schema_json
        meta = schema.get("x-agent-capability", {}) if isinstance(schema, dict) else {}
        dependencies = meta.get("requires_tools", []) if isinstance(meta, dict) else []
        for name in dependencies if isinstance(dependencies, list) else []:
            if isinstance(name, str) and name in names and name not in selected:
                selected.add(name)
                pending.append(name)
    return {
        "selected_tools": sorted(selected),
        "reason": "Matched tool names/descriptions; retained pinned tools and declared dependencies.",
    }


def callable_schema(tool: Any) -> dict:
    func = getattr(tool, "func", tool)
    try:
        signature = inspect.signature(func)
    except (ValueError, TypeError):
        return {}
    properties, required = {}, []
    for name, parameter in signature.parameters.items():
        if name in {"tool_context", "self"} or parameter.kind in {parameter.VAR_POSITIONAL, parameter.VAR_KEYWORD}:
            continue
        annotation = str(parameter.annotation)
        kind = (
            "integer"
            if annotation in {"<class 'int'>", "int"}
            else "number"
            if annotation in {"<class 'float'>", "float"}
            else "boolean"
            if annotation in {"<class 'bool'>", "bool"}
            else "object"
            if "dict" in annotation
            else ("array" if "list" in annotation else "string")
        )
        properties[name] = {"type": kind}
        if parameter.default is parameter.empty:
            required.append(name)
    return {"type": "object", "properties": properties, "required": required}


def input_issues(schema: dict, arguments: dict, prefix: str = "") -> list[dict]:
    """Validate common JSON Schema constraints without adding a dependency.

    Advanced schema constructs remain the connector's responsibility. Never return
    submitted values or defaults, which can include credentials.
    """
    if not isinstance(schema, dict) or not isinstance(arguments, dict):
        return []
    properties = schema.get("properties", {})
    required = schema.get("required", [])
    if not isinstance(properties, dict) or not isinstance(required, list):
        return []
    issues = []
    for name in sorted(set(properties) | {n for n in required if isinstance(n, str)}):
        if not isinstance(name, str):
            continue
        definition = properties.get(name, {})
        if not isinstance(definition, dict):
            definition = {}
        path = f"{prefix}{name}"
        value = arguments.get(name)
        missing = name not in arguments or value is None or value == ""
        reason = "Required input is missing" if name in required and missing else ""
        if not missing:
            kind = definition.get("type")
            checks = {
                "string": lambda v: isinstance(v, str),
                "integer": lambda v: type(v) is int,
                "number": lambda v: type(v) in {int, float},
                "boolean": lambda v: type(v) is bool,
                "object": lambda v: isinstance(v, dict),
                "array": lambda v: isinstance(v, list),
            }
            if isinstance(kind, str) and kind in checks and not checks[kind](value):
                reason = f"Expected {kind}"
            elif isinstance(definition.get("enum"), list) and value not in definition["enum"]:
                reason = "Choose an allowed value"
            elif (
                isinstance(value, str)
                and type(definition.get("minLength")) is int
                and len(value) < definition["minLength"]
            ):
                reason = "Value is too short"
            elif type(value) in {int, float} and (
                (type(definition.get("minimum")) in {int, float} and value < definition["minimum"])
                or (type(definition.get("maximum")) in {int, float} and value > definition["maximum"])
            ):
                reason = "Value is outside the allowed range"
            elif isinstance(value, dict):
                issues.extend(input_issues(definition, value, f"{path}."))
        if reason:
            if _SENSITIVE.search(path):
                issues.append(
                    {
                        "name": "administrator_configuration",
                        "type": "configuration",
                        "reason": "A required credential must be configured by an administrator.",
                    }
                )
                continue
            field = {
                "name": public_text(path, 128) or "input",
                "type": definition.get("type", "string"),
                "reason": reason,
            }
            enum = definition.get("enum")
            if isinstance(enum, list) and all(type(v) in {str, int, float, bool} for v in enum) and len(enum) <= 40:
                field["enum"] = [v for v in enum if not isinstance(v, str) or public_text(v, 200)]
            issues.append(field)
    return issues[:32]


async def prepare_tools(db: Any, agent: str, tools: list, query: str, allowed: list[str] | None) -> tuple[list, str]:
    from backend.services.conversation_runtime import current_turn

    profile = await load_settings(db, agent)
    rows = await assigned_tools(db, agent)
    if allowed is not None:
        rows = [row for row in rows if row.name.casefold() in {n.casefold() for n in allowed}]
    selection = select_tools(rows, query, profile)
    names = set(selection["selected_tools"])
    if profile.tool_selection_enabled:
        # Preserve unregistered native routing tools; existing governance still applies.
        registered = {row.name for row in rows}
        tools = [
            t
            for t in tools
            if getattr(t, "__name__", getattr(t, "name", "")) in names
            or getattr(t, "__name__", getattr(t, "name", "")) not in registered
        ]
    turn = current_turn()
    if turn:
        turn.configure(agent, profile, rows, tools)
        await turn.emit(agent, "tool_selection", "selected", selection["reason"], tools=selection["selected_tools"])
    instruction = ""
    if profile.guided_inputs_enabled:
        instruction = (
            "\n\nTool input collection: use registered schemas and conversation history. Ask only for missing required "
            "inputs. Do not invent required inputs, targets, credentials or defaults. When a tool returns needs_input, "
            "ask for the listed fields; do not repeat the same call until the user supplies or corrects them. "
            "Preserve supplied inputs from this conversation. Follow existing action authorization and approval rules."
        )
    return tools, instruction
