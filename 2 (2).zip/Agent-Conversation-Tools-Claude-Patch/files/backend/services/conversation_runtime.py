"""Request-local progress and input guidance. No database sessions or shared histories."""

import asyncio
import logging
from collections.abc import Awaitable, Callable
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import UTC, datetime
from time import monotonic
from uuid import uuid4

from backend.services.agent_capabilities import public_text
from backend.services.agent_conversation import callable_schema, input_issues

logger = logging.getLogger(__name__)
_turn = ContextVar("agent_conversation_turn", default=None)


def current_turn():
    return _turn.get()


class ConversationTurn:
    def __init__(self, callback: Callable[[dict], Awaitable] | None = None):
        self.id = str(uuid4())
        self.callback = callback
        self.profiles = {}
        self.schemas = {}
        self.events = []
        self.guidance = []
        self.running = {}
        self.started = monotonic()
        self.lock = asyncio.Lock()

    def configure(self, agent, profile, rows, tools):
        aliases = {agent, agent.replace("-", "_")}
        if not agent.endswith("_agent"):
            aliases.add(f"{agent}_agent")
        schemas = {getattr(t, "__name__", getattr(t, "name", "")): callable_schema(t) for t in tools}
        for row in rows:
            if isinstance(row.input_schema_json, dict) and row.input_schema_json.get("properties"):
                schemas[row.name] = row.input_schema_json
        for alias in aliases:
            self.profiles[alias] = profile
            self.schemas[alias] = schemas

    async def emit(self, agent, tool, status, message="", *, step_id=None, tools=None):
        profile = self.profiles.get(agent)
        if not profile or not profile.progress_enabled or len(self.events) >= 128:
            return
        event = {
            "type": "execution_progress",
            "run_id": self.id,
            "step_id": step_id or str(uuid4()),
            "agent_name": agent,
            "status": status,
            "message": public_text(message),
            "elapsed_ms": round((monotonic() - self.started) * 1000),
            "timestamp": datetime.now(UTC).isoformat(),
        }
        if profile.progress_detail == "tools":
            event["tool_name"] = public_text(tool, 128)
            if tools is not None:
                event["selected_tools"] = [public_text(n, 128) for n in tools]
        async with self.lock:
            self.events.append(event)
            if self.callback:
                try:
                    await asyncio.wait_for(self.callback(event), 2)
                except Exception:
                    logger.debug("Progress delivery unavailable", exc_info=True)

    async def before(self, agent, tool, arguments, context):
        profile = self.profiles.get(agent)
        name = getattr(tool, "name", "")
        call_id = str(getattr(context, "function_call_id", "") or uuid4())
        if profile and profile.guided_inputs_enabled:
            schema = self.schemas.get(agent, {}).get(name) or callable_schema(tool)
            values = arguments if isinstance(arguments, dict) else {}
            # Dynamic REST/MCP wrappers expose a transport envelope around the
            # registered domain schema. Validate the actual domain arguments.
            original = values
            for key in ("arguments", "body", "query_params", "path_params"):
                if isinstance(original.get(key), dict):
                    values = {**values, **original[key]}
            issues = input_issues(schema, values)
            if issues:
                guidance = {"agent_name": agent, "tool_name": public_text(name, 128), "fields": issues}
                if guidance not in self.guidance:
                    self.guidance.append(guidance)
                await self.emit(agent, name, "needs_input", "Waiting for required tool inputs.", step_id=call_id)
                return {
                    "needs_input": True,
                    "fields": issues,
                    "instruction": "Ask the user for these inputs; tool was not executed.",
                }
        self.running[call_id] = (agent, name)
        await self.emit(agent, name, "running", "Tool execution started.", step_id=call_id)
        return None

    async def after(self, agent, tool, response, context):
        call_id = str(getattr(context, "function_call_id", ""))
        if call_id not in self.running:
            candidates = [key for key, pair in self.running.items() if pair == (agent, getattr(tool, "name", ""))]
            if not candidates:
                return
            call_id = candidates[0]
        self.running.pop(call_id, None)
        failed = isinstance(response, dict) and (
            response.get("error")
            or response.get("blocked")
            or response.get("success") is False
            or response.get("status") == "error"
        )
        await self.emit(
            agent,
            getattr(tool, "name", ""),
            "failed" if failed else "completed",
            "Tool returned an error." if failed else "Tool execution completed.",
            step_id=call_id,
        )

    async def finish(self):
        for call_id, (agent, name) in list(self.running.items()):
            await self.emit(agent, name, "failed", "Execution ended without a successful tool result.", step_id=call_id)
        self.running.clear()


@contextmanager
def conversation_turn(callback=None):
    turn = ConversationTurn(callback)
    token = _turn.set(turn)
    try:
        yield turn
    finally:
        _turn.reset(token)
