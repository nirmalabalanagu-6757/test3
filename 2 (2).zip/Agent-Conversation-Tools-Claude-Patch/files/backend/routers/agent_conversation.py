"""Per-agent conversation configuration and selection preview; existing auth reused."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.database import get_session
from backend.middleware.auth import get_current_user, require_role
from backend.models.agent import AgentRegistry
from backend.models.user import User
from backend.schemas.agent_conversation import AgentConversationSettings, ToolSelectionPreview
from backend.services.agent_capabilities import public_text
from backend.services.agent_conversation import assigned_tools, load_settings, select_tools
from backend.services.configuration import ConfigurationService

router = APIRouter(prefix="/api/agents", tags=["agent-conversation"])
DB = Annotated[AsyncSession, Depends(get_session)]
AuthenticatedUser = Annotated[User, Depends(get_current_user)]
AdminUser = Annotated[User, Depends(require_role("admin"))]


async def require_agent(db, name):
    agent = await db.get(AgentRegistry, name)
    if not agent or agent.lifecycle_status == "deregistered":
        raise HTTPException(404, "Agent not found")
    return agent


@router.get("/{name}/conversation-settings", response_model=AgentConversationSettings)
async def get_settings(name: str, response: Response, db: DB, user: AuthenticatedUser):
    if not user.active:
        raise HTTPException(403, "Account is inactive")
    response.headers["Cache-Control"] = "private, no-store"
    await require_agent(db, name)
    return await load_settings(db, name)


@router.put("/{name}/conversation-settings", response_model=AgentConversationSettings)
async def put_settings(name: str, data: AgentConversationSettings, db: DB, user: AdminUser):
    if not user.active:
        raise HTTPException(403, "Account is inactive")
    await require_agent(db, name)
    rows = await assigned_tools(db, name)
    names = {row.name for row in rows}
    if (set(data.always_include_tools) | set(data.capability_overrides)) - names:
        raise HTTPException(422, "Pinned tools and capability overrides must refer to active assigned tools")
    if len(set(data.always_include_tools)) > data.max_tools:
        raise HTTPException(422, "Pinned tools exceed the configured maximum")
    for override in data.capability_overrides.values():
        if any(text and not public_text(text) for text in [override.title, override.summary, *override.examples]):
            raise HTTPException(
                422, "Capability descriptions/examples must contain public text without credentials or URLs"
            )
    await ConfigurationService().set_config(
        db,
        f"agent.conversation.{name}",
        data.model_dump_json(),
        settings.app_env,
        schema_type="json",
        updated_by=user.username,
    )
    await db.commit()
    from backend.services.agent_runner import agent_runner

    agent_runner.invalidate_runners(name)
    agent_runner.invalidate_routing_runners()
    return data


@router.post("/{name}/tool-selection-preview")
async def preview(name: str, data: ToolSelectionPreview, db: DB, user: AdminUser):
    if not user.active:
        raise HTTPException(403, "Account is inactive")
    await require_agent(db, name)
    return select_tools(await assigned_tools(db, name), data.query, await load_settings(db, name))
