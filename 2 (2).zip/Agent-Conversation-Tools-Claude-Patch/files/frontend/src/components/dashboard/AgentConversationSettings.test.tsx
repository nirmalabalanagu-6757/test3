import { act } from "react";
import { createRoot } from "react-dom/client";
import type { Root } from "react-dom/client";
import { beforeEach, afterEach, it, expect, vi } from "vitest";
import { apiGet, apiPost, apiPut } from "../../api/client";
import AgentConversationSettings from "./AgentConversationSettings";
vi.mock("../../api/client", () => ({ apiGet: vi.fn(), apiPut: vi.fn(), apiPost: vi.fn() }));
const profile = { guided_inputs_enabled: false, tool_selection_enabled: false, max_tools: 8, always_include_tools: [], progress_enabled: false, progress_detail: "tools", capability_overrides: {} };
let root: Root; let container: HTMLDivElement;
beforeEach(() => {
  vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true); container = document.createElement("div"); document.body.appendChild(container); root = createRoot(container);
  vi.mocked(apiGet).mockResolvedValue(profile); vi.mocked(apiPut).mockResolvedValue({ ...profile, guided_inputs_enabled: true });
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); vi.unstubAllGlobals(); vi.resetAllMocks(); });

it("loads and saves controls for the selected agent only", async () => {
  await act(async () => root.render(<AgentConversationSettings agentName="backup" onClose={vi.fn()} />));
  expect(apiGet).toHaveBeenCalledWith("/agents/backup/conversation-settings");
  await act(async () => (container.querySelector('input[type="checkbox"]') as HTMLInputElement).click());
  await act(async () => [...container.querySelectorAll("button")].find(b => b.textContent === "Save settings")!.click());
  expect(apiPut).toHaveBeenCalledWith("/agents/backup/conversation-settings", expect.objectContaining({ guided_inputs_enabled: true, tool_selection_enabled: false }));
  expect(container.textContent).toContain("next request");
});

it("previews saved tool selection and reports failed saves", async () => {
  vi.mocked(apiPost).mockResolvedValue({ selected_tools: ["backup_query"], reason: "Matched descriptions" });
  await act(async () => root.render(<AgentConversationSettings agentName="backup" onClose={vi.fn()} />));
  const input = container.querySelector('[aria-label="Selection preview query"]')!;
  await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!.call(input, "failed backups"); input.dispatchEvent(new Event("input", { bubbles: true })); });
  await act(async () => [...container.querySelectorAll("button")].find(b => b.textContent === "Preview selection")!.click());
  expect(apiPost).toHaveBeenCalledWith("/agents/backup/tool-selection-preview", { query: "failed backups" });
  expect(container.textContent).toContain("backup_query");
  vi.mocked(apiPut).mockRejectedValue(new Error("invalid"));
  await act(async () => [...container.querySelectorAll("button")].find(b => b.textContent === "Save settings")!.click());
  expect(container.textContent).toContain("Save failed");
});
