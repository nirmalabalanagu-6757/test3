import { useEffect, useState } from "react";
import { apiGet, apiPost, apiPut } from "../../api/client";

interface Profile {
  guided_inputs_enabled: boolean;
  tool_selection_enabled: boolean;
  max_tools: number;
  always_include_tools: string[];
  progress_enabled: boolean;
  progress_detail: "summary" | "tools";
  capability_overrides: Record<string, { title: string; summary: string; examples: string[] }>;
}

export default function AgentConversationSettings({ agentName, onClose }: { agentName: string; onClose: () => void }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [pins, setPins] = useState("");
  const [copy, setCopy] = useState("{}");
  const [query, setQuery] = useState("");
  const [preview, setPreview] = useState<{ selected_tools: string[]; reason: string } | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const base = `/agents/${encodeURIComponent(agentName)}`;
  useEffect(() => {
    let active = true;
    apiGet<Profile>(`${base}/conversation-settings`).then(data => {
      if (active) { setProfile(data); setPins(data.always_include_tools.join(", ")); setCopy(JSON.stringify(data.capability_overrides, null, 2)); }
    }).catch(() => { if (active) setMessage("Could not load conversation settings."); });
    return () => { active = false; };
  }, [base]);
  const changed = (update: Partial<Profile>) => { if (profile) setProfile({ ...profile, ...update }); setPreview(null); setMessage(""); };
  const save = async () => {
    if (!profile) return;
    setBusy(true); setMessage(""); setPreview(null);
    try {
      const data = { ...profile, always_include_tools: [...new Set(pins.split(",").map(s => s.trim()).filter(Boolean))], capability_overrides: JSON.parse(copy) };
      setProfile(await apiPut<Profile>(`${base}/conversation-settings`, data));
      setMessage("Saved. These settings apply to the next request for this agent.");
    } catch { setMessage("Save failed. Check the maximum, assigned tool names and public capability JSON."); }
    finally { setBusy(false); }
  };
  const test = async () => {
    setBusy(true); setMessage("");
    try { setPreview(await apiPost(`${base}/tool-selection-preview`, { query })); }
    catch { setMessage("Preview failed. Save valid settings and try again."); }
    finally { setBusy(false); }
  };
  return <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.45)", zIndex: 1000, display: "grid", placeItems: "center" }}>
    <section role="dialog" aria-modal="true" aria-label={`Conversation and tools for ${agentName}`} style={{ background: "var(--color-surface)", color: "var(--color-text)", padding: "1.25rem", borderRadius: 8, maxHeight: "90vh", overflow: "auto", width: "min(650px, 92vw)" }}>
      <h2>Conversation &amp; Tools</h2><p>{agentName}</p>
      {profile ? <div style={{ display: "grid", gap: "1rem" }}>
        <label><input type="checkbox" checked={profile.guided_inputs_enabled} onChange={e => changed({ guided_inputs_enabled: e.target.checked })} /> Collect missing required inputs</label>
        <small>Uses tool schemas and conversation history. Missing or invalid inputs stop the tool call and appear in a form in chat.</small>
        <label><input type="checkbox" checked={profile.tool_selection_enabled} onChange={e => changed({ tool_selection_enabled: e.target.checked })} /> Select relevant tools for each request</label>
        <label>Maximum tools in shortlist <input aria-label="Maximum tools in shortlist" type="number" min={1} max={64} value={profile.max_tools} onChange={e => changed({ max_tools: Number(e.target.value) })} /></label>
        <label>Always include assigned tools (comma separated)<input aria-label="Always include assigned tools" style={{ width: "100%" }} value={pins} onChange={e => { setPins(e.target.value); setPreview(null); setMessage(""); }} /></label>
        <small>Matching uses tool names and descriptions. Uncertain requests retain all tools. Declared dependencies may exceed the shortlist maximum.</small>
        <label><input type="checkbox" checked={profile.progress_enabled} onChange={e => changed({ progress_enabled: e.target.checked })} /> Show execution progress in chat</label>
        <label>Progress detail <select aria-label="Progress detail" value={profile.progress_detail} onChange={e => changed({ progress_detail: e.target.value as Profile["progress_detail"] })}><option value="summary">Status only</option><option value="tools">Status and tool names</option></select></label>
        <label>Public capabilities for this agent (JSON)<textarea aria-label="Public capabilities JSON" style={{ width: "100%", minHeight: 140 }} value={copy} onChange={e => { setCopy(e.target.value); setMessage(""); }} /></label>
        <small>Optional: {`{"tool_name":{"title":"Check backup status","summary":"Find recent backup results.","examples":["Show latest backups"]}}`}</small>
        <button onClick={save} disabled={busy}>Save settings</button>
        <fieldset><legend>Preview tool selection</legend><p>Uses saved settings. No tools or models are called.</p><input aria-label="Selection preview query" value={query} onChange={e => setQuery(e.target.value)} style={{ width: "100%" }} /><button onClick={test} disabled={busy || !query.trim()}>Preview selection</button>
          {preview && <div><p>{preview.reason}</p><ul>{preview.selected_tools.map(name => <li key={name}>{name}</li>)}</ul></div>}
        </fieldset>
      </div> : <p>Loading settings…</p>}
      {message && <p role="status">{message}</p>}
      <button onClick={onClose} disabled={busy}>Close</button>
    </section>
  </div>;
}
