import { useEffect, useState } from "react";
import { apiGet } from "../../api/client";
import "./AgentCapabilities.css";

export interface Capability {
  tool_name: string;
  title: string;
  summary: string;
  kind: "read" | "action" | "unknown";
  examples: string[];
}

interface CapabilitiesResponse {
  agent_name: string;
  display_name: string;
  available: boolean;
  capabilities: Capability[];
  notice: string;
}

interface Props {
  agentName: string;
  onChooseExample: (prompt: string) => void;
  disabled?: boolean;
}

export default function AgentCapabilities({ agentName, onChooseExample, disabled = false }: Props) {
  const [data, setData] = useState<CapabilitiesResponse | null>(null);
  const [error, setError] = useState(false);
  const [refresh, setRefresh] = useState(0);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    let active = true;
    let pending = false;
    const load = async () => {
      if (pending) return;
      pending = true;
      try {
        const result = await apiGet<CapabilitiesResponse>(`/agents/${encodeURIComponent(agentName)}/capabilities`);
        if (!result || result.agent_name !== agentName || !Array.isArray(result.capabilities)) {
          throw new Error("Invalid capabilities response");
        }
        if (active) { setData(result); setError(false); }
      } catch {
        // Never keep advertising stale capabilities after permission/reload errors.
        if (active) { setData(null); setError(true); }
      } finally { pending = false; }
    };
    void load();
    const refreshVisible = () => { if (!document.hidden) void load(); };
    window.addEventListener("focus", refreshVisible);
    const timer = window.setInterval(refreshVisible, 60_000);
    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener("focus", refreshVisible);
    };
  }, [agentName, refresh]);

  // Guard against old-agent content even before the new effect runs.
  const current = data?.agent_name === agentName ? data : null;
  const cards = current?.available ? current.capabilities : [];
  const visible = showAll ? cards : cards.slice(0, 4);

  return (
    <details className="agent-capabilities" open>
      <summary>{current ? `What ${current.display_name} can help you with` : "What this agent can help you with"}</summary>
      {!current && !error && <p role="status">Loading available capabilities…</p>}
      {error && <p role="status">Capabilities could not be loaded. You can still use the chat. <button type="button" onClick={() => setRefresh(n => n + 1)}>Retry</button></p>}
      {current && <>
        <ul className="agent-capability-list">
          {visible.map(card => <li key={card.tool_name}>
            <div className="agent-capability-heading">
              <strong>{card.title}</strong>
              <span>{card.kind === "read" ? "View information" : card.kind === "action" ? "Can change systems" : "Review action scope"}</span>
            </div>
            {card.summary !== card.title && <p>{card.summary}</p>}
            <div className="agent-capability-examples">
              {card.examples.map((example, index) => <button
                type="button" key={`${card.tool_name}-${index}`} disabled={disabled}
                aria-label={`Draft example: ${example}`}
                onClick={() => onChooseExample(example)}
              >{example}</button>)}
            </div>
          </li>)}
        </ul>
        {cards.length > 4 && <button type="button" onClick={() => setShowAll(value => !value)}>
          {showAll ? "Show fewer capabilities" : `Show all ${cards.length} capabilities`}
        </button>}
        <p className="agent-capability-note">{current.notice}</p>
        {cards.length > 0 && <p className="agent-capability-note">Examples fill the message box only. Review before sending; selecting an example does not run a tool.</p>}
        {cards.some(card => card.kind !== "read") && <p className="agent-capability-note">For system-changing requests, review the target and inputs before authorizing execution.</p>}
      </>}
    </details>
  );
}
