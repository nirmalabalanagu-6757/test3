import { useState } from "react";

export interface ProgressEvent {
  type?: string;
  run_id: string;
  step_id: string;
  agent_name: string;
  tool_name?: string;
  status: string;
  message: string;
  elapsed_ms: number;
  selected_tools?: string[];
}
export interface InputGuidance {
  agent_name: string;
  tool_name: string;
  fields: { name: string; type: string; reason: string; enum?: (string | number | boolean)[] }[];
}

export function ExecutionProgress({ events }: { events: ProgressEvent[] }) {
  if (!events.length) return null;
  const latest = new Map<string, ProgressEvent>();
  for (const event of events) latest.set(`${event.run_id}:${event.step_id}`, event);
  return <details open style={{ margin: ".75rem 0", padding: ".5rem", border: "1px solid var(--color-border)", borderRadius: 6 }}>
    <summary>Execution progress</summary>
    <ol aria-live="polite">{[...latest.values()].map(event => <li key={`${event.run_id}:${event.step_id}`}>
      {event.agent_name}{event.tool_name ? ` · ${event.tool_name}` : ""}: <strong>{event.status.replaceAll("_", " ")}</strong>
      {event.message && ` — ${event.message}`} <small>({(event.elapsed_ms / 1000).toFixed(1)}s)</small>
      {event.selected_tools && <div>Selected tools: {event.selected_tools.join(", ") || "None"}</div>}
    </li>)}</ol>
  </details>;
}

export function RequiredInputs({ guidance, onDraft, disabled }: { guidance: InputGuidance[]; onDraft: (text: string) => void; disabled: boolean }) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  if (!guidance.length) return null;
  const fields = guidance.flatMap((g, index) => g.fields.map(f => ({ ...f, key: `${index}:${f.name}`, tool: g.tool_name })));
  const draft = () => {
    try {
      const parts = fields.filter(f => f.type !== "configuration").map(f => {
        const raw = values[f.key] ?? "";
        if (!raw.trim()) throw new Error("Complete the requested fields.");
        let value: unknown = raw;
        if (["array", "object", "boolean", "integer", "number"].includes(f.type)) value = JSON.parse(raw);
        if (f.type === "integer" && (typeof value !== "number" || !Number.isInteger(value))) throw new Error("Enter a valid integer.");
        if (f.type === "number" && typeof value !== "number") throw new Error("Enter a valid number.");
        if (f.type === "boolean" && typeof value !== "boolean") throw new Error("Choose true or false.");
        if (f.type === "array" && !Array.isArray(value)) throw new Error("Enter a JSON array.");
        if (f.type === "object" && (!value || typeof value !== "object" || Array.isArray(value))) throw new Error("Enter a JSON object.");
        return `${f.tool}: ${f.name} = ${JSON.stringify(value)}`;
      });
      onDraft(`For the pending request, use these inputs:\n${parts.join("\n")}`); setError("");
    } catch (e) { setError(e instanceof Error ? e.message : "Check the input format."); }
  };
  return <fieldset style={{ margin: ".75rem 0" }}><legend>Required tool inputs</legend>
    {fields.map(field => <div key={field.key}>
      {field.type === "configuration" ? <p>{field.reason}</p> : <label>{field.tool} · {field.name} ({field.reason})
        {field.enum || field.type === "boolean" ? <select aria-label={field.name} value={values[field.key] ?? ""} onChange={e => setValues({ ...values, [field.key]: e.target.value })}><option value="">Choose…</option>{(field.enum ?? [true, false]).map(v => <option key={String(v)} value={String(v)}>{String(v)}</option>)}</select> :
          <input aria-label={field.name} value={values[field.key] ?? ""} onChange={e => setValues({ ...values, [field.key]: e.target.value })} />}
      </label>}
    </div>)}
    <p>Prepare the reply, review it, then Send to continue.</p>
    <button disabled={disabled || fields.some(f => f.type === "configuration")} onClick={draft}>Prepare reply</button>
    {error && <p role="alert">{error}</p>}
  </fieldset>;
}
