import { act } from "react";
import { createRoot } from "react-dom/client";
import type { Root } from "react-dom/client";
import { beforeEach, afterEach, it, expect, vi } from "vitest";
import { ExecutionProgress, RequiredInputs } from "./ExecutionProgress";
import ChatInterface from "./ChatInterface";

const socket = vi.hoisted(() => ({ send: vi.fn(), onMessage: null as null | ((data: unknown) => void) }));
vi.mock("../../api/client", () => ({ apiGet: vi.fn().mockResolvedValue({ agent_name: "backup", display_name: "Backup", capabilities: [], available: true, notice: "" }) }));
vi.mock("../../api/websocket", () => ({ buildWSUrl: (p: string) => p, WSClient: class {
  options: { onOpen: () => void; onMessage: (data: unknown) => void };
  constructor(options: { onOpen: () => void; onMessage: (data: unknown) => void }) { this.options = options; socket.onMessage = options.onMessage; }
  connect() { this.options.onOpen(); } disconnect() {} send(data: unknown) { socket.send(data); }
} }));
let root: Root;
let container: HTMLDivElement;
beforeEach(() => {
  vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true); Element.prototype.scrollIntoView = vi.fn();
  container = document.createElement("div"); document.body.appendChild(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); vi.unstubAllGlobals(); vi.clearAllMocks(); });

it("updates an existing step and retains parallel tool steps without HTML execution", async () => {
  const start = { run_id: "r", step_id: "one", agent_name: "backup", tool_name: "query", status: "running", message: "<img src=x>", elapsed_ms: 100 };
  await act(async () => root.render(<ExecutionProgress events={[start, { ...start, step_id: "two" }, { ...start, status: "completed" }]} />));
  expect(container.querySelectorAll("li")).toHaveLength(2);
  expect(container.querySelector("img")).toBeNull();
  expect(container.textContent).toContain("completed");
  expect(container.textContent).toContain("running");
});

it("validates typed required inputs and prepares a draft only", async () => {
  const draft = vi.fn();
  await act(async () => root.render(<RequiredInputs disabled={false} onDraft={draft} guidance={[{ agent_name: "backup", tool_name: "query", fields: [{ name: "limit", type: "integer", reason: "Required" }] }]} />));
  const button = container.querySelector("button")!;
  await act(async () => button.click());
  expect(draft).not.toHaveBeenCalled();
  const input = container.querySelector("input")!;
  await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!.call(input, "12"); input.dispatchEvent(new Event("input", { bubbles: true })); });
  await act(async () => button.click());
  expect(draft).toHaveBeenCalledWith(expect.stringContaining("limit = 12"));
  expect(socket.send).not.toHaveBeenCalled();
});

it("shows streamed progress without inserting it as an assistant answer", async () => {
  await act(async () => root.render(<ChatInterface agentName="backup" />));
  await act(async () => socket.onMessage!({ type: "execution_progress", run_id: "r", step_id: "one", agent_name: "backup", status: "running", message: "Tool execution started.", elapsed_ms: 100 }));
  expect(container.textContent).toContain("Execution progress");
  expect(container.querySelectorAll(".chat-markdown")).toHaveLength(0);
  await act(async () => socket.onMessage!({ type: "agent_response", content: "Found 4 backups", session_id: "s", input_guidance: [], execution_steps: [] }));
  expect(container.textContent).toContain("Found 4 backups");
  expect(container.querySelectorAll(".chat-markdown")).toHaveLength(1);
});

it("never presents credentials as user-entered fields", async () => {
  await act(async () => root.render(<RequiredInputs disabled={false} onDraft={vi.fn()} guidance={[{ agent_name: "backup", tool_name: "query", fields: [{ name: "administrator_configuration", type: "configuration", reason: "Ask an administrator to configure the credential." }] }]} />));
  expect(container.querySelector("input")).toBeNull();
  expect(container.querySelector("button")!.disabled).toBe(true);
});
