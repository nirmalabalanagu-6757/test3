"""Conversation controls: relational settings, guided execution and isolated traces."""

import asyncio
import json
import sqlite3
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from fastapi import FastAPI
from pydantic import ValidationError
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from backend.config import settings
from backend.database import get_session
from backend.middleware.auth import get_current_user
from backend.models.agent import AgentRegistry
from backend.models.config_model import Configuration
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.models.user import User
from backend.routers.agent_conversation import router
from backend.schemas.agent_conversation import AgentConversationSettings
from backend.services.agent_conversation import assigned_tools, input_issues, load_settings, prepare_tools, select_tools
from backend.services.conversation_runtime import conversation_turn, current_turn


def row(name, description="", schema=None, **extra):
    return ToolRegistry(
        name=name,
        description=description,
        input_schema_json=schema,
        tool_type="function",
        risk_classification="read_only",
        lifecycle_status="active",
        **extra,
    )


@pytest.fixture
def db():
    engine = create_engine("sqlite://")
    for table in (
        AgentRegistry.__table__,
        ToolRegistry.__table__,
        ToolAgentAssignment.__table__,
        Configuration.__table__,
    ):
        table.create(engine)
    session = Session(engine)
    session.add(AgentRegistry(name="backup", product="backup", agent_type="specialized", lifecycle_status="running"))
    session.commit()

    class Adapter:
        async def get(self, model, key):
            return session.get(model, key)

        async def execute(self, stmt):
            return session.execute(stmt)

        async def commit(self):
            session.commit()

        async def flush(self):
            session.flush()

        def add(self, obj):
            session.add(obj)

    yield session, Adapter()
    session.close()
    engine.dispose()


async def test_settings_are_per_agent_and_environment_with_safe_defaults(db):
    session, adapter = db
    enabled = AgentConversationSettings(guided_inputs_enabled=True, tool_selection_enabled=True, progress_enabled=True)
    session.add(
        Configuration(
            key="agent.conversation.backup",
            environment=settings.app_env,
            value=enabled.model_dump_json(),
            schema_type="json",
        )
    )
    session.commit()
    assert await load_settings(adapter, "backup") == enabled
    assert not (await load_settings(adapter, "other")).progress_enabled


@pytest.mark.parametrize(
    "change",
    [
        {"max_tools": 0},
        {"max_tools": 65},
        {"guided_inputs_enabled": "false"},
        {"unknown_setting": True},
        {"progress_detail": "full_secrets"},
    ],
)
def test_invalid_settings_rejected(change):
    with pytest.raises(ValidationError):
        AgentConversationSettings(**change)


def test_shortlist_pins_and_transitive_dependencies():
    rows = [
        row("backup_status", "Show failed backups", {"x-agent-capability": {"requires_tools": ["job_details"]}}),
        row("job_details", "Find job details", {"x-agent-capability": {"requires_tools": ["backup_status"]}}),
        row("list_servers"),
        row("billing_report", "Cloud costs"),
    ]
    profile = AgentConversationSettings(tool_selection_enabled=True, max_tools=1)
    result = select_tools(rows, "show failed backups", profile)
    assert result["selected_tools"] == ["backup_status", "job_details"]
    profile.always_include_tools = ["list_servers"]
    assert select_tools(rows, "show failed backups", profile)["selected_tools"] == sorted(row.name for row in rows)


def test_equal_tool_matches_do_not_hide_a_required_tool():
    rows = [row("first", "Get backup status"), row("second", "Get backup status")]
    result = select_tools(
        rows, "get backup status", AgentConversationSettings(tool_selection_enabled=True, max_tools=1)
    )
    assert result["selected_tools"] == ["first", "second"]
    assert "equally" in result["reason"]


@pytest.mark.parametrize("query", ["yes", "yesterday", "unrecognised extraterrestrial request"])
def test_uncertain_selection_retains_access_to_all_tools(query):
    rows = [row("backup"), row("billing")]
    assert (
        len(
            select_tools(rows, query, AgentConversationSettings(tool_selection_enabled=True, max_tools=1))[
                "selected_tools"
            ]
        )
        == 2
    )


def test_schema_validates_nested_inputs_without_returning_values():
    schema = {
        "properties": {
            "server": {"type": "string"},
            "count": {"type": "integer", "minimum": 1},
            "options": {"type": "object", "properties": {"mode": {"enum": ["daily", "weekly"]}}, "required": ["mode"]},
        },
        "required": ["server"],
    }
    issues = input_issues(schema, {"count": True, "options": {"mode": "wrong"}, "private": "sensitive"})
    assert {i["name"] for i in issues} == {"server", "count", "options.mode"}
    assert "sensitive" not in json.dumps(issues) and "wrong" not in json.dumps(issues)
    assert input_issues(schema, {"server": "A", "count": 2, "options": {"mode": "daily"}}) == []


def test_missing_credentials_never_become_user_inputs():
    issues = input_issues({"properties": {"api_key": {"type": "string"}}, "required": ["api_key"]}, {})
    assert issues[0]["type"] == "configuration"
    assert issues[0]["name"] == "administrator_configuration"


async def test_prepare_filters_tools_before_model_exposure_and_keeps_only_active_assignments(db):
    session, adapter = db
    for name, desc in [("backups", "Find failed backup records"), ("costs", "Find billing expenses")]:
        session.add(row(name, desc))
        session.add(ToolAgentAssignment(agent_name="backup", tool_name=name))
    session.add(row("unassigned", "Find failed backup records"))
    profile = AgentConversationSettings(tool_selection_enabled=True, max_tools=1, progress_enabled=True)
    session.add(
        Configuration(key="agent.conversation.backup", environment=settings.app_env, value=profile.model_dump_json())
    )
    session.commit()

    async def backups():
        pass

    async def costs():
        pass

    async def routing_native():
        pass

    with conversation_turn() as turn:
        tools, _ = await prepare_tools(
            adapter, "backup", [backups, costs, routing_native], "failed backup records", None
        )
        assert [t.__name__ for t in tools] == ["backups", "routing_native"]
        assert turn.events[0]["selected_tools"] == ["backups"]
        assert len(await assigned_tools(adapter, "backup")) == 2


@pytest.fixture
def governed(monkeypatch):
    from backend import database
    from backend.services.audit_log import AuditLogService
    from backend.services.token_manager import TokenManagerService
    from backend.services.tool_registry import ToolRegistryService

    fake_db = AsyncMock()

    class Factory:
        async def __aenter__(self):
            return fake_db

        async def __aexit__(self, *args):
            pass

    monkeypatch.setattr(database, "async_session_factory", Factory)
    monkeypatch.setattr(AuditLogService, "append", AsyncMock())
    authorized = AsyncMock(return_value=(True, "assigned"))
    monkeypatch.setattr(ToolRegistryService, "check_tool_authorized", authorized)
    monkeypatch.setattr(TokenManagerService, "check_budget", AsyncMock(return_value=(True, 100, 100, 0, 0, "")))
    return authorized


async def test_sql_missing_input_then_followup_executes_and_emits_real_step_states(governed):
    from agents.base.callbacks import audit_tool_callback, token_budget_check_callback, tool_governance_callback

    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE backups(server TEXT, status TEXT)")
    conn.execute("INSERT INTO backups VALUES ('A','failed')")
    invoked = []

    async def fetch_backups(server: str):
        invoked.append(server)
        return conn.execute("SELECT status FROM backups WHERE server = ?", (server,)).fetchall()

    tool = SimpleNamespace(name="fetch_backups", func=fetch_backups)
    context = SimpleNamespace(agent_name="backup", function_call_id="call-1")
    profile = AgentConversationSettings(guided_inputs_enabled=True, progress_enabled=True)
    delivered = []

    async def progress(event):
        delivered.append(event)

    with conversation_turn(progress) as turn:
        turn.configure("backup", profile, [], [fetch_backups])
        blocked = await tool_governance_callback(tool=tool, args={}, tool_context=context)
        assert blocked["needs_input"] and not invoked
        clarification = await token_budget_check_callback(callback_context=context)
        assert "server" in clarification.content.parts[0].text
        assert delivered[0]["status"] == "needs_input"
    with conversation_turn(progress) as turn:
        turn.configure("backup", profile, [], [fetch_backups])
        assert await tool_governance_callback(tool=tool, args={"server": "A"}, tool_context=context) is None
        result = await fetch_backups(server="A")
        await audit_tool_callback(tool=tool, args={"server": "A"}, tool_context=context, tool_response=result)
        assert [event["status"] for event in turn.events] == ["running", "completed"]
        assert result == [("failed",)] and invoked == ["A"]
        assert turn.guidance == []
    assert current_turn() is None
    conn.close()


async def test_authorization_still_blocks_tools_before_guidance(governed):
    from agents.base.callbacks import tool_governance_callback

    governed.return_value = (False, "not assigned")
    with conversation_turn() as turn:
        turn.configure("backup", AgentConversationSettings(guided_inputs_enabled=True, progress_enabled=True), [], [])
        response = await tool_governance_callback(
            tool=SimpleNamespace(name="forbidden"), args={}, tool_context=SimpleNamespace(agent_name="backup")
        )
        assert response["blocked"]
        assert turn.events == [] and turn.guidance == []


async def test_mcp_and_rest_envelopes_and_optional_values():
    schema = {"properties": {"job_id": {"type": "integer"}, "limit": {"type": "integer"}}, "required": ["job_id"]}
    item = row("job", schema=schema)
    profile = AgentConversationSettings(guided_inputs_enabled=True, progress_enabled=True)
    for envelope in ["arguments", "body", "query_params", "path_params"]:
        with conversation_turn() as turn:
            turn.configure("backup", profile, [item], [])
            context = SimpleNamespace(function_call_id=envelope)
            assert await turn.before("backup", SimpleNamespace(name="job"), {envelope: {"job_id": 7}}, context) is None
            await turn.after("backup", SimpleNamespace(name="job"), {"success": False}, context)
            assert turn.events[-1]["status"] == "failed"


async def test_concurrent_turns_and_parallel_calls_do_not_share_traces():
    async def run(index):
        with conversation_turn() as turn:
            turn.configure("backup", AgentConversationSettings(progress_enabled=True), [], [])
            tool = SimpleNamespace(name="query")
            contexts = [SimpleNamespace(function_call_id=f"{index}-{i}") for i in range(2)]
            await asyncio.gather(*(turn.before("backup", tool, {}, c) for c in contexts))
            await turn.after("backup", tool, {}, contexts[1])
            await turn.finish()
            return turn.id, turn.events

    first, second = await asyncio.gather(run(1), run(2))
    assert first[0] != second[0]
    assert {event["run_id"] for event in first[1]} == {first[0]}
    assert first[1][-1]["status"] == "failed"


async def test_disabled_features_emit_no_progress_and_do_not_block_inputs():
    with conversation_turn() as turn:
        turn.configure("backup", AgentConversationSettings(), [row("job", schema={"required": ["server"]})], [])
        assert await turn.before("backup", SimpleNamespace(name="job"), {}, None) is None
        await turn.after("backup", SimpleNamespace(name="job"), {}, None)
        assert not turn.events and not turn.guidance


async def test_admin_api_save_reload_preview_and_reject_unassigned_tools(db, monkeypatch):
    from backend.services.configuration import ConfigurationService

    session, adapter = db
    session.add(row("backups", "Find failed backups"))
    session.add(ToolAgentAssignment(tool_name="backups", agent_name="backup"))
    session.commit()

    async def set_config(self, db, key, value, environment, **kwargs):
        record = session.get(Configuration, (key, environment))
        if record:
            record.value = value
        else:
            session.add(Configuration(key=key, value=value, environment=environment))

    monkeypatch.setattr(ConfigurationService, "set_config", set_config)
    app = FastAPI()
    app.include_router(router)
    app.dependency_overrides[get_session] = lambda: adapter
    app.dependency_overrides[get_current_user] = lambda: User(user_id="1", username="admin", role="admin", active=True)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client:
        data = AgentConversationSettings(guided_inputs_enabled=True, progress_enabled=True).model_dump()
        assert (await client.put("/api/agents/backup/conversation-settings", json=data)).status_code == 200
        assert (await client.get("/api/agents/backup/conversation-settings")).json()["guided_inputs_enabled"]
        assert (
            await client.post("/api/agents/backup/tool-selection-preview", json={"query": "failed backups"})
        ).json()["selected_tools"] == ["backups"]
        data["always_include_tools"] = ["unassigned"]
        assert (await client.put("/api/agents/backup/conversation-settings", json=data)).status_code == 422
        data["always_include_tools"] = []
        data["capability_overrides"] = {"backups": {"title": "Bearer secret"}}
        assert (await client.put("/api/agents/backup/conversation-settings", json=data)).status_code == 422
        app.dependency_overrides[get_current_user] = lambda: User(
            user_id="2", username="viewer", role="user", active=True
        )
        # Role rejection uses existing audit logging; stub it to keep this test offline.
        from backend.middleware import auth

        monkeypatch.setattr(auth._audit_service, "append", AsyncMock())
        assert (await client.put("/api/agents/backup/conversation-settings", json=data)).status_code == 403
        assert (await client.get("/api/agents/missing/conversation-settings")).status_code == 404


async def test_claude_sonnet_adapter_real_adk_guided_tool_roundtrip(governed, monkeypatch):
    """Use the real Claude adapter and ADK runner with mocked provider HTTP responses."""
    from google.adk.agents import LlmAgent
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
    from google.genai import types

    from agents.base import anthropic_llm
    from agents.base.callbacks import audit_tool_callback, token_budget_check_callback, tool_governance_callback

    provider_calls = []
    executed = []

    async def backup_query(server: str) -> dict:
        """Read backup results for a server."""
        executed.append(server)
        return {"server": server, "failed": 1}

    def respond(request):
        body = json.loads(request.content)
        provider_calls.append(body)
        assert body["model"] == "claude-sonnet-4-6"
        assert [tool["name"] for tool in body["tools"]] == ["backup_query"]
        latest = body["messages"][-1]["content"]
        if any(block.get("type") == "tool_result" for block in latest):
            content = [{"type": "text", "text": "One failed backup on server A."}]
            stop = "end_turn"
        else:
            followup = any("server A" in block.get("text", "") for block in latest)
            content = [
                {
                    "type": "tool_use",
                    "name": "backup_query",
                    "id": f"call_{len(provider_calls)}",
                    "input": {"server": "A"} if followup else {},
                }
            ]
            stop = "tool_use"
        return httpx.Response(200, json={"content": content, "stop_reason": stop, "model": body["model"]})

    actual_client = httpx.AsyncClient
    monkeypatch.setattr(
        anthropic_llm.httpx,
        "AsyncClient",
        lambda **kwargs: actual_client(transport=httpx.MockTransport(respond), **kwargs),
    )
    monkeypatch.setattr(anthropic_llm, "_use_vertex_ai", lambda: False)
    monkeypatch.setattr(anthropic_llm, "_resolve_api_key", AsyncMock(return_value="offline-test-key"))
    monkeypatch.setattr(anthropic_llm, "_increment_model_usage", AsyncMock())
    agent = LlmAgent(
        name="backup",
        model=anthropic_llm.AnthropicLlm(model="claude-sonnet-4-6"),
        instruction="Use the backup query. Ask for missing inputs.",
        tools=[backup_query],
        before_tool_callback=tool_governance_callback,
        after_tool_callback=audit_tool_callback,
        before_model_callback=token_budget_check_callback,
    )
    sessions = InMemorySessionService()
    await sessions.create_session(app_name="conversation_test", user_id="user", session_id="s")
    runner = Runner(agent=agent, app_name="conversation_test", session_service=sessions)
    profile = AgentConversationSettings(guided_inputs_enabled=True, progress_enabled=True)

    async def run(prompt):
        with conversation_turn() as turn:
            turn.configure("backup", profile, [], [backup_query])
            events = [
                event
                async for event in runner.run_async(
                    user_id="user",
                    session_id="s",
                    new_message=types.Content(role="user", parts=[types.Part(text=prompt)]),
                )
            ]
            return turn, events

    first, events = await run("Show failed backups")
    assert first.guidance and not executed
    assert len(provider_calls) == 1  # Clarification does not make another model call.
    assert "server" in events[-1].content.parts[0].text
    second, events = await run("Use server A")
    assert executed == ["A"]
    assert [event["status"] for event in second.events] == ["running", "completed"]
    assert "One failed backup" in events[-1].content.parts[0].text


async def test_chat_service_streams_progress_and_returns_snapshot_without_extra_sessions(monkeypatch):
    from backend.schemas.chat import ChatMessage
    from backend.services.chat import ChatService
    from backend.services.intent_learning import IntentLearningService

    monkeypatch.setattr(IntentLearningService, "observe", AsyncMock())
    service = ChatService(audit_log=SimpleNamespace(append=AsyncMock()))
    service.check_agent_available = AsyncMock(
        return_value=SimpleNamespace(
            lifecycle_status="running",
            generate_content_config_json=None,
            reasoning_config_json=None,
            allow_world_knowledge=False,
            last_used_at=None,
        )
    )
    service.get_or_create_session = AsyncMock(return_value=("session", 1))
    service._token_mgr.get_session_latest_usage = AsyncMock(return_value=(0, 0))

    async def invoke(*args, **kwargs):
        turn = current_turn()
        turn.configure("backup", AgentConversationSettings(progress_enabled=True), [], [])
        tool, context = SimpleNamespace(name="query"), SimpleNamespace(function_call_id="one")
        await turn.before("backup", tool, {}, context)
        await turn.after("backup", tool, {}, context)
        return "One failed backup", {"backup": ["query"]}, None

    service.invoke_agent = invoke
    delivered = AsyncMock()
    response = await service.handle_message(
        AsyncMock(), "backup", ChatMessage(content="failed backups"), progress_callback=delivered
    )
    assert delivered.await_count == 2
    assert [event["status"] for event in response.execution_steps] == ["running", "completed"]
    assert response.content == "One failed backup" and response.execution_run_id
    assert current_turn() is None
