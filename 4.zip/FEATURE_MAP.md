# Where the complete feature lives

Use MANIFEST.json for exact archive paths; file names here refer to target application paths.

| Feature | Primary backend files | Primary frontend files |
|---|---|---|
| Approved intent rules and scope | services/intent_control.py; schemas/intent.py; models/intent.py; routers/intents.py | IntentControlManager.tsx; IntentControlPage.tsx |
| Multi-agent/multi-tool execution | services/intent_orchestrator.py; intent_parameters.py; utils/intent_bindings.py | Workflow controls and run history in IntentControlManager |
| Universal Action Templates | services/action_template.py; models/schemas/routers/action_template(s).py | ActionTemplateRegistry.tsx |
| Actual tool trace capture | services/intent_trace.py; intent_workflow_learning.py; agents/base/callbacks.py; agent_runner.py | Observed call details in IntentLearningCandidates |
| Learning and action drafts | services/intent_learning.py; intent_action_drafts.py; intent_review.py | IntentLearningCandidates.tsx |
| NEW single-package review | services/intent_learning_review.py; routers/schemas/intent_learning.py | IntentLearningCandidates.tsx |
| NEW bounded assisted matching | services/intent_learning_matching.py; models/schemas/intent_matching.py; migration 033 | IntentLearningMatchingSettings.tsx |
| Readiness / shadow checks | services/intent_assurance.py | Assurance controls in IntentControlManager |
| Golden tests and revisions | services/intent_validation.py; models/schemas/routers/intent_validation.py; migration 032 | IntentValidationPanel.tsx |
| Separate Model Compatibility | services/intent_model_comparison.py; existing model registry/adapters | ModelCompatibilityPanel.tsx; ModelCompatibilityPage.tsx |
| Claude protocol | agents/base/anthropic_llm.py | Model selection through existing registry UI |
| Integration | Agent registry/runner/chat/callbacks; ORM model registration | App.tsx; DashboardPage.tsx; AgentRegistryTable.tsx |

## Two different flows

**Execution:** prompt → eligible approved intent resolution → validated fresh parameters → exact approved tools/workflow → fresh results → configured response. If genuinely unmatched, the existing governed agent path may run and produce learning evidence.

**Learning:** successful observed calls → guarded candidate grouping / optional bounded suggestions → complete review package → non-publishing validation → **one human Approve & Publish** → linked intent/action/response/Golden configuration.

Semantic suggestions affect the second flow only in this release. They do not auto-approve or silently replace live runtime routing. Response configuration belongs to the intent version; Model Compatibility is a separate model-evaluation flow, not the learning comparator.
