# Test plan, source evidence and target acceptance

## Source verification rerun while packaging — 2026-09-29

- **161 selected backend regression tests passed**, including the opt-in PostgreSQL tests in isolated rolled-back schemas.
- **21 frontend tests passed** in the complete existing host; 17 are the feature/component tests supplied in this ZIP, while four existing authenticated API-client tests remain in the host because that implementation is deliberately excluded.
- TypeScript/Vite production build passed. The existing main-bundle size warning remains (about 708 kB before gzip); this is not an all-repository lint-clean claim.
- Latest implementation had focused Ruff/ESLint and git diff --check passes. Source files copied into the ZIP are checked against the current source bytes, and every ZIP entry is read back and compared during packaging.
- No paid models, downloaded embedding weights or real customer tool executions were used. Embeddings and provider replies were mocked. Database tests use synthetic records, not approvals of customer candidates.

These results describe the reference repository. They do not prove a Claude merge into a different repository works without its own test run. The ZIP is not a standalone host application.

## Backend regression command in the merged host

Use its Python environment and dependency setup. For ordinary offline tests omit the database opt-in. The database helpers specifically require a local PostgreSQL host and must not be repointed at a shared OCP database.

```bash
# Only for the authorized isolated local PostgreSQL test environment:
export INTENT_TEST_LOCAL_DB=1
python -m pytest \
  tests/test_intent_control.py \
  tests/test_intent_learning.py \
  tests/test_intent_workflow_learning.py \
  tests/test_intent_validation.py \
  tests/test_intent_orchestrator.py \
  tests/test_intent_learning_database.py \
  tests/test_intent_validation_database.py \
  tests/test_learning_review_database.py \
  tests/test_intent_learning_matching.py \
  tests/test_agent_runner_intent_runtime.py \
  tests/test_sample_intent_workflows.py \
  tests/test_action_templates.py \
  tests/test_claude_sonnet_compatibility.py \
  tests/test_model_compatibility.py -q
```

On PowerShell set `$env:INTENT_TEST_LOCAL_DB='1'` instead of `export`. If using Git Bash on Windows, activate/use your existing Windows virtual environment. Do not hard-code a nonexistent `/root/.../venv/bin/alembic` path.

## Frontend commands in the merged host

```bash
cd frontend
npm test -- --run
npm run build
```

Use the target's lockfile and installation workflow. Preserve its auth/client tests. Test counts may differ after integration; report exact commands/results and explain skips rather than copying the reference counts.

## Required acceptance scenarios

1. Same supported request, polite paraphrase and different schema-declared server/date values group appropriately without a comparison LLM call.
2. Latest/all, read/restore/delete, success/failure filters, negation and aggregation differences do not get merged merely because the same tool is used.
3. Different agents, tools/connections, workflow/action versions or dependency contracts stay distinct. Unknown or ambiguous connection names do not resolve to a guessed default.
4. Repeated calls to one tool remain distinct steps. Multi-tool/multi-agent workflows use fresh upstream results with correct dependencies. No old response data is replayed.
5. A clear mocked semantic match uses no comparator call; near ties remain uncertain. Preview records but does not apply suggestions. No local model means semantic search is unavailable, not silently installed.
6. Optional LLM comparison has no executable tools, strict offered IDs/output parsing, explicit enablement, a one-attempt bound and limited payload. Cache reuse/invalidation, timeout, provider failure, inactive models and exhausted budgets are exercised.
7. Reservations are global across workers using the same app database and survive learning rollback. Test concurrent requests in the target environment as part of load verification; do not claim sequential unit tests alone establish every concurrency/deployment property.
8. Complete-package validation publishes nothing. One approval saves intent/actions/response configuration/optional Golden suite together. Bad Golden results, missing bindings or conflicts leave no partial publication.
9. Candidate/dependency edits invalidate review snapshots. UI edits invalidate a previous PASS; duplicate clicking produces one approval request. Old API clients missing the token receive validation errors.
10. Existing immutable actions are reused; changes require reviewed new versions. Candidate deletion preserves published records, and restore is a review proposal rather than immediate activation.
11. Backend/page admin guards remain enforced. SSO, existing roles, authenticated client behavior and unrelated navigation remain intact.
12. Model Compatibility stays separate: synthetic tools, per-run consent, bounds, unknown usage labeling, unsupported-case REVIEW and no provider call on page load/history.
13. Claude/Vertex system/schema/tool-ID/thinking/usage protocol tests pass before any separately authorized live Sonnet check.
14. Target migration graph and missing-schema plan are checked in an isolated database; upgraded backend/frontend health is verified only after authorized rollout.

## Not established by this package

Actual OCP deployment, live Claude Sonnet 4.6/provider credentials, customer SQL/API correctness, quality of a real installed embedding model, calibrated thresholds for every agent, universal prompt recognition and 100% production robustness remain environment-specific work. Report those limits honestly.
