/**
 * ModelsPage — Dashboard sub-route for LLM Model Registry.
 */

import ModelManager from "../../components/dashboard/ModelManager";

export default function ModelsPage() {
  return (
    <div>
      <h2 style={{ marginBottom: "1rem", fontSize: "1.25rem" }}>Model Registry</h2>
      <ModelManager />
    </div>
  );
}
