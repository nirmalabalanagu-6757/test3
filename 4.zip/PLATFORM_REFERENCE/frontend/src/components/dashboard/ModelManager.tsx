/**
 * ModelManager — CRUD management for the LLM Model Registry.
 *
 * Features:
 *   - List models with provider / status filters
 *   - Register new models (name, provider, API key, endpoint, defaults)
 *   - Edit model settings (update key, params, enable/disable)
 *   - Delete models
 *   - Mark a model as default
 */

import { useEffect, useState, useCallback, useMemo } from "react";
import { apiGet, apiPost, apiPut, apiDelete } from "../../api/client";
import { type SortState, toggleSort, sorted, SortIndicator } from "../../utils/tableSort";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface Model {
  name: string;
  provider: string;
  description: string | null;
  api_key_set: boolean;
  endpoint_url: string | null;
  default_temperature: number | null;
  default_max_tokens: number | null;
  invocation_count: number;
  is_default: boolean;
  status: string;
  registered_at: string;
  updated_at: string;
  last_used_at: string | null;
}

interface ModelListResponse { models: Model[]; count: number; }

/* ------------------------------------------------------------------ */
/* Styles                                                              */
/* ------------------------------------------------------------------ */

const REFRESH_INTERVAL = 15_000;

const th: React.CSSProperties = {
  textAlign: "left", padding: "0.5rem 0.75rem", borderBottom: "2px solid var(--color-border)",
  color: "var(--color-text-muted)", fontWeight: 600, fontSize: "0.6875rem", textTransform: "uppercase",
  letterSpacing: "0.05em", whiteSpace: "nowrap", cursor: "pointer", userSelect: "none",
};
const td: React.CSSProperties = { padding: "0.5rem 0.75rem", borderBottom: "1px solid var(--color-border)", verticalAlign: "middle" };
const btn: React.CSSProperties = {
  padding: "0.3rem 0.625rem", borderRadius: "0.25rem", border: "1px solid var(--color-border)",
  background: "var(--color-surface)", cursor: "pointer", fontSize: "0.75rem", fontWeight: 500, color: "var(--color-text)",
};
const btnPrimary: React.CSSProperties = { ...btn, background: "var(--color-primary)", color: "var(--color-on-primary)", border: "1px solid var(--color-primary)" };
const btnDanger: React.CSSProperties = { ...btn, color: "var(--color-error)", border: "1px solid var(--color-error)" };
const input: React.CSSProperties = {
  padding: "0.375rem 0.625rem", border: "1px solid var(--color-border)", borderRadius: "0.25rem",
  fontSize: "0.8125rem", background: "var(--color-bg)", color: "var(--color-text)", width: "100%", boxSizing: "border-box" as const,
};
const selectStyle: React.CSSProperties = { ...input, width: "auto", minWidth: "120px" };
const overlay: React.CSSProperties = {
  position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center",
  justifyContent: "center", zIndex: 1000, padding: "2rem",
};
const modal: React.CSSProperties = {
  background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: "0.5rem",
  width: "100%", maxWidth: "560px", overflow: "hidden", maxHeight: "90vh", display: "flex", flexDirection: "column",
};
const modalHeader: React.CSSProperties = {
  display: "flex", justifyContent: "space-between", alignItems: "center", padding: "1rem 1.25rem",
  borderBottom: "1px solid var(--color-border)", flexShrink: 0,
};
const modalBody: React.CSSProperties = { padding: "1.25rem", overflow: "auto", flex: 1 };
const modalFooter: React.CSSProperties = {
  display: "flex", gap: "0.5rem", justifyContent: "flex-end", padding: "0.75rem 1.25rem",
  borderTop: "1px solid var(--color-border)", flexShrink: 0,
};
const section: React.CSSProperties = {
  background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: "0.375rem",
  padding: "1rem", marginBottom: "1rem",
};
const labelSm: React.CSSProperties = {
  display: "block", fontSize: "0.6875rem", fontWeight: 600, color: "var(--color-text-muted)", marginBottom: "0.25rem",
};
const badge = (bg: string, fg: string, border: string): React.CSSProperties => ({
  padding: "0.125rem 0.5rem", borderRadius: "9999px", fontSize: "0.6875rem", fontWeight: 600,
  background: bg, color: fg, border: `1px solid ${border}`, display: "inline-block",
});

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function providerBadge(p: string) {
  switch (p) {
    case "google": return badge("var(--color-info-surface)", "var(--color-info)", "var(--color-info)");
    case "openai": return badge("var(--color-success-surface)", "var(--color-success)", "var(--color-success)");
    case "anthropic": return badge("var(--color-warning-surface)", "var(--color-warning)", "var(--color-warning)");
    case "azure": return badge("rgba(134, 168, 233, 0.12)", "var(--color-primary)", "var(--color-primary)");
    default: return badge("var(--color-surface-raised)", "var(--color-text-muted)", "var(--color-border)");
  }
}

function statusBadge(s: string) {
  return s === "active" ? badge("var(--color-success-surface)", "var(--color-success)", "var(--color-success)") : badge("var(--color-surface-raised)", "var(--color-text-muted)", "var(--color-border)");
}

function formatTs(ts: string): string {
  return new Date(ts).toLocaleString();
}

const PROVIDERS = ["google", "openai", "anthropic", "azure", "custom"];

/* ------------------------------------------------------------------ */
/* Register Modal                                                      */
/* ------------------------------------------------------------------ */

function RegisterModelModal({ onCreated, onClose }: { onCreated: () => void; onClose: () => void }) {
  const [name, setName] = useState("");
  const [provider, setProvider] = useState("google");
  const [description, setDescription] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [endpointUrl, setEndpointUrl] = useState("");
  const [temperature, setTemperature] = useState("");
  const [maxTokens, setMaxTokens] = useState("");
  const [isDefault, setIsDefault] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCreate = async () => {
    if (!name.trim()) { setError("Name is required"); return; }
    setSaving(true); setError(null);
    try {
      await apiPost("/models", {
        name: name.trim(),
        provider,
        description: description.trim() || null,
        api_key: apiKey.trim() || null,
        endpoint_url: endpointUrl.trim() || null,
        default_temperature: temperature ? parseFloat(temperature) : null,
        default_max_tokens: maxTokens ? parseInt(maxTokens, 10) : null,
        is_default: isDefault,
      });
      onCreated();
    } catch (e: any) { setError(e?.message ?? "Failed to register model"); } finally { setSaving(false); }
  };

  return (
    <div style={overlay} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={modal}>
        <div style={modalHeader}>
          <strong style={{ fontSize: "1rem" }}>Register New Model</strong>
          <button style={{ ...btn, fontSize: "1rem", lineHeight: 1, padding: "0.25rem 0.5rem" }} onClick={onClose}>&times;</button>
        </div>
        <div style={modalBody}>
          <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
            <div style={{ display: "flex", gap: "0.75rem" }}>
              <div style={{ flex: 2 }}>
                <label style={labelSm}>Model Name *</label>
                <input style={input} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. gemini-2.5-flash" />
              </div>
              <div style={{ flex: 1 }}>
                <label style={labelSm}>Provider</label>
                <select style={selectStyle} value={provider} onChange={(e) => setProvider(e.target.value)}>
                  {PROVIDERS.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label style={labelSm}>Description</label>
              <input style={input} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Optional description" />
            </div>
            <div>
              <label style={labelSm}>API Key</label>
              <input style={input} type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="Provider API key" />
            </div>
            <div>
              <label style={labelSm}>Endpoint URL</label>
              <input style={input} value={endpointUrl} onChange={(e) => setEndpointUrl(e.target.value)} placeholder="Leave blank for provider default" />
            </div>
            <div style={{ display: "flex", gap: "0.75rem" }}>
              <div style={{ flex: 1 }}>
                <label style={labelSm}>Default Temperature</label>
                <input style={input} type="number" step="0.1" min="0" max="2" value={temperature} onChange={(e) => setTemperature(e.target.value)} placeholder="e.g. 0.7" />
              </div>
              <div style={{ flex: 1 }}>
                <label style={labelSm}>Default Max Tokens</label>
                <input style={input} type="number" min="1" value={maxTokens} onChange={(e) => setMaxTokens(e.target.value)} placeholder="e.g. 8192" />
              </div>
            </div>
            <label style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.8125rem", cursor: "pointer" }}>
              <input type="checkbox" checked={isDefault} onChange={(e) => setIsDefault(e.target.checked)} />
              Set as default model for new agents
            </label>
          </div>
          {error && <p style={{ color: "var(--color-error)", fontSize: "0.8125rem", marginTop: "0.75rem" }}>{error}</p>}
        </div>
        <div style={modalFooter}>
          <button style={btn} onClick={onClose}>Cancel</button>
          <button style={btnPrimary} onClick={handleCreate} disabled={saving}>{saving ? "Registering..." : "Register Model"}</button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Edit Modal                                                          */
/* ------------------------------------------------------------------ */

function EditModelModal({ model, onUpdated, onClose }: { model: Model; onUpdated: () => void; onClose: () => void }) {
  const [description, setDescription] = useState(model.description ?? "");
  const [apiKey, setApiKey] = useState("");
  const [endpointUrl, setEndpointUrl] = useState(model.endpoint_url ?? "");
  const [temperature, setTemperature] = useState(model.default_temperature?.toString() ?? "");
  const [maxTokens, setMaxTokens] = useState(model.default_max_tokens?.toString() ?? "");
  const [isDefault, setIsDefault] = useState(model.is_default);
  const [status, setStatus] = useState(model.status);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    setSaving(true); setError(null);
    const payload: Record<string, unknown> = {
      description: description.trim() || null,
      endpoint_url: endpointUrl.trim() || null,
      default_temperature: temperature ? parseFloat(temperature) : null,
      default_max_tokens: maxTokens ? parseInt(maxTokens, 10) : null,
      is_default: isDefault,
      status,
    };
    // Only include api_key if user entered a new one
    if (apiKey.trim()) payload.api_key = apiKey.trim();

    try {
      await apiPut(`/models/${encodeURIComponent(model.name)}`, payload);
      onUpdated();
    } catch (e: any) { setError(e?.message ?? "Failed to save"); } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!window.confirm(`Delete model "${model.name}"? Agents referencing this model will need to be updated.`)) return;
    setSaving(true); setError(null);
    try {
      await apiDelete(`/models/${encodeURIComponent(model.name)}`);
      onUpdated();
    } catch (e: any) { setError(e?.message ?? "Failed to delete"); } finally { setSaving(false); }
  };

  return (
    <div style={overlay} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={modal}>
        <div style={modalHeader}>
          <div>
            <strong style={{ fontSize: "1rem" }}>{model.name}</strong>
            <span style={{ marginLeft: "0.5rem", ...providerBadge(model.provider) }}>{model.provider}</span>
            {model.is_default && <span style={{ marginLeft: "0.375rem", ...badge("rgba(134, 168, 233, 0.12)", "var(--color-primary)", "var(--color-primary)") }}>default</span>}
          </div>
          <button style={{ ...btn, fontSize: "1rem", lineHeight: 1, padding: "0.25rem 0.5rem" }} onClick={onClose}>&times;</button>
        </div>
        <div style={modalBody}>
          <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
            <div>
              <label style={labelSm}>Description</label>
              <input style={input} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div>
              <label style={labelSm}>API Key {model.api_key_set && <span style={{ color: "var(--color-success)", fontWeight: 400 }}>(configured)</span>}</label>
              <input style={input} type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder={model.api_key_set ? "Leave blank to keep current key" : "Enter API key"} />
            </div>
            <div>
              <label style={labelSm}>Endpoint URL</label>
              <input style={input} value={endpointUrl} onChange={(e) => setEndpointUrl(e.target.value)} placeholder="Leave blank for provider default" />
            </div>
            <div style={{ display: "flex", gap: "0.75rem" }}>
              <div style={{ flex: 1 }}>
                <label style={labelSm}>Default Temperature</label>
                <input style={input} type="number" step="0.1" min="0" max="2" value={temperature} onChange={(e) => setTemperature(e.target.value)} />
              </div>
              <div style={{ flex: 1 }}>
                <label style={labelSm}>Default Max Tokens</label>
                <input style={input} type="number" min="1" value={maxTokens} onChange={(e) => setMaxTokens(e.target.value)} />
              </div>
            </div>
            <div style={{ display: "flex", gap: "0.75rem" }}>
              <div style={{ flex: 1 }}>
                <label style={labelSm}>Status</label>
                <select style={selectStyle} value={status} onChange={(e) => setStatus(e.target.value)}>
                  <option value="active">Active</option>
                  <option value="disabled">Disabled</option>
                </select>
              </div>
              <div style={{ flex: 1, display: "flex", alignItems: "flex-end", paddingBottom: "0.25rem" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.8125rem", cursor: "pointer" }}>
                  <input type="checkbox" checked={isDefault} onChange={(e) => setIsDefault(e.target.checked)} />
                  Default model
                </label>
              </div>
            </div>
            <div style={{ display: "flex", gap: "0.75rem", fontSize: "0.75rem", color: "var(--color-text-muted)" }}>
              <span>Registered: {formatTs(model.registered_at)}</span>
              <span>Updated: {formatTs(model.updated_at)}</span>
            </div>
          </div>
          {error && <p style={{ color: "var(--color-error)", fontSize: "0.8125rem", marginTop: "0.75rem" }}>{error}</p>}
        </div>
        <div style={modalFooter}>
          <button style={btnDanger} onClick={handleDelete} disabled={saving}>Delete</button>
          <div style={{ flex: 1 }} />
          <button style={btn} onClick={onClose}>Cancel</button>
          <button style={btnPrimary} onClick={handleSave} disabled={saving}>{saving ? "Saving..." : "Save Changes"}</button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Main component                                                      */
/* ------------------------------------------------------------------ */

type ModelSortKey = "name" | "provider" | "invocation_count" | "status" | "last_used_at" | "registered_at";

interface TestResult {
  status: "running" | "ok" | "error";
  latency_ms?: number;
  response?: string;
  error?: string;
}

export default function ModelManager() {
  const [models, setModels] = useState<Model[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showRegister, setShowRegister] = useState(false);
  const [selectedModel, setSelectedModel] = useState<Model | null>(null);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortState<ModelSortKey>>({ key: "name", dir: "asc" });
  const [testResults, setTestResults] = useState<Record<string, TestResult>>({});

  const runTest = useCallback(async (modelName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setTestResults((prev) => ({ ...prev, [modelName]: { status: "running" } }));
    try {
      const res = await apiPost<{ status: string; response: string; latency_ms: number }>(`/models/${encodeURIComponent(modelName)}/test`);
      setTestResults((prev) => ({ ...prev, [modelName]: { status: "ok", latency_ms: res.latency_ms, response: res.response } }));
    } catch (err: any) {
      let msg = "Test failed";
      try {
        const body = JSON.parse(err?.message ?? "");
        if (typeof body.error === "string") msg = body.error;
        else if (body.error?.message) msg = body.error.message;
      } catch {
        if (err?.message) msg = err.message;
      }
      setTestResults((prev) => ({ ...prev, [modelName]: { status: "error", error: msg } }));
    }
  }, []);

  const filtered = useMemo(() => {
    if (!search.trim()) return models;
    const q = search.toLowerCase();
    return models.filter(
      (m) => m.name.toLowerCase().includes(q) || m.provider.toLowerCase().includes(q) || (m.description ?? "").toLowerCase().includes(q)
    );
  }, [models, search]);

  const sortedModels = useMemo(() => sorted(filtered, sort.key, sort.dir), [filtered, sort]);

  const fetchData = useCallback(async () => {
    try {
      const data = await apiGet<ModelListResponse>("/models");
      setModels(data.models);
      setError(null);
    } catch { setError("Failed to load models"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); const id = setInterval(fetchData, REFRESH_INTERVAL); return () => clearInterval(id); }, [fetchData]);

  if (loading) return <p style={{ color: "var(--color-text-muted)" }}>Loading models...</p>;
  if (error) return <p style={{ color: "var(--color-error)" }}>{error}</p>;

  return (
    <div>
      <div style={{ display: "flex", gap: "0.75rem", alignItems: "center", marginBottom: "1rem" }}>
        <div style={{ position: "relative", flex: 1, maxWidth: "360px" }}>
          <input
            style={{ ...input, paddingLeft: "2rem" }}
            placeholder="Search models..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span style={{ position: "absolute", left: "0.625rem", top: "50%", transform: "translateY(-50%)", color: "var(--color-text-muted)", fontSize: "0.875rem", pointerEvents: "none" }}>&#x1F50D;</span>
        </div>
        <span style={{ fontSize: "0.75rem", color: "var(--color-text-muted)" }}>
          {filtered.length} of {models.length} model{models.length !== 1 ? "s" : ""}
        </span>
        <button style={btnPrimary} onClick={() => setShowRegister(true)}>+ Register Model</button>
      </div>

      {filtered.length === 0 ? (
        <p style={{ color: "var(--color-text-muted)", padding: "1rem 0" }}>
          {search ? "No models match your search." : "No models registered. Click \"Register Model\" to add one."}
        </p>
      ) : (
        <div style={{ ...section, padding: 0, overflow: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.8125rem" }}>
            <thead>
              <tr>
                {([["name", "Name", th], ["provider", "Provider", th], ["invocation_count", "Usage", th], ["status", "Status", th], ["last_used_at", "Last Used", th], ["registered_at", "Registered", th]] as [ModelSortKey, string, React.CSSProperties][]).map(([k, label, s]) => (
                  <th key={k} style={s} onClick={() => setSort(p => toggleSort(p, k))}>
                    {label}<SortIndicator active={sort.key === k} dir={sort.dir} />
                  </th>
                ))}
                <th style={{ ...th, cursor: "default" }}>Test</th>
              </tr>
            </thead>
            <tbody>
              {sortedModels.map((m) => {
                const tr = testResults[m.name];
                return (
                <tr
                  key={m.name}
                  onClick={() => setSelectedModel(m)}
                  style={{ cursor: "pointer", transition: "background 0.1s" }}
                  onMouseEnter={(e) => e.currentTarget.style.background = "rgba(0,32,91,0.06)"}
                  onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                >
                  <td style={td}>
                    <strong>{m.name}</strong>
                    {m.is_default && <span style={{ marginLeft: "0.375rem", ...badge("rgba(134, 168, 233, 0.12)", "var(--color-primary)", "var(--color-primary)") }}>default</span>}
                    {m.description && <div style={{ fontSize: "0.6875rem", color: "var(--color-text-muted)", marginTop: "0.125rem" }}>{m.description}</div>}
                  </td>
                  <td style={td}><span style={providerBadge(m.provider)}>{m.provider}</span></td>
                  <td style={{ ...td, textAlign: "center", fontWeight: 600 }}>{m.invocation_count}</td>
                  <td style={td}><span style={statusBadge(m.status)}>{m.status}</span></td>
                  <td style={{ ...td, fontSize: "0.75rem", color: "var(--color-text-muted)", whiteSpace: "nowrap" }}>
                    {m.last_used_at ? formatTs(m.last_used_at) : "—"}
                  </td>
                  <td style={{ ...td, fontSize: "0.75rem", color: "var(--color-text-muted)", whiteSpace: "nowrap" }}>{formatTs(m.registered_at)}</td>
                  <td style={{ ...td, textAlign: "center" }}>
                    <button
                      style={{
                        background: "none",
                        border: "none",
                        cursor: tr?.status === "running" ? "wait" : "pointer",
                        padding: "0.25rem",
                        borderRadius: "0.25rem",
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "0.25rem",
                        color: tr?.status === "ok" ? "var(--color-success)" : tr?.status === "error" ? "var(--color-error)" : "var(--color-text-muted)",
                        transition: "color 0.15s",
                      }}
                      title={tr?.status === "ok" ? `OK — ${tr.latency_ms}ms` : tr?.status === "error" ? tr.error : "Run quick test"}
                      onClick={(e) => runTest(m.name, e)}
                      disabled={tr?.status === "running"}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                        style={tr?.status === "running" ? { animation: "spin 1s linear infinite" } : undefined}
                      >
                        <path d="M23 4v6h-6" /><path d="M1 20v-6h6" />
                        <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                      </svg>
                      {tr?.status === "ok" && <span style={{ fontSize: "0.625rem", fontWeight: 600 }}>{tr.latency_ms}ms</span>}
                    </button>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modals */}
      {showRegister && (
        <RegisterModelModal
          onCreated={() => { setShowRegister(false); fetchData(); }}
          onClose={() => setShowRegister(false)}
        />
      )}
      {selectedModel && (
        <EditModelModal
          model={selectedModel}
          onUpdated={() => { setSelectedModel(null); fetchData(); }}
          onClose={() => setSelectedModel(null)}
        />
      )}
    </div>
  );
}
