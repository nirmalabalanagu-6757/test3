"""Pydantic schemas for Communication Policy CRUD, import/export, graph, and compliance."""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# CRUD schemas
# ---------------------------------------------------------------------------


class PolicyCreate(BaseModel):
    """Schema for creating a new communication policy."""

    source_agent: str = Field(
        ..., min_length=1, max_length=128,
        description="Source agent name or '*' for wildcard",
    )
    target_agent: str = Field(
        ..., min_length=1, max_length=128,
        description="Target agent name or '*' for wildcard",
    )
    action: Literal["allow", "deny"] = Field(..., description="allow or deny")
    priority: int = Field(0, ge=0, description="Higher priority wins on conflict")
    justification: str | None = Field(None, description="Reason for this policy")


class PolicyUpdate(BaseModel):
    """Schema for updating an existing policy (all fields optional)."""

    source_agent: str | None = Field(None, min_length=1, max_length=128)
    target_agent: str | None = Field(None, min_length=1, max_length=128)
    action: Literal["allow", "deny"] | None = None
    priority: int | None = Field(None, ge=0)
    justification: str | None = None


class PolicyResponse(BaseModel):
    """Schema for returning a single policy."""

    id: str
    source_agent: str
    target_agent: str
    action: str
    priority: int
    justification: str | None
    created_by: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class PolicyListResponse(BaseModel):
    """Schema for returning a list of policies."""

    policies: list[PolicyResponse]
    count: int
    default_policy: str = Field(
        description="The default policy when no rule matches: 'allow' or 'deny'",
    )


# ---------------------------------------------------------------------------
# Policy decision
# ---------------------------------------------------------------------------


class PolicyDecision(BaseModel):
    """Result of checking a communication policy."""

    source_agent: str
    target_agent: str
    decision: Literal["allow", "deny"]
    matched_rule_id: str | None = Field(
        None, description="ID of the rule that matched, or None if default",
    )
    reason: str


# ---------------------------------------------------------------------------
# Graph
# ---------------------------------------------------------------------------


class PolicyGraphNode(BaseModel):
    """A node in the policy graph representing an agent."""

    agent: str


class PolicyGraphEdge(BaseModel):
    """An edge in the policy graph representing a communication path."""

    source: str
    target: str
    action: str
    priority: int
    policy_id: str


class PolicyGraph(BaseModel):
    """Graph of agent communication paths derived from policies."""

    nodes: list[PolicyGraphNode]
    edges: list[PolicyGraphEdge]


# ---------------------------------------------------------------------------
# Compliance report
# ---------------------------------------------------------------------------


class ComplianceViolation(BaseModel):
    """A single group of policy violations (denied attempts)."""

    source_agent: str
    target_agent: str
    denied_count: int
    last_denied_at: datetime | None = None


class ComplianceReport(BaseModel):
    """Compliance report: denied communication attempts grouped by pair."""

    total_denied: int
    violations: list[ComplianceViolation]
    generated_at: datetime


# ---------------------------------------------------------------------------
# Import / Export
# ---------------------------------------------------------------------------


class PolicyImportRequest(BaseModel):
    """Schema for bulk policy import."""

    format: Literal["json", "yaml"] = Field("json", description="Import format")
    data: str = Field(..., description="Serialised policy data (JSON or YAML string)")


class PolicyImportResponse(BaseModel):
    """Result of a bulk import."""

    imported: int
    errors: list[str]


class PolicyExportResponse(BaseModel):
    """Result of a bulk export."""

    format: str
    data: str
