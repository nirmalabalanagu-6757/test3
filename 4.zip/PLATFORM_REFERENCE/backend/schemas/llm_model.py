"""Pydantic schemas for LLM Model Registry CRUD."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class ModelProvider(str, Enum):
    google = "google"
    openai = "openai"
    anthropic = "anthropic"
    azure = "azure"
    custom = "custom"


class ModelStatus(str, Enum):
    active = "active"
    disabled = "disabled"


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class ModelCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128, description="Unique model identifier (e.g. gemini-2.5-flash)")
    provider: ModelProvider = Field(..., description="Model provider")
    description: str | None = Field(None)
    api_key: str | None = Field(None, description="API key for this model/provider")
    endpoint_url: str | None = Field(None, description="Custom endpoint URL (leave blank for provider default)")
    default_temperature: float | None = Field(None, ge=0.0, le=2.0)
    default_max_tokens: int | None = Field(None, ge=1)
    is_default: bool = Field(False, description="Set as the default model for new agents")


class ModelUpdate(BaseModel):
    description: str | None = None
    api_key: str | None = None
    endpoint_url: str | None = None
    default_temperature: float | None = None
    default_max_tokens: int | None = None
    is_default: bool | None = None
    status: ModelStatus | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class ModelResponse(BaseModel):
    name: str
    provider: str
    description: str | None
    api_key_set: bool  # True if an API key is configured (never expose the actual key)
    endpoint_url: str | None
    default_temperature: float | None
    default_max_tokens: int | None
    invocation_count: int
    is_default: bool
    status: str
    registered_at: datetime
    updated_at: datetime
    last_used_at: datetime | None = None

    model_config = {"from_attributes": True}


class ModelListResponse(BaseModel):
    models: list[ModelResponse]
    count: int
