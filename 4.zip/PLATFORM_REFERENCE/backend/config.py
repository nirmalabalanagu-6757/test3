"""Configuration loading from environment using pydantic-settings."""

from pydantic import field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Runtime settings for the standalone RHEL 9 / PostgreSQL build."""

    app_env: str = "development"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    cors_origins: str = "http://localhost:3000"
    database_url: str
    db_pool_size: int = 10
    db_pool_timeout: int = 30
    db_max_overflow: int = 20
    db_pool_recycle_sec: int = 1800

    # Used as the pgcrypto passphrase for dynamic tool credentials.
    credential_encryption_key: str = ""

    # Google ADK / Gemini
    google_api_key: str = ""
    default_model: str = "gemini-2.5-flash"

    # Agent health checks
    health_check_interval_sec: int = 60
    health_check_max_failures: int = 3

    # Session management
    session_timeout_minutes: int = 30

    # Audit log
    audit_log_retention_days: int = 365

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}

    @field_validator("database_url")
    @classmethod
    def validate_database_url(cls, value: str) -> str:
        value = value.strip()
        if not value.startswith("postgresql+asyncpg://"):
            raise ValueError(
                "PostgreSQL is required; DATABASE_URL must start with postgresql+asyncpg://"
            )
        return value

    @property
    def cors_origin_list(self) -> list[str]:
        """Parse comma-separated CORS origins into a list."""
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()
