"""PostgreSQL 15.12+ engine and async session factory for AIOps."""

import logging
import os
import time
from typing import Any

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from backend.config import settings

logger = logging.getLogger(__name__)

DATABASE_URL = settings.database_url
MIN_POSTGRES_SERVER_VERSION_NUM = 150012
MIN_POSTGRES_VERSION = "15.12"

engine = create_async_engine(
    DATABASE_URL,
    echo=os.getenv("DB_ECHO", "false").lower() == "true",
    pool_size=settings.db_pool_size,
    max_overflow=settings.db_max_overflow,
    pool_timeout=settings.db_pool_timeout,
    pool_recycle=settings.db_pool_recycle_sec,
    pool_pre_ping=True,
)

async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)

_POOL_WARN_THRESHOLD = 0.85


def _on_checkout(dbapi_conn, connection_rec, connection_proxy) -> None:  # type: ignore[no-untyped-def]
    """Warn when the PostgreSQL pool is near its configured capacity."""
    pool = engine.pool
    if hasattr(pool, "size"):
        checked_out = pool.checkedout()
        base_size = pool.size()
        capacity = base_size + settings.db_max_overflow
        if capacity > 0 and checked_out / capacity >= _POOL_WARN_THRESHOLD:
            logger.warning(
                "PostgreSQL pool health: %d/%d connections in use",
                checked_out,
                capacity,
            )


def _on_checkin(dbapi_conn, connection_rec) -> None:  # type: ignore[no-untyped-def]
    pool = engine.pool
    if hasattr(pool, "size"):
        logger.debug(
            "PostgreSQL pool checkin: size=%d checked_out=%d overflow=%d",
            pool.size(),
            pool.checkedout(),
            pool.overflow(),
        )


def _on_connect(dbapi_conn, connection_rec) -> None:  # type: ignore[no-untyped-def]
    logger.debug("New PostgreSQL connection established")


def _on_invalidate(dbapi_conn, connection_rec, exception) -> None:  # type: ignore[no-untyped-def]
    logger.warning("PostgreSQL connection invalidated: %s", exception)


event.listen(engine.pool, "checkout", _on_checkout)
event.listen(engine.pool, "checkin", _on_checkin)
event.listen(engine.pool, "connect", _on_connect)
event.listen(engine.pool, "invalidate", _on_invalidate)


class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""

    pass


async def get_session() -> AsyncSession:  # type: ignore[misc]
    """Dependency that yields an async PostgreSQL session."""
    async with async_session_factory() as session:
        yield session


async def validate_postgresql_server() -> dict[str, Any]:
    """Fail fast unless the connected database is PostgreSQL 15.12 or newer."""
    async with engine.connect() as conn:
        version_num = int((await conn.execute(text("SHOW server_version_num"))).scalar_one())
        version = str((await conn.execute(text("SHOW server_version"))).scalar_one())
        if version_num < MIN_POSTGRES_SERVER_VERSION_NUM:
            raise RuntimeError(
                f"PostgreSQL {MIN_POSTGRES_VERSION}+ is required; connected server is {version}"
            )
        return {"server_version": version, "server_version_num": version_num}


async def check_database_health() -> dict[str, Any]:
    """Test PostgreSQL connectivity, minimum version, latency and pool health."""
    health: dict[str, Any] = {
        "status": "unhealthy",
        "database": "postgresql",
        "server_version": None,
        "server_version_num": None,
        "minimum_version": MIN_POSTGRES_VERSION,
        "latency_ms": None,
        "pool": None,
    }

    try:
        start = time.monotonic()
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
            version_num = int((await conn.execute(text("SHOW server_version_num"))).scalar_one())
            version = str((await conn.execute(text("SHOW server_version"))).scalar_one())
        health["server_version"] = version
        health["server_version_num"] = version_num
        if version_num < MIN_POSTGRES_SERVER_VERSION_NUM:
            logger.error(
                "Unsupported PostgreSQL server %s; minimum is %s",
                version,
                MIN_POSTGRES_VERSION,
            )
            return health
        health["status"] = "healthy"
        health["latency_ms"] = round((time.monotonic() - start) * 1000, 2)
    except Exception as exc:
        logger.error("PostgreSQL health check failed: %s", exc)
        return health

    pool = engine.pool
    if hasattr(pool, "size"):
        health["pool"] = {
            "pool_size": pool.size(),
            "checked_out": pool.checkedout(),
            "overflow": pool.overflow(),
            "checked_in": pool.checkedin(),
        }

    return health
