"""LLM Model Registry Service — CRUD and default model management."""

from __future__ import annotations

import logging

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.llm_model import LlmModelRegistry
from backend.schemas.llm_model import ModelCreate, ModelUpdate

logger = logging.getLogger(__name__)


class ModelNotFoundError(Exception):
    def __init__(self, name: str) -> None:
        super().__init__(f"Model '{name}' not found")


class ModelNameExistsError(Exception):
    def __init__(self, name: str) -> None:
        super().__init__(f"Model '{name}' already exists")


class LlmModelRegistryService:

    async def list_models(
        self,
        session: AsyncSession,
        *,
        provider: str | None = None,
        status: str | None = None,
    ) -> list[LlmModelRegistry]:
        stmt = select(LlmModelRegistry).order_by(LlmModelRegistry.name)
        if provider:
            stmt = stmt.where(LlmModelRegistry.provider == provider)
        if status:
            stmt = stmt.where(LlmModelRegistry.status == status)
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def get_model(self, session: AsyncSession, name: str) -> LlmModelRegistry:
        stmt = select(LlmModelRegistry).where(LlmModelRegistry.name == name)
        result = await session.execute(stmt)
        model = result.scalar_one_or_none()
        if model is None:
            raise ModelNotFoundError(name)
        return model

    async def register_model(
        self,
        session: AsyncSession,
        data: ModelCreate,
    ) -> LlmModelRegistry:
        existing = await session.execute(
            select(LlmModelRegistry).where(LlmModelRegistry.name == data.name)
        )
        if existing.scalar_one_or_none() is not None:
            raise ModelNameExistsError(data.name)

        # If this model is the default, clear any existing default
        if data.is_default:
            await self._clear_defaults(session)

        model = LlmModelRegistry(
            name=data.name,
            provider=data.provider.value,
            description=data.description,
            api_key=data.api_key,
            endpoint_url=data.endpoint_url,
            default_temperature=data.default_temperature,
            default_max_tokens=data.default_max_tokens,
            is_default=data.is_default,
            status="active",
        )
        session.add(model)
        await session.flush()
        return model

    async def update_model(
        self,
        session: AsyncSession,
        name: str,
        data: ModelUpdate,
    ) -> LlmModelRegistry:
        model = await self.get_model(session, name)
        update_data = data.model_dump(exclude_unset=True)

        if update_data.get("is_default"):
            await self._clear_defaults(session)

        if "status" in update_data and update_data["status"] is not None:
            update_data["status"] = update_data["status"].value

        for key, value in update_data.items():
            setattr(model, key, value)

        await session.flush()
        return model

    async def delete_model(self, session: AsyncSession, name: str) -> None:
        model = await self.get_model(session, name)
        await session.delete(model)
        await session.flush()

    async def _clear_defaults(self, session: AsyncSession) -> None:
        await session.execute(
            update(LlmModelRegistry).where(LlmModelRegistry.is_default.is_(True)).values(is_default=False)
        )
