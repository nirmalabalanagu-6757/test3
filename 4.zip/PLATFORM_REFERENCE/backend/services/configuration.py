"""Configuration service with environment-specific profiles, secret management,
schema validation, and audit logging.

Requirements 22.1: ConfigurationService
- Environment-specific profiles (development, staging, production)
- Secret management (separate storage flag, never in audit logs)
- Serve config on startup
- Validate against schema_type
- Audit logging for all changes
"""

import json
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.config_model import Configuration
from backend.services.audit_log import AuditLogService

VALID_ENVIRONMENTS = {"development", "staging", "production"}
VALID_SCHEMA_TYPES = {"str", "int", "float", "bool", "json"}

_audit = AuditLogService()


class ConfigNotFoundError(Exception):
    """Raised when a configuration entry is not found."""

    def __init__(self, key: str, environment: str) -> None:
        self.key = key
        self.environment = environment
        super().__init__(f"Configuration '{key}' not found in '{environment}'")


class ConfigValidationError(Exception):
    """Raised when a configuration value fails schema validation."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__(f"Validation failed: {'; '.join(errors)}")


class ConfigurationService:
    """Manages configuration entries across environment profiles."""

    # --- Read operations ---------------------------------------------------

    async def get_config(
        self,
        session: AsyncSession,
        key: str,
        environment: str | None = None,
    ) -> Configuration:
        """Get a single configuration entry by key and optional environment.

        If environment is None, returns the first match found.
        """
        stmt = select(Configuration).where(Configuration.key == key)
        if environment:
            stmt = stmt.where(Configuration.environment == environment)
        result = await session.execute(stmt)
        config = result.scalar_one_or_none()
        if config is None:
            raise ConfigNotFoundError(key, environment or "any")
        return config

    async def list_config(
        self,
        session: AsyncSession,
        environment: str | None = None,
    ) -> list[Configuration]:
        """List all configuration entries, optionally filtered by environment."""
        stmt = select(Configuration).order_by(Configuration.key)
        if environment:
            stmt = stmt.where(Configuration.environment == environment)
        result = await session.execute(stmt)
        return list(result.scalars().all())

    # --- Write operations --------------------------------------------------

    async def set_config(
        self,
        session: AsyncSession,
        key: str,
        value: str | None,
        environment: str,
        *,
        is_secret: bool = False,
        schema_type: str | None = None,
        updated_by: str | None = None,
    ) -> Configuration:
        """Create or update a configuration entry.

        Secrets are stored with is_secret=True and their values are never
        included in audit log details.
        """
        # Validate schema_type if value provided
        if schema_type and value is not None:
            self._validate_value(value, schema_type)

        # Upsert: check if exists
        stmt = select(Configuration).where(
            Configuration.key == key,
            Configuration.environment == environment,
        )
        result = await session.execute(stmt)
        config = result.scalar_one_or_none()

        now = datetime.now(timezone.utc)
        old_value = None

        if config is None:
            config = Configuration(
                key=key,
                environment=environment,
                value=value,
                is_secret=is_secret,
                schema_type=schema_type,
                updated_at=now,
                updated_by=updated_by,
            )
            session.add(config)
            action = "config_created"
        else:
            old_value = config.value
            config.value = value
            config.is_secret = is_secret
            if schema_type is not None:
                config.schema_type = schema_type
            config.updated_at = now
            config.updated_by = updated_by
            action = "config_updated"

        await session.flush()

        # Audit log: never include secret values
        details: dict = {
            "action": action,
            "key": key,
            "environment": environment,
            "is_secret": is_secret,
        }
        if not is_secret:
            details["value"] = value
            if old_value is not None and action == "config_updated":
                details["old_value"] = old_value
        else:
            details["value"] = "***REDACTED***"

        await _audit.append(
            session,
            "config_change",
            user_id=updated_by,
            details=details,
        )

        return config

    async def delete_config(
        self,
        session: AsyncSession,
        key: str,
        environment: str,
        *,
        deleted_by: str | None = None,
    ) -> None:
        """Remove a configuration entry."""
        stmt = select(Configuration).where(
            Configuration.key == key,
            Configuration.environment == environment,
        )
        result = await session.execute(stmt)
        config = result.scalar_one_or_none()
        if config is None:
            raise ConfigNotFoundError(key, environment)

        is_secret = config.is_secret
        await session.delete(config)
        await session.flush()

        # Audit log
        details: dict = {
            "action": "config_deleted",
            "key": key,
            "environment": environment,
        }
        if is_secret:
            details["value"] = "***REDACTED***"

        await _audit.append(
            session,
            "config_change",
            user_id=deleted_by,
            details=details,
        )

    # --- Validation --------------------------------------------------------

    async def validate_config(
        self,
        session: AsyncSession,
        environment: str,
    ) -> tuple[bool, list[str]]:
        """Validate all configuration entries for an environment against their schema_type.

        Returns (is_valid, list_of_error_messages).
        """
        configs = await self.list_config(session, environment=environment)
        errors: list[str] = []

        for cfg in configs:
            if cfg.schema_type and cfg.value is not None:
                try:
                    self._validate_value(cfg.value, cfg.schema_type)
                except ConfigValidationError as exc:
                    errors.extend(
                        f"{cfg.key}: {e}" for e in exc.errors
                    )

        return len(errors) == 0, errors

    # --- Helpers -----------------------------------------------------------

    @staticmethod
    def _validate_value(value: str, schema_type: str) -> None:
        """Validate a value string against its declared schema type."""
        errors: list[str] = []

        if schema_type not in VALID_SCHEMA_TYPES:
            errors.append(f"Unknown schema_type '{schema_type}'")
        elif schema_type == "int":
            try:
                int(value)
            except ValueError:
                errors.append(f"Expected int, got '{value}'")
        elif schema_type == "float":
            try:
                float(value)
            except ValueError:
                errors.append(f"Expected float, got '{value}'")
        elif schema_type == "bool":
            if value.lower() not in ("true", "false", "1", "0"):
                errors.append(f"Expected bool, got '{value}'")
        elif schema_type == "json":
            try:
                json.loads(value)
            except (json.JSONDecodeError, TypeError):
                errors.append(f"Expected valid JSON, got '{value[:50]}'")
        # 'str' always passes

        if errors:
            raise ConfigValidationError(errors)

    @staticmethod
    def redact_response(config: Configuration) -> dict:
        """Return a dict representation with secret values redacted."""
        return {
            "key": config.key,
            "environment": config.environment,
            "value": "***REDACTED***" if config.is_secret else config.value,
            "is_secret": config.is_secret,
            "schema_type": config.schema_type,
            "updated_at": config.updated_at,
            "updated_by": config.updated_by,
        }
