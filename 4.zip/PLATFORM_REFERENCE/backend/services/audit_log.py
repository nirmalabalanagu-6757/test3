"""Audit Log service for recording and querying governance events.

Provides append-only writes, filtered queries, aggregate stats,
and retention-based purging. Immutability is enforced by design:
no update or delete methods are exposed for existing entries.
"""

import json
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.audit import AuditLog

VALID_EVENT_TYPES: set[str] = {
    "lifecycle",
    "interaction",
    "delegation",
    "tool_invocation",
    "document_change",
    "config_change",
    "error",
    "auth",
    "policy_violation",
    "backup",
}

DEFAULT_RETENTION_DAYS: int = 365


class InvalidEventTypeError(Exception):
    """Raised when an unrecognised event_type is supplied."""

    def __init__(self, event_type: str) -> None:
        self.event_type = event_type
        super().__init__(
            f"Invalid event_type '{event_type}'. "
            f"Must be one of: {', '.join(sorted(VALID_EVENT_TYPES))}"
        )


class AuditLogService:
    """Append-only audit log with query, stats, and retention purge."""

    # --- Write ----------------------------------------------------------

    async def append(
        self,
        session: AsyncSession,
        event_type: str,
        *,
        agent_name: str | None = None,
        session_id: str | None = None,
        user_id: str | None = None,
        source_agent: str | None = None,
        target_agent: str | None = None,
        tool_name: str | None = None,
        details: dict[str, Any] | None = None,
        request_summary: str | None = None,
        response_summary: str | None = None,
    ) -> AuditLog:
        """Create an audit log entry.

        Validates *event_type* against ``VALID_EVENT_TYPES`` before persisting.

        Returns the created ``AuditLog`` row (with ``event_id`` populated
        after flush).
        """
        if event_type not in VALID_EVENT_TYPES:
            raise InvalidEventTypeError(event_type)

        entry = AuditLog(
            event_type=event_type,
            agent_name=agent_name,
            session_id=session_id,
            user_id=user_id,
            source_agent=source_agent,
            target_agent=target_agent,
            tool_name=tool_name,
            details=json.dumps(details) if details is not None else None,
            request_summary=request_summary,
            response_summary=response_summary,
        )
        session.add(entry)
        await session.flush()
        return entry

    # --- Query ----------------------------------------------------------

    async def query(
        self,
        session: AsyncSession,
        *,
        time_from: datetime | None = None,
        time_to: datetime | None = None,
        agent_name: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[AuditLog]:
        """Return audit entries matching all supplied filters.

        Filters are AND-combined.  Results are ordered by ``event_id``
        ascending (chronological).
        """
        stmt = select(AuditLog)

        if time_from is not None:
            stmt = stmt.where(AuditLog.timestamp >= time_from)
        if time_to is not None:
            stmt = stmt.where(AuditLog.timestamp <= time_to)
        if agent_name is not None:
            stmt = stmt.where(AuditLog.agent_name == agent_name)
        if user_id is not None:
            stmt = stmt.where(AuditLog.user_id == user_id)
        if session_id is not None:
            stmt = stmt.where(AuditLog.session_id == session_id)
        if event_type is not None:
            stmt = stmt.where(AuditLog.event_type == event_type)

        stmt = stmt.order_by(AuditLog.event_id.desc()).limit(limit).offset(offset)

        result = await session.execute(stmt)
        return list(result.scalars().all())

    # --- Stats ----------------------------------------------------------

    async def get_stats(
        self,
        session: AsyncSession,
    ) -> dict[str, int]:
        """Return a mapping of ``event_type → count`` for all entries."""
        stmt = (
            select(AuditLog.event_type, func.count(AuditLog.event_id))
            .group_by(AuditLog.event_type)
        )
        result = await session.execute(stmt)
        return {row[0]: row[1] for row in result.all()}

    # --- Retention / purge ----------------------------------------------

    async def purge_expired(
        self,
        session: AsyncSession,
        retention_days: int = DEFAULT_RETENTION_DAYS,
    ) -> int:
        """Delete entries older than *retention_days*.

        Returns the number of rows deleted.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        stmt = select(AuditLog).where(AuditLog.timestamp < cutoff)
        result = await session.execute(stmt)
        rows = result.scalars().all()
        count = len(rows)
        for row in rows:
            await session.delete(row)
        await session.flush()
        return count
