"""Communication Policy Service — CRUD, enforcement, graph, compliance, import/export.

Provides directional allow/deny rules for agent-to-agent communication,
a configurable default policy, bulk import/export in YAML/JSON, and audit
logging of all changes.  Policy decisions are evaluated at runtime with
no restart required — the service always reads from the database.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

import yaml
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.audit import AuditLog
from backend.models.policy import CommunicationPolicy
from backend.schemas.policy import (
    ComplianceReport,
    ComplianceViolation,
    PolicyCreate,
    PolicyDecision,
    PolicyGraph,
    PolicyGraphEdge,
    PolicyGraphNode,
    PolicyUpdate,
)
from backend.services.audit_log import AuditLogService

logger = logging.getLogger(__name__)

# Default policy when no rule matches.  Can be overridden at init time.
DEFAULT_POLICY: str = "allow"


class PolicyNotFoundError(Exception):
    """Raised when a policy cannot be found by id."""

    def __init__(self, policy_id: str) -> None:
        self.policy_id = policy_id
        super().__init__(f"Policy '{policy_id}' not found")


class CommunicationPolicyService:
    """Service for managing communication policies between agents."""

    def __init__(
        self,
        audit_log: AuditLogService | None = None,
        default_policy: str = DEFAULT_POLICY,
    ) -> None:
        self._audit = audit_log or AuditLogService()
        self._default_policy = default_policy

    @property
    def default_policy(self) -> str:
        return self._default_policy

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    async def create_policy(
        self,
        session: AsyncSession,
        data: PolicyCreate,
        *,
        created_by: str | None = None,
    ) -> CommunicationPolicy:
        """Create a new communication policy rule."""
        policy = CommunicationPolicy(
            source_agent=data.source_agent,
            target_agent=data.target_agent,
            action=data.action,
            priority=data.priority,
            justification=data.justification,
            created_by=created_by,
        )
        session.add(policy)
        await session.flush()

        await self._audit.append(
            session,
            "config_change",
            details={
                "action": "policy_created",
                "policy_id": policy.id,
                "source_agent": policy.source_agent,
                "target_agent": policy.target_agent,
                "policy_action": policy.action,
                "priority": policy.priority,
                "justification": policy.justification,
            },
            user_id=created_by,
        )
        return policy

    async def get_policy(
        self, session: AsyncSession, policy_id: str
    ) -> CommunicationPolicy:
        """Get a single policy by id. Raises PolicyNotFoundError if missing."""
        policy = await session.get(CommunicationPolicy, policy_id)
        if policy is None:
            raise PolicyNotFoundError(policy_id)
        return policy

    async def list_policies(
        self, session: AsyncSession
    ) -> list[CommunicationPolicy]:
        """Return all policies ordered by priority descending."""
        stmt = (
            select(CommunicationPolicy)
            .order_by(CommunicationPolicy.priority.desc())
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def update_policy(
        self,
        session: AsyncSession,
        policy_id: str,
        data: PolicyUpdate,
        *,
        updated_by: str | None = None,
    ) -> CommunicationPolicy:
        """Update fields on an existing policy."""
        policy = await self.get_policy(session, policy_id)
        changes: dict[str, Any] = {}

        for field_name in ("source_agent", "target_agent", "action", "priority", "justification"):
            new_value = getattr(data, field_name, None)
            if new_value is not None:
                old_value = getattr(policy, field_name)
                if old_value != new_value:
                    changes[field_name] = {"old": old_value, "new": new_value}
                    setattr(policy, field_name, new_value)

        await session.flush()

        await self._audit.append(
            session,
            "config_change",
            details={
                "action": "policy_updated",
                "policy_id": policy_id,
                "changes": changes,
            },
            user_id=updated_by,
        )
        return policy

    async def delete_policy(
        self,
        session: AsyncSession,
        policy_id: str,
        *,
        deleted_by: str | None = None,
    ) -> CommunicationPolicy:
        """Delete a policy by id. Returns the deleted policy for confirmation."""
        policy = await self.get_policy(session, policy_id)

        await self._audit.append(
            session,
            "config_change",
            details={
                "action": "policy_deleted",
                "policy_id": policy_id,
                "source_agent": policy.source_agent,
                "target_agent": policy.target_agent,
                "policy_action": policy.action,
                "priority": policy.priority,
            },
            user_id=deleted_by,
        )

        await session.delete(policy)
        await session.flush()
        return policy

    # ------------------------------------------------------------------
    # Policy evaluation
    # ------------------------------------------------------------------

    async def check_policy(
        self,
        session: AsyncSession,
        source_agent: str,
        target_agent: str,
    ) -> PolicyDecision:
        """Evaluate whether *source_agent* may communicate with *target_agent*.

        Matching rules (from highest priority):
        1. Exact match on both source and target
        2. Wildcard on source or target
        3. Wildcard on both (global rule)
        4. Default policy

        Among rules at the same specificity, the highest priority wins.
        """
        # Fetch all potentially matching rules in one query, ordered by priority desc.
        stmt = (
            select(CommunicationPolicy)
            .where(
                CommunicationPolicy.source_agent.in_([source_agent, "*"]),
                CommunicationPolicy.target_agent.in_([target_agent, "*"]),
            )
            .order_by(CommunicationPolicy.priority.desc())
        )
        result = await session.execute(stmt)
        rules = list(result.scalars().all())

        if not rules:
            return PolicyDecision(
                source_agent=source_agent,
                target_agent=target_agent,
                decision=self._default_policy,  # type: ignore[arg-type]
                matched_rule_id=None,
                reason=f"No matching rule; default policy is '{self._default_policy}'",
            )

        # Score each rule by specificity then priority.
        def _specificity(rule: CommunicationPolicy) -> tuple[int, int]:
            score = 0
            if rule.source_agent != "*":
                score += 2
            if rule.target_agent != "*":
                score += 1
            return (score, rule.priority)

        best = max(rules, key=_specificity)
        return PolicyDecision(
            source_agent=source_agent,
            target_agent=target_agent,
            decision=best.action,  # type: ignore[arg-type]
            matched_rule_id=best.id,
            reason=(
                f"Matched rule {best.id}: {best.source_agent} -> {best.target_agent} "
                f"({best.action}, priority={best.priority})"
            ),
        )

    # ------------------------------------------------------------------
    # Graph
    # ------------------------------------------------------------------

    async def get_policy_graph(
        self, session: AsyncSession
    ) -> PolicyGraph:
        """Build a graph of agent communication paths from all policies."""
        policies = await self.list_policies(session)
        agents: set[str] = set()
        edges: list[PolicyGraphEdge] = []

        for p in policies:
            agents.add(p.source_agent)
            agents.add(p.target_agent)
            edges.append(
                PolicyGraphEdge(
                    source=p.source_agent,
                    target=p.target_agent,
                    action=p.action,
                    priority=p.priority,
                    policy_id=p.id,
                )
            )

        nodes = [PolicyGraphNode(agent=a) for a in sorted(agents)]
        return PolicyGraph(nodes=nodes, edges=edges)

    # ------------------------------------------------------------------
    # Compliance report
    # ------------------------------------------------------------------

    async def get_compliance_report(
        self, session: AsyncSession
    ) -> ComplianceReport:
        """Generate a compliance report of denied communication attempts.

        Queries audit log entries of type ``policy_violation`` and groups
        them by source_agent / target_agent.
        """
        stmt = (
            select(
                AuditLog.source_agent,
                AuditLog.target_agent,
                func.count(AuditLog.event_id).label("denied_count"),
                func.max(AuditLog.timestamp).label("last_denied_at"),
            )
            .where(AuditLog.event_type == "policy_violation")
            .group_by(AuditLog.source_agent, AuditLog.target_agent)
        )
        result = await session.execute(stmt)
        rows = result.all()

        violations: list[ComplianceViolation] = []
        total = 0
        for row in rows:
            violations.append(
                ComplianceViolation(
                    source_agent=row.source_agent or "unknown",
                    target_agent=row.target_agent or "unknown",
                    denied_count=row.denied_count,
                    last_denied_at=row.last_denied_at,
                )
            )
            total += row.denied_count

        return ComplianceReport(
            total_denied=total,
            violations=violations,
            generated_at=datetime.now(timezone.utc),
        )

    # ------------------------------------------------------------------
    # Import / Export
    # ------------------------------------------------------------------

    async def import_policies(
        self,
        session: AsyncSession,
        data: str,
        fmt: str = "json",
        *,
        imported_by: str | None = None,
    ) -> tuple[int, list[str]]:
        """Bulk-import policies from a JSON or YAML string.

        Returns (imported_count, error_list).
        """
        errors: list[str] = []
        try:
            if fmt == "yaml":
                raw = yaml.safe_load(data)
            else:
                raw = json.loads(data)
        except Exception as exc:
            return 0, [f"Parse error: {exc}"]

        if not isinstance(raw, list):
            raw = raw.get("policies", []) if isinstance(raw, dict) else []

        imported = 0
        for idx, item in enumerate(raw):
            try:
                create_data = PolicyCreate(**item)
                await self.create_policy(
                    session, create_data, created_by=imported_by
                )
                imported += 1
            except Exception as exc:
                errors.append(f"Item {idx}: {exc}")

        await self._audit.append(
            session,
            "config_change",
            details={
                "action": "policies_imported",
                "format": fmt,
                "imported": imported,
                "errors": errors,
            },
            user_id=imported_by,
        )
        return imported, errors

    async def export_policies(
        self, session: AsyncSession, fmt: str = "json"
    ) -> str:
        """Export all policies as a JSON or YAML string."""
        policies = await self.list_policies(session)
        payload = [
            {
                "source_agent": p.source_agent,
                "target_agent": p.target_agent,
                "action": p.action,
                "priority": p.priority,
                "justification": p.justification,
            }
            for p in policies
        ]

        if fmt == "yaml":
            return yaml.dump({"policies": payload}, default_flow_style=False)
        return json.dumps({"policies": payload}, indent=2)
