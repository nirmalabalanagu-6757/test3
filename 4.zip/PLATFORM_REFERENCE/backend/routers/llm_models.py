"""LLM Model Registry REST API endpoints."""

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import require_role
from backend.models.token import TokenUsage
from backend.models.user import User
from backend.schemas.llm_model import (
    ModelCreate,
    ModelListResponse,
    ModelResponse,
    ModelUpdate,
)
from backend.services.llm_model_registry import (
    LlmModelRegistryService,
    ModelNameExistsError,
    ModelNotFoundError,
)

router = APIRouter(prefix="/api/models", tags=["models"])

_service = LlmModelRegistryService()


def _error_response(
    status_code: int, code: str, message: str, request: Request
) -> JSONResponse:
    request_id = getattr(request.state, "request_id", "unknown")
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": {},
                "request_id": request_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        },
    )


def _to_response(model: Any, last_used_at: datetime | None = None) -> ModelResponse:
    return ModelResponse(
        name=model.name,
        provider=model.provider,
        description=model.description,
        api_key_set=model.api_key is not None and len(model.api_key) > 0,
        endpoint_url=model.endpoint_url,
        default_temperature=model.default_temperature,
        default_max_tokens=model.default_max_tokens,
        invocation_count=model.invocation_count,
        is_default=model.is_default,
        status=model.status,
        registered_at=model.registered_at,
        updated_at=model.updated_at,
        last_used_at=last_used_at,
    )


@router.get("", response_model=ModelListResponse)
async def list_models(
    provider: str | None = Query(None),
    status: str | None = Query(None),
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    models = await _service.list_models(session, provider=provider, status=status)

    model_names = [m.name for m in models]
    last_used_stmt = (
        select(
            TokenUsage.model_name,
            func.max(TokenUsage.recorded_at).label("last_used"),
        )
        .where(TokenUsage.model_name.in_(model_names))
        .group_by(TokenUsage.model_name)
    )
    rows = await session.execute(last_used_stmt)
    last_used_map: dict[str, datetime] = {r.model_name: r.last_used for r in rows}

    return ModelListResponse(
        models=[_to_response(m, last_used_at=last_used_map.get(m.name)) for m in models],
        count=len(models),
    )


@router.post("", response_model=ModelResponse, status_code=201)
async def register_model(
    data: ModelCreate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    try:
        model = await _service.register_model(session, data)
        await session.commit()
        return _to_response(model)
    except ModelNameExistsError as exc:
        await session.rollback()
        return _error_response(409, "MODEL_NAME_EXISTS", str(exc), request)


@router.get("/{name}", response_model=ModelResponse)
async def get_model(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    try:
        model = await _service.get_model(session, name)
        return _to_response(model)
    except ModelNotFoundError as exc:
        return _error_response(404, "MODEL_NOT_FOUND", str(exc), request)


@router.put("/{name}", response_model=ModelResponse)
async def update_model(
    name: str,
    data: ModelUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    try:
        model = await _service.update_model(session, name, data)
        await session.commit()
        return _to_response(model)
    except ModelNotFoundError as exc:
        await session.rollback()
        return _error_response(404, "MODEL_NOT_FOUND", str(exc), request)


@router.post("/{name}/increment", status_code=200)
async def increment_model_usage(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Increment the invocation counter for a model (internal, no auth required)."""
    try:
        model = await _service.get_model(session, name)
        model.invocation_count += 1
        await session.commit()
        return {"name": name, "invocation_count": model.invocation_count}
    except ModelNotFoundError as exc:
        return _error_response(404, "MODEL_NOT_FOUND", str(exc), request)


@router.get("/{name}/key")
async def get_model_key(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Return the raw API key for internal agent use (admin only)."""
    try:
        model = await _service.get_model(session, name)
        return {"api_key": model.api_key or ""}
    except ModelNotFoundError as exc:
        return _error_response(404, "MODEL_NOT_FOUND", str(exc), request)


@router.delete("/{name}", status_code=204, response_model=None)
async def delete_model(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    try:
        await _service.delete_model(session, name)
        await session.commit()
        return None
    except ModelNotFoundError as exc:
        await session.rollback()
        return _error_response(404, "MODEL_NOT_FOUND", str(exc), request)


@router.post("/{name}/test")
async def test_model(
    name: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    _user: User = Depends(require_role("admin")),
) -> Any:
    """Send a minimal prompt to the model and return success/failure + latency."""
    import os

    from backend.services.model_test_service import ModelTestService
    from backend.startup_config.model_definitions import get_model_test_via, resolve_location

    try:
        model = await _service.get_model(session, name)
    except ModelNotFoundError as exc:
        return _error_response(404, "MODEL_NOT_FOUND", str(exc), request)

    if model.status != "active":
        return _error_response(400, "MODEL_DISABLED", f"Model '{name}' is disabled", request)

    gcp_project = os.getenv("GOOGLE_CLOUD_PROJECT", "")
    if not gcp_project:
        return _error_response(500, "CONFIG_ERROR", "GOOGLE_CLOUD_PROJECT not configured", request)

    location = resolve_location(name)
    test_via = get_model_test_via(name, provider=model.provider)

    result = await ModelTestService().test_model(name, gcp_project, location, test_via)

    if result.ok:
        return {
            "model": name,
            "status": "ok",
            "response": result.reply,
            "latency_ms": result.latency_ms,
            "location": result.location,
        }
    return _error_response(502, "MODEL_TEST_FAILED", result.error, request)
