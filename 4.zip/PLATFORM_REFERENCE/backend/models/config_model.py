"""SQLAlchemy models for Configuration, Feature Flags, and Migrations."""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class Configuration(Base):
    __tablename__ = "configuration"

    key: Mapped[str] = mapped_column(String(256), primary_key=True)
    environment: Mapped[str] = mapped_column(
        String(20), primary_key=True
    )  # development | staging | production
    value: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_secret: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    schema_type: Mapped[str | None] = mapped_column(String(64), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )
    updated_by: Mapped[str | None] = mapped_column(String(128), nullable=True)


class FeatureFlag(Base):
    __tablename__ = "feature_flag"

    name: Mapped[str] = mapped_column(String(128), primary_key=True)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    toggled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    toggled_by: Mapped[str | None] = mapped_column(String(128), nullable=True)


class Migration(Base):
    __tablename__ = "migration_record"

    migration_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    applied_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
