"""SQLAlchemy models for Tool Registry and Tool-Agent assignments."""

import json
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, Integer, JSON, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class ToolRegistry(Base):
    __tablename__ = "tool_registry"
    __table_args__ = (Index("ix_tool_registry_lifecycle_type", "lifecycle_status", "tool_type"),)

    name: Mapped[str] = mapped_column(String(128), primary_key=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    detail_description: Mapped[str | None] = mapped_column(Text, nullable=True)
    tool_type: Mapped[str] = mapped_column(String(20), nullable=False)  # function | mcp | api_connector
    risk_classification: Mapped[str] = mapped_column(String(20), nullable=False)  # read_only | write | execute
    target_system: Mapped[str | None] = mapped_column(String(256), nullable=True)
    api_endpoint: Mapped[str | None] = mapped_column(String(512), nullable=True)
    connector_type: Mapped[str] = mapped_column(
        String(40), nullable=False, default="generic_rest", server_default="generic_rest"
    )
    auth_type: Mapped[str] = mapped_column(
        String(32), nullable=False, default="none"
    )  # none | api_key | api_key_query | bearer | basic | digest | oauth2_client_credentials
    credential_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    api_key_header_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    extra_headers_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    oauth2_token_url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    oauth2_client_id: Mapped[str | None] = mapped_column(String(256), nullable=True)

    # Dynamic execution configuration.  These fields allow a tool registered
    # entirely in the database to be executable without a Python implementation.
    http_method: Mapped[str] = mapped_column(String(10), nullable=False, default="GET", server_default="GET")
    request_format: Mapped[str] = mapped_column(
        String(20), nullable=False, default="json", server_default="json"
    )
    response_format: Mapped[str] = mapped_column(
        String(20), nullable=False, default="auto", server_default="auto"
    )
    file_field_name: Mapped[str] = mapped_column(
        String(128), nullable=False, default="file", server_default="file"
    )
    request_template_json: Mapped[dict | list | None] = mapped_column(JSON, nullable=True)
    input_schema_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    response_mapping_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    timeout_sec: Mapped[int] = mapped_column(Integer, nullable=False, default=15, server_default="15")
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1, server_default="1")
    max_response_bytes: Mapped[int] = mapped_column(Integer, nullable=False, default=2_000_000, server_default="2000000")
    verify_tls: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="1")
    mcp_tool_name: Mapped[str | None] = mapped_column(String(128), nullable=True)

    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    lifecycle_status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="registered"
    )  # registered | pending_approval | active | deprecated | disabled
    invocation_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    last_invocation_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    registered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    @property
    def has_credential(self) -> bool:
        return bool(self.credential_encrypted)

    @property
    def extra_headers(self) -> dict[str, str] | None:
        if not self.extra_headers_json:
            return None
        try:
            return json.loads(self.extra_headers_json)
        except ValueError:
            return None


class ToolAgentAssignment(Base):
    __tablename__ = "tool_agent_assignment"
    __table_args__ = (Index("ix_tool_agent_assignment_agent_name", "agent_name"),)

    tool_name: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("tool_registry.name", ondelete="CASCADE"),
        primary_key=True,
    )
    agent_name: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("agent_registry.name", ondelete="CASCADE"),
        primary_key=True,
    )
    assigned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    assigned_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
