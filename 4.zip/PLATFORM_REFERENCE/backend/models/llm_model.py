"""SQLAlchemy model for the LLM Model Registry."""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class LlmModelRegistry(Base):
    __tablename__ = "llm_model_registry"

    name: Mapped[str] = mapped_column(String(128), primary_key=True)
    provider: Mapped[str] = mapped_column(String(64), nullable=False)  # google, openai, anthropic, ...
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    api_key: Mapped[str | None] = mapped_column(String(512), nullable=True)
    endpoint_url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    default_temperature: Mapped[float | None] = mapped_column(nullable=True)
    default_max_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    invocation_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="active")  # active | disabled
    registered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )
