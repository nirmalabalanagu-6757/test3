"""Full-resolver Golden tests with the real DAG engine and fixture-only I/O.

No tool runtime loader and no model adapter are imported by this module.
Per-run objects (not global monkeypatches) isolate concurrent live requests.
"""

from __future__ import annotations

import asyncio
import copy
import json

from sqlalchemy import select

from backend.models.intent import IntentRule
from backend.models.intent_validation import GoldenRun, GoldenSuite, IntentRevision
from backend.schemas.intent import IntentRuleCreate
from backend.schemas.intent_validation import GoldenCase, GoldenSuiteCreate
from backend.services.action_template import ActionTemplateService
from backend.services.audit_log import AuditLogService
from backend.services.communication_policy import CommunicationPolicyService
from backend.services.intent_control import IntentControlService
from backend.services.intent_orchestrator import IntentOrchestrator
from backend.services.intent_workflow_learning import _equal


def rule_snapshot(rule):
    return IntentRuleCreate.model_validate(
        {key: getattr(rule, key) for key in IntentRuleCreate.model_fields}
    ).model_dump(mode="json")


async def save_revision(session, rule, actor):
    previous = await session.scalar(
        select(IntentRevision).where(
            IntentRevision.intent_id == rule.id,
            IntentRevision.version == rule.workflow_version,
        )
    )
    if previous is None:
        session.add(
            IntentRevision(
                intent_id=rule.id, version=rule.workflow_version, snapshot_json=rule_snapshot(rule), created_by=actor
            )
        )
        await session.flush()


class OverlayResolver(IntentControlService):
    """Use normal competing rules and permissions, replacing only this proposal."""

    def __init__(self, proposal=None):
        super().__init__()
        self.proposal = proposal

    async def list_rules(self, session, **kwargs):
        rules = await super().list_rules(session, **kwargs)
        if self.proposal:
            rules = [rule for rule in rules if rule.name != self.proposal.name]
            proposal = IntentRule(id="golden-proposal", **self.proposal.model_dump(mode="json"))
            enabled = kwargs.get("enabled")
            if (enabled is None or proposal.enabled == enabled) and (
                not kwargs.get("source_agent") or self._source_agent_allowed(proposal, kwargs["source_agent"])
            ):
                rules.append(proposal)
        return rules

    async def _record_shadow_evaluations(self, *args, **kwargs):
        return None


class FixtureOrchestrator(IntentOrchestrator):
    def __init__(self, session, case: GoldenCase):
        self.session = session
        self.case = case
        self.calls = []
        self.failures = []
        self.llm_attempts = 0
        self._db_lock = asyncio.Lock()

    async def _noop(self, *args, **kwargs):
        return "golden-simulation"

    _create_run = _finish_run = _start_step = _finish_step = _record_skipped_step = _noop

    async def no_llm(self, *args, **kwargs):
        self.llm_attempts += 1
        raise RuntimeError("This Golden simulation forbids LLM calls; review the non-direct execution path")

    async def _authorize_step(self, run_id, intent_name, step, previous, session_id, user_id, *, source_agent):
        sources = {
            previous[key].agent for key in step.depends_on if key in previous and previous[key].status == "completed"
        } or {source_agent}
        async with self._db_lock:
            for source in sorted(sources):
                result = await CommunicationPolicyService().check_policy(self.session, source, step.agent)
                if result.decision != "allow":
                    return False, result.reason
        return True, "Current communication policy permits simulated execution"

    async def _invoke_action_template(self, *, intent, step, agent_name, user_message, previous, **kwargs):
        action = step.resolved_action
        if not action or step.connection_ref != action.tool_name:
            raise ValueError("Direct workflow needs an exact registered connection")
        async with self._db_lock:
            await ActionTemplateService().validate_for_agent(self.session, action, agent_name)
        rendered = self._render_action(intent, step, user_message, previous)
        actual = {
            "intent_name": intent.intent_name,
            "step_id": step.id,
            "agent": agent_name,
            "tool": action.tool_name,
            "action_template": action.reference,
            "arguments": rendered.tool_arguments,
            "depends_on": step.depends_on,
        }
        if any(call["intent_name"] == intent.intent_name and call["step_id"] == step.id for call in self.calls):
            self.failures.append(f"Unexpected repeated attempt: {intent.intent_name}.{step.id}")
        self.calls.append(actual)
        expected = next(
            (call for call in self.case.calls if (call.intent_name, call.step_id) == (intent.intent_name, step.id)),
            None,
        )
        if expected is None:
            self.failures.append(f"Unexpected tool call: {intent.intent_name}.{step.id}")
            raise ValueError(self.failures[-1])
        contract = expected.model_dump(exclude={"fixture"})
        if not _equal(actual, contract):
            self.failures.append(f"Tool/agent/connection/action/argument/dependency mismatch: {step.id}")
            raise ValueError(self.failures[-1])
        output = self._limit_action_output(
            copy.deepcopy(expected.fixture),
            max_rows=action.policy.max_rows,
            max_response_bytes=action.policy.max_response_bytes,
        )
        ActionTemplateService.validate_output(output, action.output_schema_json)
        response = output if isinstance(output, str) else json.dumps(output)
        return response, {agent_name: [action.tool_name]}, "fixture-only"


class IntentValidationService:
    async def run(self, session, suite: GoldenSuiteCreate, *, proposal=None):
        results = []
        resolver = OverlayResolver(proposal)
        if proposal:
            await resolver._validate_references(session, proposal)
            resolver._validate_patterns(proposal)
        for case in suite.cases:
            engine = FixtureOrchestrator(session, case)
            failures = []
            actual_decision = None
            status, response, snapshot = None, "", None
            try:
                decision = await resolver.resolve(
                    session,
                    case.query,
                    source_agent=case.source_agent,
                    confirmed=case.confirmed,
                    parameters=case.parameters,
                )
                snapshot = decision.model_dump(mode="json")
                actual_decision = decision.decision
                if actual_decision != case.expected_decision:
                    failures.append(
                        f"Expected decision {case.expected_decision}, got {actual_decision}: {decision.reason}"
                    )
                names = [item.intent_name for item in decision.selected_intents]
                if names != case.expected_intents:
                    failures.append(f"Expected intents {case.expected_intents}, got {names}")
                if actual_decision == "route":
                    result = await engine.execute(
                        decision,
                        session_id="golden-test",
                        user_id="golden-test",
                        user_message=case.query,
                        invoke_agent=engine.no_llm,
                    )
                    status, response = result.status, result.response
                    if status != case.expected_status and not engine.llm_attempts:
                        failures.append(f"Expected execution {case.expected_status}, got {status}")
                if len(engine.calls) != len(case.calls) and not engine.llm_attempts:
                    failures.append(f"Expected {len(case.calls)} calls, observed {len(engine.calls)}")
                for fragment in case.expected_response_contains:
                    if fragment not in response:
                        failures.append(f"Expected response fragment missing: {fragment}")
            except Exception as exc:  # noqa: BLE001 -- one failed case must not stop the suite
                failures.append(f"{type(exc).__name__}: {exc}")
            failures.extend(engine.failures)
            results.append(
                {
                    "name": case.name,
                    "status": "FAIL" if failures else "REVIEW" if engine.llm_attempts else "PASS",
                    "decision": actual_decision,
                    "execution_status": status,
                    "failures": failures,
                    "llm_attempts": engine.llm_attempts,
                    "model_calls": 0,
                    "actual_calls": engine.calls,
                    "resolved_snapshot": snapshot,
                }
            )
        status = (
            "FAIL"
            if any(row["status"] == "FAIL" for row in results)
            else "REVIEW"
            if any(row["status"] == "REVIEW" for row in results)
            else "PASS"
        )
        return {
            "status": status,
            "mode": "intent_simulation",
            "cases": results,
            "suite": suite.model_dump(mode="json"),
            "proposal": proposal.model_dump(mode="json") if proposal else None,
            "limitations": [
                "Synthetic fixtures only; no live connector or model was invoked",
                "PASS covers these reviewed cases, not every possible prompt",
            ],
        }

    async def validate_approval(self, session, suite_id, proposal):
        suite = await session.get(GoldenSuite, suite_id)
        if suite is None:
            raise ValueError("Select a saved, reviewed Golden suite")
        definition = GoldenSuiteCreate.model_validate(suite.definition_json)
        if not any(
            case.expected_decision == "route"
            and case.expected_status == "completed"
            and proposal.name in case.expected_intents
            and case.calls
            for case in definition.cases
        ):
            raise ValueError("Approval suite must test a successful tool workflow for this intent")
        report = await self.run(session, definition, proposal=proposal)
        if report["status"] != "PASS":
            reasons = [failure for case in report["cases"] for failure in case["failures"]]
            raise ValueError("Golden approval blocked: " + ("; ".join(reasons) or "An LLM path still needs review"))
        return report

    async def receipt(self, session, suite_id, report, actor):
        row = GoldenRun(
            suite_id=suite_id, mode=report["mode"], status=report["status"], results_json=report, created_by=actor
        )
        session.add(row)
        await session.flush()
        await AuditLogService().append(
            session,
            "config_change",
            user_id=actor,
            details={
                "action": "golden_test_run",
                "run_id": row.id,
                "suite_id": suite_id,
                "status": row.status,
                "mode": row.mode,
            },
        )
        return row
