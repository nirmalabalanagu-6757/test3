"""Atomic, explicit review of learned rules and their action dependencies."""

from sqlalchemy import select

from backend.models.action_template import ActionTemplate
from backend.schemas.action_template import ActionTemplateCreate, ActionTemplateUpdate
from backend.services.action_template import ActionTemplateService
from backend.services.intent_control import IntentConfigurationError


async def prepare_actions(session, actions, rule, actor):
    references = {step.action_template for step in rule.workflow_json}
    service = ActionTemplateService()
    seen = set()
    for data in actions:
        reference = f"{data.name}@{data.version}"
        if reference not in references or reference in seen:
            raise IntentConfigurationError(f"Reviewed action {reference} must be used exactly once in the action list")
        seen.add(reference)
        if data.execution_mode != "direct":
            raise IntentConfigurationError("Combined action approval requires direct action contracts")
        desired = data.model_copy(update={"lifecycle_status": "active"})
        current = await session.scalar(
            select(ActionTemplate).where(
                ActionTemplate.name == data.name,
                ActionTemplate.version == data.version,
            )
        )
        if current:
            snapshot = {key: getattr(current, key) for key in ActionTemplateCreate.model_fields}
            actual = ActionTemplateCreate.model_validate(snapshot).model_dump(mode="json")
            actual["lifecycle_status"] = "active"
            if actual != desired.model_dump(mode="json") or current.lifecycle_status not in {"draft", "active"}:
                raise IntentConfigurationError(
                    f"Action {reference} already exists with a different contract; clone a new version"
                )
            if current.lifecycle_status == "draft":
                await service.update_template(
                    session, current.id, ActionTemplateUpdate(lifecycle_status="active"), updated_by=actor
                )
        else:
            await service.create_template(session, desired, created_by=actor)


async def require_review(session, rule, suite_id, allow_llm_execution, actor):
    if not rule.enabled:
        return
    service = ActionTemplateService()
    needs_llm = not rule.workflow_json or bool(
        rule.aggregator_agent and rule.response_mode in {"auto", "detailed", "llm_summary"}
    )
    for step in rule.workflow_json:
        if not step.action_template:
            needs_llm = True
        else:
            action = await service.resolve_reference(session, step.action_template)
            needs_llm = needs_llm or action.execution_mode != "direct"
    if needs_llm and not allow_llm_execution:
        raise IntentConfigurationError(
            "This intent still needs an LLM. Complete direct mappings or explicitly allow LLM execution."
        )
    if suite_id:
        # Persist the suite link; later edits and rollback must pass it again.
        rule.execution_options_json.golden_suite_id = suite_id
        rule.execution_options_json.require_golden = True
