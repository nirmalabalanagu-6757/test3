"""Opt-in, bounded model preflight with declarative tools and synthetic results.

Intent matching is deliberately bypassed: a receipt cannot claim model testing
when only a deterministic intent ran. This is a single-agent tool-contract eval,
not an assertion that a multi-agent production deployment has been validated.
"""

import asyncio
import copy
import time

from sqlalchemy import select

from backend.models.agent import AgentRegistry
from backend.models.llm_model import LlmModelRegistry
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.services.intent_workflow_learning import _equal


class ComparisonFailure(Exception):
    """A safe, locally generated diagnostic (never a raw provider response)."""


def adapter_for(name):
    from google.adk.models.registry import LLMRegistry

    import agents.base.anthropic_llm
    import agents.base.openai_compat_llm  # noqa: F401 -- register existing adapter

    return LLMRegistry.new_llm(name)


async def compare(session, suite, request, *, factory=None):
    if not request.allow_model_calls:
        raise ValueError("Explicit consent is required for provider model calls")
    from google.adk.models.llm_request import LlmRequest
    from google.adk.tools.base_tool import BaseTool
    from google.genai.types import Content, FunctionDeclaration, FunctionResponse, GenerateContentConfig, Part, Tool

    class FixtureTool(BaseTool):
        def __init__(self, record):
            super().__init__(name=record.name, description=record.description or record.name)
            self.schema = copy.deepcopy(record.input_schema_json)

        def _get_declaration(self):
            return FunctionDeclaration(name=self.name, description=self.description, parameters_json_schema=self.schema)

        async def run_async(self, **kwargs):
            raise RuntimeError("Evaluation tools cannot invoke real runtimes")

    agent = await session.get(AgentRegistry, request.agent)
    if not agent:
        raise ValueError("Agent not found")
    records = list(
        (
            await session.execute(
                select(ToolRegistry)
                .join(
                    ToolAgentAssignment,
                    ToolRegistry.name == ToolAgentAssignment.tool_name,
                )
                .where(ToolAgentAssignment.agent_name == agent.name, ToolRegistry.lifecycle_status == "active")
            )
        )
        .scalars()
        .all()
    )
    if any(not record.input_schema_json for record in records):
        raise ValueError("Model comparison requires declared input schemas for every assigned active tool")
    tools = {record.name: FixtureTool(record) for record in records}
    instruction = agent.instruction or ""
    # Freeze one shared config before testing either model. Never alter live defaults.
    config = {
        **(agent.generate_content_config_json or {}),
        "system_instruction": instruction,
        "max_output_tokens": request.max_output_tokens,
    }
    config.pop("tools", None)
    config.pop("automatic_function_calling", None)
    declarations = [tool._get_declaration() for tool in tools.values()]
    if declarations:
        config["tools"] = [Tool(function_declarations=declarations)]
    generation = GenerateContentConfig.model_validate(config)
    models = list(dict.fromkeys(request.models))
    for name in models:
        record = await session.get(LlmModelRegistry, name)
        if not record or record.status != "active":
            raise ValueError(f"Model '{name}' must be active in the existing Model Registry")
    results = []
    total_model_calls = 0
    for name in models:
        model = None
        initialization_failed = False
        for case in suite.cases:
            if (
                case.expected_decision != "route"
                or not case.calls
                or case.expected_status != "completed"
                or case.source_agent != agent.name
                or any(call.agent != agent.name for call in case.calls)
            ):
                results.append(
                    {
                        "model": name,
                        "case": case.name,
                        "status": "REVIEW",
                        "model_calls": 0,
                        "reason": "Model preflight requires a successful tool case for the selected source agent; "
                        "use intent simulation for routing, expected failures and multi-agent policy",
                    }
                )
                continue
            contents = [Content(role="user", parts=[Part(text=case.query)])]
            pending = list(case.calls)
            seen_steps = set()
            calls, failures = [], []
            model_calls, input_tokens, output_tokens = 0, 0, 0
            usage_responses = 0
            response_text, final_received = "", False
            started = time.monotonic()
            try:
                async with asyncio.timeout(180):
                    if initialization_failed:
                        raise ComparisonFailure("Provider initialization failed; check model/provider configuration")
                    # Do not initialize adapters for skipped cases or spent budgets.
                    if total_model_calls >= request.max_total_model_calls:
                        raise ComparisonFailure("Comparison model-call budget exhausted")
                    if model is None:
                        try:
                            model = (factory or adapter_for)(name)
                        except Exception as exc:
                            initialization_failed = True
                            raise ComparisonFailure(
                                "Provider initialization failed; check model/provider configuration"
                            ) from exc
                    for _ in range(request.max_turns):
                        if total_model_calls >= request.max_total_model_calls:
                            raise ComparisonFailure("Comparison model-call budget exhausted")
                        llm_request = LlmRequest(
                            model=name, contents=contents, config=generation.model_copy(deep=True), tools_dict=tools
                        )
                        model_calls += 1
                        total_model_calls += 1
                        replies = [reply async for reply in model.generate_content_async(llm_request, stream=False)]
                        if not replies:
                            raise ComparisonFailure("Provider returned no response")
                        reply = replies[-1]
                        if reply.error_code:
                            # Provider error bodies can contain sensitive request detail.
                            raise ComparisonFailure(
                                "Provider returned an error; check provider availability and configuration"
                            )
                        usage = reply.usage_metadata
                        usage_responses += 1
                        inc, out = (
                            getattr(usage, "prompt_token_count", None),
                            getattr(usage, "candidates_token_count", None),
                        )
                        input_tokens = input_tokens + inc if input_tokens is not None and inc is not None else None
                        output_tokens = output_tokens + out if output_tokens is not None and out is not None else None
                        if reply.content is None:
                            raise ComparisonFailure("Provider returned no content")
                        contents.append(reply.content)
                        functions = [part.function_call for part in reply.content.parts or [] if part.function_call]
                        if not functions:
                            response_text = "\n".join(
                                part.text for part in reply.content.parts or [] if part.text and not part.thought
                            )
                            final_received = True
                            break
                        responses = []
                        # Calls in the same model turn are parallel. A dependency
                        # cannot consume another call from this unfinished batch.
                        available = set(seen_steps)
                        for call in functions:
                            calls.append({"tool": call.name, "arguments": call.args, "call_id": call.id})
                            matches = [
                                item
                                for item in pending
                                if item.tool == call.name
                                and _equal(item.arguments, call.args)
                                and {(item.intent_name, dependency) for dependency in item.depends_on} <= available
                            ]
                            if call.name not in tools or len(matches) != 1:
                                failures.append("Unexpected/ambiguous tool, arguments or dependency order")
                                break
                            expected = matches[0]
                            pending.remove(expected)
                            seen_steps.add((expected.intent_name, expected.step_id))
                            output = copy.deepcopy(expected.fixture)
                            responses.append(
                                Part(
                                    function_response=FunctionResponse(
                                        name=call.name,
                                        id=call.id,
                                        response=output if isinstance(output, dict) else {"result": output},
                                    )
                                )
                            )
                        if failures:
                            break
                        contents.append(Content(role="user", parts=responses))
            except ComparisonFailure as exc:
                failures.append(str(exc))
            except TimeoutError:
                failures.append("Provider case exceeded the 180-second time budget")
            except Exception as exc:  # noqa: BLE001 -- raw provider errors may contain credentials/request data
                failures.append(f"Provider/protocol failure ({type(exc).__name__}); check provider configuration")
            if pending:
                failures.append(f"{len(pending)} expected call(s) not completed")
            if not model_calls or usage_responses != model_calls:
                input_tokens = output_tokens = None
            if not final_received:
                failures.append("No final response within the model turn/time budget")
            if any(fragment not in response_text for fragment in case.expected_response_contains):
                failures.append("Expected response content missing")
            results.append(
                {
                    "model": name,
                    "case": case.name,
                    "status": "FAIL" if failures else "PASS",
                    "failures": failures,
                    "actual_calls": calls,
                    "model_calls": model_calls,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "estimated_cost": None,
                    "latency_ms": round((time.monotonic() - started) * 1000, 2),
                }
            )
    return {
        "status": "FAIL"
        if any(row["status"] == "FAIL" for row in results)
        else "REVIEW"
        if any(row["status"] == "REVIEW" for row in results)
        else "PASS",
        "mode": "model_comparison",
        "results": results,
        "suite": suite.model_dump(mode="json"),
        "snapshot": {
            "agent": agent.name,
            "instruction": instruction,
            "generation_config": generation.model_dump(mode="json", exclude_none=True),
            "tools": {name: tool.schema for name, tool in tools.items()},
            "models": models,
        },
        "limitations": [
            "Single-agent contract preflight; live connector and multi-agent behavior are not exercised",
            "Unknown token usage/cost is null; no prices assumed",
            "No model is promoted automatically",
        ],
    }
