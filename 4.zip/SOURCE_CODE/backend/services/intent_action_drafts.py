"""Produce review-only contracts, never publish observations automatically."""

import copy
import hashlib
import json
import re

from backend.models.action_template import ActionTemplate
from backend.schemas.action_template import ActionTemplateCreate
from backend.services.intent_identity import resolve_name
from backend.services.intent_workflow_learning import _contains_secret, template_inputs


def propose_actions(trace, route, tools, published, query):
    """Keep schemas/code, not response rows or arbitrary captured input values.

    SQL literals need human review. Bound SQL + separate data is eligible. For
    other arguments, only a declared enum/const is frozen; all others are slots.
    An unextractable slot remains REVIEW, never a captured value as a default.
    """
    proposals = {}
    for call in trace.calls:
        agent = resolve_name(call.agent, route)
        tool_name = resolve_name(call.tool, route[agent]) if agent else None
        tool = tools.get(tool_name)
        if not tool or call.status != "completed" or _contains_secret(call.arguments):
            continue
        if any(t.tool_name == tool_name and template_inputs(t, call.arguments, query) is not None for t in published):
            continue
        payload, properties, text_argument, template_text = {}, {}, None, None
        declared = (tool.input_schema_json or {}).get("properties", {})
        supported = True
        for name, value in call.arguments.items():
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name):
                supported = False
                break
            spec = copy.deepcopy(declared.get(name) or {})
            if isinstance(value, str) and re.match(r"(?is)^\s*(select|with)\b", value):
                # Do not freeze identifiers supplied as data inside SQL literals.
                if text_argument or "'" in value or re.search(r"(?<![\w:])\d+", value) or "{{" in value:
                    supported = False
                    break
                text_argument, template_text = name, value
                continue
            if "const" in spec and spec["const"] == value or value in spec.get("enum", []):
                payload[name] = value
                continue
            if not spec:
                kind = {
                    str: "string",
                    int: "integer",
                    float: "number",
                    bool: "boolean",
                    dict: "object",
                    list: "array",
                }.get(type(value))
                if kind is None:
                    supported = False
                    break
                spec = {"type": kind}
            # Defaults from observation/schema must not silently reuse old resources.
            spec.pop("default", None)
            properties[name] = spec
            payload[name] = "{{" + name + "}}"
        if not supported:
            continue
        contract = {
            "tool_name": tool_name,
            "template_text": template_text,
            "payload_template_json": payload,
            "input_schema_json": {"type": "object", "properties": properties, "required": list(properties)},
            "execution_options_json": {"text_argument": text_argument},
            "policy_json": {
                "risk_classification": tool.risk_classification,
                "requires_confirmation": tool.risk_classification != "read_only",
                "allowed_agents": [agent],
            },
        }
        digest = hashlib.sha256(json.dumps(contract, sort_keys=True).encode()).hexdigest()[:20]
        name = f"learned.action.{digest}"
        proposal = ActionTemplateCreate(
            name=name,
            version=1,
            execution_mode="direct",
            lifecycle_status="draft",
            template_type="sql" if template_text else "json",
            description="Observed contract. Review parameters, SQL and policy before publishing.",
            **contract,
        )
        proposals[name] = proposal
    return list(proposals.values())


def preview_records(proposals):
    # Ephemeral objects only, for compiling mappings before administrator approval.
    return [
        ActionTemplate(id=f"draft-{p.name}", **(p.model_dump(mode="json") | {"lifecycle_status": "active"}))
        for p in proposals
    ]
