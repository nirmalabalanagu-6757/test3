"""One reviewed package, one transactional publication, no second approval."""

from sqlalchemy import select

from backend.models.action_template import ActionTemplate
from backend.models.agent import AgentRegistry
from backend.models.intent import IntentRule
from backend.models.tool import ToolAgentAssignment, ToolRegistry
from backend.services.intent_learning_matching import digest


async def review_token(session, candidate):
    route = candidate.observed_route_json or {}
    names = sorted({name for tools in route.values() for name in tools})
    tools = list((await session.execute(select(ToolRegistry).where(ToolRegistry.name.in_(names)))).scalars().all())
    # Hash relevant contracts, never return credentials or include mutable usage counters.
    dependencies = [{key: getattr(tool, key) for key in (
        "name", "version", "lifecycle_status", "risk_classification", "input_schema_json",
        "request_template_json", "http_method", "api_endpoint", "response_mapping_json",
    )} for tool in sorted(tools, key=lambda item: item.name)]
    assignments = list((await session.execute(select(ToolAgentAssignment.agent_name, ToolAgentAssignment.tool_name)
                                              .where(ToolAgentAssignment.tool_name.in_(names)))).all())
    agents = list((await session.execute(select(AgentRegistry).where(AgentRegistry.name.in_(route)))).scalars().all())
    actions = list((await session.execute(select(ActionTemplate).where(ActionTemplate.tool_name.in_(names)))).scalars().all())
    target = await session.get(IntentRule, candidate.suggested_intent_id) if candidate.suggested_intent_id else None
    return digest({
        "candidate": {key: getattr(candidate, key) for key in (
            "id", "status", "source_agent", "examples_json", "observed_route_json", "proposed_rule_json",
            "observation_json", "occurrence_count", "suggested_intent_id",
        )},
        "tools": dependencies, "assignments": sorted([list(row) for row in assignments]),
        "agents": sorted((a.name, a.lifecycle_status, a.intent_control_enabled) for a in agents),
        "actions": sorted((a.name, a.version, a.lifecycle_status, str(a.updated_at)) for a in actions),
        "target_version": target.workflow_version if target else None,
    })


async def validate_package(service, session, candidate_id, **kwargs):
    """Exercise the actual approval path in a savepoint, then discard all writes."""
    transaction = await session.begin_nested()
    try:
        _, intent = await service.approve(session, candidate_id, **kwargs)
        return {"status": "PASS", "published": False, "model_calls": 0,
                "intent_name": intent.name, "workflow_version": intent.workflow_version,
                "steps": len(intent.workflow_json or []),
                "message": "Complete package validated. Approve & Publish will revalidate before saving."}
    finally:
        await transaction.rollback()
