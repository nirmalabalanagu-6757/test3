"""Resolve recorded names without guessing between colliding registry entries."""

from collections.abc import Iterable


def normalize_name(value: str) -> str:
    return value.strip().replace("-", "_").replace(" ", "_").casefold()


def resolve_name(value: str, registered: Iterable[str]) -> str | None:
    names = set(registered)
    if value in names:
        return value
    matches = [name for name in names if normalize_name(name) == normalize_name(value)]
    return matches[0] if len(matches) == 1 else None
