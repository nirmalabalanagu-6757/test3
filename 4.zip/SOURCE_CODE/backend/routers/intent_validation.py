"""Admin validation, model comparison and revision history. SSO stays external."""

# ruff: noqa: B008
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import require_role
from backend.models.intent import IntentLearningCandidate
from backend.models.intent_validation import GoldenRun, GoldenSuite, IntentRevision
from backend.models.user import User
from backend.schemas.intent_validation import GoldenModelCompareRequest, GoldenSuiteCreate, GoldenTestRequest
from backend.services.action_template import (
    ActionTemplateConfigurationError,
    ActionTemplateExistsError,
    ActionTemplateNotFoundError,
)
from backend.services.audit_log import AuditLogService
from backend.services.intent_control import IntentConfigurationError, IntentControlService, IntentNotFoundError
from backend.services.intent_review import prepare_actions
from backend.services.intent_validation import IntentValidationService

router = APIRouter(
    prefix="/api/intent-validation", tags=["intent-validation"], dependencies=[Depends(require_role("admin"))]
)
_service = IntentValidationService()
_invalid = (
    ValueError,
    IntentConfigurationError,
    ActionTemplateConfigurationError,
    ActionTemplateExistsError,
    ActionTemplateNotFoundError,
)


@router.get("/suites")
async def suites(session: AsyncSession = Depends(get_session)):
    rows = (
        (await session.execute(select(GoldenSuite).order_by(GoldenSuite.created_at.desc()).limit(200))).scalars().all()
    )
    return {
        "suites": [
            {
                "id": row.id,
                "name": row.name,
                "version": row.version,
                "definition": row.definition_json,
                "reviewed_by": row.reviewed_by,
            }
            for row in rows
        ]
    }


@router.post("/suites")
async def create_suite(
    data: GoldenSuiteCreate, session: AsyncSession = Depends(get_session), user: User = Depends(require_role("admin"))
):
    row = GoldenSuite(
        name=data.name, version=data.version, definition_json=data.model_dump(mode="json"), reviewed_by=user.username
    )
    session.add(row)
    try:
        await session.flush()
        await AuditLogService().append(
            session,
            "config_change",
            user_id=user.username,
            details={"action": "golden_suite_reviewed", "suite_id": row.id, "version": row.version},
        )
        await session.commit()
        return {"id": row.id, "name": row.name, "version": row.version}
    except IntegrityError as exc:
        await session.rollback()
        raise HTTPException(409, "This suite version exists. Save changes as a new version.") from exc


@router.post("/suites/{suite_id}/test")
async def run_suite(
    suite_id: str,
    data: GoldenTestRequest,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
):
    suite = await session.get(GoldenSuite, suite_id)
    if not suite:
        raise HTTPException(404, "Golden suite not found")
    definition = GoldenSuiteCreate.model_validate(suite.definition_json)
    try:
        # Proposed actions exist only inside this rolled-back savepoint. Live
        # readers never see them; no globals, credentials or tools are replaced.
        transaction = await session.begin_nested()
        try:
            if data.actions:
                if not data.rule:
                    raise ValueError("Testing proposed actions requires the proposed rule")
                await prepare_actions(session, data.actions, data.rule, user.username)
            report = await _service.run(session, definition, proposal=data.rule)
        finally:
            await transaction.rollback()
        receipt = await _service.receipt(session, suite_id, report, user.username)
        await session.commit()
        return {"id": receipt.id, **report}
    except _invalid as exc:
        await session.rollback()
        raise HTTPException(422, str(exc)) from exc


@router.get("/runs")
async def runs(
    suite_id: str | None = None,
    mode: Literal["intent_simulation", "model_comparison"] | None = None,
    session: AsyncSession = Depends(get_session),
):
    stmt = select(GoldenRun).order_by(GoldenRun.created_at.desc()).limit(100)
    if suite_id:
        stmt = stmt.where(GoldenRun.suite_id == suite_id)
    if mode:
        stmt = stmt.where(GoldenRun.mode == mode)
    rows = (await session.execute(stmt)).scalars().all()
    return {
        "runs": [
            {
                "id": row.id,
                "suite_id": row.suite_id,
                "mode": row.mode,
                "status": row.status,
                "created_at": row.created_at,
                "results": row.results_json,
            }
            for row in rows
        ]
    }


@router.post("/suites/{suite_id}/compare-models")
async def compare_models(
    suite_id: str,
    data: GoldenModelCompareRequest,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
):
    if not data.allow_model_calls:
        raise HTTPException(422, "Explicitly enable model calls; provider charges may apply")
    suite = await session.get(GoldenSuite, suite_id)
    if not suite:
        raise HTTPException(404, "Golden suite not found")
    from backend.services.intent_model_comparison import compare

    try:
        report = await compare(session, GoldenSuiteCreate.model_validate(suite.definition_json), data)
        receipt = await _service.receipt(session, suite_id, report, user.username)
        await session.commit()
        return {"id": receipt.id, **report}
    except _invalid as exc:
        await session.rollback()
        raise HTTPException(422, str(exc)) from exc


@router.get("/intents/{intent_id}/versions")
async def versions(intent_id: str, session: AsyncSession = Depends(get_session)):
    rows = (
        (
            await session.execute(
                select(IntentRevision).where(IntentRevision.intent_id == intent_id).order_by(IntentRevision.version)
            )
        )
        .scalars()
        .all()
    )
    previous, result = {}, []
    for row in rows:
        diff = {
            key: {"old": previous.get(key), "new": value}
            for key, value in row.snapshot_json.items()
            if value != previous.get(key)
        }
        result.append(
            {
                "version": row.version,
                "snapshot": row.snapshot_json,
                "diff": diff,
                "created_by": row.created_by,
                "created_at": row.created_at,
            }
        )
        previous = row.snapshot_json
    return {"versions": list(reversed(result))}


@router.post("/intents/{intent_id}/versions/{version}/restore")
async def restore(
    intent_id: str,
    version: int,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
):
    row = await session.scalar(
        select(IntentRevision).where(IntentRevision.intent_id == intent_id, IntentRevision.version == version)
    )
    if not row:
        raise HTTPException(404, "Revision not found")
    service = IntentControlService()
    try:
        current = await service.get_rule(session, intent_id)
        snapshot = dict(row.snapshot_json)
        # Keep the current live row intact until this proposal is approved.
        snapshot.update(
            name=current.name, workflow_version=current.workflow_version + 1, enabled=True, shadow_mode=False
        )
        # A current Golden gate cannot be bypassed by restoring a pre-gate version.
        options = current.execution_options_json or {}
        if options.get("require_golden"):
            snapshot["execution_options_json"] = {
                **snapshot["execution_options_json"],
                "require_golden": True,
                "golden_suite_id": options.get("golden_suite_id"),
            }
        import uuid

        source = (snapshot.get("allowed_source_agents_json") or [snapshot["target_agent"]])[0]
        proposal = IntentLearningCandidate(
            status="pending",
            source_agent=source,
            fingerprint=uuid.uuid4().hex + uuid.uuid4().hex,
            normalized_pattern=f"restore revision {version}",
            examples_json=snapshot.get("examples_json", []),
            observed_route_json={},
            model_names_json=[],
            occurrence_count=1,
            proposal_confidence=1.0,
            proposed_execution_mode="agent_llm",
            proposed_rule_json=snapshot,
            observation_json={"restore_from_version": version},
            suggested_intent_id=intent_id,
        )
        session.add(proposal)
        await session.flush()
        await AuditLogService().append(
            session,
            "config_change",
            user_id=user.username,
            details={
                "action": "intent_restore_proposed",
                "intent_id": intent_id,
                "from_version": version,
                "candidate_id": proposal.id,
            },
        )
        await session.commit()
        return {"intent_id": intent_id, "candidate_id": proposal.id, "active_intent_unchanged": True}
    except IntentNotFoundError as exc:
        raise HTTPException(404, str(exc)) from exc
    except _invalid as exc:
        await session.rollback()
        raise HTTPException(422, str(exc)) from exc
