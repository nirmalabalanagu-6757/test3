"""Administrator APIs for approval-gated dynamic intent learning."""

# FastAPI's dependency-injection pattern uses calls in defaults.
# ruff: noqa: B008

from datetime import UTC, datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from pydantic import ValidationError
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings as app_settings
from backend.database import get_session
from backend.middleware.auth import require_role
from backend.models.intent_matching import LearningMatchBudget
from backend.models.llm_model import LlmModelRegistry
from backend.models.user import User
from backend.schemas.intent import IntentRuleResponse
from backend.schemas.intent_learning import (
    IntentLearningApprovalResponse,
    IntentLearningApproveRequest,
    IntentLearningCandidateListResponse,
    IntentLearningCandidateResponse,
    IntentLearningRejectRequest,
)
from backend.schemas.intent_matching import MatchingSettingsUpdate
from backend.services.action_template import (
    ActionTemplateConfigurationError,
    ActionTemplateExistsError,
    ActionTemplateNotFoundError,
)
from backend.services.configuration import ConfigurationService
from backend.services.intent_control import (
    IntentConfigurationError,
    IntentNameExistsError,
)
from backend.services.intent_learning import (
    IntentLearningCandidateNotFoundError,
    IntentLearningCandidateStateError,
    IntentLearningService,
)
from backend.services.intent_learning_matching import CONFIG_KEY, load_settings
from backend.services.intent_learning_review import review_token, validate_package

router = APIRouter(
    prefix="/api/intent-learning",
    tags=["intent-learning"],
    dependencies=[Depends(require_role("admin"))],
)
_service = IntentLearningService()


@router.get("/matching/settings")
async def matching_settings(session: AsyncSession = Depends(get_session)):
    config = await load_settings(session)
    usage = await session.get(LearningMatchBudget, datetime.now(UTC).date())
    return {"settings": config.model_dump(), "usage": {
        "day": datetime.now(UTC).date().isoformat(), "calls": usage.calls if usage else 0,
        "reserved_tokens": usage.reserved_tokens if usage else 0,
        "reported_tokens": usage.reported_tokens if usage else 0,
        "unreported_calls": usage.unreported_calls if usage else 0,
    }}


@router.put("/matching/settings")
async def update_matching_settings(data: MatchingSettingsUpdate, session: AsyncSession = Depends(get_session),
                                   user: User = Depends(require_role("admin"))):
    if data.settings.llm_enabled:
        if not data.allow_provider_calls:
            raise HTTPException(422, "Acknowledge provider calls and prompt sharing before enabling comparisons")
        model = await session.get(LlmModelRegistry, data.settings.llm_model)
        if not model or model.status != "active":
            raise HTTPException(422, "Choose an active model from the Model Registry")
    await ConfigurationService().set_config(
        session, CONFIG_KEY, data.settings.model_dump_json(), app_settings.app_env,
        schema_type="json", updated_by=user.username,
    )
    await session.commit()
    return await matching_settings(session)


def _error(status: int, code: str, message: str, request: Request) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": {},
                "request_id": getattr(request.state, "request_id", "unknown"),
                "timestamp": datetime.now(UTC).isoformat(),
            }
        },
    )


@router.get("", response_model=IntentLearningCandidateListResponse)
async def list_candidates(
    status: Literal["pending", "approved", "rejected"] | None = Query("pending"),
    source_agent: str | None = Query(None),
    limit: int = Query(200, ge=1, le=1_000),
    session: AsyncSession = Depends(get_session),
) -> IntentLearningCandidateListResponse:
    candidates = await _service.list_candidates(
        session,
        status=status,
        source_agent=source_agent,
        limit=limit,
    )
    return IntentLearningCandidateListResponse(
        candidates=[IntentLearningCandidateResponse.model_validate(item) for item in candidates],
        count=len(candidates),
    )


@router.get("/{candidate_id}", response_model=IntentLearningCandidateResponse)
async def get_candidate(
    candidate_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        candidate = await _service.get_candidate(session, candidate_id)
        return IntentLearningCandidateResponse.model_validate(candidate)
    except IntentLearningCandidateNotFoundError as exc:
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)


@router.get("/{candidate_id}/review")
async def review_candidate(candidate_id: str, request: Request, session: AsyncSession = Depends(get_session)):
    try:
        candidate = await _service.get_candidate(session, candidate_id)
        return {"candidate": IntentLearningCandidateResponse.model_validate(candidate),
                "review_token": await review_token(session, candidate)}
    except IntentLearningCandidateNotFoundError as exc:
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)


@router.post("/{candidate_id}/validate")
async def validate_candidate(candidate_id: str, data: IntentLearningApproveRequest, request: Request,
                             session: AsyncSession = Depends(get_session),
                             user: User = Depends(require_role("admin"))):
    try:
        return await validate_package(_service, session, candidate_id, reviewed_by=user.username,
                                      **data.model_dump(exclude={"rule", "actions", "golden_suite"}),
                                      rule=data.rule, actions=data.actions, golden_suite=data.golden_suite)
    except IntentLearningCandidateNotFoundError as exc:
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)
    except IntentLearningCandidateStateError as exc:
        return _error(409, "INTENT_REVIEW_CHANGED", str(exc), request)
    except IntegrityError:
        return _error(409, "REVIEW_VERSION_CONFLICT", "A proposed version already exists; reopen the review", request)
    except (IntentConfigurationError, ValidationError, ActionTemplateConfigurationError,
            ActionTemplateNotFoundError, ActionTemplateExistsError, IntentNameExistsError) as exc:
        return _error(422, "INVALID_INTENT_PROPOSAL", str(exc), request)


@router.post(
    "/{candidate_id}/approve",
    response_model=IntentLearningApprovalResponse,
)
async def approve_candidate(
    candidate_id: str,
    data: IntentLearningApproveRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        candidate, intent = await _service.approve(
            session,
            candidate_id,
            reviewed_by=user.username,
            rule=data.rule,
            note=data.note,
            actions=data.actions,
            golden_suite_id=data.golden_suite_id,
            allow_llm_execution=data.allow_llm_execution,
            expected_review_token=data.expected_review_token,
            golden_suite=data.golden_suite,
        )
        await session.commit()
        return IntentLearningApprovalResponse(
            candidate=IntentLearningCandidateResponse.model_validate(candidate),
            intent=IntentRuleResponse.model_validate(intent),
        )
    except IntentLearningCandidateNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)
    except IntentLearningCandidateStateError as exc:
        await session.rollback()
        return _error(409, "INTENT_CANDIDATE_ALREADY_REVIEWED", str(exc), request)
    except IntentNameExistsError as exc:
        await session.rollback()
        return _error(409, "INTENT_NAME_EXISTS", str(exc), request)
    except IntegrityError:
        await session.rollback()
        return _error(409, "REVIEW_VERSION_CONFLICT", "A proposed version already exists; reopen the review", request)
    except (IntentConfigurationError, ValidationError, ActionTemplateConfigurationError,
            ActionTemplateNotFoundError, ActionTemplateExistsError) as exc:
        await session.rollback()
        return _error(422, "INVALID_INTENT_PROPOSAL", str(exc), request)


@router.delete("/{candidate_id}")
async def delete_candidate(candidate_id: str, request: Request,
                           session: AsyncSession = Depends(get_session),
                           user: User = Depends(require_role("admin"))):
    try:
        await _service.delete_candidate(session, candidate_id, deleted_by=user.username)
        await session.commit()
        return {"deleted": candidate_id, "published_intents_and_actions_preserved": True}
    except IntentLearningCandidateNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)


@router.post(
    "/{candidate_id}/reject",
    response_model=IntentLearningCandidateResponse,
)
async def reject_candidate(
    candidate_id: str,
    data: IntentLearningRejectRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        candidate = await _service.reject(
            session,
            candidate_id,
            reviewed_by=user.username,
            note=data.note,
        )
        await session.commit()
        return IntentLearningCandidateResponse.model_validate(candidate)
    except IntentLearningCandidateNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_CANDIDATE_NOT_FOUND", str(exc), request)
    except IntentLearningCandidateStateError as exc:
        await session.rollback()
        return _error(409, "INTENT_CANDIDATE_ALREADY_REVIEWED", str(exc), request)
