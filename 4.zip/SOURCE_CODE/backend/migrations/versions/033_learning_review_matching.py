"""Bounded learning comparisons; existing intents and SSO are unchanged."""

import sqlalchemy as sa
from alembic import op

revision = "033_learning_review_matching"
down_revision = "032_intent_validation"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "intent_learning_match_cache",
        sa.Column("key", sa.String(64), primary_key=True),
        sa.Column("decision_json", sa.JSON(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_intent_learning_match_cache_expires_at", "intent_learning_match_cache", ["expires_at"])
    op.create_table(
        "intent_learning_match_budget",
        sa.Column("day", sa.Date(), primary_key=True),
        sa.Column("calls", sa.Integer(), nullable=False),
        sa.Column("reserved_tokens", sa.Integer(), nullable=False),
        sa.Column("reported_tokens", sa.Integer(), nullable=False),
        sa.Column("unreported_calls", sa.Integer(), nullable=False),
    )


def downgrade():
    op.drop_table("intent_learning_match_cache")
    op.drop_table("intent_learning_match_budget")
