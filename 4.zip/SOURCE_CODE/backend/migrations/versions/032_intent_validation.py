"""Add immutable intent revision and Golden validation storage. No SSO changes."""

import sqlalchemy as sa
from alembic import op

revision = "032_intent_validation"
down_revision = "031_intent_call_learning"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "intent_revision",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("intent_id", sa.String(36), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("snapshot_json", sa.JSON(), nullable=False),
        sa.Column("created_by", sa.String(128)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("intent_id", "version", name="uq_intent_revision_version"),
    )
    op.create_index("ix_intent_revision_intent_id", "intent_revision", ["intent_id"])
    op.create_table(
        "golden_suite",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("definition_json", sa.JSON(), nullable=False),
        sa.Column("reviewed_by", sa.String(128), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("name", "version", name="uq_golden_suite_version"),
    )
    op.create_table(
        "golden_run",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("suite_id", sa.String(36), nullable=False),
        sa.Column("mode", sa.String(24), nullable=False),
        sa.Column("status", sa.String(12), nullable=False),
        sa.Column("results_json", sa.JSON(), nullable=False),
        sa.Column("created_by", sa.String(128), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_golden_run_suite_id", "golden_run", ["suite_id"])


def downgrade():
    op.drop_table("golden_run")
    op.drop_table("golden_suite")
    op.drop_table("intent_revision")
