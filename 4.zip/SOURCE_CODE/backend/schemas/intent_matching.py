"""Administrator controls for learning-only semantic suggestions."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class LearningMatchingSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mode: Literal["off", "preview", "group"] = "preview"
    embedding_model_path: str = Field("", max_length=500)
    embedding_revision: str = Field("", max_length=128)
    semantic_threshold: float = Field(0.92, ge=0.80, le=1)
    ambiguity_margin: float = Field(0.08, ge=0.01, le=0.5)
    llm_enabled: bool = False
    llm_model: str = Field("", max_length=256)
    max_daily_calls: int = Field(20, ge=0, le=1000)
    daily_token_budget: int = Field(40000, ge=0, le=2_000_000)
    max_input_bytes: int = Field(2400, ge=512, le=8000)
    max_output_tokens: int = Field(192, ge=64, le=512)
    timeout_sec: int = Field(15, ge=2, le=30)
    cache_hours: int = Field(24, ge=1, le=168)
    golden_verified: bool = False

    @model_validator(mode="after")
    def configured(self):
        if self.llm_enabled and not self.llm_model.strip():
            raise ValueError("Select an active registered model before enabling comparisons")
        if self.mode == "group" and not self.golden_verified:
            raise ValueError("Verify positive and negative Golden cases before enabling assisted grouping")
        if self.embedding_model_path and not self.embedding_revision.strip():
            raise ValueError("Provide an embedding revision; change it whenever local model files change")
        return self


class MatchingSettingsUpdate(BaseModel):
    settings: LearningMatchingSettings
    allow_provider_calls: bool = False


class MatchVerdict(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    match_id: str | None
    relation: Literal["same", "different", "uncertain"]
