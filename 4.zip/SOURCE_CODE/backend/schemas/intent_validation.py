"""Human-authored expectations. Results must never become their own oracle."""

import json
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from backend.schemas.action_template import ActionTemplateCreate
from backend.schemas.intent import DecisionType, IntentRuleCreate


class GoldenCall(BaseModel):
    step_id: str = Field(..., min_length=1, max_length=128)
    intent_name: str = Field(..., min_length=1, max_length=128)
    agent: str = Field(..., min_length=1, max_length=128)
    tool: str = Field(..., min_length=1, max_length=128)
    action_template: str = Field(..., pattern=r"^[A-Za-z][A-Za-z0-9_.-]*@[1-9][0-9]*$")
    arguments: dict[str, Any]
    depends_on: list[str] = Field(default_factory=list, max_length=100)
    fixture: Any = Field(default_factory=dict)


class GoldenCase(BaseModel):
    name: str = Field(..., min_length=1, max_length=160)
    query: str = Field(..., min_length=1, max_length=20_000)
    source_agent: str = Field(..., min_length=1, max_length=128)
    parameters: dict[str, Any] = Field(default_factory=dict)
    confirmed: bool = False
    expected_decision: DecisionType = "route"
    expected_intents: list[str] = Field(default_factory=list, max_length=10)
    expected_status: Literal["completed", "partial", "failed"] = "completed"
    calls: list[GoldenCall] = Field(default_factory=list, max_length=100)
    expected_response_contains: list[str] = Field(default_factory=list, max_length=50)

    @model_validator(mode="after")
    def unique_steps(self):
        keys = [(call.intent_name, call.step_id) for call in self.calls]
        if len(set(keys)) != len(keys):
            raise ValueError("Expected call keys (intent_name, step_id) must be unique")
        if self.expected_decision != "route" and self.calls:
            raise ValueError("Non-routing expectations cannot contain tool calls")
        return self


class GoldenSuiteCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    version: int = Field(1, ge=1)
    description: str = Field("", max_length=2000)
    cases: list[GoldenCase] = Field(..., min_length=1, max_length=100)
    expectations_reviewed: bool = False

    @model_validator(mode="after")
    def reviewed_and_bounded(self):
        if not self.expectations_reviewed:
            raise ValueError("Review independent expectations before saving a Golden suite")
        if len({case.name for case in self.cases}) != len(self.cases):
            raise ValueError("Golden case names must be unique")
        if len(json.dumps(self.model_dump(), allow_nan=False).encode()) > 1_000_000:
            raise ValueError("Golden suite exceeds 1 MB; use small synthetic fixtures")
        from backend.services.intent_workflow_learning import _contains_secret

        if _contains_secret(self.model_dump()):
            raise ValueError("Golden suites must not contain credentials; use synthetic credential-free fixtures")
        return self


class GoldenTestRequest(BaseModel):
    rule: IntentRuleCreate | None = None
    actions: list[ActionTemplateCreate] = Field(default_factory=list, max_length=100)


class GoldenModelCompareRequest(BaseModel):
    models: list[str] = Field(..., min_length=1, max_length=2)
    agent: str = Field(..., min_length=1, max_length=128)
    allow_model_calls: bool = False
    max_turns: int = Field(4, ge=1, le=10)
    max_output_tokens: int = Field(2048, ge=64, le=8192)
    max_total_model_calls: int = Field(20, ge=1, le=50)

    @model_validator(mode="after")
    def distinct_models(self):
        if any(not name.strip() or name != name.strip() for name in self.models):
            raise ValueError("Model names must be nonblank registry identifiers without surrounding spaces")
        if len(set(self.models)) != len(self.models):
            raise ValueError("Select distinct models for comparison")
        return self
