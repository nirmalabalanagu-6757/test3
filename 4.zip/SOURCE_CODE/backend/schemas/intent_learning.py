"""Schemas for approval-gated dynamic intent learning."""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

from backend.schemas.action_template import ActionTemplateCreate
from backend.schemas.intent import IntentRuleCreate, IntentRuleResponse
from backend.schemas.intent_validation import GoldenSuiteCreate

IntentLearningStatus = Literal["pending", "approved", "rejected"]
ProposedExecutionMode = Literal["direct_action", "agent_llm", "multi_agent"]


class IntentLearningCandidateResponse(BaseModel):
    id: str
    status: IntentLearningStatus
    source_agent: str
    fingerprint: str
    normalized_pattern: str
    examples_json: list[str]
    observed_route_json: dict[str, list[str]]
    model_names_json: list[str]
    occurrence_count: int
    proposal_confidence: float
    proposed_execution_mode: ProposedExecutionMode
    proposed_rule_json: dict
    observation_json: dict = Field(default_factory=dict)
    suggested_intent_id: str | None
    approved_intent_id: str | None
    reviewed_by: str | None
    review_note: str | None
    reviewed_at: datetime | None
    first_seen_at: datetime
    last_seen_at: datetime

    model_config = {"from_attributes": True}


class IntentLearningCandidateListResponse(BaseModel):
    candidates: list[IntentLearningCandidateResponse]
    count: int


class IntentLearningApproveRequest(BaseModel):
    expected_review_token: str = Field(..., pattern=r"^[0-9a-f]{64}$")
    golden_suite: GoldenSuiteCreate | None = None
    actions: list[ActionTemplateCreate] = Field(default_factory=list, max_length=100)
    golden_suite_id: str | None = Field(None, max_length=36)
    allow_llm_execution: bool = False
    rule: IntentRuleCreate | None = Field(
        None,
        description=(
            "Optional administrator-reviewed rule. When omitted, the current "
            "database-generated proposal is validated and used."
        ),
    )
    note: str | None = Field(None, max_length=2_000)


class IntentLearningRejectRequest(BaseModel):
    note: str | None = Field(None, max_length=2_000)


class IntentLearningApprovalResponse(BaseModel):
    candidate: IntentLearningCandidateResponse
    intent: IntentRuleResponse
