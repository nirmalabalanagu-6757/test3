"""Comparison metadata only. No prompts, credentials or business results."""

from datetime import date, datetime

from sqlalchemy import JSON, Date, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class LearningMatchCache(Base):
    __tablename__ = "intent_learning_match_cache"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    decision_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)


class LearningMatchBudget(Base):
    __tablename__ = "intent_learning_match_budget"
    day: Mapped[date] = mapped_column(Date, primary_key=True)
    calls: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    reserved_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    reported_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    unreported_calls: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
