"""Offline protocol tests. No Anthropic/Vertex credentials or paid calls."""

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from google.adk.models.llm_request import LlmRequest
from google.genai.types import Content, FunctionCall, FunctionResponse, GenerateContentConfig, Part

from agents.base import anthropic_llm as claude


def call(name="sql_tool", id="a", args=None):
    return Part(function_call=FunctionCall(id=id, name=name, args=args or {}))


def result(name="sql_tool", id="a"):
    return Part(function_response=FunctionResponse(id=id, name=name, response={"rows": []}))


def test_repeated_parallel_same_tool_preserves_ids_and_result_order():
    content = [
        Content(role="model", parts=[call(id="a"), call(id="b")]),
        Content(role="user", parts=[Part(text="continue"), result(id="b")]),
        Content(role="user", parts=[result(id="a")]),
    ]
    _, messages = claude._contents_to_anthropic_messages(content)
    assert len(messages) == 2
    assert [block["tool_use_id"] for block in messages[1]["content"][:2]] == ["b", "a"]
    assert messages[1]["content"][2] == {"type": "text", "text": "continue"}


@pytest.mark.parametrize("parts", [[result(id="unknown")], [result(id=None)]])
def test_ambiguous_or_foreign_result_ids_fail_closed(parts):
    with pytest.raises(ValueError, match="mismatched"):
        claude._contents_to_anthropic_messages(
            [Content(role="model", parts=[call(id="a"), call(id="b")]), Content(role="user", parts=parts)]
        )


def test_missing_and_duplicate_call_ids():
    with pytest.raises(ValueError, match="matching results"):
        claude._contents_to_anthropic_messages([Content(role="model", parts=[call()])])
    with pytest.raises(ValueError, match="Duplicate"):
        claude._contents_to_anthropic_messages([Content(role="model", parts=[call(), call()])])
    _, messages = claude._contents_to_anthropic_messages(
        [
            Content(role="model", parts=[call(id=None)]),
            Content(role="user", parts=[result(id=None)]),
            Content(role="model", parts=[call(id=None)]),
            Content(role="user", parts=[result(id=None)]),
        ]
    )
    assert messages[0]["content"][0]["id"] != messages[2]["content"][0]["id"]


def test_nested_schema_constraints_and_signed_thinking_roundtrip():
    schema = {
        "type": "OBJECT",
        "properties": {
            "rows": {
                "type": "ARRAY",
                "items": {"type": "OBJECT", "properties": {"id": {"type": "INTEGER"}}, "required": ["id"]},
            }
        },
        "additionalProperties": False,
    }
    normalized = claude._normalize_schema(schema)
    assert normalized["properties"]["rows"]["items"]["properties"]["id"]["type"] == "integer"
    assert normalized["additionalProperties"] is False
    signed = {"type": "thinking", "thinking": "private reasoning", "signature": "synthetic-signature"}
    response = claude._anthropic_response_to_llm_response(
        {
            "content": [signed, {"type": "tool_use", "id": "a", "name": "sql_tool", "input": {}}],
            "stop_reason": "tool_use",
            "usage": {
                "input_tokens": 3,
                "output_tokens": 4,
                "cache_creation_input_tokens": 5,
                "cache_read_input_tokens": 7,
            },
        },
        "claude-sonnet-4-6",
    )
    assert response.usage_metadata.prompt_token_count == 15
    assert not response.turn_complete
    _, messages = claude._contents_to_anthropic_messages([response.content, Content(role="user", parts=[result()])])
    assert messages[0]["content"][0] == signed


@pytest.mark.asyncio
@pytest.mark.parametrize("vertex", [False, True])
async def test_sonnet_46_request_preserves_instructions_schemas_and_routing(monkeypatch, vertex):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(
            200,
            json={
                "model": "claude-sonnet-4-6",
                "stop_reason": "end_turn",
                "content": [{"type": "text", "text": "ok"}],
                "usage": {"input_tokens": 12, "output_tokens": 2},
            },
        )

    original_client = httpx.AsyncClient
    monkeypatch.setattr(
        claude.httpx, "AsyncClient", lambda **kwargs: original_client(transport=httpx.MockTransport(respond), **kwargs)
    )
    monkeypatch.setattr(claude, "_resolve_api_key", AsyncMock(return_value="test-only-key"))
    monkeypatch.setattr(claude, "_get_vertex_access_token", AsyncMock(return_value="test-only-adc"))
    monkeypatch.setattr(claude, "_increment_model_usage", AsyncMock())
    if vertex:
        monkeypatch.setenv("GOOGLE_CLOUD_PROJECT", "synthetic-project")
    else:
        monkeypatch.delenv("GOOGLE_CLOUD_PROJECT", raising=False)
    declaration = SimpleNamespace(
        description="read synthetic SQL",
        parameters=None,
        parameters_json_schema={"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
    )
    tool = SimpleNamespace(_get_declaration=lambda: declaration)
    request = LlmRequest(
        contents=[Content(role="user", parts=[Part(text="test")])],
        config=GenerateContentConfig(system_instruction="Only approved tools.", max_output_tokens=100),
    )
    request.tools_dict["sql_tool"] = tool
    replies = [reply async for reply in claude.AnthropicLlm(model="claude-sonnet-4-6").generate_content_async(request)]
    assert replies[0].content.parts[0].text == "ok"
    body = json.loads(requests[0].content)
    assert body["system"] == "Only approved tools."
    assert body["max_tokens"] == 100
    assert body["tools"][0]["input_schema"]["required"] == ["query"]
    assert "claude-sonnet-4-6" in (str(requests[0].url) if vertex else body["model"])
    assert ("x-api-key" in requests[0].headers) is not vertex


def test_missing_usage_stays_unknown():
    response = claude._anthropic_response_to_llm_response(
        {"content": [], "usage": {"output_tokens": 7}}, "claude-sonnet-4-6"
    )
    assert response.usage_metadata.prompt_token_count is None
