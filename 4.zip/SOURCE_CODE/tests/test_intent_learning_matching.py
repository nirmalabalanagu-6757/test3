"""Offline matching regressions: no real models, embeddings or business tools."""

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from pydantic import ValidationError
from test_intent_learning import _agent, _LearningSession

from backend.models.config_model import Configuration
from backend.models.intent import IntentLearningCandidate
from backend.models.llm_model import LlmModelRegistry
from backend.schemas.intent_matching import LearningMatchingSettings
from backend.services.intent_learning import IntentLearningService
from backend.services.intent_learning_matching import (
    LearningMatcher,
    lexical_score,
    matching_text,
    model_verdict,
    operation_guard,
    redact,
)


class ConfigSession:
    def __init__(self, config, *, active=True):
        self.config = config
        self.active = active

    async def get(self, model, key):
        if model is Configuration:
            return SimpleNamespace(value=self.config.model_dump_json())
        if model is LlmModelRegistry:
            return SimpleNamespace(status="active" if self.active else "disabled", updated_at="revision-1")
        return None


class Ledger:
    def __init__(self, allowed=True):
        self.entries = {}
        self.calls = 0
        self.allowed = allowed
        self.reservations = []

    async def cached(self, key):
        return self.entries.get(key)

    async def reserve(self, config, tokens, day):
        if not self.allowed:
            return False
        self.calls += 1
        self.reservations.append(tokens)
        return True

    async def finish(self, config, key, verdict, day, usage):
        self.entries[key] = verdict


def config(**kwargs):
    return LearningMatchingSettings(**{
        "mode": "group", "golden_verified": True, "llm_enabled": True, "llm_model": "test-model", **kwargs,
    })


CONTEXT = {"source": "backup", "route": {"backup": ["sql"]}, "plan": "exact-plan-v1"}
OPTIONS = [{"id": "c1", "text": "backup overview parameter", "version": 1}]


@pytest.mark.parametrize("left,right", [
    ("show latest backup details for parameter", "Please help me with most recent backup details of parameter"),
    ("Please check newest snapshot status", "show latest backup status"),
])
def test_polite_paraphrases_match_without_model(left, right):
    assert lexical_score(left.casefold(), right.casefold()) >= 0.8


@pytest.mark.parametrize("other", [
    "restore latest backup", "show all backups", "show latest failed backups", "delete latest backup",
    "show oldest backup", "do not show latest backup", "show latest backup count",
])
def test_operation_filters_aggregation_and_negation_stay_separate(other):
    assert lexical_score("show latest backup", other) == 0


def test_only_declared_parameters_are_masked():
    params = {"properties": {"server": {"type": "string", "x-intent": {"extractor": "label"}}}}
    assert matching_text("Show backups for server APP01", params) == matching_text("Show backups for server APP02", params)
    assert matching_text("Show backups APP01") != matching_text("Show backups APP02")
    assert "APP01".casefold() not in matching_text("Show backups for server APP01", params)


def test_redacts_credentials_before_comparison():
    text = redact('password="multi word secret" https://user:pass@host Bearer abc.def.ghi token=secret')
    assert "multi word" not in text and "user:pass" not in text and "abc.def" not in text


@pytest.mark.asyncio
async def test_clear_semantic_match_uses_no_llm_or_ledger():
    compare = AsyncMock()
    ledger = Ledger()
    matcher = LearningMatcher(ledger=ledger, compare=compare, embed=lambda *_: [0.98])
    selected = await matcher.suggest(ConfigSession(config(embedding_model_path="local", embedding_revision="v1")),
                                     "backup report parameter", OPTIONS, CONTEXT)
    assert selected == "c1"
    assert matcher.evidence["method"] == "semantic"
    assert ledger.calls == 0 and not compare.called


@pytest.mark.asyncio
async def test_preview_records_suggestion_but_does_not_group():
    compare = AsyncMock(return_value=({"match_id": "c1", "relation": "same"}, 80))
    matcher = LearningMatcher(ledger=Ledger(), compare=compare)
    assert await matcher.suggest(ConfigSession(config(mode="preview")), "backup report parameter", OPTIONS, CONTEXT) is None
    assert matcher.evidence["suggested_id"] == "c1" and matcher.evidence["applied"] is False


@pytest.mark.asyncio
async def test_uncertain_comparison_cached_and_invalidated_by_plan_model_or_dependency():
    compare = AsyncMock(return_value=({"match_id": "c1", "relation": "same"}, 80))
    ledger = Ledger()
    for _ in range(2):
        matcher = LearningMatcher(ledger=ledger, compare=compare)
        assert await matcher.suggest(ConfigSession(config()), "backup report parameter", OPTIONS, CONTEXT) == "c1"
    assert compare.call_count == 1 and matcher.evidence["cache_hit"] is True
    for ctx, settings, dependency in [
        ({**CONTEXT, "plan": "v2"}, config(), ""),
        (CONTEXT, config(llm_model="another-model"), ""),
        (CONTEXT, config(), "connection-v2"),
    ]:
        assert await LearningMatcher(ledger=ledger, compare=compare, dependency_key=dependency).suggest(
            ConfigSession(settings), "backup report parameter", OPTIONS, ctx) == "c1"
    assert compare.call_count == 4


@pytest.mark.asyncio
async def test_budget_failure_never_falls_back_to_an_unbounded_model():
    compare = AsyncMock()
    matcher = LearningMatcher(ledger=Ledger(False), compare=compare)
    assert await matcher.suggest(ConfigSession(config()), "backup report parameter", OPTIONS, CONTEXT) is None
    assert "budget exhausted" in matcher.evidence["reason"]
    compare.assert_not_called()


@pytest.mark.asyncio
@pytest.mark.parametrize("reply", [
    {"match_id": "not-offered", "relation": "same"},
    {"match_id": "c1", "relation": "uncertain"},
    {"match_id": "c1", "relation": "same", "approve": True},
])
async def test_untrusted_verdict_cannot_select_unknown_candidate_or_approve(reply):
    matcher = LearningMatcher(ledger=Ledger(), compare=AsyncMock(return_value=(reply, None)))
    assert await matcher.suggest(ConfigSession(config()), "backup report parameter", OPTIONS, CONTEXT) is None


@pytest.mark.asyncio
async def test_timeout_keeps_reserved_call_and_is_safe():
    ledger = Ledger()
    matcher = LearningMatcher(ledger=ledger, compare=AsyncMock(side_effect=TimeoutError("sensitive body")))
    assert await matcher.suggest(ConfigSession(config()), "backup report parameter", OPTIONS, CONTEXT) is None
    assert ledger.calls == 1 and "sensitive" not in str(matcher.evidence)


@pytest.mark.asyncio
async def test_one_attempt_per_observation_and_no_long_prompt_truncation():
    compare = AsyncMock(return_value=({"match_id": None, "relation": "different"}, 50))
    matcher = LearningMatcher(ledger=Ledger(), compare=compare)
    session = ConfigSession(config())
    await matcher.suggest(session, "backup report parameter", OPTIONS, CONTEXT)
    await matcher.suggest(session, "backup report parameter", OPTIONS, CONTEXT)
    assert compare.call_count == 1
    another = LearningMatcher(ledger=Ledger(), compare=compare)
    assert await another.suggest(session, "backup " * 300, OPTIONS, CONTEXT) is None
    assert compare.call_count == 1


@pytest.mark.asyncio
async def test_no_plan_off_disabled_model_or_operation_conflict_never_calls():
    compare = AsyncMock()
    for settings, context, query, active in [
        (config(mode="off"), CONTEXT, "backup report", True),
        (config(), {**CONTEXT, "plan": ""}, "backup report", True),
        (config(), CONTEXT, "backup report", False),
        (config(), CONTEXT, "restore backup report", True),
    ]:
        assert await LearningMatcher(ledger=Ledger(), compare=compare).suggest(
            ConfigSession(settings, active=active), query, OPTIONS, context) is None
    compare.assert_not_called()


@pytest.mark.asyncio
async def test_semantic_tie_requests_review_without_llm_if_disabled():
    matcher = LearningMatcher(ledger=Ledger(), embed=lambda *_: [0.96, 0.95], compare=AsyncMock())
    assert await matcher.suggest(ConfigSession(config(llm_enabled=False, embedding_model_path="local", embedding_revision="v1")),
                                 "backup report", [*OPTIONS, {"id": "c2", "text": "backup result", "version": 1}], CONTEXT) is None
    matcher.compare.assert_not_called()


def candidate(**changes):
    return IntentLearningCandidate(**{
        "id": "c1", "status": "pending", "source_agent": "backup", "normalized_pattern": "show latest backup details",
        "examples_json": ["show latest backup details"], "observed_route_json": {"backup": ["sql"]},
        "proposed_rule_json": {}, "observation_json": {"plan_key": "v1"}, **changes,
    })


@pytest.mark.asyncio
async def test_real_pending_lookup_groups_example_and_checks_agent_connection_plan():
    item = candidate()
    session = _LearningSession(agents=[_agent("backup")], candidates=[item])
    service = IntentLearningService()
    assert await service._find_similar_pending(session, "backup", "please help me with latest backup details", {"backup": ["sql"]}, plan_key="v1") is item
    for source, route, plan in [("another", {"backup": ["sql"]}, "v1"), ("backup", {"backup": ["other"]}, "v1"), ("backup", {"backup": ["sql"]}, "v2")]:
        assert await service._find_similar_pending(session, source, "please help me with latest backup details", route, plan_key=plan) is None


@pytest.mark.asyncio
async def test_adapter_has_no_tools_and_accepts_strict_json_with_reported_usage():
    class FakeModel:
        async def generate_content_async(self, request, stream):
            assert request.tools_dict == {} and not request.config.tools and stream is False
            assert request.config.max_output_tokens == 192
            yield SimpleNamespace(error_code=None, content=SimpleNamespace(parts=[SimpleNamespace(
                text=json.dumps({"match_id": "c1", "relation": "same"}), function_call=None, thought=False,
            )]), usage_metadata=SimpleNamespace(total_token_count=123))
    verdict, tokens = await model_verdict(config(), "{}", factory=lambda _: FakeModel())
    assert verdict["match_id"] == "c1" and tokens == 123


def test_group_enable_requires_golden_attestation_and_model_selection():
    with pytest.raises(ValidationError):
        LearningMatchingSettings(mode="group")
    with pytest.raises(ValidationError):
        LearningMatchingSettings(llm_enabled=True)
    assert operation_guard("show latest backup") == operation_guard("please help with latest backup")
