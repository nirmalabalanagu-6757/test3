"""Opt-in PostgreSQL integration tests, entirely inside rolled-back schemas."""

import importlib
import os
import uuid

import pytest
import pytest_asyncio
from alembic.migration import MigrationContext
from alembic.operations import Operations
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession
from test_intent_learning import _agent, _tool
from test_intent_learning_database import local_engine
from test_intent_workflow_learning import action, compile_trace, one_call, rule_for

from backend.database import Base
from backend.models.action_template import ActionTemplate
from backend.models.intent import IntentLearningCandidate, IntentRule
from backend.models.intent_validation import GoldenSuite, IntentRevision
from backend.models.llm_model import LlmModelRegistry
from backend.models.policy import CommunicationPolicy
from backend.models.tool import ToolAgentAssignment
from backend.schemas.action_template import ActionTemplateCreate
from backend.schemas.intent import IntentRuleCreate, IntentRuleUpdate
from backend.schemas.intent_validation import GoldenModelCompareRequest, GoldenSuiteCreate
from backend.services.intent_control import IntentConfigurationError, IntentControlService
from backend.services.intent_learning import IntentLearningService
from backend.services.intent_model_comparison import compare
from backend.services.intent_validation import IntentValidationService

pytestmark = [
    pytest.mark.asyncio,
    pytest.mark.skipif(os.getenv("INTENT_TEST_LOCAL_DB") != "1", reason="Opt-in local PostgreSQL"),
]


@pytest_asyncio.fixture
async def db():
    engine = local_engine()
    try:
        async with engine.connect() as connection:
            transaction = await connection.begin()
            try:
                schema = "validation_test_" + uuid.uuid4().hex
                await connection.execute(text(f'CREATE SCHEMA "{schema}"'))
                connection = await connection.execution_options(schema_translate_map={None: schema})
                await connection.run_sync(Base.metadata.create_all)
                async with AsyncSession(bind=connection, expire_on_commit=False) as session:
                    yield session
            finally:
                if transaction.is_active:
                    await transaction.rollback()
    finally:
        await engine.dispose()


async def setup(db, *, published=True):
    tool = _tool("backup_api")
    tool.input_schema_json = {
        "type": "object",
        "properties": {"operation": {"type": "string", "enum": ["list"]}, "server": {"type": "string"}},
        "required": ["operation", "server"],
    }
    db.add_all([_agent("backup_agent"), tool])
    if published:
        db.add(action())
    await db.flush()
    db.add(ToolAgentAssignment(agent_name="backup_agent", tool_name="backup_api"))
    await db.flush()


def suite_for(rule, *, action_ref="backup.list@1", wrong=False):
    return GoldenSuiteCreate(
        name="backup-regression",
        expectations_reviewed=True,
        cases=[
            {
                "name": "fresh server",
                "query": "Show backups for server APP02",
                "source_agent": "backup_agent",
                "expected_intents": [rule.name],
                "calls": [
                    {
                        "intent_name": rule.name,
                        "step_id": "call_1",
                        "agent": "backup_agent",
                        "tool": "backup_api",
                        "action_template": action_ref,
                        "arguments": {"operation": "list", "server": "WRONG" if wrong else "APP02"},
                        "fixture": {"rows": [{"server": "APP02", "status": "OK"}]},
                    }
                ],
                "expected_response_contains": ["APP02"],
            },
            {
                "name": "unrelated",
                "query": "Discuss unrelated subject",
                "source_agent": "backup_agent",
                "expected_decision": "no_match",
                "expected_intents": [],
                "calls": [],
            },
        ],
    )


async def test_full_resolution_competition_connections_args_and_policy(db):
    await setup(db)
    proposal = rule_for(
        compile_trace(one_call(), [action()], "Show backups for server APP01"), "Show backups for server APP01"
    )
    suite = suite_for(proposal)
    report = await IntentValidationService().run(db, suite, proposal=proposal)
    assert report["status"] == "PASS", report
    assert report["cases"][0]["model_calls"] == 0
    report = await IntentValidationService().run(db, suite_for(proposal, wrong=True), proposal=proposal)
    assert report["status"] == "FAIL"
    competitor = proposal.model_copy(update={"name": "competing", "priority": 200, "ambiguity_action": "clarify"})
    db.add(IntentRule(**competitor.model_dump(mode="json")))
    await db.flush()
    report = await IntentValidationService().run(db, suite, proposal=proposal)
    assert report["status"] == "FAIL"  # isolated-rule tests would miss this
    current = await db.scalar(select(IntentRule).where(IntentRule.name == "competing"))
    current.enabled = False
    db.add(CommunicationPolicy(source_agent="backup_agent", target_agent="backup_agent", action="deny", priority=999))
    await db.flush()
    report = await IntentValidationService().run(db, suite, proposal=proposal)
    assert report["status"] == "FAIL"


async def test_atomic_review_publishes_actions_only_after_golden_pass_and_deletion_preserves_intent(db):
    await setup(db, published=False)
    learning = IntentLearningService()
    candidate = await learning.observe(
        db, source_agent="backup_agent", query="Show backups for server APP01", tool_trace=one_call()
    )
    rule = IntentRuleCreate.model_validate(candidate.proposed_rule_json)
    actions = [ActionTemplateCreate.model_validate(item) for item in candidate.observation_json["draft_actions"]]
    assert candidate.proposed_execution_mode == "direct_action"
    reference = rule.workflow_json[0].action_template
    suite = suite_for(rule, action_ref=reference, wrong=True)
    bad = GoldenSuite(name="bad", version=1, definition_json=suite.model_dump(mode="json"), reviewed_by="tester")
    db.add(bad)
    await db.flush()
    candidate_id, bad_id = candidate.id, bad.id
    with pytest.raises(IntentConfigurationError, match="Golden approval blocked"):
        async with db.begin_nested():
            await learning.approve(
                db,
                candidate_id,
                rule=rule.model_copy(deep=True),
                actions=actions,
                golden_suite_id=bad_id,
                reviewed_by="tester",
            )
    assert list((await db.execute(select(ActionTemplate))).scalars()) == []
    assert list((await db.execute(select(IntentRule))).scalars()) == []
    assert (await db.get(IntentLearningCandidate, candidate_id)).status == "pending"
    good = GoldenSuite(
        name="good",
        version=1,
        definition_json=suite_for(rule, action_ref=reference).model_dump(mode="json"),
        reviewed_by="tester",
    )
    db.add(good)
    await db.flush()
    _, approved = await learning.approve(
        db, candidate_id, rule=rule, actions=actions, golden_suite_id=good.id, reviewed_by="tester"
    )
    assert approved.enabled
    assert (await db.scalar(select(ActionTemplate))).lifecycle_status == "active"
    intent_id = approved.id
    await learning.delete_candidate(db, candidate_id, deleted_by="tester")
    assert await db.get(IntentLearningCandidate, candidate_id) is None
    assert await db.get(IntentRule, intent_id) is not None
    assert await db.scalar(select(IntentRevision).where(IntentRevision.intent_id == intent_id)) is not None


async def test_revision_and_restore_proposal_leave_current_active_intent_unchanged(db):
    from types import SimpleNamespace

    from backend.routers.intent_validation import restore

    await setup(db)
    service = IntentControlService()
    proposal = rule_for(
        compile_trace(one_call(), [action()], "Show backups for server APP01"), "Show backups for server APP01"
    )
    current = await service.create_rule(db, proposal, created_by="tester")
    updated = await service.update_rule(db, current.id, IntentRuleUpdate(display_name="New name"), updated_by="tester")
    assert updated.workflow_version == 2
    assert len(list((await db.execute(select(IntentRevision))).scalars())) == 2
    result = await restore(current.id, 1, session=db, user=SimpleNamespace(username="tester"))
    assert result["active_intent_unchanged"]
    assert current.enabled and current.display_name == "New name" and current.workflow_version == 2
    candidate = await db.get(IntentLearningCandidate, result["candidate_id"])
    assert candidate.status == "pending" and candidate.proposed_rule_json["workflow_version"] == 3


async def test_multitool_multiagent_dependencies_and_repeated_queries(db):
    await setup(db)
    db.add_all(
        [
            _agent("database_agent"),
            _tool("database_api"),
            action(
                "database.lookup",
                "database_api",
                payload={"server": "{{server}}"},
                properties={"server": {"type": "string"}},
                required=["server"],
            ),
        ]
    )
    await db.flush()
    db.add(ToolAgentAssignment(agent_name="database_agent", tool_name="database_api"))
    await db.flush()
    trace = one_call(output={"lookup_id": "derived-old"})
    trace.call("database_agent", "database_api", {"server": "derived-old"}, "b")
    trace.response("database_agent", "database_api", {"rows": []}, "b")
    templates = list((await db.execute(select(ActionTemplate))).scalars())
    proposal = rule_for(
        compile_trace(trace, templates, "Show backups for server APP01"), "Show backups for server APP01"
    )
    suite = suite_for(proposal)
    suite.cases[0].calls[0].fixture = {"lookup_id": "fresh-link-APP02"}
    from backend.schemas.intent_validation import GoldenCall

    suite.cases[0].calls.append(
        GoldenCall(
            intent_name=proposal.name,
            step_id="call_2",
            agent="database_agent",
            tool="database_api",
            action_template="database.lookup@1",
            arguments={"server": "fresh-link-APP02"},
            depends_on=["call_1"],
            fixture={"rows": ["APP02"]},
        )
    )
    for _ in range(3):
        report = await IntentValidationService().run(db, suite, proposal=proposal)
        assert report["status"] == "PASS", report
        assert len(report["cases"][0]["actual_calls"]) == 2


async def test_model_comparison_makes_real_adapter_calls_but_only_fixture_tools(db):
    from google.adk.models.llm_response import LlmResponse
    from google.genai.types import Content, FunctionCall, Part

    await setup(db)
    db.add(LlmModelRegistry(name="claude-sonnet-4-6", provider="anthropic", status="active"))
    await db.flush()
    seen = []

    class SyntheticProvider:
        async def generate_content_async(self, request, stream=False):
            seen.append(request)
            if len(request.contents) == 1:
                yield LlmResponse(
                    content=Content(
                        role="model",
                        parts=[
                            Part(
                                function_call=FunctionCall(
                                    name="backup_api", args={"operation": "list", "server": "APP02"}, id="toolu-test"
                                )
                            )
                        ],
                    )
                )
            else:
                assert request.contents[-1].parts[0].function_response.id == "toolu-test"
                yield LlmResponse(content=Content(role="model", parts=[Part(text="APP02 is OK")]), turn_complete=True)

    proposal = rule_for(
        compile_trace(one_call(), [action()], "Show backups for server APP01"), "Show backups for server APP01"
    )
    suite = suite_for(proposal)
    suite.cases = suite.cases[:1]
    report = await compare(
        db,
        suite,
        GoldenModelCompareRequest(models=["claude-sonnet-4-6"], agent="backup_agent", allow_model_calls=True),
        factory=lambda name: SyntheticProvider(),
    )
    assert report["status"] == "PASS", report
    assert report["results"][0]["model_calls"] == 2
    assert report["results"][0]["input_tokens"] is None
    assert report["results"][0]["estimated_cost"] is None
    assert len(seen) == 2


async def test_migration032_upgrade_downgrade_in_isolated_schema():
    migration = importlib.import_module("backend.migrations.versions.032_intent_validation")
    engine = local_engine()
    try:
        async with engine.connect() as connection:
            transaction = await connection.begin()
            try:
                schema = "migration_test_" + uuid.uuid4().hex
                await connection.execute(text(f'CREATE SCHEMA "{schema}"'))
                await connection.execute(text(f'SET LOCAL search_path TO "{schema}"'))

                def round_trip(sync):
                    with Operations.context(MigrationContext.configure(sync)):
                        migration.upgrade()
                        migration.downgrade()
                        migration.upgrade()

                await connection.run_sync(round_trip)
                assert (await connection.execute(text("SELECT count(*) FROM golden_suite"))).scalar_one() == 0
            finally:
                await transaction.rollback()
    finally:
        await engine.dispose()


async def test_model_provider_error_reports_unknown_usage_not_free_tokens(db):
    from google.adk.models.llm_response import LlmResponse

    await setup(db)
    db.add(LlmModelRegistry(name="claude-sonnet-4-6", provider="anthropic", status="active"))
    await db.flush()

    class ErrorProvider:
        async def generate_content_async(self, request, stream=False):
            yield LlmResponse(error_code="429", error_message="synthetic limit")

    proposal = rule_for(
        compile_trace(one_call(), [action()], "Show backups for server APP01"), "Show backups for server APP01"
    )
    suite = suite_for(proposal)
    suite.cases = suite.cases[:1]
    report = await compare(
        db,
        suite,
        GoldenModelCompareRequest(models=["claude-sonnet-4-6"], agent="backup_agent", allow_model_calls=True),
        factory=lambda name: ErrorProvider(),
    )
    assert report["status"] == "FAIL"
    assert report["results"][0]["model_calls"] == 1
    assert report["results"][0]["input_tokens"] is None
    assert report["results"][0]["output_tokens"] is None


async def test_history_filters_by_mode_and_suite_without_mixing_receipts(db):
    from backend.models.intent_validation import GoldenRun
    from backend.routers.intent_validation import runs

    db.add_all(
        [
            GoldenRun(
                suite_id="suite-a", mode="intent_simulation", status="PASS", results_json={}, created_by="tester"
            ),
            GoldenRun(
                suite_id="suite-a", mode="model_comparison", status="REVIEW", results_json={}, created_by="tester"
            ),
            GoldenRun(suite_id="suite-b", mode="model_comparison", status="FAIL", results_json={}, created_by="tester"),
        ]
    )
    await db.flush()
    comparison = await runs(suite_id="suite-a", mode="model_comparison", session=db)
    assert len(comparison["runs"]) == 1
    assert comparison["runs"][0]["status"] == "REVIEW"
    assert len((await runs(mode="model_comparison", session=db))["runs"]) == 2
    assert len((await runs(session=db))["runs"]) == 3
