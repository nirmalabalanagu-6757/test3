"""Actual PostgreSQL package transactions and budget limits; rolled-back schemas."""
# ruff: noqa: F811 -- pytest discovers the imported fixture by its public name

import os
from datetime import UTC, datetime

import pytest
from sqlalchemy import select
from test_intent_validation_database import db, setup, suite_for  # noqa: F401 -- shared isolated fixture
from test_intent_workflow_learning import one_call

from backend.models.action_template import ActionTemplate
from backend.models.intent import IntentLearningCandidate, IntentRule
from backend.models.intent_matching import LearningMatchBudget
from backend.models.intent_validation import GoldenRun, GoldenSuite, IntentRevision
from backend.models.tool import ToolRegistry
from backend.schemas.action_template import ActionTemplateCreate
from backend.schemas.intent import IntentRuleCreate
from backend.schemas.intent_matching import LearningMatchingSettings
from backend.services.intent_control import IntentConfigurationError
from backend.services.intent_learning import IntentLearningCandidateStateError, IntentLearningService
from backend.services.intent_learning_matching import reserve_in_session
from backend.services.intent_learning_review import review_token, validate_package

pytestmark = [pytest.mark.asyncio, pytest.mark.skipif(os.getenv("INTENT_TEST_LOCAL_DB") != "1", reason="Opt-in local PostgreSQL")]


async def package(db):
    await setup(db, published=False)
    service = IntentLearningService()
    candidate = await service.observe(db, source_agent="backup_agent", query="Show backups for server APP01",
                                      tool_trace=one_call())
    rule = IntentRuleCreate.model_validate(candidate.proposed_rule_json)
    actions = [ActionTemplateCreate.model_validate(raw) for raw in candidate.observation_json["draft_actions"]]
    assert len(actions) == 1
    suite = suite_for(rule, action_ref=f"{actions[0].name}@1")
    kwargs = {"reviewed_by": "reviewer", "rule": rule, "actions": actions, "golden_suite": suite,
              "expected_review_token": await review_token(db, candidate)}
    return service, candidate.id, kwargs


async def test_one_approval_publishes_intent_actions_response_suite_and_revision(db):
    service, candidate_id, kwargs = await package(db)
    # Validation follows exactly the publication path, but publishes nothing.
    report = await validate_package(service, db, candidate_id, **kwargs)
    assert report["status"] == "PASS" and report["published"] is False
    for model in (IntentRule, ActionTemplate, GoldenSuite, GoldenRun, IntentRevision):
        assert (await db.execute(select(model))).scalars().all() == []
    candidate = await db.get(IntentLearningCandidate, candidate_id, populate_existing=True)
    assert candidate.status == "pending"
    candidate, rule = await service.approve(db, candidate_id, **kwargs)
    assert candidate.status == "approved"
    assert rule.workflow_json[0]["connection_ref"] == "backup_api"
    assert rule.response_mode == kwargs["rule"].response_mode
    assert (await db.execute(select(ActionTemplate))).scalar_one().lifecycle_status == "active"
    assert (await db.execute(select(GoldenSuite))).scalar_one().reviewed_by == "reviewer"
    assert (await db.execute(select(GoldenRun))).scalar_one().status == "PASS"
    assert (await db.execute(select(IntentRevision))).scalar_one().version == 1
    with pytest.raises(IntentLearningCandidateStateError):
        await service.approve(db, candidate_id, **kwargs)


async def test_failed_golden_package_leaves_everything_pending(db):
    service, candidate_id, kwargs = await package(db)
    kwargs["golden_suite"].cases[0].calls[0].arguments["server"] = "WRONG"
    with pytest.raises(IntentConfigurationError):
        await validate_package(service, db, candidate_id, **kwargs)
    for model in (IntentRule, ActionTemplate, GoldenSuite, GoldenRun, IntentRevision):
        assert (await db.execute(select(model))).scalars().all() == []
    assert (await db.get(IntentLearningCandidate, candidate_id, populate_existing=True)).status == "pending"


async def test_connection_contract_change_rejects_stale_review(db):
    service, candidate_id, kwargs = await package(db)
    tool = await db.get(ToolRegistry, "backup_api")
    tool.version += 1
    await db.flush()
    with pytest.raises(IntentLearningCandidateStateError, match="dependency changed"):
        await service.approve(db, candidate_id, **kwargs)
    assert (await db.execute(select(IntentRule))).scalars().all() == []


async def test_new_observation_rejects_stale_review(db):
    service, candidate_id, kwargs = await package(db)
    candidate = await db.get(IntentLearningCandidate, candidate_id)
    candidate.occurrence_count += 1
    await db.flush()
    with pytest.raises(IntentLearningCandidateStateError):
        await service.approve(db, candidate_id, **kwargs)


async def test_budget_reservation_limits_calls_and_tokens_in_postgres(db):
    day = datetime.now(UTC).date()
    config = LearningMatchingSettings(max_daily_calls=2, daily_token_budget=1000)
    assert await reserve_in_session(db, config, 400, day)
    assert await reserve_in_session(db, config, 400, day)
    assert not await reserve_in_session(db, config, 100, day)
    row = await db.get(LearningMatchBudget, day)
    assert (row.calls, row.reserved_tokens, row.unreported_calls) == (2, 800, 2)
    config.max_daily_calls = 10
    assert not await reserve_in_session(db, config, 201, day)
    assert await reserve_in_session(db, config, 200, day)
    config.max_daily_calls = 0
    assert not await reserve_in_session(db, config, 1, day)


async def test_real_database_groups_paraphrases_and_new_hosts_but_not_changed_operation(db):
    await setup(db)
    service = IntentLearningService()
    first = await service.observe(db, source_agent="backup_agent", query="Show latest backups for server APP01",
                                  tool_trace=one_call())
    again = await service.observe(db, source_agent="backup_agent",
                                  query="Please help me with most recent backups for server APP02",
                                  tool_trace=one_call({"operation": "list", "server": "APP02"}))
    assert first.id == again.id
    assert again.occurrence_count == 2
    assert again.observation_json["matching"]["model_calls"] == 0
    distinct = await service.observe(db, source_agent="backup_agent", query="Show all backups for server APP02",
                                     tool_trace=one_call({"operation": "list", "server": "APP02"}))
    assert distinct.id != first.id
    assert len(list((await db.execute(select(IntentLearningCandidate))).scalars())) == 2


async def test_settings_cannot_enable_paid_calls_without_consent_or_active_model(db):
    from types import SimpleNamespace

    from fastapi import HTTPException

    from backend.routers.intent_learning import update_matching_settings
    from backend.schemas.intent_matching import MatchingSettingsUpdate

    data = MatchingSettingsUpdate(settings=LearningMatchingSettings(llm_enabled=True, llm_model="missing-model"))
    with pytest.raises(HTTPException, match="Acknowledge"):
        await update_matching_settings(data, db, SimpleNamespace(username="reviewer"))
    data.allow_provider_calls = True
    with pytest.raises(HTTPException, match="active model"):
        await update_matching_settings(data, db, SimpleNamespace(username="reviewer"))
