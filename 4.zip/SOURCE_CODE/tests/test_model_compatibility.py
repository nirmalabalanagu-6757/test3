"""Model preflight regression tests: no provider network or live tools."""

from types import SimpleNamespace

import pytest
from google.adk.models.llm_response import LlmResponse
from google.genai.types import Content, FunctionCall, Part

from backend.models.agent import AgentRegistry
from backend.schemas.intent_validation import GoldenModelCompareRequest, GoldenSuiteCreate
from backend.services.intent_model_comparison import compare


class Session:
    async def get(self, model, name):
        if model is AgentRegistry:
            return SimpleNamespace(name=name, instruction="Use synthetic tools", generate_content_config_json={})
        return SimpleNamespace(name=name, status="active")

    async def execute(self, statement):
        tool = SimpleNamespace(name="lookup", description="Fixture lookup", input_schema_json={"type": "object"})
        return SimpleNamespace(scalars=lambda: SimpleNamespace(all=lambda: [tool]))


def expected_call(step="one", intent="lookup.intent", depends=()):
    return {
        "step_id": step,
        "intent_name": intent,
        "agent": "backup_agent",
        "tool": "lookup",
        "action_template": "lookup.action@1",
        "arguments": {"step": step, "intent": intent},
        "depends_on": list(depends),
        "fixture": {"status": "OK"},
    }


def suite(calls=None, **case_options):
    return GoldenSuiteCreate(
        name="synthetic",
        expectations_reviewed=True,
        cases=[
            {
                "name": "lookup",
                "query": "Check synthetic record",
                "source_agent": "backup_agent",
                "expected_intents": ["lookup.intent"],
                "calls": calls if calls is not None else [expected_call()],
                **case_options,
            }
        ],
    )


def request(**options):
    return GoldenModelCompareRequest(
        **{"models": ["baseline"], "agent": "backup_agent", "allow_model_calls": True, **options}
    )


def tool_reply(call):
    return LlmResponse(
        content=Content(
            role="model",
            parts=[
                Part(
                    function_call=FunctionCall(
                        name=call["tool"], args=call["arguments"], id=f"{call['intent_name']}-{call['step_id']}"
                    )
                )
            ],
        )
    )


class Provider:
    def __init__(self, calls=()):
        self.replies = [tool_reply(call) for call in calls]
        self.count = 0

    async def generate_content_async(self, request, stream=False):
        self.count += 1
        yield (
            self.replies.pop(0)
            if self.replies
            else LlmResponse(content=Content(role="model", parts=[Part(text="OK")]), turn_complete=True)
        )


@pytest.mark.asyncio
async def test_adapter_initialization_failure_does_not_abort_other_model():
    def factory(name):
        if name == "unavailable":
            raise RuntimeError("private provider configuration")
        return Provider([expected_call()])

    report = await compare(Session(), suite(), request(models=["unavailable", "working"]), factory=factory)
    assert [row["status"] for row in report["results"]] == ["FAIL", "PASS"]
    assert report["results"][0]["model_calls"] == 0
    assert report["results"][0]["input_tokens"] is None


@pytest.mark.asyncio
async def test_exception_details_are_not_returned_or_stored_in_receipt():
    class BrokenProvider:
        async def generate_content_async(self, request, stream=False):
            raise RuntimeError("Authorization Bearer SECRET_SENTINEL")
            yield  # pragma: no cover -- async generator shape

    report = await compare(Session(), suite(), request(), factory=lambda name: BrokenProvider())
    assert report["status"] == "FAIL"
    assert "SECRET_SENTINEL" not in str(report)


@pytest.mark.asyncio
@pytest.mark.parametrize("options", [{"calls": []}, {"source_agent": "different_agent"}, {"expected_status": "failed"}])
async def test_non_comparable_cases_are_review_without_provider_initialization(options):
    initialized = []

    def factory(name):
        initialized.append(name)
        return Provider()

    report = await compare(Session(), suite(**options), request(), factory=factory)
    assert report["status"] == "REVIEW"
    assert report["results"][0]["model_calls"] == 0
    assert not initialized


@pytest.mark.asyncio
async def test_dependency_step_ids_are_scoped_to_their_intent():
    first = expected_call("one", "first")
    other_first = expected_call("one", "second")
    dependent = expected_call("two", "second", depends=["one"])
    report = await compare(
        Session(),
        suite([first, other_first, dependent]),
        request(),
        factory=lambda name: Provider([first, dependent, other_first]),
    )
    assert report["status"] == "FAIL", "first.one must not satisfy second.one"


def test_duplicate_model_selections_are_rejected():
    with pytest.raises(ValueError, match="distinct"):
        request(models=["baseline", "baseline"])


@pytest.mark.asyncio
async def test_explicit_consent_is_required_before_adapter_initialization():
    with pytest.raises(ValueError, match="consent"):
        await compare(
            Session(), suite(), request(allow_model_calls=False), factory=lambda name: pytest.fail("provider called")
        )


@pytest.mark.asyncio
async def test_model_call_budget_and_fixture_tool_are_enforced():
    provider = Provider([expected_call()])
    report = await compare(Session(), suite(), request(max_total_model_calls=1), factory=lambda name: provider)
    assert report["status"] == "FAIL"
    assert provider.count == report["results"][0]["model_calls"] == 1


@pytest.mark.asyncio
async def test_valid_sequential_calls_and_repeated_cases_pass():
    calls = [expected_call(), expected_call("two", depends=["one"])]
    for _ in range(3):
        report = await compare(Session(), suite(calls), request(), factory=lambda name: Provider(calls))
        assert report["status"] == "PASS", report
        assert report["results"][0]["model_calls"] == 3


@pytest.mark.asyncio
async def test_same_turn_cannot_satisfy_a_dependency_even_with_correct_call_order():
    calls = [expected_call(), expected_call("two", depends=["one"])]

    class ParallelProvider:
        async def generate_content_async(self, request, stream=False):
            yield LlmResponse(
                content=Content(role="model", parts=[tool_reply(item).content.parts[0] for item in calls])
            )

    report = await compare(Session(), suite(calls), request(), factory=lambda name: ParallelProvider())
    assert report["status"] == "FAIL"
    assert report["results"][0]["model_calls"] == 1


@pytest.mark.asyncio
async def test_unknown_provider_usage_stays_unknown_across_turns_and_reported_usage_sums():
    from google.genai.types import GenerateContentResponseUsageMetadata

    class MeteredProvider(Provider):
        async def generate_content_async(self, request, stream=False):
            async for reply in super().generate_content_async(request, stream):
                reply.usage_metadata = GenerateContentResponseUsageMetadata(
                    prompt_token_count=4, candidates_token_count=2
                )
                yield reply

    report = await compare(Session(), suite(), request(), factory=lambda name: MeteredProvider([expected_call()]))
    assert report["results"][0]["input_tokens"] == 8
    assert report["results"][0]["output_tokens"] == 4
    assert report["results"][0]["estimated_cost"] is None


@pytest.mark.asyncio
async def test_admin_api_denies_viewers_and_rejects_unconsented_calls(monkeypatch):
    from fastapi import FastAPI
    from httpx import ASGITransport, AsyncClient

    from backend.database import get_session
    from backend.middleware import auth
    from backend.routers.intent_validation import router

    role = "viewer"
    app = FastAPI()
    app.include_router(router)

    async def user():
        return SimpleNamespace(role=role, username="synthetic")

    class FakeSession:
        async def commit(self):
            pass

        async def get(self, *args):
            pytest.fail("Rejected model calls must not load a suite or execute a provider")

    async def session():
        yield FakeSession()

    async def audit(*args, **kwargs):
        pass

    monkeypatch.setattr(auth._audit_service, "append", audit)
    app.dependency_overrides[auth.get_current_user] = user
    app.dependency_overrides[get_session] = session
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        payload = request().model_dump()
        response = await client.post("/api/intent-validation/suites/synthetic/compare-models", json=payload)
        assert response.status_code == 403
        assert (await client.get("/api/intent-validation/runs?mode=model_comparison")).status_code == 403
        role = "admin"
        response = await client.post(
            "/api/intent-validation/suites/synthetic/compare-models", json={**payload, "allow_model_calls": False}
        )
        assert response.status_code == 422
        assert (await client.get("/api/intent-validation/runs?mode=invalid")).status_code == 422
