"""Dynamic identity, draft contracts and review boundaries (offline)."""

import json

import pytest
from test_intent_learning import _tool
from test_intent_workflow_learning import action, one_call

from backend.schemas.intent import IntentRuleCreate
from backend.schemas.intent_validation import GoldenSuiteCreate
from backend.services.intent_action_drafts import preview_records, propose_actions
from backend.services.intent_identity import resolve_name
from backend.services.intent_workflow_learning import compile_workflow


def test_exact_identity_wins_and_alias_collision_never_guesses():
    assert resolve_name("Backup-API", ["backup_api"]) == "backup_api"
    assert resolve_name("BACKUP API", ["Backup-API", "backup_api"]) is None
    assert resolve_name("Backup-API", ["Backup-API", "backup_api"]) == "Backup-API"


def test_recorded_alias_binds_to_registered_connection_without_dropping_call():
    trace = one_call()
    trace.calls[0].tool = "Backup-API"
    trace.calls[0].agent = "Backup Agent"
    learned = compile_workflow(
        trace,
        route={"backup_agent": ["backup_api"]},
        templates=[action()],
        assignments={("backup_agent", "backup_api")},
        query="Show backups for server APP01",
    )
    assert learned.direct
    assert learned.steps[0]["connection_ref"] == "backup_api"
    assert trace.calls[0].tool == "Backup-API"  # original evidence is not rewritten


def test_unknown_or_ambiguous_calls_are_reported_and_block_partial_replay():
    trace = one_call()
    trace.call("backup_agent", "unknown_tool", {}, "unresolved")
    learned = compile_workflow(
        trace,
        route={"backup_agent": ["backup_api"]},
        templates=[action()],
        assignments={("backup_agent", "backup_api")},
        query="Show backups for server APP01",
    )
    assert not learned.direct
    assert learned.evidence["unresolved_calls"][0]["id"] == "call_2"


def test_draft_contract_uses_schema_constants_and_fresh_parameters_not_captured_values():
    tool = _tool("backup_api")
    tool.input_schema_json = {"properties": {"operation": {"enum": ["list"]}, "server": {"type": "string"}}}
    drafts = propose_actions(
        one_call(), {"backup_agent": ["backup_api"]}, {tool.name: tool}, [], "Show backups for server APP01"
    )
    assert len(drafts) == 1 and drafts[0].lifecycle_status == "draft"
    assert "APP01" not in json.dumps(drafts[0].model_dump())
    compiled = compile_workflow(
        one_call(),
        route={"backup_agent": ["backup_api"]},
        templates=preview_records(drafts),
        assignments={("backup_agent", "backup_api")},
        query="Show backups for server APP01",
    )
    assert compiled.direct


@pytest.mark.parametrize(
    "sql,eligible",
    [
        ("SELECT id FROM backups WHERE server = :server", True),
        ("SELECT id FROM backups WHERE server = 'APP01'", False),
        ("SELECT id FROM backups WHERE id = 37", False),
    ],
)
def test_sql_drafts_capture_bound_code_not_user_literals(sql, eligible):
    trace = one_call({"sql": sql, "server": "APP01"})
    drafts = propose_actions(
        trace, {"backup_agent": ["backup_api"]}, {"backup_api": _tool("backup_api")}, [], "Show server APP01"
    )
    assert bool(drafts) == eligible
    if drafts:
        assert drafts[0].template_type == "sql"
        assert drafts[0].template_text == sql
        assert "APP01" not in json.dumps(drafts[0].model_dump())


def test_secrets_never_become_draft_contracts():
    drafts = propose_actions(
        one_call({"Authorization": "Bearer secret-value"}),
        {"backup_agent": ["backup_api"]},
        {"backup_api": _tool("backup_api")},
        [],
        "backup",
    )
    assert drafts == []


def test_strict_direct_requires_pinned_actions_and_rejects_llm_response_mode():
    with pytest.raises(ValueError, match="pinned"):
        IntentRuleCreate(
            name="test", target_agent="a", keywords_json=["test"], execution_options_json={"require_direct": True}
        )
    with pytest.raises(ValueError, match="summarization"):
        IntentRuleCreate(
            name="test",
            target_agent="a",
            keywords_json=["test"],
            response_mode="llm_summary",
            workflow_json=[{"id": "s", "agent": "a", "action_template": "test@1"}],
            execution_options_json={"require_direct": True},
        )


def test_golden_suite_requires_independently_reviewed_expectations():
    with pytest.raises(ValueError, match="Review independent"):
        GoldenSuiteCreate(name="test", cases=[{"name": "x", "query": "show", "source_agent": "a"}])


def test_permission_alias_collision_does_not_grant_assignment():
    learned = compile_workflow(
        one_call(),
        route={"backup_agent": ["backup_api"]},
        templates=[action()],
        assignments={("Backup-Agent", "backup_api")},
        query="Show backups for server APP01",
    )
    assert not learned.direct


def test_nested_json_values_do_not_confuse_boolean_with_integer():
    from backend.services.intent_workflow_learning import _equal

    assert not _equal({"items": [{"id": True}]}, {"items": [{"id": 1}]})
    assert _equal({"items": [{"id": 1}]}, {"items": [{"id": 1}]})


def test_strict_direct_does_not_silently_allow_ambiguity_llm_fallback():
    with pytest.raises(ValueError, match="ambiguity"):
        IntentRuleCreate(name="test", target_agent="a", keywords_json=["test"],
                         workflow_json=[{"id": "s", "agent": "a", "action_template": "action@1"}],
                         execution_options_json={"require_direct": True}, ambiguity_action="llm_fallback")
