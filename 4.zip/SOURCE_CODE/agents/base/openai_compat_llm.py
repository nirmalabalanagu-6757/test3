"""OpenAI-compatible LLM adapter for Google ADK.

Implements ADK's BaseLlm interface for any OpenAI-compatible API server
(llama.cpp, Ollama, vLLM, LM Studio, etc.). Registered with ADK's
LLMRegistry for model names matching ``local-*`` or ``qwen-*`` or ``llama-*``.

Configuration via environment variables:
  - OPENAI_COMPAT_BASE_URL: API base URL (default: http://localhost:8080/v1)
  - OPENAI_COMPAT_API_KEY: API key if required (default: "not-needed")
  - OPENAI_COMPAT_MODEL: Override model name sent to server (optional)
"""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncGenerator
from types import SimpleNamespace
from typing import Any

import httpx
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.models.registry import LLMRegistry
from google.genai.types import Content, FunctionCall, Part

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "http://localhost:8080/v1"


def _get_base_url() -> str:
    return os.environ.get("OPENAI_COMPAT_BASE_URL", DEFAULT_BASE_URL)


def _get_api_key() -> str:
    return os.environ.get("OPENAI_COMPAT_API_KEY", "not-needed")


def _convert_content_to_messages(contents: list[Content]) -> tuple[str | None, list[dict]]:
    """Convert ADK Content list to OpenAI messages format.

    Returns (system_message, messages) tuple.
    """
    system_msg: str | None = None
    messages: list[dict] = []

    for content in contents:
        role = content.role
        if role == "system":
            # Extract system message text
            texts = [p.text for p in (content.parts or []) if p.text]
            system_msg = "\n".join(texts)
            continue

        # Map ADK roles to OpenAI roles
        openai_role = "assistant" if role == "model" else role

        parts = content.parts or []
        text_parts: list[str] = []
        tool_calls: list[dict] = []
        tool_results: list[dict] = []

        for part in parts:
            if part.text:
                text_parts.append(part.text)
            elif part.function_call:
                fc = part.function_call
                tool_calls.append({
                    "id": getattr(fc, "id", None) or f"call_{fc.name}_{len(tool_calls)}",
                    "type": "function",
                    "function": {
                        "name": fc.name,
                        "arguments": json.dumps(fc.args) if fc.args else "{}",
                    },
                })
            elif part.function_response:
                fr = part.function_response
                tool_results.append({
                    "role": "tool",
                    "tool_call_id": getattr(fr, "id", None) or f"call_{fr.name}_{len(tool_results)}",
                    "content": json.dumps(fr.response) if isinstance(fr.response, dict) else str(fr.response),
                })

        if tool_results:
            for tr in tool_results:
                messages.append(tr)
        elif tool_calls:
            msg: dict[str, Any] = {"role": "assistant", "content": None, "tool_calls": tool_calls}
            messages.append(msg)
        else:
            messages.append({"role": openai_role, "content": "\n".join(text_parts) or ""})

    return system_msg, messages


def _convert_tools_to_openai(tools_dict: list[dict] | None) -> list[dict] | None:
    """Convert ADK tool declarations to OpenAI function format."""
    if not tools_dict:
        return None

    openai_tools: list[dict] = []
    for tool in tools_dict:
        # ADK tool format varies; handle both raw dict and FunctionDeclaration-style
        if "function_declarations" in tool:
            for fd in tool["function_declarations"]:
                schema = fd.get("parameters", {})
                # Normalize type names (ADK uppercase → JSON Schema lowercase)
                schema = _normalize_schema(schema)
                openai_tools.append({
                    "type": "function",
                    "function": {
                        "name": fd["name"],
                        "description": fd.get("description", ""),
                        "parameters": schema,
                    },
                })
        elif "name" in tool:
            schema = tool.get("parameters", {})
            schema = _normalize_schema(schema)
            openai_tools.append({
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool.get("description", ""),
                    "parameters": schema,
                },
            })

    return openai_tools if openai_tools else None


def _normalize_schema(schema: dict) -> dict:
    """Normalize ADK schema types (uppercase) to JSON Schema (lowercase)."""
    if not isinstance(schema, dict):
        return schema

    result = {}
    for key, value in schema.items():
        if key == "type" and isinstance(value, str):
            result[key] = value.lower()
        elif key == "properties" and isinstance(value, dict):
            result[key] = {k: _normalize_schema(v) for k, v in value.items()}
        elif key == "items" and isinstance(value, dict):
            result[key] = _normalize_schema(value)
        elif key == "default":
            # Some providers don't support 'default' in tool schemas
            continue
        else:
            result[key] = value
    return result


def _parse_response_to_content(response: dict) -> Content:
    """Convert OpenAI chat completion response to ADK Content."""
    choice = response["choices"][0]
    message = choice["message"]

    parts: list[Part] = []

    # Handle tool calls
    if message.get("tool_calls"):
        for tc in message["tool_calls"]:
            fn = tc["function"]
            try:
                args = json.loads(fn["arguments"]) if fn["arguments"] else {}
            except json.JSONDecodeError:
                args = {"raw": fn["arguments"]}
            parts.append(Part(function_call=FunctionCall(name=fn["name"], args=args, id=tc.get("id"))))
    elif message.get("content"):
        parts.append(Part(text=message["content"]))

    return Content(role="model", parts=parts)


class OpenAICompatLlm(BaseLlm):
    """ADK-compatible LLM that talks to any OpenAI-compatible API."""

    @classmethod
    def supported_models(cls) -> list[str]:
        """Regex patterns for model names this adapter handles."""
        return [
            r"local-.*",
            r"qwen.*",
            r"llama.*",
            r"openai-compat-.*",
        ]

    async def generate_content_async(
        self,
        llm_request: LlmRequest,
        stream: bool = False,
    ) -> AsyncGenerator[LlmResponse, None]:
        """Call the OpenAI-compatible API and yield an ADK LlmResponse.

        This is an async generator (yields, not returns) to match the ADK
        BaseLlm contract. Callers consume with ``async for resp in ...``.

        Tool-enabled local agents and the concierge use this adapter through
        the ADK Runner so function calling, governance callbacks, and multi-agent
        routing remain available.  Tool-less local agents may use a faster
        direct single-turn path.
        """
        base_url = _get_base_url()
        api_key = _get_api_key()

        # Convert ADK request to OpenAI format
        system_msg, messages = _convert_content_to_messages(llm_request.contents or [])

        # Build request body
        body: dict[str, Any] = {
            "model": os.environ.get("OPENAI_COMPAT_MODEL", llm_request.model or "default"),
            "messages": [],
        }

        if system_msg:
            body["messages"].append({"role": "system", "content": system_msg})
        body["messages"].extend(messages)

        # Add tools if present
        tools_dict = None
        if hasattr(llm_request, "tools_dict") and llm_request.tools_dict:
            tools_dict = _convert_tools_to_openai(llm_request.tools_dict)
            if tools_dict:
                body["tools"] = tools_dict

        # Generation config
        if hasattr(llm_request, "config") and llm_request.config:
            config = llm_request.config
            if hasattr(config, "temperature") and config.temperature is not None:
                body["temperature"] = config.temperature
            if hasattr(config, "max_output_tokens") and config.max_output_tokens is not None:
                body["max_tokens"] = config.max_output_tokens

            thinking_cfg = getattr(config, "thinking_config", None)
            if thinking_cfg:
                logger.info(
                    "Reasoning/thinking configured but not supported for OpenAI-compatible models — skipping"
                )

        # Default max_tokens if not set
        if "max_tokens" not in body:
            body["max_tokens"] = 4096

        logger.debug("OpenAI-compat request to %s: model=%s, messages=%d",
                     base_url, body["model"], len(body["messages"]))

        try:
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(
                    f"{base_url}/chat/completions",
                    json=body,
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            content = _parse_response_to_content(data)

            # Extract usage metadata from OpenAI response
            usage_metadata = None
            usage = data.get("usage")
            if usage:
                # Map OpenAI fields to ADK format
                prompt_tokens = usage.get("prompt_tokens", 0) or 0
                completion_tokens = usage.get("completion_tokens", 0) or 0
                usage_metadata = SimpleNamespace(
                    prompt_token_count=prompt_tokens,
                    candidates_token_count=completion_tokens,
                )

            yield LlmResponse(content=content, usage_metadata=usage_metadata)

        except httpx.HTTPStatusError as e:
            logger.error("OpenAI-compat API error: %s %s", e.response.status_code, e.response.text[:200])
            yield LlmResponse(
                error_code=str(e.response.status_code),
                error_message=f"OpenAI-compat API error: {e.response.text[:300]}",
                partial=False,
                turn_complete=True,
            )
        except Exception as e:
            logger.error("OpenAI-compat request failed: %s", e)
            yield LlmResponse(
                error_code="CONNECTION_ERROR",
                error_message=str(e),
                partial=False,
                turn_complete=True,
            )


# Register with ADK's LLMRegistry
LLMRegistry.register(OpenAICompatLlm)
LLMRegistry.resolve.cache_clear()

logger.info("Registered OpenAI-compatible LLM adapter (local-*, qwen*, llama*)")
