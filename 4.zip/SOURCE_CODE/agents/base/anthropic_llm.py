"""Anthropic Claude LLM adapter for Google ADK.

Implements ADK's BaseLlm interface so that agents can use Claude models
via the standard GovernedAgent / LlmAgent pipeline. Registered with
ADK's LLMRegistry for model names matching ``claude-*``.

Auth resolution:
  - When GOOGLE_CLOUD_PROJECT is set (GCP/OpenShift deployment):
    Routes through Vertex AI rawPredict endpoint using ADC credentials.
  - Otherwise (local dev): Uses ANTHROPIC_API_KEY env var or LLM Model
    Registry database to call the Anthropic Messages API directly.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from collections.abc import AsyncGenerator
from typing import Any

import httpx
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.models.registry import LLMRegistry
from google.genai.types import Content, FunctionCall, GenerateContentResponseUsageMetadata, Part

logger = logging.getLogger(__name__)

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"

_VERTEX_RAWPREDICT_URL = (
    "https://{region}-aiplatform.googleapis.com/v1/projects/{project}"
    "/locations/{region}/publishers/anthropic/models/{model}:rawPredict"
)
_VERTEX_ANTHROPIC_VERSION = "vertex-2023-10-16"

_api_key_cache: dict[str, str] = {}


def _use_vertex_ai() -> bool:
    """Return True if Vertex AI env vars are configured (GCP deployment)."""
    return bool(os.environ.get("GOOGLE_CLOUD_PROJECT"))


_vertex_credentials: Any = None
_vertex_credentials_lock = asyncio.Lock()


async def _get_vertex_access_token() -> str:
    """Get a valid ADC access token for Vertex AI, refreshing if expired."""
    global _vertex_credentials

    async with _vertex_credentials_lock:
        if _vertex_credentials is None:
            import google.auth
            loop = asyncio.get_event_loop()
            _vertex_credentials, _ = await loop.run_in_executor(
                None,
                lambda: google.auth.default(
                    scopes=["https://www.googleapis.com/auth/cloud-platform"]
                ),
            )

        if not _vertex_credentials.valid:
            import google.auth.transport.requests
            request = google.auth.transport.requests.Request()
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, _vertex_credentials.refresh, request)

    return _vertex_credentials.token


async def _increment_model_usage(model_name: str) -> None:
    """Increment the model invocation counter via async DB or HTTP."""
    try:
        from backend.database import async_session_factory
        from sqlalchemy import text
        async with async_session_factory() as session:
            await session.execute(
                text("UPDATE llm_model_registry SET invocation_count = invocation_count + 1 WHERE name = :name"),
                {"name": model_name},
            )
            await session.commit()
        return
    except Exception as exc:
        logger.debug("DB increment failed for model '%s': %s", model_name, exc)
    # HTTP fallback for agent containers
    platform_url = os.environ.get("PLATFORM_API_URL", "http://backend:8000")
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            await client.post(f"{platform_url}/api/models/{model_name}/increment")
    except Exception as exc:
        logger.debug("HTTP increment failed for model '%s': %s", model_name, exc)


async def _resolve_api_key(model_name: str) -> str:
    """Resolve the Anthropic API key from env, cache, or async DB read."""
    # 1. Environment variable
    key = os.environ.get("ANTHROPIC_API_KEY")
    if key:
        return key

    # 2. Cache from previous resolution
    if model_name in _api_key_cache:
        return _api_key_cache[model_name]

    # 3. Async database read (avoids HTTP self-call deadlock in same process)
    try:
        from backend.database import async_session_factory
        from sqlalchemy import text
        async with async_session_factory() as session:
            result = await session.execute(
                text("SELECT api_key FROM llm_model_registry WHERE name = :name"),
                {"name": model_name},
            )
            row = result.fetchone()
            if row and row[0]:
                _api_key_cache[model_name] = row[0]
                logger.info("Resolved API key for '%s' via async DB read", model_name)
                return row[0]
    except Exception as exc:
        logger.warning("Async DB read for API key failed: %s", exc)

    # 4. HTTP fallback (works from agent containers, not from backend itself)
    platform_user = os.environ.get("PLATFORM_USER", "admin")
    platform_pass = os.environ.get("PLATFORM_PASSWORD", "admin")
    urls = [u for u in [
        os.environ.get("PLATFORM_API_URL"),
        "http://backend:8000",
    ] if u]

    for platform_url in urls:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                login = await client.post(f"{platform_url}/api/auth/login", json={"username": platform_user, "password": platform_pass})
                if login.status_code != 200:
                    continue
                token = login.json()["access_token"]
                resp = await client.get(f"{platform_url}/api/models/{model_name}/key", headers={"Authorization": f"Bearer {token}"})
                if resp.status_code == 200:
                    api_key = resp.json().get("api_key", "")
                    if api_key:
                        _api_key_cache[model_name] = api_key
                        logger.info("Resolved API key for '%s' via %s", model_name, platform_url)
                        return api_key
        except Exception:
            continue

    raise RuntimeError(
        f"No API key found for model '{model_name}'. "
        "Set ANTHROPIC_API_KEY env var or configure the key in the Model Registry."
    )


# ---------------------------------------------------------------------------
# ADK Content ↔ Anthropic message conversion
# ---------------------------------------------------------------------------


def _contents_to_anthropic_messages(contents: list[Content]) -> tuple[str | None, list[dict[str, Any]]]:
    """Convert ADK Content list to Anthropic messages format.

    Returns (system_prompt, messages).
    """
    system_prompt: str | None = None
    messages: list[dict[str, Any]] = []
    pending: dict[str, str] = {}
    used_ids: set[str] = set()

    for content in contents:
        role = content.role or "user"
        if not content.parts:
            continue

        # Map ADK roles to Anthropic roles
        if role == "model":
            anthropic_role = "assistant"
        elif role == "system":
            # Anthropic uses a top-level system param, not a message role
            texts = [p.text for p in content.parts if p.text]
            if texts:
                system_prompt = "\n".join(filter(None, [system_prompt, *texts]))
            continue
        else:
            anthropic_role = "user"

        blocks: list[dict[str, Any]] = []
        for part in content.parts:
            metadata = getattr(part, "part_metadata", None) or {}
            if metadata.get("anthropic_thinking"):
                blocks.append(metadata["anthropic_thinking"])
            elif part.text is not None and not part.thought:
                blocks.append({"type": "text", "text": part.text})
            elif part.function_call is not None:
                fc = part.function_call
                call_id = fc.id or f"call_{len(used_ids) + 1}"
                if call_id in used_ids:
                    raise ValueError("Duplicate tool-call ID in Claude conversation")
                used_ids.add(call_id)
                pending[call_id] = fc.name
                blocks.append({
                    "type": "tool_use",
                    "id": call_id,
                    "name": fc.name,
                    "input": fc.args if isinstance(fc.args, dict) else json.loads(fc.args) if fc.args else {},
                })
            elif part.function_response is not None:
                fr = part.function_response
                matches = [key for key, name in pending.items() if name == fr.name]
                call_id = fr.id or (matches[0] if len(matches) == 1 else None)
                if call_id not in pending or pending[call_id] != fr.name:
                    raise ValueError("Missing, ambiguous or mismatched Claude tool-result ID")
                del pending[call_id]
                response_content = fr.response if isinstance(fr.response, dict) else {"result": str(fr.response)}
                blocks.append({
                    "type": "tool_result",
                    "tool_use_id": call_id,
                    "content": json.dumps(response_content),
                    "is_error": bool(response_content.get("error")) or response_content.get("success") is False,
                })

        if blocks:
            # Anthropic requires tool_result blocks to be in user messages
            has_tool_result = any(b["type"] == "tool_result" for b in blocks)
            if has_tool_result:
                anthropic_role = "user"
            if messages and messages[-1]["role"] == anthropic_role:
                messages[-1]["content"].extend(blocks)
            else:
                messages.append({"role": anthropic_role, "content": blocks})

    for message in messages:
        if message["role"] == "user":
            message["content"].sort(key=lambda block: block["type"] != "tool_result")
    if pending:
        raise ValueError("Claude tool calls must have matching results before the next model invocation")

    return system_prompt, messages


# Google genai uses uppercase type names; Anthropic/JSON Schema uses lowercase
_TYPE_MAP = {
    "STRING": "string", "INTEGER": "integer", "NUMBER": "number",
    "BOOLEAN": "boolean", "ARRAY": "array", "OBJECT": "object",
}


def _normalize_schema(d: dict[str, Any]) -> dict[str, Any]:
    """Normalize a schema dict: lowercase types, strip unsupported fields."""
    result: dict[str, Any] = {}
    for k, v in d.items():
        if k == "type" and isinstance(v, str):
            result[k] = _TYPE_MAP.get(v, v.lower())
        elif k == "properties" and isinstance(v, dict):
            result[k] = {pk: _normalize_schema(pv) if isinstance(pv, dict) else pv for pk, pv in v.items()}
        elif isinstance(v, dict):
            result[k] = _normalize_schema(v)
        elif isinstance(v, list):
            result[k] = [_normalize_schema(item) if isinstance(item, dict) else item for item in v]
        else:
            result[k] = v
    return result


def _schema_to_dict(schema: Any) -> dict[str, Any]:
    """Convert an ADK/genai Schema object to a normalized plain dict."""
    raw: dict[str, Any]
    if isinstance(schema, dict):
        raw = schema
    elif hasattr(schema, "model_dump"):
        raw = {k: v for k, v in schema.model_dump(exclude_none=True).items() if v is not None}
    elif hasattr(schema, "to_dict"):
        raw = schema.to_dict()
    else:
        return {}
    return _normalize_schema(raw)


def _build_tools_param(tools_dict: dict[str, Any]) -> list[dict[str, Any]] | None:
    """Convert ADK tools to Anthropic tool format."""
    if not tools_dict:
        return None

    tools = []
    for name, tool in tools_dict.items():
        schema: dict[str, Any] = {"type": "object", "properties": {}}
        description = name
        try:
            if hasattr(tool, "_get_declaration"):
                decl = tool._get_declaration()
                if decl:
                    if decl.description:
                        description = decl.description
                    raw_schema = getattr(decl, "parameters_json_schema", None) or decl.parameters
                    if raw_schema:
                        schema = _schema_to_dict(raw_schema)
        except Exception as exc:
            logger.warning("Could not extract schema for tool '%s': %s", name, exc)

        tools.append({
            "name": name,
            "description": description,
            "input_schema": schema,
        })
    return tools if tools else None


def _anthropic_response_to_llm_response(data: dict[str, Any], model: str) -> LlmResponse:
    """Convert Anthropic API response to ADK LlmResponse."""
    parts: list[Part] = []

    for block in data.get("content", []):
        if block["type"] in {"thinking", "redacted_thinking"}:
            # Signed thinking must travel unchanged with a tool-use turn.
            parts.append(Part(thought=True, part_metadata={"anthropic_thinking": block}))
        elif block["type"] == "text":
            parts.append(Part(text=block["text"]))
        elif block["type"] == "tool_use":
            parts.append(Part(function_call=FunctionCall(
                name=block["name"],
                args=block["input"],
                id=block["id"],
            )))

    content = Content(role="model", parts=parts) if parts else None

    stop_reason = data.get("stop_reason", "")
    turn_complete = stop_reason in ("end_turn", "stop_sequence", "max_tokens")

    # Extract usage metadata from Anthropic response
    usage_metadata = None
    usage = data.get("usage")
    if usage:
        # Map Anthropic fields to ADK format
        input_counts = [usage.get(key) for key in ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens")]
        prompt_tokens = sum(value or 0 for value in input_counts) if input_counts[0] is not None else None
        output_tokens = usage.get("output_tokens")
        usage_metadata = GenerateContentResponseUsageMetadata(
            prompt_token_count=prompt_tokens,
            candidates_token_count=output_tokens,
            cached_content_token_count=usage.get("cache_read_input_tokens"),
        )

    return LlmResponse(
        content=content,
        model_version=data.get("model", model),
        partial=False,
        turn_complete=turn_complete,
        usage_metadata=usage_metadata,
    )


# ---------------------------------------------------------------------------
# AnthropicLlm — ADK BaseLlm implementation
# ---------------------------------------------------------------------------


class AnthropicLlm(BaseLlm):
    """ADK-compatible LLM adapter for Anthropic Claude models."""

    model: str

    @classmethod
    def supported_models(cls) -> list[str]:
        return [r"claude-.*"]

    async def generate_content_async(
        self, llm_request: LlmRequest, stream: bool = False
    ) -> AsyncGenerator[LlmResponse, None]:
        system_prompt, messages = _contents_to_anthropic_messages(llm_request.contents)
        instruction = getattr(llm_request.config, "system_instruction", None)
        if instruction:
            if isinstance(instruction, str):
                instruction_text = instruction
            else:
                instruction_text = "\n".join(p.text for p in (getattr(instruction, "parts", None) or []) if p.text)
            system_prompt = "\n".join(filter(None, [system_prompt, instruction_text]))

        if not messages:
            messages = [{"role": "user", "content": [{"type": "text", "text": "Hello"}]}]

        body: dict[str, Any] = {
            "messages": messages,
            "max_tokens": 8192,
        }

        if system_prompt:
            body["system"] = system_prompt

        if llm_request.config:
            if hasattr(llm_request.config, "temperature") and llm_request.config.temperature is not None:
                body["temperature"] = llm_request.config.temperature
            if hasattr(llm_request.config, "max_output_tokens") and llm_request.config.max_output_tokens is not None:
                body["max_tokens"] = llm_request.config.max_output_tokens

            thinking_cfg = getattr(llm_request.config, "thinking_config", None)
            if thinking_cfg:
                budget = (
                    thinking_cfg.get("thinking_budget", 0)
                    if isinstance(thinking_cfg, dict)
                    else getattr(thinking_cfg, "thinking_budget", 0)
                )
                if budget and budget > 0:
                    body["thinking"] = {"type": "enabled", "budget_tokens": budget}
                    body["max_tokens"] = max(body["max_tokens"], budget + 8192)
                    body.pop("temperature", None)
                    logger.info("Anthropic extended thinking enabled: budget=%d", budget)

        tools = _build_tools_param(llm_request.tools_dict)
        if tools:
            body["tools"] = tools

        # Vertex AI rawPredict vs direct Anthropic API
        if _use_vertex_ai():
            body["anthropic_version"] = _VERTEX_ANTHROPIC_VERSION
            gcp_project = os.environ["GOOGLE_CLOUD_PROJECT"]
            try:
                from backend.startup_config.model_definitions import resolve_location

                gcp_region = resolve_location(self.model)
            except ImportError:
                gcp_region = os.environ.get(
                    "CLOUD_ML_REGION",
                    os.environ.get("GOOGLE_CLOUD_LOCATION", "europe-west1"),
                )
            url = _VERTEX_RAWPREDICT_URL.format(
                region=gcp_region, project=gcp_project, model=self.model
            )
            try:
                access_token = await _get_vertex_access_token()
            except Exception as exc:
                logger.error("Failed to get Vertex AI credentials: %s", exc)
                error_text = f"Vertex AI ADC credential error: {exc}"
                yield LlmResponse(
                    content=Content(role="model", parts=[Part(text=error_text)]),
                    error_code="AUTH_ERROR",
                    error_message=error_text,
                    partial=False,
                    turn_complete=True,
                )
                return
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
            }
            logger.debug("Routing claude request via Vertex AI rawPredict: %s", url)
        else:
            api_key = await _resolve_api_key(self.model)
            body["model"] = self.model
            url = ANTHROPIC_API_URL
            headers = {
                "x-api-key": api_key,
                "anthropic-version": ANTHROPIC_VERSION,
                "Content-Type": "application/json",
            }

        async with httpx.AsyncClient(timeout=120) as client:
            try:
                resp = await client.post(url, json=body, headers=headers)
                resp.raise_for_status()
                data = resp.json()
                try:
                    await _increment_model_usage(self.model)
                except Exception:
                    pass
                yield _anthropic_response_to_llm_response(data, self.model)
            except httpx.HTTPStatusError as exc:
                logger.error("Anthropic API error %s: %s", exc.response.status_code, exc.response.text[:500])
                error_text = f"Anthropic API error ({exc.response.status_code}): {exc.response.text[:300]}"
                yield LlmResponse(
                    content=Content(role="model", parts=[Part(text=error_text)]),
                    error_code=str(exc.response.status_code),
                    error_message=error_text,
                    partial=False,
                    turn_complete=True,
                )
            except Exception as exc:
                logger.error("Anthropic request failed: %s", exc)
                error_text = f"Anthropic request failed: {exc}"
                yield LlmResponse(
                    content=Content(role="model", parts=[Part(text=error_text)]),
                    error_code="CONNECTION_ERROR",
                    error_message=error_text,
                    partial=False,
                    turn_complete=True,
                )


# ---------------------------------------------------------------------------
# Register with ADK on import
# ---------------------------------------------------------------------------

LLMRegistry.register(AnthropicLlm)
# Clear the resolve cache so previously-failed lookups for claude-* are retried
LLMRegistry.resolve.cache_clear()
logger.info("Registered AnthropicLlm adapter for claude-* models with ADK LLMRegistry")
