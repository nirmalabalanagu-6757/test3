import ModelCompatibilityPanel from "../../components/dashboard/ModelCompatibilityPanel";

export default function ModelCompatibilityPage() {
  return <div>
    <h2 style={{ marginBottom: "0.25rem", fontSize: "1.25rem" }}>Model Compatibility</h2>
    <p style={{ color: "var(--color-text-muted)", margin: "0 0 1rem" }}>
      Compare registered models against reviewed Golden prompts before changing an agent’s model.
    </p>
    <ModelCompatibilityPanel />
  </div>;
}
