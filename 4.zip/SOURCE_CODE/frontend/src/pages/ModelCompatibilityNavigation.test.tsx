import { act } from "react";
import { createRoot } from "react-dom/client";
import { MemoryRouter } from "react-router-dom";
import { afterEach, expect, it, vi } from "vitest";
import { useAuth } from "../auth/AuthContext";
import App from "../App";

vi.mock("../auth/AuthContext", () => ({ useAuth: vi.fn() }));
vi.mock("./ChatPage", () => ({ default: () => null }));
vi.mock("./CockpitPage", () => ({ default: () => null }));
vi.mock("./dashboard/ModelCompatibilityPage", () => ({ default: () => <h2>Compatibility page loaded</h2> }));
afterEach(() => { vi.clearAllMocks(); vi.unstubAllGlobals(); });

it.each(["admin", "viewer"])("restricts the model compatibility route and Admin entry for %s", async role => {
  vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true);
  vi.mocked(useAuth).mockReturnValue({ user: { role, username: "test", display_name: "Tester" } } as ReturnType<typeof useAuth>);
  const host = document.createElement("div"); document.body.append(host); const root = createRoot(host);
  try {
    await act(async () => root.render(<MemoryRouter initialEntries={["/dashboard/model-compatibility"]}><App /></MemoryRouter>));
    expect(Boolean(host.querySelector('a[href="/dashboard/model-compatibility"]'))).toBe(role === "admin");
    expect(host.textContent?.includes("Compatibility page loaded")).toBe(role === "admin");
  } finally { await act(async () => root.unmount()); host.remove(); }
});
