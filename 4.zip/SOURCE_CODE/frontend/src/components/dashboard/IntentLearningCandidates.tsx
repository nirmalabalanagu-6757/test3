import { useCallback, useRef, useState } from "react";
import { apiDelete, apiGet, apiPost } from "../../api/client";
import type { GoldenSuiteItem } from "./IntentValidationPanel";
import { useDeferredLoad } from "../../hooks/useDeferredLoad";
import IntentLearningMatchingSettings from "./IntentLearningMatchingSettings";

type CandidateStatus = "pending" | "approved" | "rejected";
type ExecutionMode = "direct_action" | "agent_llm" | "multi_agent";

interface IntentLearningCandidate {
  id: string;
  status: CandidateStatus;
  source_agent: string;
  normalized_pattern: string;
  examples_json: string[];
  observed_route_json: Record<string, string[]>;
  model_names_json: string[];
  occurrence_count: number;
  proposal_confidence: number;
  proposed_execution_mode: ExecutionMode;
  proposed_rule_json: Record<string, unknown>;
  observation_json?: {
    matching?: { method: string; mode?: string; reason?: string; suggested_id?: string; applied?: boolean; model_calls: number; cache_hit?: boolean };
    draft_actions?: Record<string, unknown>[];
    unresolved_calls?: { id: string; reason: string }[];
    complete?: boolean;
    direct_ready?: boolean;
    requires_action_publication?: boolean;
    unobserved_agents?: string[];
    calls?: {
      id: string;
      agent: string;
      tool: string;
      status: string;
      argument_names: string[];
      depends_on: string[];
      action_template?: string;
      matching_actions?: string[];
      reason: string;
    }[];
  };
  suggested_intent_id: string | null;
  approved_intent_id: string | null;
  reviewed_by: string | null;
  review_note: string | null;
  first_seen_at: string;
  last_seen_at: string;
}

const panelStyle: React.CSSProperties = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-md)",
  padding: "1rem",
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "0.4rem 0.55rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-bg)",
  color: "var(--color-text)",
  fontSize: "0.8125rem",
};

const buttonStyle: React.CSSProperties = {
  padding: "0.35rem 0.7rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-surface)",
  color: "var(--color-text)",
  cursor: "pointer",
  fontSize: "0.75rem",
};

function errorMessage(error: unknown): string {
  return typeof error === "object" && error && "message" in error ? String(error.message) : String(error);
}

function modeLabel(mode: ExecutionMode): { label: string; color: string } {
  if (mode === "direct_action") {
    return { label: "Direct action — no execution LLM", color: "var(--color-success)" };
  }
  if (mode === "multi_agent") {
    return { label: "Workflow — review LLM steps", color: "var(--color-warning)" };
  }
  return { label: "Agent LLM execution", color: "var(--color-warning)" };
}

export default function IntentLearningCandidates({
  agents,
  onApproved,
}: {
  agents: string[];
  onApproved: () => void;
}) {
  const [status, setStatus] = useState<CandidateStatus>("pending");
  const [sourceAgent, setSourceAgent] = useState("all");
  const [candidates, setCandidates] = useState<IntentLearningCandidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviewing, setReviewing] = useState<IntentLearningCandidate | null>(null);
  const [ruleJson, setRuleJson] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [actionsJson, setActionsJson] = useState("[]");
  const [suites, setSuites] = useState<GoldenSuiteItem[]>([]);
  const [suiteId, setSuiteId] = useState("");
  const [allowLlm, setAllowLlm] = useState(false);
  const [validation, setValidation] = useState<unknown>(null);
  const [reviewToken, setReviewToken] = useState("");
  const [inlineGolden, setInlineGolden] = useState(false);
  const [goldenJson, setGoldenJson] = useState('{"name":"reviewed-workflow","version":1,"cases":[]}');
  const [expectationsReviewed, setExpectationsReviewed] = useState(false);
  const [validatedPackage, setValidatedPackage] = useState("");
  const inFlight = useRef(false);
  const packageKey = JSON.stringify([ruleJson, actionsJson, suiteId, allowLlm, inlineGolden, goldenJson, expectationsReviewed, reviewToken]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const source = sourceAgent === "all" ? "" : `&source_agent=${encodeURIComponent(sourceAgent)}`;
      const data = await apiGet<{ candidates: IntentLearningCandidate[] }>(
        `/intent-learning?status=${status}&limit=500${source}`,
      );
      setCandidates(data.candidates);
      setSuites((await apiGet<{ suites: GoldenSuiteItem[] }>("/intent-validation/suites")).suites);
      setError(null);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [sourceAgent, status]);

  useDeferredLoad(load);

  const openReview = async (candidate: IntentLearningCandidate) => {
    if (inFlight.current) return;
    inFlight.current = true; setSaving(true); setReviewing(null); setError(null);
    try {
    const snapshot = await apiGet<{ candidate: IntentLearningCandidate; review_token: string }>(`/intent-learning/${candidate.id}/review`);
    candidate = snapshot.candidate;
    setReviewToken(snapshot.review_token); setValidatedPackage("");
    setReviewing(candidate);
    setRuleJson(JSON.stringify(candidate.proposed_rule_json, null, 2));
    setActionsJson(JSON.stringify(candidate.observation_json?.draft_actions || [], null, 2));
    setSuiteId(""); setAllowLlm(false); setValidation(null);
    setInlineGolden(false); setExpectationsReviewed(false);
    setNote("");
    setError(null);
    } catch (err) { setError(errorMessage(err)); }
    finally { inFlight.current = false; setSaving(false); }
  };

  const packagePayload = () => ({
    rule: JSON.parse(ruleJson), actions: JSON.parse(actionsJson), note: note.trim() || null,
    golden_suite_id: inlineGolden ? null : suiteId || null,
    golden_suite: inlineGolden ? { ...JSON.parse(goldenJson), expectations_reviewed: expectationsReviewed } : null,
    expected_review_token: reviewToken, allow_llm_execution: allowLlm,
  });

  const approve = async () => {
    if (!reviewing || inFlight.current || validatedPackage !== packageKey) return;
    inFlight.current = true;
    setSaving(true);
    try {
      await apiPost(`/intent-learning/${reviewing.id}/approve`, packagePayload());
      setReviewing(null);
      await load();
      onApproved();
    } catch (err) {
      setValidatedPackage("");
      setError(errorMessage(err));
    } finally {
      inFlight.current = false;
      setSaving(false);
    }
  };

  const reject = async (candidate: IntentLearningCandidate) => {
    if (!window.confirm("Reject this learned intent candidate?")) return;
    try {
      await apiPost(`/intent-learning/${candidate.id}/reject`, { note: null });
      await load();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const removeCandidate = async (candidate: IntentLearningCandidate) => {
    if (!window.confirm("Delete this learning candidate? Published intents, action templates and audit history remain. Similar prompts may be learned again.")) return;
    try {
      await apiDelete(`/intent-learning/${candidate.id}`);
      if (reviewing?.id === candidate.id) setReviewing(null);
      await load();
    } catch (err) { setError(errorMessage(err)); }
  };

  const testProposal = async () => {
    if (!reviewing || inFlight.current) return;
    inFlight.current = true; setSaving(true); setError(null); setValidation(null); setValidatedPackage("");
    try {
      const result = await apiPost<{ status: string }>(`/intent-learning/${reviewing.id}/validate`, packagePayload());
      setValidation(result); if (result.status === "PASS") setValidatedPackage(packageKey);
    }
    catch (err) { setError(errorMessage(err)); }
    finally { inFlight.current = false; setSaving(false); }
  };

  return (
    <div style={panelStyle}>
      <IntentLearningMatchingSettings />
      <div style={{ display: "flex", justifyContent: "space-between", gap: "0.75rem", flexWrap: "wrap" }}>
        <div>
          <h3 style={{ margin: 0, fontSize: "0.95rem" }}>Dynamic Learning Queue</h3>
          <p style={{ margin: "0.3rem 0 0.75rem", color: "var(--color-text-muted)", fontSize: "0.72rem", maxWidth: "850px" }}>
            Review intent matching, agent access, connections, workflow, actions and response settings together. One Approve &amp; Publish action saves the complete validated package. Matching suggestions never approve or activate anything. Every execution fetches fresh data; business responses are not cached.
          </p>
        </div>
        <button style={buttonStyle} onClick={() => void load()}>Refresh</button>
      </div>
      <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
        <select style={{ ...inputStyle, width: "160px" }} value={status} onChange={(event) => setStatus(event.target.value as CandidateStatus)}>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <select style={{ ...inputStyle, width: "210px" }} value={sourceAgent} onChange={(event) => setSourceAgent(event.target.value)}>
          <option value="all">All source agents</option>
          {agents.map((agent) => <option key={agent}>{agent}</option>)}
        </select>
        <span style={{ alignSelf: "center", color: "var(--color-text-muted)", fontSize: "0.75rem" }}>{candidates.length} candidates</span>
      </div>
      {error && <p role="alert" style={{ color: "var(--color-error)", fontSize: "0.8rem" }}>{error}</p>}
      {loading ? <p style={{ color: "var(--color-text-muted)" }}>Loading candidates...</p> : (
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.75rem" }}>
            <thead>
              <tr>{["Observed request", "Source / route", "Execution", "Seen", "Last observed", "Actions"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.5rem", borderBottom: "2px solid var(--color-border)", color: "var(--color-text-muted)", whiteSpace: "nowrap" }}>{heading}</th>)}</tr>
            </thead>
            <tbody>
              {candidates.map((candidate) => {
                const mode = modeLabel(candidate.proposed_execution_mode);
                const proposedName = String(candidate.proposed_rule_json.name || candidate.suggested_intent_id || "intent");
                const proposedVersion = Number(candidate.proposed_rule_json.workflow_version || 1);
                return (
                  <tr key={candidate.id}>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", minWidth: "280px" }}>
                      <strong>{candidate.examples_json[0] || candidate.normalized_pattern}</strong>
                      {candidate.suggested_intent_id && <div style={{ color: "var(--color-primary)", fontSize: "0.68rem", marginTop: "0.2rem" }}>Proposes updating {proposedName} to workflow v{proposedVersion}; requires your approval</div>}
                      {candidate.observation_json?.matching && <div>Matching: {candidate.observation_json.matching.method} · {candidate.observation_json.matching.model_calls} comparison calls{candidate.observation_json.matching.cache_hit ? " · cached decision" : ""}{candidate.observation_json.matching.mode === "preview" ? " · preview only" : ""}. {candidate.observation_json.matching.reason}{candidate.observation_json.matching.suggested_id && ` Suggested: ${candidate.observation_json.matching.suggested_id}`}</div>}
                      {candidate.examples_json.length > 1 && <details><summary style={{ cursor: "pointer", color: "var(--color-primary)", fontSize: "0.68rem" }}>{candidate.examples_json.length} grouped examples</summary><ul>{candidate.examples_json.map((example) => <li key={example}>{example}</li>)}</ul></details>}
                    </td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>
                      <strong>{candidate.source_agent}</strong>
                      <div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{Object.entries(candidate.observed_route_json).map(([agent, tools]) => `${agent}: ${tools.join(", ") || "no observed tool"}`).join(" | ")}</div>
                      {Object.values(candidate.observed_route_json).some((tools) => tools.length > 0) && <div style={{ color: "var(--color-primary)", fontSize: "0.64rem", marginTop: "0.18rem" }}>Connection captured from actual tool execution</div>}
                    </td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", color: mode.color }}>
                      {mode.label}
                      <div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{candidate.suggested_intent_id && ["llm", "semantic"].includes(candidate.observation_json?.matching?.method || "") ? "Assisted suggestion — review required" : `${candidate.suggested_intent_id ? "text similarity" : "proposal confidence"} ${candidate.proposal_confidence.toFixed(2)}`}</div>
                    </td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{candidate.occurrence_count}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}>{new Date(candidate.last_seen_at).toLocaleString()}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}>
                      {candidate.status === "pending" ? <><button style={buttonStyle} onClick={() => openReview(candidate)}>Review</button> <button style={{ ...buttonStyle, color: "var(--color-error)" }} onClick={() => void reject(candidate)}>Reject</button></> : <span>{candidate.status}{candidate.approved_intent_id ? ` · ${candidate.approved_intent_id}` : ""}</span>}
                      <button style={buttonStyle} onClick={() => void removeCandidate(candidate)}>Delete candidate</button>
                    </td>
                  </tr>
                );
              })}
              {candidates.length === 0 && <tr><td colSpan={6} style={{ padding: "1.5rem", textAlign: "center", color: "var(--color-text-muted)" }}>No candidates in this state.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {reviewing && (
        <div style={{ marginTop: "1rem", paddingTop: "1rem", borderTop: "1px solid var(--color-border)" }}>
          <h4 style={{ margin: "0 0 0.35rem" }}>{reviewing.suggested_intent_id ? `Review workflow v${Number(reviewing.proposed_rule_json.workflow_version || 1)} update` : "Review proposed rule"}</h4>
          <p style={{ margin: "0 0 0.6rem", color: "var(--color-text-muted)", fontSize: "0.72rem" }}>{reviewing.suggested_intent_id ? "This updates the existing intent after approval. Its access scope and response settings are preserved. Review the complete proposed workflow, parameter mappings and versioned actions, including any upgrade from agent execution to direct actions." : "Edit any matching, scope, workflow, parameter, risk, or response setting. Approval validates all referenced agents, tools and Action Templates before activation."}</p>
          {!!reviewing.observation_json?.calls?.length && (
            <div style={{ ...panelStyle, marginBottom: "0.75rem" }}>
              <strong style={{ fontSize: "0.8rem" }}>Observed tool calls</strong>
              <p style={{ fontSize: "0.72rem", color: "var(--color-text-muted)" }}>
                {reviewing.observation_json.requires_action_publication
                  ? "Direct mappings were proposed, but actions are not published yet. Review their contracts and run a Golden suite before combined approval."
                  : reviewing.observation_json.direct_ready
                  ? "Each call matches one published action. Request parameters and earlier results are read again on every execution."
                  : "Some calls need review before direct execution is possible. The proposal uses agent execution until the action mappings are complete."}
                {reviewing.observation_json.complete === false && " Capture reached a limit or a response could not be paired with its call."}
                {!!reviewing.observation_json.unobserved_agents?.length && ` Agents without observed tool calls: ${reviewing.observation_json.unobserved_agents.join(", ")}. Review their work before replacing the agent workflow.`}
              </p>
              <ol style={{ paddingLeft: "1.2rem", fontSize: "0.75rem" }}>
                {reviewing.observation_json.calls.map((call) => (
                  <li key={call.id} style={{ marginBottom: "0.6rem" }}>
                    <strong>{call.id}: {call.agent} → {call.tool}</strong> · {call.status}
                    <div>After: {call.depends_on.join(", ") || "no earlier calls"}</div>
                    <div>Action: {call.action_template || "Review required"}</div>
                    <div style={{ color: "var(--color-text-muted)" }}>{call.reason}</div>
                    {(call.matching_actions?.length ?? 0) > 1 && <div>Matching actions: {call.matching_actions?.join(", ")}</div>}
                    <div style={{ color: "var(--color-text-muted)" }}>Inputs: {call.argument_names.join(", ") || "none"}</div>
                  </li>
                ))}
              </ol>
            </div>
          )}
          <p>The intent JSON includes all matching, access, workflow, parameter and response options. Action contracts below are created or reused by the same approval. No separate Action Templates approval is needed.</p>
          <label>Intent, workflow and response configuration
            <textarea aria-label="Intent workflow and response configuration" disabled={saving} style={{ ...inputStyle, minHeight: "360px", fontFamily: "var(--font-family-mono)" }} value={ruleJson} onChange={(event) => setRuleJson(event.target.value)} />
          </label>
          {!!reviewing.observation_json?.unresolved_calls?.length && <p role="alert">Unresolved recorded calls: {reviewing.observation_json.unresolved_calls.map(call => `${call.id}: ${call.reason}`).join("; ")}</p>}
          <label>Reviewed action contracts (published atomically with approval)
            <textarea aria-label="Reviewed action contracts" disabled={saving} style={{ ...inputStyle, minHeight: "180px", fontFamily: "monospace" }} value={actionsJson} onChange={e => setActionsJson(e.target.value)} />
          </label>
          <p style={{ fontSize: "0.75rem" }}>Draft contracts are suggestions, not automatically approved SQL. Review every connection, query, input mapping and risk. Remove unused contracts from this list. Publishing new actions requires a passing reviewed Golden suite.</p>
          <label><input type="checkbox" disabled={saving} checked={inlineGolden} onChange={e => setInlineGolden(e.target.checked)} /> Include a new Golden suite in this same approval</label>
          {inlineGolden ? <>
            <p>Supply independently reviewed expected calls and synthetic fixtures. Do not paste business results or credentials. This suite is saved only when the complete package passes and you approve.</p>
            <textarea aria-label="Golden suite in review package" disabled={saving} style={{ ...inputStyle, minHeight: "200px" }} value={goldenJson} onChange={e => { setGoldenJson(e.target.value); setExpectationsReviewed(false); }} />
            <label><input type="checkbox" disabled={saving} checked={expectationsReviewed} onChange={e => setExpectationsReviewed(e.target.checked)} /> I reviewed the expected Golden results independently.</label>
          </> : <select aria-label="Approval Golden suite" disabled={saving} style={inputStyle} value={suiteId} onChange={e => setSuiteId(e.target.value)}><option value="">Select an existing reviewed Golden suite</option>{suites.map(suite => <option key={suite.id} value={suite.id}>{suite.name} v{suite.version}</option>)}</select>}
          <button style={buttonStyle} disabled={saving || (inlineGolden && !expectationsReviewed)} onClick={() => void testProposal()}>Validate complete package — no real tools or LLM</button>
          <label style={{ display: "block", marginTop: "0.5rem" }}><input aria-label="Allow LLM execution" type="checkbox" disabled={saving} checked={allowLlm} onChange={e => setAllowLlm(e.target.checked)} /> Allow LLM execution if direct mappings are incomplete (not a zero-LLM intent).</label>
          {validation != null && <pre style={{ maxHeight: "350px", overflow: "auto", whiteSpace: "pre-wrap" }}>{JSON.stringify(validation, null, 2)}</pre>}
          <input style={{ ...inputStyle, marginTop: "0.5rem" }} value={note} onChange={(event) => setNote(event.target.value)} placeholder="Optional approval note" />
          <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.65rem" }}>
            <button style={{ ...buttonStyle, background: "var(--color-primary)", color: "var(--color-on-primary)" }} disabled={saving || validatedPackage !== packageKey} onClick={() => void approve()}>{saving ? "Working..." : "Approve & Publish"}</button>
            <button style={buttonStyle} disabled={saving} onClick={() => setReviewing(null)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}
