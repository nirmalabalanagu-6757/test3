import { useCallback, useState } from "react";
import { Link } from "react-router-dom";
import { apiGet, apiPost } from "../../api/client";
import { useDeferredLoad } from "../../hooks/useDeferredLoad";

const field: React.CSSProperties = { width: "100%", padding: "0.5rem", background: "var(--color-bg)", color: "var(--color-text)", border: "1px solid var(--color-border)", borderRadius: "4px" };
const button: React.CSSProperties = { padding: "0.4rem 0.7rem", margin: "0.3rem", cursor: "pointer" };
export interface GoldenSuiteItem { id: string; name: string; version: number; definition: Record<string, unknown> }
function validationError(error: unknown): string {
  return typeof error === "object" && error && "message" in error ? String(error.message) : String(error);
}

export default function IntentValidationPanel({ agents, intents }: {
  agents: string[]; intents: { id: string; name: string }[];
}) {
  const [suites, setSuites] = useState<GoldenSuiteItem[]>([]);
  const [suite, setSuite] = useState("");
  const [reviewed, setReviewed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<unknown>(null);
  const [intent, setIntent] = useState("");
  const [versions, setVersions] = useState<{ version: number; diff: unknown; snapshot: unknown }[]>([]);
  const [editor, setEditor] = useState(JSON.stringify({
    name: "my-agent-regression", version: 1, description: "Replace this example with independently reviewed synthetic expectations.",
    cases: [{ name: "unrelated request", query: "A synthetic unrelated request", source_agent: agents[0] || "YOUR_AGENT",
      expected_decision: "no_match", expected_intents: [], calls: [] }],
  }, null, 2));
  const load = useCallback(async () => {
    try {
      const saved = await apiGet<{ suites: GoldenSuiteItem[] }>("/intent-validation/suites");
      setSuites(saved.suites);
    } catch (err) { setError(validationError(err)); }
  }, []);
  useDeferredLoad(load);

  const perform = async (work: () => Promise<unknown>) => {
    setBusy(true); setError("");
    try { setResult(await work()); }
    catch (err) { setError(validationError(err)); }
    finally { setBusy(false); }
  };

  return <section style={{ border: "1px solid var(--color-border)", padding: "1rem" }}>
    <h3>Golden tests and intent revisions</h3>
    <p>Review expected behavior independently. Intent simulation runs the real resolver and workflow engine with synthetic tool results, never real connectors. PASS covers only the saved cases.</p>
    <p>Provider testing has moved to <Link to="/dashboard/model-compatibility">Admin → Model Compatibility</Link>. Your saved Golden suites are shared with that page.</p>
    {error && <p role="alert" style={{ color: "var(--color-error)" }}>{error}</p>}
    <label>Saved suite version
      <select aria-label="Golden suite" style={field} value={suite} onChange={event => setSuite(event.target.value)}>
        <option value="">Select a reviewed suite</option>
        {suites.map(item => <option key={item.id} value={item.id}>{item.name} v{item.version}</option>)}
      </select>
    </label>
    <button style={button} disabled={!suite || busy} onClick={() => void perform(() => apiPost(`/intent-validation/suites/${suite}/test`, {}))}>Test current intents (no LLM)</button>
    <button style={button} disabled={!suite || busy} onClick={() => void perform(() => apiGet(`/intent-validation/runs?mode=intent_simulation&suite_id=${suite}`))}>Run history</button>
    <button style={button} disabled={!suite || busy} onClick={() => {
      const saved = suites.find(item => item.id === suite);
      if (saved) { setEditor(JSON.stringify({ ...saved.definition, version: saved.version + 1, expectations_reviewed: false }, null, 2)); setReviewed(false); }
    }}>Copy to next suite version</button>
    <details>
      <summary>Create a reviewed Golden suite</summary>
      <p>Use synthetic prompts/results only. Never paste passwords, tokens or customer records. For a routed test include expected_intents and calls with step_id, intent_name, agent, tool, action_template@version, arguments, depends_on and fixture. Approval needs a successful tool-workflow case.</p>
      <textarea aria-label="Golden suite JSON" style={{ ...field, minHeight: "300px", fontFamily: "monospace" }} value={editor} onChange={e => { setEditor(e.target.value); setReviewed(false); }} />
      <label><input type="checkbox" checked={reviewed} onChange={e => setReviewed(e.target.checked)} /> I reviewed the expected behavior and synthetic fixtures.</label>
      <button style={button} disabled={busy || !reviewed} onClick={() => void perform(async () => {
        const created = await apiPost<{ id: string }>("/intent-validation/suites", { ...JSON.parse(editor), expectations_reviewed: reviewed });
        setSuite(created.id); setReviewed(false); await load(); return created;
      })}>Save immutable suite version</button>
    </details>
    <details style={{ marginTop: "1rem" }}>
      <summary>Intent revision history and restore</summary>
      <select aria-label="Intent history" style={field} value={intent} onChange={e => { setIntent(e.target.value); setVersions([]); }}><option value="">Select intent</option>{intents.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
      <button style={button} disabled={busy || !intent} onClick={() => void perform(async () => {
        const data = await apiGet<{ versions: typeof versions }>(`/intent-validation/intents/${intent}/versions`); setVersions(data.versions); return data;
      })}>Load revisions</button>
      <p>History begins with the first save after this update. Restore creates a Learning Queue proposal; the current active intent remains unchanged until you approve it.</p>
      {versions.map(item => <details key={item.version}><summary>Revision {item.version}</summary><pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(item.diff, null, 2)}</pre><button style={button} disabled={busy} onClick={() => {
        if (window.confirm(`Create a reviewed restore proposal from revision ${item.version}?`)) void perform(() => apiPost(`/intent-validation/intents/${intent}/versions/${item.version}/restore`));
      }}>Create restore proposal</button></details>)}
    </details>
    {result != null && <pre aria-label="Validation result" style={{ whiteSpace: "pre-wrap", overflowWrap: "anywhere", maxHeight: "550px", overflow: "auto" }}>{JSON.stringify(result, null, 2)}</pre>}
  </section>;
}
