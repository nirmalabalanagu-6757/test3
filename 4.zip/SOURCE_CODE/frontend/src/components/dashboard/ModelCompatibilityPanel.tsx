import { useCallback, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { apiGet, apiPost } from "../../api/client";
import { useDeferredLoad } from "../../hooks/useDeferredLoad";
import type { GoldenSuiteItem } from "./IntentValidationPanel";

const field: React.CSSProperties = { width: "100%", padding: "0.5rem", background: "var(--color-bg)", color: "var(--color-text)", border: "1px solid var(--color-border)", borderRadius: "4px" };
const button: React.CSSProperties = { padding: "0.5rem 0.75rem", cursor: "pointer" };
const cell: React.CSSProperties = { padding: "0.5rem", textAlign: "left", borderBottom: "1px solid var(--color-border)" };
interface ComparisonRow {
  model: string; case: string; status: string; model_calls: number;
  input_tokens?: number | null; output_tokens?: number | null; reason?: string; failures?: string[];
}
interface ComparisonReport { id: string; status: string; results: ComparisonRow[] }
interface Run { id: string; status: string; created_at: string; results: ComparisonReport }
function message(error: unknown) {
  return typeof error === "object" && error && "message" in error ? String(error.message) : String(error);
}

export default function ModelCompatibilityPanel() {
  const [suites, setSuites] = useState<GoldenSuiteItem[]>([]);
  const [agents, setAgents] = useState<string[]>([]);
  const [models, setModels] = useState<string[]>([]);
  const [suite, setSuite] = useState("");
  const [agent, setAgent] = useState("");
  const [modelA, setModelA] = useState("");
  const [modelB, setModelB] = useState("");
  const [allowModels, setAllowModels] = useState(false);
  const [maxTurns, setMaxTurns] = useState(4);
  const [maxTokens, setMaxTokens] = useState(2048);
  const [maxCalls, setMaxCalls] = useState(20);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const inFlight = useRef(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<ComparisonReport | null>(null);
  const [history, setHistory] = useState<Run[] | null>(null);
  const load = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [saved, registry, registeredAgents] = await Promise.all([
        apiGet<{ suites: GoldenSuiteItem[] }>("/intent-validation/suites"),
        apiGet<{ models: { name: string; status: string }[] }>("/models"),
        apiGet<{ agents: { name: string }[] }>("/agents"),
      ]);
      setSuites(saved.suites);
      setModels(registry.models.filter(item => item.status === "active").map(item => item.name));
      setAgents(registeredAgents.agents.map(item => item.name));
    } catch (err) { setError(message(err)); }
    finally { setLoading(false); }
  }, []);
  useDeferredLoad(load);

  const changed = () => { setAllowModels(false); setResult(null); setError(""); };
  const validLimit = (n: number, low: number, high: number) => Number.isInteger(n) && n >= low && n <= high;
  const limitsValid = validLimit(maxTurns, 1, 10) && validLimit(maxTokens, 64, 8192) && validLimit(maxCalls, 1, 50);
  const selectionValid = suites.some(item => item.id === suite) && agents.includes(agent) && models.includes(modelA)
    && (!modelB || (models.includes(modelB) && modelA !== modelB));
  const run = async () => {
    if (inFlight.current || !allowModels || !selectionValid || !limitsValid || loading) return;
    inFlight.current = true; setBusy(true); setError(""); setResult(null); setAllowModels(false);
    try {
      setResult(await apiPost<ComparisonReport>(`/intent-validation/suites/${encodeURIComponent(suite)}/compare-models`, {
        agent, models: [modelA, modelB].filter(Boolean), allow_model_calls: true,
        max_turns: maxTurns, max_output_tokens: maxTokens, max_total_model_calls: maxCalls,
      }));
      setHistory(null);
    } catch (err) { setError(message(err)); }
    finally { inFlight.current = false; setBusy(false); }
  };
  const loadHistory = async () => {
    if (inFlight.current) return;
    inFlight.current = true; setBusy(true); setError("");
    try {
      const saved = await apiGet<{ runs: Run[] }>(`/intent-validation/runs?mode=model_comparison${suite ? `&suite_id=${encodeURIComponent(suite)}` : ""}`);
      setHistory(saved.runs);
    } catch (err) { setError(message(err)); }
    finally { inFlight.current = false; setBusy(false); }
  };

  return <section style={{ border: "1px solid var(--color-border)", borderRadius: "6px", padding: "1rem" }} aria-label="Model compatibility testing">
    <p style={{ marginTop: 0 }}>This test calls the selected providers with synthetic prompts, agent instructions and tool schemas. Tool results come from fixtures; no real SQL, APIs or other tools are executed. Your live model is not changed.</p>
    <p><Link to="/dashboard/intents">Manage Golden suites in Intent Control → Golden Tests</Link> · <Link to="/dashboard/models">Register a model</Link></p>
    <p style={{ color: "var(--color-text-muted)" }}>Single-agent successful tool workflows only. Routing-only, different-source-agent, multi-agent and expected-failure cases are REVIEW, not a compatibility pass. Provider charges may apply; unreported usage and costs remain unknown.</p>
    {loading && <p role="status">Loading registered models, agents and Golden suites…</p>}
    {error && <p role="alert" style={{ color: "var(--color-error)" }}>{error}</p>}
    {!loading && (!suites.length || !models.length || !agents.length) && <p role="status">A saved reviewed Golden suite, a registered agent and an active model are required. Register any missing items before running a comparison.</p>}
    <fieldset disabled={busy || loading} style={{ border: 0, padding: 0, margin: 0 }}>
      <legend style={{ fontWeight: 600, marginBottom: "0.75rem" }}>Test configuration</legend>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem" }}>
        <label>Saved Golden suite version<select aria-label="Golden suite" style={field} value={suite} onChange={e => { setSuite(e.target.value); setHistory(null); changed(); }}>
          <option value="">Select a reviewed suite</option>{suites.map(item => <option key={item.id} value={item.id}>{item.name} v{item.version}</option>)}
        </select></label>
        <label>Agent<select aria-label="Agent" style={field} value={agent} onChange={e => { setAgent(e.target.value); changed(); }}>
          <option value="">Select an agent</option>{agents.map(name => <option key={name}>{name}</option>)}
        </select></label>
        {[{ value: modelA, set: setModelA, label: "Current model" }, { value: modelB, set: setModelB, label: "Candidate model (optional)" }].map(item => <label key={item.label}>{item.label}<select aria-label={item.label} style={field} value={item.value} onChange={e => { item.set(e.target.value); changed(); }}>
          <option value="">Select model</option>{models.map(name => <option key={name}>{name}</option>)}
        </select></label>)}
      </div>
      {modelA && modelA === modelB && <p role="alert">Select different current and candidate models, or leave the candidate blank.</p>}
      <details style={{ margin: "1rem 0" }}><summary>Provider call limits</summary>
        <p>Limits apply to this comparison only. The call budget is shared across all cases and models, in the selected order; exhaustion is a FAIL, never a pass. Each case has a 180-second timeout.</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem" }}>
          {[{ label: "Maximum turns per case", value: maxTurns, set: setMaxTurns, min: 1, max: 10 },
            { label: "Maximum output tokens per call", value: maxTokens, set: setMaxTokens, min: 64, max: 8192 },
            { label: "Maximum total model calls", value: maxCalls, set: setMaxCalls, min: 1, max: 50 }].map(item => <label key={item.label}>{item.label}<input aria-label={item.label} type="number" step="1" min={item.min} max={item.max} value={item.value} style={field} onChange={e => { item.set(Number(e.target.value)); changed(); }} /></label>)}
        </div>
        {!limitsValid && <p role="alert">Use whole numbers within the displayed limits.</p>}
      </details>
      <label style={{ display: "block", margin: "1rem 0" }}><input type="checkbox" checked={allowModels} onChange={e => setAllowModels(e.target.checked)} /> Allow provider model calls for this run. I understand charges may apply.</label>
      <button style={button} disabled={busy || loading || !allowModels || !selectionValid || !limitsValid} onClick={() => void run()}>{busy ? "Working…" : "Run model comparison"}</button>
      <button style={{ ...button, marginLeft: "0.5rem" }} disabled={busy || loading} onClick={() => void loadHistory()}>Comparison history (no model calls)</button>
      <button style={{ ...button, marginLeft: "0.5rem" }} disabled={busy || loading} onClick={() => { changed(); void load(); }}>Refresh registries</button>
    </fieldset>
    {result && <section aria-label="Comparison result" style={{ marginTop: "1rem" }}>
      <h3>Result: {result.status}</h3>
      <div style={{ overflowX: "auto" }}><table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead><tr>{["Model", "Case", "Status", "Model calls", "Input tokens", "Output tokens", "Details"].map(label => <th key={label} style={cell}>{label}</th>)}</tr></thead>
        <tbody>{result.results.map((row, index) => <tr key={`${row.model}-${row.case}-${index}`}>
          <td style={cell}>{row.model}</td><td style={cell}>{row.case}</td><td style={cell}>{row.status}</td><td style={cell}>{row.model_calls}</td>
          <td style={cell}>{row.input_tokens ?? "Unknown"}</td><td style={cell}>{row.output_tokens ?? "Unknown"}</td><td style={cell}>{row.reason || row.failures?.join("; ") || "Expected tool contract matched"}</td>
        </tr>)}</tbody>
      </table></div>
      <details><summary>Full comparison receipt</summary><pre style={{ whiteSpace: "pre-wrap", overflowWrap: "anywhere" }}>{JSON.stringify(result, null, 2)}</pre></details>
    </section>}
    {history && <section aria-label="Comparison history"><h3>Saved comparison runs</h3>
      {!history.length && <p>No comparison runs found for this selection.</p>}
      {history.map(item => <details key={item.id}><summary>{item.created_at} — {item.status}</summary><pre style={{ whiteSpace: "pre-wrap", overflowWrap: "anywhere" }}>{JSON.stringify(item.results, null, 2)}</pre></details>)}
    </section>}
  </section>;
}
