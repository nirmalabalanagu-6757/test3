import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { MemoryRouter } from "react-router-dom";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { apiGet, apiPost } from "../../api/client";
import ModelCompatibilityPanel from "./ModelCompatibilityPanel";

vi.mock("../../api/client", () => ({ apiGet: vi.fn(), apiPost: vi.fn() }));
let host: HTMLDivElement;
let root: Root;
beforeEach(() => {
  vi.useFakeTimers(); vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true);
  host = document.createElement("div"); document.body.append(host); root = createRoot(host);
  vi.mocked(apiGet).mockImplementation(async path => {
    if (path === "/models") return { models: [{ name: "claude-sonnet-4-6", status: "active" }, { name: "baseline", status: "active" }, { name: "retired", status: "inactive" }] };
    if (path === "/agents") return { agents: [{ name: "backup_agent" }] };
    if (path.includes("/runs")) return { runs: [] };
    return { suites: [{ id: "suite", name: "Reviewed", version: 1, definition: {} }] };
  });
  vi.mocked(apiPost).mockResolvedValue({ id: "receipt", status: "PASS", results: [{ model: "baseline", case: "test", status: "PASS", model_calls: 2, input_tokens: null, output_tokens: null }] });
});
afterEach(async () => {
  await act(async () => root.unmount()); host.remove();
  vi.useRealTimers(); vi.unstubAllGlobals(); vi.resetAllMocks();
});
const button = (label: string) => [...host.querySelectorAll("button")].find(item => item.textContent === label)!;
const consent = () => host.querySelector<HTMLInputElement>('input[type="checkbox"]')!;
async function render() {
  await act(async () => root.render(<MemoryRouter><ModelCompatibilityPanel /></MemoryRouter>));
  await act(async () => { await vi.runAllTimersAsync(); });
}
async function select(label: string, value: string) {
  await act(async () => {
    const element = host.querySelector<HTMLSelectElement>(`select[aria-label="${label}"]`)!;
    element.value = value; element.dispatchEvent(new Event("change", { bubbles: true }));
  });
}
async function configure() {
  await select("Golden suite", "suite"); await select("Agent", "backup_agent"); await select("Current model", "baseline");
}

it("requires selections and per-run consent; page load and history never call a model", async () => {
  await render();
  expect(host.textContent).not.toContain("retired");
  expect(button("Run model comparison").disabled).toBe(true);
  await act(async () => button("Comparison history (no model calls)").click());
  expect(apiGet).toHaveBeenCalledWith("/intent-validation/runs?mode=model_comparison");
  expect(host.textContent).toContain("No comparison runs");
  await configure(); expect(button("Run model comparison").disabled).toBe(true);
  await act(async () => consent().click());
  expect(button("Run model comparison").disabled).toBe(false);
  expect(apiPost).not.toHaveBeenCalled();
});

it("posts a bounded comparison once even on double-click, consumes consent, and shows unknown usage", async () => {
  await render(); await configure(); await select("Candidate model (optional)", "claude-sonnet-4-6");
  await act(async () => consent().click());
  await act(async () => { button("Run model comparison").click(); button("Run model comparison").click(); });
  expect(apiPost).toHaveBeenCalledExactlyOnceWith("/intent-validation/suites/suite/compare-models", {
    agent: "backup_agent", models: ["baseline", "claude-sonnet-4-6"], allow_model_calls: true,
    max_turns: 4, max_output_tokens: 2048, max_total_model_calls: 20,
  });
  expect(host.textContent).toContain("Result: PASS"); expect(host.textContent).toContain("Unknown");
  expect(consent().checked).toBe(false); expect(button("Run model comparison").disabled).toBe(true);
});

it("rejects identical models and resets consent when configuration changes", async () => {
  await render(); await configure(); await act(async () => consent().click());
  await select("Candidate model (optional)", "baseline");
  expect(consent().checked).toBe(false); expect(host.textContent).toContain("Select different");
  await act(async () => consent().click()); expect(button("Run model comparison").disabled).toBe(true);
  expect(apiPost).not.toHaveBeenCalled();
});

it("does not leave a previous PASS visible when the next request fails", async () => {
  await render(); await configure(); await act(async () => consent().click());
  await act(async () => button("Run model comparison").click());
  expect(host.textContent).toContain("Result: PASS");
  vi.mocked(apiPost).mockRejectedValue({ message: "Synthetic provider unavailable" });
  await act(async () => consent().click()); await act(async () => button("Run model comparison").click());
  expect(host.textContent).not.toContain("Result: PASS");
  expect(host.querySelector('[role="alert"]')?.textContent).toContain("Synthetic provider unavailable");
});

it("shows missing prerequisites and allows a failed registry load to be retried", async () => {
  vi.mocked(apiGet).mockRejectedValueOnce({ message: "Synthetic offline" });
  await render(); expect(host.textContent).toContain("Synthetic offline");
  expect(button("Run model comparison").disabled).toBe(true);
  await act(async () => button("Refresh registries").click());
  expect(host.textContent).not.toContain("Synthetic offline");
  expect(host.textContent).toContain("claude-sonnet-4-6"); expect(apiPost).not.toHaveBeenCalled();
});
