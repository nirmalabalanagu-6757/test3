import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { apiGet, apiPut } from "../../api/client";
import IntentLearningMatchingSettings from "./IntentLearningMatchingSettings";

vi.mock("../../api/client", () => ({ apiGet: vi.fn(), apiPut: vi.fn() }));
let root: Root;
let container: HTMLDivElement;
const data = {
  settings: { mode: "preview", embedding_model_path: "", embedding_revision: "", semantic_threshold: 0.92,
    ambiguity_margin: 0.08, llm_enabled: false, llm_model: "", max_daily_calls: 20, daily_token_budget: 40000,
    max_input_bytes: 2400, max_output_tokens: 192, timeout_sec: 15, cache_hours: 24, golden_verified: false },
  usage: { day: "2026-09-29", calls: 0, reserved_tokens: 0, reported_tokens: 0, unreported_calls: 0 },
};
beforeEach(() => {
  vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true);
  container = document.createElement("div"); document.body.appendChild(container); root = createRoot(container);
  vi.mocked(apiGet).mockImplementation(async url => url === "/models"
    ? { models: [{ name: "active-model", status: "active" }, { name: "disabled-model", status: "disabled" }] } : data);
  vi.mocked(apiPut).mockResolvedValue(data);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); vi.unstubAllGlobals(); vi.clearAllMocks(); });
async function open() {
  await act(async () => root.render(<IntentLearningMatchingSettings />));
  await act(async () => container.querySelector("button")!.click());
}

it("defaults to preview and no paid calls, and shows only active registered models", async () => {
  await open();
  expect(container.querySelector<HTMLSelectElement>('[aria-label="Assisted matching mode"]')!.value).toBe("preview");
  expect(container.querySelector<HTMLInputElement>('input[type="checkbox"]')!.checked).toBe(false);
  expect(container.textContent).not.toContain("disabled-model");
  expect(apiPut).not.toHaveBeenCalled();
});

it("requires fresh provider consent, and never approves an intent when settings are saved", async () => {
  await open();
  await act(async () => container.querySelector<HTMLInputElement>('input[type="checkbox"]')!.click());
  const save = [...container.querySelectorAll("button")].find(b => b.textContent === "Save matching controls")!;
  expect(save.disabled).toBe(true);
  const model = container.querySelectorAll<HTMLSelectElement>("select")[1];
  await act(async () => { model.value = "active-model"; model.dispatchEvent(new Event("change", { bubbles: true })); });
  const checkboxes = [...container.querySelectorAll<HTMLInputElement>('input[type="checkbox"]')];
  await act(async () => checkboxes[2].click());
  await act(async () => { save.click(); save.click(); });
  expect(apiPut).toHaveBeenCalledTimes(1);
  expect(apiPut).toHaveBeenCalledWith("/intent-learning/matching/settings", expect.objectContaining({ allow_provider_calls: true }));
  expect(container.textContent).toContain("No candidates or intents were approved");
});

it("blocks assisted grouping until Golden checks are acknowledged", async () => {
  await open();
  const mode = container.querySelector<HTMLSelectElement>('[aria-label="Assisted matching mode"]')!;
  await act(async () => { mode.value = "group"; mode.dispatchEvent(new Event("change", { bubbles: true })); });
  const save = [...container.querySelectorAll("button")].find(b => b.textContent === "Save matching controls")!;
  expect(save.disabled).toBe(true);
});
