import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, expect, it, vi } from "vitest";
import { MemoryRouter } from "react-router-dom";
import { apiGet, apiPost } from "../../api/client";
import IntentValidationPanel from "./IntentValidationPanel";

vi.mock("../../api/client", () => ({ apiGet: vi.fn(), apiPost: vi.fn() }));
afterEach(() => { vi.clearAllMocks(); vi.useRealTimers(); vi.unstubAllGlobals(); });

it("keeps Golden tests separate and links to the dedicated model compatibility page", async () => {
  vi.useFakeTimers();
  vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true);
  vi.mocked(apiGet).mockImplementation(async path => path.endsWith("/models")
    ? { models: [{ name: "claude-sonnet-4-6", status: "active" }] }
    : { suites: [{ id: "suite", name: "Reviewed", version: 1, definition: {} }] });
  const host = document.createElement("div");
  document.body.append(host);
  const root = createRoot(host);
  try {
    await act(async () => root.render(<MemoryRouter><IntentValidationPanel agents={["backup_agent"]} intents={[]} /></MemoryRouter>));
    await act(async () => { await vi.runAllTimersAsync(); });
    expect(host.querySelector('a[href="/dashboard/model-compatibility"]')?.textContent).toContain("Model Compatibility");
    expect(apiGet).not.toHaveBeenCalledWith("/models");
    expect(host.textContent).not.toContain("Run model comparison");
    expect(apiPost).not.toHaveBeenCalled();
    const save = [...host.querySelectorAll("button")].find(item => item.textContent === "Save immutable suite version")!;
    expect(save.disabled).toBe(true);
  } finally {
    await act(async () => root.unmount()); host.remove();
  }
});
