import { useRef, useState } from "react";
import { apiGet, apiPut } from "../../api/client";

interface MatchingSettings {
  mode: "off" | "preview" | "group";
  embedding_model_path: string; embedding_revision: string;
  semantic_threshold: number; ambiguity_margin: number;
  llm_enabled: boolean; llm_model: string;
  max_daily_calls: number; daily_token_budget: number;
  max_input_bytes: number; max_output_tokens: number;
  timeout_sec: number; cache_hours: number; golden_verified: boolean;
}
interface MatchingResponse {
  settings: MatchingSettings;
  usage: { day: string; calls: number; reserved_tokens: number; reported_tokens: number; unreported_calls: number };
}

export default function IntentLearningMatchingSettings() {
  const [opened, setOpened] = useState(false);
  const [data, setData] = useState<MatchingResponse | null>(null);
  const [models, setModels] = useState<string[]>([]);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const inFlight = useRef(false);
  const load = async () => {
    setOpened(true); setBusy(true); setMessage("");
    try {
      const [result, registry] = await Promise.all([
        apiGet<MatchingResponse>("/intent-learning/matching/settings"),
        apiGet<{ models: { name: string; status: string }[] }>("/models"),
      ]);
      setData(result); setModels(registry.models.filter(model => model.status === "active").map(model => model.name));
      setConsent(false);
    } catch { setMessage("Could not load matching controls. Check the backend and migration 033."); }
    finally { setBusy(false); }
  };
  const change = <K extends keyof MatchingSettings>(key: K, value: MatchingSettings[K]) => {
    if (!data) return;
    setData({ ...data, settings: { ...data.settings, [key]: value } }); setConsent(false); setMessage("");
  };
  const save = async () => {
    if (!data || inFlight.current) return;
    inFlight.current = true; setBusy(true); setMessage("");
    try {
      setData(await apiPut<MatchingResponse>("/intent-learning/matching/settings", {
        settings: data.settings, allow_provider_calls: consent,
      }));
      setConsent(false); setMessage("Matching controls saved. No candidates or intents were approved.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Could not save matching controls"); }
    finally { inFlight.current = false; setBusy(false); }
  };
  const config = data?.settings;
  const fieldStyle = { display: "block", margin: "0.65rem 0" };
  const inputStyle = { padding: "0.35rem 0.5rem", marginLeft: "0.4rem", border: "1px solid var(--color-border)", borderRadius: "var(--radius-sm)", background: "var(--color-bg)", color: "var(--color-text)", fontSize: "0.8rem", maxWidth: "100%" };
  const buttonStyle = { ...inputStyle, marginLeft: 0, cursor: "pointer" };
  return <section style={{ border: "1px solid var(--color-border)", borderRadius: "var(--radius-md)", padding: "0.75rem", marginBottom: "1rem", fontSize: "0.8rem", lineHeight: 1.5 }}>
    <button style={buttonStyle} onClick={() => opened ? setOpened(false) : void load()}>Learning matching & token controls</button>
    {opened && <>
      <p>Learning proposals only—not live routing or approval. Preview records suggestions without grouping. No tool results are sent to the comparison model.</p>
      {message && <p role="status">{message}</p>}
      {busy && <p>Loading / saving…</p>}
      {!config && !busy && <button onClick={() => void load()}>Retry matching settings</button>}
      {config && data && <fieldset disabled={busy} style={{ border: 0, padding: 0 }}>
        <label style={fieldStyle}>Assisted matching mode <select style={inputStyle} aria-label="Assisted matching mode" value={config.mode} onChange={e => change("mode", e.target.value as MatchingSettings["mode"])}>
          <option value="off">Off — deterministic only</option><option value="preview">Preview suggestions</option><option value="group">Group compatible candidates</option>
        </select></label>
        <label style={fieldStyle}>Local embedding model directory <input style={inputStyle} value={config.embedding_model_path} onChange={e => change("embedding_model_path", e.target.value)} /></label>
        <label style={fieldStyle}>Embedding model revision <input style={inputStyle} value={config.embedding_revision} onChange={e => change("embedding_revision", e.target.value)} /></label>
        <p>Optional local sentence-transformers model. Provision the semantic dependency and model on the server; no automatic downloads. Without it, semantic search is unavailable.</p>
        {([
          ["semantic_threshold", "Semantic threshold", 0.8, 1, 0.01], ["ambiguity_margin", "Ambiguity margin", 0.01, 0.5, 0.01],
          ["max_daily_calls", "Maximum comparison calls per UTC day", 0, 1000, 1], ["daily_token_budget", "Daily token reservation budget", 0, 2000000, 1],
          ["max_input_bytes", "Maximum comparison input bytes", 512, 8000, 1], ["max_output_tokens", "Maximum output tokens per comparison", 64, 512, 1],
          ["timeout_sec", "Comparison timeout seconds", 2, 30, 1], ["cache_hours", "Decision cache hours", 1, 168, 1],
        ] as const).map(([key, label, min, max, step]) => <label style={fieldStyle} key={key}>{label} <input style={inputStyle} type="number" min={min} max={max} step={step} value={config[key]} onChange={e => change(key, Number(e.target.value))} /></label>)}
        <label style={fieldStyle}><input type="checkbox" checked={config.llm_enabled} onChange={e => change("llm_enabled", e.target.checked)} /> Use one short LLM comparison for uncertain matches</label>
        <label style={fieldStyle}>Comparison model <select style={inputStyle} value={config.llm_model} onChange={e => change("llm_model", e.target.value)}>
          <option value="">Select a registered model</option>{models.map(name => <option key={name}>{name}</option>)}
        </select></label>
        <label style={fieldStyle}><input type="checkbox" checked={config.golden_verified} onChange={e => change("golden_verified", e.target.checked)} /> I verified positive and negative Golden cases before enabling assisted grouping.</label>
        {config.llm_enabled && <label style={fieldStyle}><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} /> Allow provider charges and sharing redacted prompt excerpts with the selected model. This does not approve any intent.</label>}
        <p>{data.usage.day}: {data.usage.calls} calls; {data.usage.reserved_tokens} tokens reserved; {data.usage.reported_tokens} reported tokens; {data.usage.unreported_calls} calls with unknown usage. Reservations are estimates, not billing totals.</p>
        <button style={buttonStyle} disabled={busy || (config.llm_enabled && (!consent || !models.includes(config.llm_model))) || (config.mode === "group" && !config.golden_verified)} onClick={() => void save()}>Save matching controls</button>
      </fieldset>}
    </>}
  </section>;
}
