# Learning Candidates: single approval and bounded matching — v1

## What changed

Learning Candidates now provides one complete review package and one **Approve & Publish** action. It contains the intent, matching examples, agent scope, exact Tool Registry connections, workflow/dependencies, parameter bindings, action contracts and response settings. Unchanged action versions are reused. New actions and an optional reviewed Golden suite are saved in the same transaction as the intent and its revision. Response configuration remains part of the versioned intent; this feature does not add a separate response-template registry.

The existing admin role and SSO implementation are unchanged. The comparison model cannot approve candidates, run tools, grant access or change a live intent.

## End-user review

1. Open **Admin → Intent Control → Learning Candidates → Review**.
2. Check every observed connection and step. Inspect the intent JSON, including `parameter_config_json`, `workflow_json`, `response_mode`, `response_template` and `response_options_json`.
3. Review proposed action contracts. Keep only contracts used by the workflow. Unresolved mappings must be corrected; missing connections are never guessed.
4. Select an existing reviewed Golden suite, or check **Include a new Golden suite in this same approval**. Supply synthetic cases with independently reviewed expected routing, calls, arguments, dependencies and responses. The expectation checkbox is part of the review, not a second publication approval.
5. Click **Validate complete package**. This executes the real approval validation path in a rolled-back database savepoint. It cannot call a real tool or LLM and publishes nothing. New direct action contracts require passing Golden tests. Explicitly acknowledged legacy LLM execution is not certified as zero-LLM execution.
6. Click **Approve & Publish** once. The backend revalidates the package and commits all related records together. A failure rolls everything back. Edits invalidate the displayed validation result; changed candidates, tool contracts, assignments, action dependencies or intent versions require reopening the review.

Golden expectations should include changed parameter values, paraphrases, negative requests, authorization failures, missing inputs and multi-step dependency failures. A PASS covers those test cases, not all possible prompts.

## Learning matching and token controls

Open **Learning matching & token controls** on the same page.

- Deterministic exact/declared-parameter and lexical matching always runs first. Polite wording no longer creates a different operation signature. Only schema-declared parameter values are masked; host names are not blindly erased.
- Different agents, exact connections, plan identities, operations, filters, negation and aggregation remain distinct. Assisted matching requires a nonempty compatible captured plan. Similarity is not permission or correctness probability.
- **Off:** deterministic matching only.
- **Preview** (default): optional semantic/LLM comparisons record suggestions but do not apply those suggestions to grouping or intent updates.
- **Group:** apply compatible suggestions to pending candidates or reviewed-next-version proposals. The administrator must attest to positive and negative Golden checks. This attestation is not an automated statistical proof of semantic accuracy. Human intent publication approval still applies.
- Optional semantic search uses a provisioned **local** sentence-transformers model. Set its absolute server directory and a revision label. Change the revision whenever model files change. No automatic model downloads and no remote model code are enabled. Missing package/model or a busy worker leaves the case for review (or the separately enabled bounded LLM comparison).
- Optional LLM comparisons are **off by default**. Select an active registered model and acknowledge provider costs/prompt sharing to enable them. The payload contains only a redacted, parameterized request and up to three compatible candidate examples/identities, not SQL results or complete conversation history. Redaction is best-effort, not a general DLP guarantee; follow your organization's data policy.
- At most **one short comparison attempt per new observation**. Exact/clear matches do not call the comparison LLM. Cached decisions skip the provider. Cache keys include algorithm/settings/model version, source agent, route, workflow/dependency identity and compared text; entries expire. This cache contains decision metadata, not business answers.
- Default caps: 20 calls per UTC day, 40,000 token-reservation units/day, 2,400 input bytes, 192 output tokens, 15-second provider timeout and 24-hour decision cache. These are configurable global limits across agents/workers using this database, not per-user budgets.
- A reservation is committed before contacting the provider and is not refunded when learning fails or the provider times out. Actual reported tokens and unknown-usage calls are shown separately. Byte-based reservations are conservative estimates, not provider billing guarantees. Provider SDK internal retries/billing remain provider-dependent.
- Limits exhausted, oversized input, disabled model, ambiguous comparison or provider failure leave a separate pending proposal for manual review. They never enable an unbounded fallback.

This release improves **learning-time grouping**. It does not replace the approved-intent runtime resolver with embedding/LLM routing and does not bulk-merge existing candidates. Existing runtime rules still fetch fresh data and enforce their own access and execution policies.

## Installation and deployment

Deploy backend and frontend together: the approval API now requires the review snapshot token returned by `GET /api/intent-learning/{id}/review`. Older clients must be rebuilt.

From the project root, using the deployment's existing Python environment:

```bash
python -m alembic -c backend/migrations/alembic.ini upgrade head
cd frontend
npm ci
npm run build
```

Migration `033_learning_review_matching` follows `032_intent_validation`. It only adds `intent_learning_match_cache` and `intent_learning_match_budget`. Settings use the existing environment-scoped `configuration` table. No business tables, credentials or SSO files are altered. For a Claude-merged/OCP repository, map these changes to its actual modules and migration head; do not blindly replace deployment or authentication code.

Optional semantic dependency: install the `semantic` extra using your approved package mirror/build process, and provision a trusted, pinned model directory in the container/VM. The default application works without this optional dependency. No embedding package or model was downloaded during implementation. API reference: [SentenceTransformer local-only loading](https://sbert.net/docs/package_reference/sentence_transformer/model.html).

Restart/redeploy through your existing application process or OCP rollout procedure. Start in Preview with paid comparisons disabled; enable a model only after validating credentials, data policy and budgets in your environment.

## API summary

- `GET/PUT /api/intent-learning/matching/settings`: validated environment settings and current-day usage. Enabling model calls requires `allow_provider_calls: true`.
- `GET /api/intent-learning/{id}/review`: candidate plus opaque `review_token`.
- `POST /api/intent-learning/{id}/validate`: same payload as approval, rolled back.
- `POST /api/intent-learning/{id}/approve`: `expected_review_token`, reviewed `rule`, `actions`, optional `golden_suite_id` **or** inline `golden_suite`, `allow_llm_execution` and `note`.

These routes retain the existing admin-role guard. Tokens are review fingerprints, not credentials. A stale review returns 409; invalid contracts/Golden results return 422. Inline Golden versions are immutable and cannot overwrite a saved suite version.

## Source map for a Claude merge

- `backend/services/intent_learning.py`: deterministic grouping, bounded assisted suggestions, package approval integration.
- `backend/services/intent_learning_matching.py`: redaction, lexical guards, optional local embeddings, provider adapter and durable budget/cache logic.
- `backend/services/intent_learning_review.py`: stale-review fingerprint and rollback-only validation.
- `backend/schemas/intent_learning.py`, `intent_matching.py`: review and matching request contracts.
- `backend/routers/intent_learning.py`: admin settings, review, validate and one-approval routes.
- `backend/models/intent_matching.py`, `backend/models/__init__.py`, migration 033: additive comparison metadata tables.
- `frontend/src/components/dashboard/IntentLearningCandidates.tsx`: unified review, inline Golden option, validation gate and one publication button.
- `frontend/src/components/dashboard/IntentLearningMatchingSettings.tsx`: provider consent, model selection, preview/group controls and limits.
- `frontend/src/components/dashboard/IntentControlManager.tsx`: labels the entry tab Learning Candidates consistently.
- `pyproject.toml`: optional semantic dependency only.
- Associated backend/frontend tests exercise deterministic/semantic/LLM suggestions, unsafe matches, strict model output, budget/cache behavior, stale review, combined publication and rollback.

Preserve the target repository's existing SSO, API client, deployment manifests, model credential loading, environment files and business connectors. Verify both backend contracts and the rebuilt frontend. Mocked adapter tests establish protocol behavior; they are not a live Claude Sonnet or OCP certification.

## Verification on the local reference application (2026-09-29)

- 161 selected backend regression tests passed, including isolated PostgreSQL tests for combined publication, failed Golden rollback, stale connection/candidate reviews and durable budget reservations.
- 21 frontend tests passed; production TypeScript/Vite build passed. The existing large-bundle warning remains (main bundle about 708 kB before gzip).
- Focused Ruff/ESLint checks and `git diff --check` passed.
- Migration 033 applied to the local database. Backend health and frontend returned healthy/HTTP 200.
- Browser inspection confirmed the Learning Candidates tab, matching controls, Preview default, 0 comparison calls and disabled LLM assistance. The local database had no pending candidates; the approval interaction was covered by component and isolated database tests rather than approval of customer records.
- No paid provider calls or live business tool executions were used. Real embedding-model quality, customer Golden suites, OCP deployment and live Claude Sonnet comparisons remain environment-specific verification work.
- No commit, push or ZIP release was made for this change.

## Rollback

Disable assisted matching first. Restore the prior backend/frontend code together while keeping the additive tables. Do not downgrade the database merely to undo UI code: migration downgrade deletes comparison usage/cache records and does not undo already approved intents/actions. Restore intent behavior through reviewed version history, with a database backup appropriate to your deployment.
