# Intent Control + Golden validation — v1 operator guide

Updated 2026-09-28. This is an additive update to the existing Intent Control v2 implementation, not a replacement for your application. Existing documentation and SSO are preserved.

## What changed

- Observed tool/agent aliases resolve to exact registered names only when unambiguous. Unknown calls remain visible and prevent partial direct replay. Permission checks still use exact registered identities.
- Learning proposes credential-free draft Action Templates and captures every observed call and dependency. An administrator must review and publish them. SQL literals or unextractable inputs need manual mapping; they are not silently frozen as reusable defaults.
- Combined approval publishes reviewed actions and the intent in one database transaction. New action publication requires a passing reviewed Golden suite. Failure rolls both back.
- Strict direct intents pin action versions and prohibit agent fallback/LLM summaries. Missing actions/connections return `unavailable`, not an unexpected LLM call. Intent evaluation or communication-policy outages now block execution instead of failing open.
- Golden Tests is a tab inside Intent Control. Model Compatibility is a separate Admin sidebar page at `/dashboard/model-compatibility`. Both use the same reviewed suites, with separate run histories.
- Intent revisions preserve full configuration snapshots and diffs. Restoring a revision creates a pending Learning Queue proposal; the currently active intent is unchanged until approval.
- Delete candidate removes only that candidate. Published intent/action records and audit history remain. A similar future request can be learned again. Deleting a rule preserves its revision history; disabling it through the existing lifecycle selector is the reversible alternative.
- Optional model comparison calls registered models against synthetic tool fixtures. It bypasses intent matching so a no-LLM match cannot masquerade as a model test. It never switches the live model automatically.

## End-user workflow

1. Register/enable the required tool in Tool Manager and assign it to the correct agent. Its exact registry name is the connection reference. Keep credentials in the existing encrypted Tool Registry; do not paste them into prompts, SQL, actions or tests.
2. Enable Intent Control for the agent. Make a normal request. A successful unmatched execution may create a pending learning candidate with its observed calls.
3. Open Intent Control > Learning Queue > Review. Check each agent, tool, call ID, dependencies and mappings. A connection reference is captured from execution, not invented from the prompt.
4. Review the rule JSON and proposed action-contract JSON. Draft suggestions are not automatically published. Each action in the approval list must actually be referenced by the proposed workflow. Remove unused draft suggestions, or finish their workflow mappings.
5. Create a Golden suite under Intent Control > Golden Tests. Use synthetic examples with independently reviewed expected outcomes; do not copy actual model responses into expected results without review. Add positive variations, missing-parameter cases, unrelated prompts, competing-rule cases, access-denied cases and multi-tool dependencies.
6. Select that saved suite in the candidate review. Click **Simulate proposal — no real tools or LLM**. Inspect PASS / REVIEW / FAIL, exact argument differences and the resolved action snapshots.
7. Approve manually. Approval reruns the suite against current rules, tool assignment and policies, so a previous green result is not a reusable bypass. Actions and the intent commit together only after checks succeed.
8. Repeat a supported prompt with a different resource value. Direct execution reads fresh tool results. It does not replay saved database rows or old responses.

If mappings are incomplete, leave the proposal pending, or deliberately enable **Allow LLM execution**. That checkbox does NOT make it a zero-LLM intent. A Golden simulation requiring an LLM is REVIEW, not PASS.

## SQL mapping example (adapt to your actual registered tool)

The tool must already support bound parameters; the platform does not invent a SQL driver or rewrite arbitrary SQL. A reviewed action might contain:

```json
{
  "name": "backup.by-server",
  "version": 1,
  "tool_name": "YOUR_REGISTERED_SQL_TOOL",
  "template_type": "sql",
  "execution_mode": "direct",
  "template_text": "SELECT status FROM backup_jobs WHERE server = :server",
  "payload_template_json": {"parameters": {"server": "{{server}}"}},
  "input_schema_json": {"type":"object","properties":{"server":{"type":"string","pattern":"^[A-Za-z0-9_-]+$"}},"required":["server"]},
  "execution_options_json": {"text_argument":"sql"},
  "policy_json": {"risk_classification":"read_only","allowed_agents":["YOUR_AGENT"]},
  "lifecycle_status": "draft"
}
```

Use the tool's real argument names and SQL dialect. `:server` works only if that connector binds it. Never replace it with raw string interpolation. Use a least-privilege, read-only database credential. Existing SQL validation is defense-in-depth, not a complete SQL parser/security boundary.

Store SQL/action contracts in `action_template`; intent workflows and parameter mappings live in `intent_rule`. Credentials/endpoints stay in `tool_registry`. Each workflow step pins `action_template` to `name@version` and `connection_ref` to the tool name. A workflow can have multiple steps using the same or different tools, with separate queries and data dependencies.

## Golden suite format

The following is an example, not an expected result for your environment. Replace every identifier/argument with your independently reviewed contract before saving:

```json
{
  "name":"backup-golden",
  "version":1,
  "expectations_reviewed":true,
  "cases":[{
    "name":"fresh server",
    "query":"Show backups for server TEST02",
    "source_agent":"backup_agent",
    "expected_decision":"route",
    "expected_intents":["backup.lookup"],
    "expected_status":"completed",
    "calls":[{
      "intent_name":"backup.lookup",
      "step_id":"call_1",
      "agent":"backup_agent",
      "tool":"YOUR_REGISTERED_SQL_TOOL",
      "action_template":"backup.by-server@1",
      "arguments":{"sql":"SELECT status FROM backup_jobs WHERE server = :server","parameters":{"server":"TEST02"}},
      "depends_on":[],
      "fixture":{"rows":[{"status":"OK"}]}
    }],
    "expected_response_contains":["OK"]
  }]
}
```

Cases execute the full matcher across eligible competing rules and the real DAG orchestrator. Only tool I/O, model I/O and execution-history writes are replaced with isolated test adapters. Tool assignment and communication policy are still checked. Exact argument types matter: `true` is not the integer `1`. Dependency order is checked, not arbitrary scheduling order between parallel steps.

PASS covers only these synthetic cases, not live API connectivity, SQL correctness on your database, or every possible paraphrase. A successful tool-workflow case for the intended rule is required to use a suite as an activation gate. A suite consisting only of no-match or expected-failure cases is insufficient.

Saved suite versions are immutable through the API. Use **Copy to next suite version** for changes. Test receipts preserve the reviewed suite, proposal and resolved action snapshots. These tables contain admin-supplied synthetic data; retention management is not included in this update.

## Runtime flags and compatibility

Optional JSON settings in `execution_options_json`:

```json
{"require_direct":true,"require_golden":true,"golden_suite_id":"SAVED_SUITE_ID"}
```

`require_direct` requires pinned direct action versions at every step, no agent fallback and no LLM summarization. Ambiguity must clarify, deny or explicitly route the best match, not fall back to an LLM. This is a per-intent setting; a genuinely unmatched prompt still follows the normal agent path, and a separate selected intent can have its own LLM policy. `require_golden` reruns the saved suite on activation/update. Existing rules retain their previous settings unless reviewed/edited; this update does not retroactively approve, rewrite or gate all old rules.

This remains a deterministic lexical/regex/example/parameter matcher. It does not guarantee arbitrary natural-language equivalence. Add reviewed examples and tests for wording that should match. JSON/CSV/REST/Ansible tools use the same registered-tool/action mechanism, but unsupported mappings need explicit contracts rather than guessed behavior.

## Claude Sonnet 4.6 as the application's model

Register the exact model ID `claude-sonnet-4-6` using your existing Model Registry and provider configuration. Then select it on the agent. No live model, credential, SSO setting or OCP deployment was switched by this patch. The inspected local registry did not already contain Sonnet 4.6.

The Claude adapter now preserves system instructions, nested JSON schemas, repeated tool-use IDs, matching result IDs and signed thinking blocks. Unpairable tool results fail explicitly rather than being assigned to another call. Usage metadata uses the ADK-supported structure and includes reported cached input tokens.

Both direct Anthropic Messages API and existing Vertex rawPredict routing were tested with mocked HTTP transport. Official protocol references:

- [Sonnet 4.6 overview](https://platform.claude.com/docs/en/models/sonnet-4-6/overview)
- [Claude tool use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)

Open **Admin > Model Compatibility** (`/dashboard/model-compatibility`). Select a saved Golden suite version, its source agent, a current model and optionally a different candidate model. The model dropdown contains active models from the existing registry. If Sonnet 4.6 is absent, register it through the normal Model Registry; this page does not create or switch models. Golden suites are still created under Intent Control > Golden Tests.

Expand **Provider call limits** to configure turns (1–10, default 4), output tokens per call (64–8192, default 2048) and the total model-call budget (1–50, default 20). The call budget is shared across both models/all cases in selection order; an exhausted budget fails remaining applicable cases, so provide enough budget for a fair comparison. Each case also has a 180-second timeout. Check the provider consent box and click **Run model comparison**. Consent resets after each run or configuration change; repeated clicks cannot queue a second paid request. Provider charges may apply.

The comparison sends the reviewed synthetic prompts, agent instructions and declared tool schemas to the selected providers. It returns fixture results only; it never imports the executable tool loader. The results table displays each model/case, status, calls, reported input/output tokens and failure/review reasons. Missing provider usage and estimated costs remain unknown (`null`); no pricing table is assumed. A provider startup failure produces a failed receipt for that model without preventing the other model from being evaluated. Raw provider exception text is not returned or saved in the receipt.

**Comparison history (no model calls)** reads saved model-comparison receipts only; it does not invoke a provider. Golden test history shows intent-simulation receipts only. No new database migration is required for this separate Admin page or history filtering beyond migration 032 from the original validation update.

Model comparison currently covers one agent's successful tool contract, not production RAG augmentation or full multi-agent model delegation. Multi-agent, routing-only, different-source-agent and expected-failure cases are marked REVIEW without initializing/calling a provider for those cases; use the intent simulator for deterministic policy/workflow tests. Dependency step IDs are scoped to their intent; calls in the same parallel model turn cannot satisfy each other's dependencies. Model comparison does not authorize live tool execution or model promotion.

## Deploy and rollback

1. Back up repository and database through your normal process. Test in a clone first. Preserve SSO and all environment secrets.
2. Review the Claude merge guide. For the exact source baseline, apply the patch only after `git apply --check` succeeds. A diverged Claude/OCP project needs semantic integration, not file overwrite.
3. In the target application's existing virtual environment, inspect Alembic history/current. Migration `032_intent_validation` follows `031_intent_call_learning` and adds only `intent_revision`, `golden_suite` and `golden_run` plus indexes/constraints. No existing tables or credentials are rewritten.
4. Run `python -m alembic -c backend/migrations/alembic.ini upgrade head` once before deploying new backend replicas. Rebase the migration onto the target's actual head if it diverged; never stamp past a missing migration.
5. Run tests below, build frontend and deploy through the existing OCP pipeline. Do not install a RHEL/systemd service in OCP. Verify health and route visibility after deployment.
6. To roll back code, deploy the previous tested backend/frontend images. Keeping the three additive tables is the safest code-only rollback. If database downgrade is necessary, first back up validation/history records, then explicitly run the revision downgrade in a maintenance window; it drops those three tables and their records. It does not undo approved changes to existing intent/action records. Review/restore those separately or restore your database backup.

Local commands:

```bash
python -m pytest tests -q
# Only against localhost PostgreSQL: creates transaction-isolated schemas and rolls them back.
INTENT_TEST_LOCAL_DB=1 python -m pytest tests -q
cd frontend
npm run test
npm run build
```

No new credential, .env file, SSO implementation or checksum file is needed. Windows/Git Bash and Linux source are the same; environment startup remains platform-specific.
