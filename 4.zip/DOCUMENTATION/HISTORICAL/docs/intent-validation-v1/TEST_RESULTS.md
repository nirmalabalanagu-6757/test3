# Verification record — 2026-09-28

- Backend: **154 passed**, including opt-in localhost PostgreSQL integration tests in rolled-back schemas.
- Frontend: **16 passed** across five test files.
- Frontend production build: passed. Existing bundle-size warning remains (main bundle exceeds 500 kB).
- Focused Ruff checks for new validation/compiler/review code: passed. Existing lint findings in legacy agent/provider modules are outside this patch's logic changes.
- Focused ESLint for changed Intent Manager and Model Compatibility components, route/menu and tests: passed.
- Migration 032: isolated upgrade/downgrade/upgrade test passed. Applied locally from 031 to 032; only three new tables added.
- Browser: separate Admin > Model Compatibility page renders; registry dropdowns and provider-limit controls load; history shows empty state; comparison is disabled without prerequisites/consent. No paid comparison or live intent approval/deletion was performed.
- Local backend `/health`: healthy, PostgreSQL healthy. Frontend `/dashboard/model-compatibility`: HTTP 200. Mode-filtered comparison history: HTTP 200. Backend restarted to load current fixes; Vite served the current frontend.

## Iterative regression testing

The initial baseline passed 140 backend and 9 frontend tests. New focused tests first reproduced seven failing cases: provider initialization aborted the comparison, raw provider exception details leaked into receipts, routing-only cases could falsely pass, other-source/expected-failure cases were evaluated incorrectly, dependency names collided across intents, and duplicate models were silently accepted. These cases passed after the fixes.

Additional coverage checks successful sequential/repeated calls, parallel dependency rejection, shared model-call limits, unknown/reported usage, per-run consent, duplicate click prevention, stale PASS removal after a failed run, registry retry, separate history filters and Admin/non-Admin UI/API authorization. Providers remain mocked/synthetic; fixture tests do not execute real tools.

## Covered scenarios

Identity alias vs collision; unresolved calls; exact connection binding; typed JSON; draft generation without captured resource defaults; bound SQL vs unsafe frozen literals; strict-direct schema checks; independent Golden review; full resolver competition; wrong arguments; communication denial; multi-agent/two-tool fresh data dependencies repeated three times; atomic approval rollback and publication; candidate deletion preserving intent/action; immutable revisions; restore proposal preserving live rule; additive migration round-trip.

Claude Sonnet 4.6 protocol tests cover direct Messages and Vertex rawPredict requests with **mocked HTTP**, configured system instructions, nested schema constraints, repeated/parallel tool IDs, result ordering, missing/ambiguous IDs, signed thinking replay and ADK usage metadata. Model-comparison tests use a **synthetic provider** with two adapter calls and fixture tool results.

## Not verified / not claimed

No paid live Anthropic/Vertex request was made. Sonnet 4.6 was not added to or selected in the live Model Registry. No real customer SQL/Skywise/CSV/Ansible tool execution, target Claude-merged repository verification or OCP deployment was performed. This does not guarantee all natural-language paraphrases match. Comparison is single-agent contract preflight, not full multi-agent model/RAG evaluation. Automatic learning suppression, retention management and provider pricing tables are not implemented in this update.
