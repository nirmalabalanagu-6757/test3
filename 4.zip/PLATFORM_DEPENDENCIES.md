# Host interfaces that must be mapped, not replaced

The archive contains the complete related feature implementation. It deliberately does not contain every unrelated module, business connector, asset, lockfile or bootstrap file in the host application. It is not expected to run by itself after extraction.

| Host interface | Required behavior | How to integrate |
|---|---|---|
| Database Base / AsyncSession / session factory | Shared ORM metadata; request transaction; independently committed comparison reservations | Map references to the target implementation. Preserve its database/tenant boundaries. |
| Environment settings | app_env and existing DB/provider settings | Preserve actual values and secret loading. No `.env` supplied. |
| require_role / current user | Real server-side admin authorization and actor identity | Use target SSO/auth middleware; never stub it in the application. Auth mocks belong only in tests. |
| Frontend apiGet/apiPost/apiPut/apiDelete | Existing authenticated API transport and error behavior | Keep target API client, base URL, cookies/tokens, CSRF and error conventions. The client implementation is excluded. |
| User model and frontend auth context | Existing identity and roles | Map type/imports; do not recreate users or local-admin sessions. |
| Tool Registry / assignments / runtime loader | Stable exact connection identity, current credentials, schema, lifecycle and authorized assignment | Keep actual connectors and records. The supplied model is a structural reference, not customer configuration. |
| Agent Registry and communication policy | Enabled/scoped agents, actual instructions, current permissions | Merge intent fields and runtime hooks. Do not broaden agent access. |
| Audit log | Append-only intended governance events | Keep target audit/retention policy. No raw credentials or business outputs in comparison diagnostics. |
| Configuration service | Environment-scoped settings persistence and audited admin updates | Reuse existing equivalent schema/service; latest release does not create a new configuration table. |
| Model Registry / adapters | Active model identifiers, existing endpoint/credential resolution, usage metadata | Keep target model management; no actual credentials or default-model change in the archive. |
| Router registration | Intent, action, learning and validation routes discoverable | Source host auto-discovers router modules. Explicitly register them if the target does not. Backend main.py is not supplied to overwrite. |
| Frontend route/nav shell | Existing admin routing and layouts | Use App.tsx / DashboardPage.tsx as integration references, preserving target wrappers and other routes. |

Shared runtime files import additional existing session, policy, notification, tool-runtime and tracing infrastructure. Inspect those imports in the target. Missing infrastructure is a gap to report, not a reason to copy an unrelated app wholesale or invent permissive shims.

## Runtime/dependency reference

The source tests used Python 3.12 and the existing Google ADK/provider stack. Broad minimum constraints in pyproject.toml do not guarantee that much older target versions support `Part.part_metadata`, `FunctionDeclaration.parameters_json_schema` or current usage objects. Inspect the target lock/dependency versions and run protocol tests. Merge only necessary dependency changes and regenerate the target's lockfile using its normal tooling; do not replace its whole dependency graph.

The optional `semantic` extra is additional; no embedding model weights are bundled. For offline OCP, obtain approved wheels and trusted pinned model files through your normal artifact process, mount the model read-only, and use the absolute path in admin settings. Do not enable network downloads inside a pod just to satisfy an import.

No automatic enablement or migration command is included as an executable helper. Use the target's deployment and change process after reviewing the plan.
