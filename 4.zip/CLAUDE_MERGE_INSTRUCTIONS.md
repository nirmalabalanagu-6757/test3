# Claude Sonnet 4.6 — full-feature integration instructions

## 1. Understand before editing

Treat this archive as a final-state reference for **the entire Intent Control feature**, including its Golden and Model Compatibility dependencies. Do not apply only the 18 latest files to an unknown earlier application. Also do not replace whole shared files simply because they appear in the ZIP.

Read the root docs in this order: START_HERE, PREVIOUS_VS_CURRENT, PLATFORM_DEPENDENCIES, FILE_CHANGE_SUMMARY, DATABASE_AND_OCP_DEPLOYMENT, TEST_PLAN_AND_RESULTS. Then inspect the actual target code and relevant reference modules/tests. Work in small phases; use the manifest rather than loading every source file into one prompt.

Produce a gap map with target paths and status: equivalent / missing / divergent / blocked. Identify the target runtime, dirty changes, migrations/schema, model/tool registries, actual execution callbacks, audit/configuration services, frontend routing and admin-role mechanism. If repository access is missing, ask for it instead of pretending to merge.

The previous baseline is 5bcc579. Current source includes tested uncommitted updates. No source commit history is required in the target, and the target does not need the older ZIPs.

## 2. Preserve platform and authorization

- No SSO, login/logout, OAuth/OIDC/SAML/session/JWT, identity-provider or authenticated API-client implementation is included for replacement. Preserve the host's implementations, middleware, wrappers, role assignments, issuer/audience checks, routes and ingress authentication.
- Shared files under INTEGRATION_REFERENCE contain feature integration points and may import host auth interfaces. Merge those feature points into the existing host, not its login/profile/app-shell implementation wholesale.
- Retain existing admin guards on APIs/pages and agent/tool/communication-policy enforcement during execution. Never add a local administrator bypass or weaken checks to pass a test.
- Preserve `.env`, secrets, encryption keys, provider identity/endpoint configuration and credential rotation. Do not print or copy actual keys into instructions, test fixtures or docs.
- Preserve unrelated edits, existing documentation and OCP manifests. No reset, force push, automatic SQL database recreation, Alembic stamp workaround, uncontrolled downgrade or deployment.
- Tests use mocks and isolated data. Do not call paid models, customer SQL/APIs/Ansible tools or promote an intent merely to verify integration. Deployment/commit/push require separate authorization.

## 3. Merge in dependency order

### Phase A — persistence and schemas

Map historical migrations 023–032 to existing target equivalents, then add the missing equivalent of 033. Migration 030 is historical provenance, not a request for new notification/auth work. Do not alter already applied revision history or invent a missing parent. Register feature models with the target's Base. Reuse target Configuration, audit, Tool/Agent/Model Registry and independent database session interfaces.

New comparison reservations must use an independently committed transaction so a later learning rollback cannot refund a charged call. Preserve the target's correct database/tenant scoping; do not accidentally reserve against a different database. The reference is an environment-scoped single-application configuration, not a ready-made tenant-isolation design.

### Phase B — complete execution and learning feature

Merge runtime intent matching, parameter extraction, action contracts, orchestration, trace capture and agent scope before UI-only changes. Preserve unique call IDs and predecessor edges for repeated/multi-tool/multi-agent calls. Arguments/results may be used transiently to learn mappings; persist structural evidence, not business response rows, credentials or prior resource values as defaults.

Use exact Tool Registry names for connection_ref. Aliases resolve only when unique. Pin action versions; validate assignments, policies and operations on approval and again at execution. Strict-direct plans must not silently fall through to an LLM on a missing connection, invalid binding or policy outage. Missing/ambiguous inputs clarify or block according to the reviewed policy.

Capture only agents with Intent Control enabled. Compare both agent scope and actual workflow identity, not prompt wording alone. Learning-time similarity is not a replacement for the approved runtime resolver.

### Phase C — single manual publication

GET the fresh `/{candidate_id}/review` snapshot. Present all intent/workflow/connection/action/parameter/risk/response choices in Learning Candidates. Existing immutable actions may be reused; proposed actions are not silently active.

POST `/{candidate_id}/validate` uses the actual approval service within a database savepoint and rolls back everything. Inline independently reviewed Golden expectations may be tested there, but neither the suite nor candidate/actions/intent may become published. No real tools/models can be called by this validation path.

POST `/{candidate_id}/approve` requires `expected_review_token`; it may include an existing `golden_suite_id` or a new `golden_suite`, not both. Revalidate all contracts, Golden requirements and current dependencies. Save the reviewed related records and candidate approval in ONE database transaction. A failure returns an appropriate error and rolls back every related write.

The only publication decision is **Approve & Publish**. Do not add separate Intent/Action/Response approval screens. The Validate button and reviewed-expectations checkbox are checks inside the same review, not extra publication approvals. Edits invalidate UI validation; backend never trusts a stale displayed PASS. Prevent duplicate submissions. Changed approved configuration follows the existing version safeguards; unchanged action contracts are reused.

Response mode/template/options remain on the intent. Do not invent a separate response registry or claim it already exists. Missing direct mappings may use explicitly acknowledged existing LLM execution, but must not be labeled zero-LLM execution or pass a direct-only Golden test falsely.

### Phase D — bounded learning matching

Keep deterministic exact/schema-parameter/lexical checks first. Fix polite-wording operation signatures without erasing meaningful filters, negation, aggregation or operational risk. Parameter masking must use schema-declared extractors; do not strip every hostname, number or changing word globally.

Optional semantic matching uses a locally provisioned model, local-only loading, no remote code and a revision-keyed bounded cache. Missing/busy models fail to manual review or the separately enabled limited comparator. Default mode is Preview, with no local model path configured.

Optional LLM comparison is off by default. Require an active registered model and explicit provider-cost/redacted-prompt-sharing consent. Send only the bounded relevant request/compatible shortlist, no business results or full conversation. Keep strict response parsing; reject unknown IDs, extra approval instructions, tool calls and ambiguous decisions. Model output cannot change access, execute tools or approve an intent.

At most one short comparison attempt per new observation. Respect input/output/time bounds and durable shared daily call/token reservations. Cache only decisions; invalidate on settings/model/source/route/plan/dependency/text changes and expiry. Do not fabricate zero usage when the provider omits it. Byte-based reservations are conservative estimates, not exact provider billing guarantees. A timeout or learning rollback must not refund a provider attempt.

Off means deterministic-only; Preview records assisted suggestions without applying them; Group applies eligible learning suggestions only after the administrator's Golden-check acknowledgment. Neither mode grants publication approval. Do not silently switch the live runtime resolver to semantic/LLM routing or bulk-merge old candidates.

### Phase E — Golden tests, Model Compatibility and Claude protocol

Retain independently reviewed, versioned Golden suites, real competing-rule resolution and real DAG validation with synthetic I/O. Keep revision/deletion/restore safeguards. Customer data must not become its own test oracle.

Retain the separate Admin Model Compatibility page and route. It uses the same saved Golden suites but a distinct comparison flow with per-run provider consent and its own bounds. Page load/history must not call providers. Unsupported multi-agent/routing-only/expected-failure cases return REVIEW rather than false PASS. Dependencies are scoped by intent and step; parallel calls cannot satisfy unfinished dependencies in the same turn. This remains single-agent successful tool-contract preflight, not complete production RAG/multi-agent certification.

Merge existing Claude adapter system-instruction, nested-schema, tool-use/result-ID, role sequencing, thinking replay and usage fixes while preserving provider authentication. Protocol mocks must pass before any separately authorized live Sonnet call. Do not automatically register a model or change the app default.

## 4. Verify, then document

Follow TEST_PLAN_AND_RESULTS. Adapt test imports/setup, not safety expectations. Run focused suites, fix failures, rerun the relevant combined suite, frontend tests and build. Test schema changes only in an isolated authorized database before proposing an actual upgrade. Verify the target admin navigation and fresh-review API contract together; old frontends without expected_review_token are not compatible with the new approval endpoint.

Keep the existing target documentation and add a versioned guide covering full workflow, previous/new behavior, each changed file, parameters/connections, Golden review, model setup/consent, budgets, database changes and OCP rollout/rollback.

## 5. Required final handoff from Claude

Report target paths changed and why, reused versus new behavior, migration mapping, exact test/build results (including skips/failures), auth/SSO preservation, optional features not enabled, and remaining environment-specific work. Separate source/mock success from live Sonnet/customer API/OCP verification. No 100% guarantee. Do not commit, push, deploy or claim those actions occurred unless the user separately requested them and tools confirm success.
