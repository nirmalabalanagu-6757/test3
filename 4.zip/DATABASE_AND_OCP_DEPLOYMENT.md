# Schema mapping, OCP rollout and rollback

This ZIP prepares source for a Claude-assisted merge. It does not modify your OCP cluster. Deploying to the actual target requires its repository, schema/migration inspection, configuration choices and authorization.

## Historical feature chain

| Source revision | Purpose |
|---|---|
| 023 | Intent rules; parent is the source platform's 022_skywise_connector_type |
| 024 | Workflow/orchestration/run records |
| 025 | Communication-policy priority |
| 026 | Action Template Registry |
| 027 | Agent intent enablement and scope |
| 028 | Learning candidates |
| 029 | Assurance/shadow support |
| 030 | Historical notification/configuration/tool-auth-type schema reconciliation; reference only, not a new v3 requirement |
| 031 | Structural observed-call learning evidence |
| 032 | Intent revisions, Golden suites and Golden receipts |
| 033 | NEW: learning comparison cache and daily budget |

The ZIP intentionally does not include all pre-023 platform migrations. Do not fabricate 022, remove down_revision, stamp a database past missing schema, replay existing columns or rewrite applied migrations. A Claude-merged target can have equivalent schema under different names. Map the actual tables/columns and migration graph first; attach only genuinely missing changes to its actual head.

If the target is equivalent through 032, latest schema changes are only:

- `intent_learning_match_cache`: digest key, decision JSON and expiration timestamp/index. No raw prompts or business rows.
- `intent_learning_match_budget`: UTC day, reserved call count, reserved token units, reported token count and unknown-usage call count.

Configuration uses the existing environment-scoped `configuration` table under key `intent_learning.matching`. No new credential encryption key or SSO configuration is introduced. If the target predates 032, the missing earlier feature schema must also be merged; copying only migration 033 is insufficient.

## Deployment sequence

1. Preserve a recoverable code version and database backup. Build/test the merge against an isolated clone/test database first. Do not rename a shared database as an improvised rollback mechanism without reviewing all consumers and connection settings.
2. Check the target Alembic current/head/history and real schema. Produce the reviewed migration mapping. Source command examples below apply only when the target uses the same paths and graph.
3. Merge backend, frontend and API schemas together. The new approval API requires `expected_review_token` from the fresh review endpoint; an old frontend will fail validation.
4. Build images using your existing pipeline. Keep OCP secrets, service accounts, routes, ingress/SSO, networking, storage and security contexts unchanged.
5. Apply the reviewed additive migration once using the authorized target migration job/procedure. Do not let every replica race to upgrade or run unsafe downgrade commands.
6. Roll out backend/frontend images together. Check backend health, frontend readiness, admin authorization, role-gated navigation, review endpoint, deterministic grouping and synthetic Golden validation.
7. Start assisted matching in Preview with LLM calls disabled. Local semantic search needs the approved optional dependency and a provisioned model directory/revision. LLM advice needs an active registered model, reviewed data policy and explicit cost consent.
8. Only after representative positive/negative Golden checks and human review should assisted Group mode or live-model testing be enabled. No automatic promotion is implemented.

Example commands from the merged project root, using that deployment's Python environment (not the Windows venv in the source workstation):

```bash
python -m alembic -c backend/migrations/alembic.ini current
python -m alembic -c backend/migrations/alembic.ini heads
# After authorization and graph/schema review:
python -m alembic -c backend/migrations/alembic.ini upgrade head
# Use the target's package manager/lockfile:
cd frontend
npm ci
npm run build
```

These are documentation examples, not a ready-to-run patch script or permission to upgrade the actual cluster.

## Rollback

Disable assisted matching before rollback. Restore compatible backend/frontend images together. Prefer retaining the additive comparison tables; old code can leave them unused. Migration 033 downgrade deletes cache/budget metadata and does not undo published intent/action changes. Migration 032 downgrade would delete Golden/revision history. Neither is a routine application rollback.

Restore an intent through the existing reviewed version/restore workflow; the previous active behavior should not be replaced by an unreviewed model suggestion. Configuration transactions are atomic, but external tool side effects are not made atomic by this release.

For incident diagnosis retain version/migration identifiers, safe application logs and test receipts. Never share raw tokens, authorization headers, SQL result rows or `.env` in the handoff.
