# Previous implementation versus this update

## Baselines: do not confuse application versions with model names

The previous reference is source commit **5bcc579ba9b2435efd9fdcdcfc85a1969af5b7d2**, which included Golden validation and the separate Model Compatibility admin page. The current snapshot includes that entire feature plus **18 uncommitted changed/new files** for single approval and bounded learning matching. It has not been committed or pushed as part of packaging.

Older desktop ZIPs, especially incremental `Intent-Control-v2-Claude-Patch` variants, may contain different subsets. Do not assume their filenames prove migration or feature parity. Compare the target repository and schema. This ZIP is independently sufficient to understand the current feature and its integration requirements.

Claude Sonnet 4.6 as a merge assistant is separate from the model selected at application runtime. This update does not change the application's default model or supply provider credentials.

## Behavior comparison

| Area | Previous reference (5bcc579) | Current full snapshot |
|---|---|---|
| Review/publication | Combined intent/action backend approval already existed. UI offered JSON review and a previously saved Golden suite. | One complete Learning Candidate review with one **Approve & Publish** button, fresh review fingerprint and a **Validate complete package** step that publishes nothing. |
| Golden suite | Saved through the separate Golden Tests workflow and selected at approval. | May also be supplied and independently reviewed inside the same package; saved atomically on publication. Existing suites remain reusable. |
| Candidate similarity | Word overlap/SequenceMatcher and a literal operation signature. `show ... backup` and `help ... backup` could get different signatures. | Consistent polite-wording handling and schema-declared parameter masking. Known operation/filter/negation/aggregation differences remain guarded. |
| Semantic search | No embedding-based candidate search in the reference learning matcher. | Optional local sentence-transformers embeddings. Clear unambiguous compatible suggestions need no comparison LLM. Requires local model provisioning. |
| LLM comparison | No LLM comparison for learning-candidate matching. | Optional bounded advice for an uncertain shortlist; strict output validation; no tool execution or approval. Disabled by default. |
| Matching controls | Fixed lexical thresholds in the learning service. | Admin controls for assisted Off/Preview/Group, semantic threshold/margin, model, provider consent, daily budget/calls, input/output bounds, timeout and cache lifetime. |
| Comparison spending | Not applicable to the old lexical matcher. | PostgreSQL shared daily reservations committed before provider calls; actual reported usage/unknown usage separate; cached decision metadata and expiry. |
| Stale review | Suggested-intent workflow version checks. | Also checks candidate contents/count, tool contracts, relevant assignments, agent state and action dependencies; stale snapshots must be reopened. |
| Frontend submission | Existing approval and Golden simulation controls. | Successful package validation is required in the UI; edits invalidate it; double-click protection; backend revalidates at publication. |
| Database additions in latest update | Tables through migration 032. | Migration 033 adds only comparison cache and daily budget tables. Settings reuse existing environment-scoped Configuration. |
| Runtime intent resolver | Governed deterministic matching, action contracts, typed bindings and direct/LLM execution choices. | Remains the same runtime approach. This update does **not** add embedding/LLM routing for approved live intents. |
| Model Compatibility | Separate admin page, reviewed Golden suites, opt-in bounded adapter comparison with synthetic tools. | Included intact in the full bundle. It is separate from the low-cost learning comparator and has its own consent/budget flow. |
| Response templates | Response mode/template/options live on the intent version. | Still stored on the intent, now reviewed/published with the package. No separate response-template registry was added. |
| SSO | Host implementation. | Unchanged and not supplied for replacement. |

## Already supported and still included

- Agent enable/disable and source-agent scope; exact registered tool connections and assignment/policy checks.
- Distinct observed call IDs, repeated calls to one tool, multi-tool/multi-agent DAGs and fresh upstream result bindings.
- Versioned Action Templates for supported SQL/JSON/API/tool contracts; direct replay only when inputs/operations are safely mapped.
- Intent revisions, deletion safeguards, review-gated restore proposals and Golden tests using the real resolver with synthetic execution.
- Claude/Vertex adapter protocol tests for system instructions, nested schemas, correlated tool-use/result IDs, signed thinking and usage reporting.

These are part of the full feature, not all newly implemented by v3.

## What does not happen automatically

- A different hostname/date alone does not authorize a new operation or a new workflow version. The runtime reuses supported approved behavior with fresh inputs. Learning proposals that actually extend configuration remain manually reviewed/versioned.
- Similarity never authorizes access or approves a candidate. Group mode may group eligible learning evidence; **you** still publish the reviewed package.
- Existing duplicate rows are not bulk-merged by migration. Ambiguous, incomplete or incompatible captures remain separate/manual-review cases.
- A Golden PASS is not a proof of every possible prompt. Group-mode Golden acknowledgment is an administrator attestation, not automatic statistical certification of embedding quality.
- The ZIP does not install an embedding model, enable paid calls, select Claude, execute customer SQL, restart OCP or modify a shared database.

## Latest changes by file

Read the first section of `FILE_CHANGE_SUMMARY.txt` for the exact 18 changed/new source paths. The rest of that file lists the complete source/reference inventory and why each file is present. `MANIFEST.json` is the machine-readable equivalent.
