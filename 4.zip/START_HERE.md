# Intent Control — complete Claude Sonnet 4.6 handoff, v3

Prepared 29 September 2026. **This ZIP contains the whole current feature, not only the latest changes. No earlier patch ZIP is required.**

It includes backend/frontend Intent Control, agent scope and workflow capture, Action Templates, Golden tests, revision history, the separate Model Compatibility page, Claude protocol support, and the latest single-approval / low-cost learning matching update.

## Give Claude these instructions first

1. Open `COPY_TO_CLAUDE_SONNET_4_6.txt` and paste it as your request to Claude.
2. Give Claude access to this extracted ZIP **and your actual target repository**. A ZIP alone does not let it modify your application.
3. Ask it to read `PREVIOUS_VS_CURRENT.md`, `CLAUDE_MERGE_INSTRUCTIONS.md` and `FILE_CHANGE_SUMMARY.txt` before editing.
4. Require the gap analysis, tested target changes and migration plan described in those documents.

If your Claude interface cannot unpack ZIP files, extract the ZIP yourself and supply the folder/files. Do not paste the entire codebase into one prompt; use the manifest to let Claude inspect relevant files in stages.

## Folder meanings

- `SOURCE_CODE/`: complete current feature modules, migrations and tests. Compare and merge; these are not automatic overwrite instructions.
- `INTEGRATION_REFERENCE/`: full shared host files showing where the feature connects. Merge only the relevant behavior into your target; never replace SSO, the app shell or unrelated runtime features.
- `PLATFORM_REFERENCE/`: existing interfaces for configuration, database, tool/model registries and governance. Reuse your target equivalents.
- `DOCUMENTATION/CURRENT/`: latest single-approval and learning-matching user guide.
- `DOCUMENTATION/HISTORICAL/`: earlier feature documentation retained for context. Root v3 instructions and current source take precedence where behavior differs.
- `HISTORICAL_MIGRATION_REFERENCE/`: source migration 030, included only to explain the original migration chain.

`MANIFEST.json` maps each archive entry to its original application path, purpose, latest change and merge action. `FILE_CHANGE_SUMMARY.txt` first lists the **18 latest changed/new files**, then all **116 included source/reference files**.

## Important boundaries

This is a **feature integration bundle for an existing application**, not a standalone runnable application or an automatic OCP deployment. SSO implementations, `.env`, real credentials, authenticated frontend API-client implementation, business records, installed dependencies, logs, build output and checksum files are absent. Imports of the host auth interfaces remain where required; implement no replacement authentication.

The model name has two separate meanings: Claude Sonnet 4.6 may **merge this code**, and the application adapter may **run a configured Claude model**. Neither happens automatically merely by uploading the ZIP. "Previous/current" in the comparison guide means **application implementation versions**, not a change of provider model.

Latest optional semantic search needs a provisioned local embedding model. Paid comparison calls are disabled by default. Preview is the default; human approval is always required for publication. There is no automatic intent approval, no cached business-answer replay, and no guarantee every prompt matches.

Source verification was rerun during packaging: 161 selected backend tests and 21 frontend tests passed; production build passed. See `TEST_PLAN_AND_RESULTS.md` for scope and limitations. The actual Claude-merged/OCP target has not been tested by this package preparation.
