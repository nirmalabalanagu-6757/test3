# Complete Intent Control + Model Compatibility — Claude Sonnet 4.6 handoff

Prepared 2026-09-28. This ZIP contains the **whole current related feature implementation**, not only the latest changes and not a patch-only delta. The earlier Desktop ZIPs are not needed to understand or merge this package.

## Contents

- `SOURCE_CODE/`: complete current Intent Control, Universal Action Templates, workflow learning/capture, agent-scoped controls, multi-agent/multi-tool orchestration, approval/versioning, Golden validation and Model Compatibility source files. Includes frontend, backend, Claude adapter, migrations, tests and feature documentation with their repository-relative paths.
- `SUPPORTING_REFERENCE/`: existing Model Registry backend/frontend and test/dependency configuration. These explain the integration interfaces. Reuse equivalent target components; do not replace target dependencies or credentials blindly.
- `CLAUDE_SONNET_4_6_MERGE_INSTRUCTIONS.md`: the integration contract for Claude, including preservation of SSO and target authorization.
- `COPY_TO_CLAUDE.txt`: a short ready-to-paste request for the model receiving this ZIP.
- `FILES_AND_ACTIONS.txt`: every included source/reference file, its purpose and expected merge action.
- `MANIFEST.json`: exact file inventory and source provenance. No checksum files.
- `DEPLOYMENT_AND_ROLLBACK.md`: migration mapping, OCP deployment and rollback cautions.
- `VERIFICATION.md`: actual local results and packaging verification, distinct from unverified target/live-provider behavior.

## What is included

1. Intent administration, matching, typed parameters, direct/template/internal/LLM response choices and per-agent access/enable controls.
2. Action Template Registry, pinned versions and exact registered-tool connection binding.
3. Per-request tool-call capture, repeated tool calls, dependencies, dynamic workflow proposals, human approval and candidate deletion.
4. Multi-agent/multi-tool execution, policy checks, learning deduplication/version proposals and assurance/shadow checks.
5. Golden suite creation, immutable test versions, synthetic workflow tests, atomic action-plus-intent approval, intent revision history and restore proposals.
6. Separate **Admin > Model Compatibility** page at `/dashboard/model-compatibility`, registry selections, per-run consent, bounded provider calls, results table and separate comparison history.
7. Claude adapter protocol fixes and mocked Claude Sonnet 4.6 compatibility tests.
8. Latest regression fixes: provider initialization isolation, safe failure receipts, intent-scoped dependency IDs, unsupported-case REVIEW classification, distinct model selections and duplicate-submission protection.

This is a complete **feature integration bundle for your existing application**, not a standalone application distribution. Keep the host project's existing database/session layer, tool runtimes, model/provider setup, audit/policy facilities, application bootstrapping, SSO and deployment configuration. Claude must map those interfaces before merging.

## How to give this to Claude

Upload this single ZIP with access to your actual project, then paste `COPY_TO_CLAUDE.txt`. Ask Claude to follow `CLAUDE_SONNET_4_6_MERGE_INSTRUCTIONS.md`. It should inspect what is already implemented, integrate missing/different behavior and test the merged target. Do not extract these source files over the project or run historical migrations blindly.

`SOURCE_CODE/` is the current reference implementation. Older v1 documentation is retained as feature background; the root merge instructions and current validation operator guide describe the latest behavior. If old prose conflicts with the current code, tests or root acceptance contract, investigate and update the target documentation rather than reintroducing historical behavior.

## Boundaries

No SSO/login/session/token-validation implementation, browser auth/API client, `.env`, actual credentials, customer records, runtime logs, build output, dependency folders or SHA-256 files are included. General integration files such as App, DashboardPage, routers and agent_runner still reference the host authentication contracts; merge only feature-related changes and preserve target auth calls.

Source HEAD was `c2c58699c39a5a5263ead65398caac8b37a1df38`, with the tested uncommitted validation/model-compatibility changes included. No Git commit/push or OCP deployment is performed by creating this ZIP. Existing Desktop ZIPs are preserved.

The instructions are written for Claude Sonnet 4.6 to integrate the code, but successful merging in your different repository is not guaranteed until Claude runs the target tests. Live Sonnet/provider behavior and your OCP environment have not been verified here.
