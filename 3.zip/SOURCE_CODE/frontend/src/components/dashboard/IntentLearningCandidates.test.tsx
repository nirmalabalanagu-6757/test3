import { act } from "react";
import { createRoot } from "react-dom/client";
import type { Root } from "react-dom/client";
import { afterEach, beforeEach, expect, it, vi } from "vitest";

import { apiDelete, apiGet, apiPost } from "../../api/client";
import IntentLearningCandidates from "./IntentLearningCandidates";

vi.mock("../../api/client", () => ({ apiDelete: vi.fn(), apiGet: vi.fn(), apiPost: vi.fn() }));

let root: Root;
let container: HTMLDivElement;

beforeEach(() => {
  vi.useFakeTimers();
  vi.stubGlobal("IS_REACT_ACT_ENVIRONMENT", true);
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.clearAllMocks();
});

async function review(direct: boolean) {
  vi.mocked(apiGet).mockResolvedValue({ candidates: [{
    id: "candidate", status: "pending", source_agent: "backup_agent", examples_json: ["Show backups"],
    observed_route_json: { backup_agent: ["backup_api"] }, proposed_execution_mode: direct ? "direct_action" : "agent_llm",
    proposed_rule_json: { name: "backup.list", workflow_version: 1 }, proposal_confidence: 0.9,
    occurrence_count: 1, last_seen_at: "2026-09-21T00:00:00Z",
    observation_json: { complete: true, direct_ready: direct, calls: [{
      id: "call_2", agent: "backup_agent", tool: "backup_api", status: "completed",
      argument_names: ["server"], depends_on: ["call_1"],
      action_template: direct ? "backup.list@1" : undefined,
      matching_actions: direct ? ["backup.list@1"] : ["backup.list@1", "backup.list@2"],
      reason: direct ? "Exact argument match to one published action" : "Multiple actions match; select the intended action during review",
    }] },
  }], suites: [] });
  await act(async () => root.render(<IntentLearningCandidates agents={["backup_agent"]} onApproved={vi.fn()} />));
  await act(async () => { await vi.runAllTimersAsync(); });
  const button = [...container.querySelectorAll("button")].find((item) => item.textContent === "Review");
  expect(button).toBeDefined();
  await act(async () => button!.click());
}

it("shows each observed call, connection, dependency and matched action during review", async () => {
  await review(true);
  expect(container.textContent).toContain("Observed tool calls");
  expect(container.textContent).toContain("call_2: backup_agent → backup_api");
  expect(container.textContent).toContain("After: call_1");
  expect(container.textContent).toContain("Action: backup.list@1");
  expect(apiPost).not.toHaveBeenCalled();
});

it("explains ambiguity without silently approving or selecting the latest action", async () => {
  await review(false);
  expect(container.textContent).toContain("Action: Review required");
  expect(container.textContent).toContain("Matching actions: backup.list@1, backup.list@2");
  expect(container.textContent).toContain("Some calls need review before direct execution is possible");
  expect(apiPost).not.toHaveBeenCalled();
});

it("requires explicit LLM acknowledgement and includes reviewed actions in approval", async () => {
  await review(false);
  const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!;
  expect(checkbox.checked).toBe(false);
  await act(async () => checkbox.click());
  const approve = [...container.querySelectorAll("button")].find(item => item.textContent === "Approve and activate")!;
  await act(async () => approve.click());
  expect(apiPost).toHaveBeenCalledWith("/intent-learning/candidate/approve", expect.objectContaining({ allow_llm_execution: true, actions: [], golden_suite_id: null }));
});

it("confirms candidate deletion without requesting intent or action deletion", async () => {
  await review(true);
  vi.spyOn(window, "confirm").mockReturnValue(true);
  const remove = [...container.querySelectorAll("button")].find(item => item.textContent === "Delete candidate")!;
  await act(async () => remove.click());
  expect(apiDelete).toHaveBeenCalledExactlyOnceWith("/intent-learning/candidate");
  expect(apiPost).not.toHaveBeenCalled();
});
