# Claude Sonnet 4.6 — full-feature semantic merge instructions

## Objective

Integrate the entire Intent Control and Model Compatibility feature set into the user's existing application using `SOURCE_CODE/` as the final-state reference. This is not only the last commit or a sequence of patches. Earlier user ZIPs are not required. Preserve existing functionality already equivalent to this reference.

The code also supports using `claude-sonnet-4-6` as an application model through the existing Anthropic/Vertex adapter. That runtime capability is separate from using Claude to merge the bundle. Do not substitute a different model or automatically register/select a live provider.

## 1. Inventory before edits

Read target repository instructions; inspect dirty files, branches, runtime versions, model/tool registries, migrations, existing intent features, frontend routing, roles and tests. Never print environment secrets. Produce a gap map: present/equivalent, missing, divergent or blocked.

Map the source imports to the target's real services. In particular, identify equivalents of database/session/Base, `require_role`/`get_current_user`, the authenticated frontend API client, User/ToolRegistry/ToolAgentAssignment/AgentRegistry/LlmModelRegistry, audit logs, communication policy, tool loader, agent callbacks and model adapters. These shared platform services are dependencies, not permission to replace the platform. Some registry/dependency examples are in `SUPPORTING_REFERENCE/`.

Read all relevant current source and tests before deciding merge actions. Source files are complete examples, not overwrite instructions. Use the root file manifest to locate frontend/backend pieces. Do not assume the target has the source commit history.

## 2. Non-negotiable boundaries

- Preserve SSO, login/logout, OIDC/SAML/OAuth/session/JWT verification, identity provider configuration, role assignment, auth middleware, ingress authentication and secrets. Do not add a local-admin bypass. SSO implementations and the source API client are deliberately absent.
- Merge feature route/menu/UI hunks into App.tsx and DashboardPage.tsx without removing target auth wrappers. New pages and backend APIs must use the target's established Admin authorization.
- Preserve the target's current `.env`, encrypted credentials, provider endpoint/identity mechanisms and existing documentation. Never copy source credential values or return keys in registry responses.
- Preserve unrelated user changes. No reset --hard, force push, wholesale source overwrite, Alembic stamp workaround, table/database recreation or automatic downgrade.
- No paid provider calls, live customer APIs/SQL/Ansible actions, database upgrades or deployment during ordinary tests. Use mocks and isolated test data. Commit, push and deploy only if separately authorized.
- Do not add an arbitrary universal row cap, automatic approval, automatic model promotion or cached business-answer replay.

## 3. Integration sequence

### Database, schemas and feature services

Map migrations 023–032 to existing target equivalents; do not rerun migrations already applied. Preserve historical revision IDs and rebase only new equivalent migrations onto the actual target head when needed. Migration 032 adds intent_revision, golden_suite and golden_run. See the deployment guide for the historical migration 030 dependency and rollback risks.

Register feature ORM models, API schemas and routers through the existing application startup. The source app auto-discovers routers; explicitly register `intents`, `action_templates`, `intent_learning` and `intent_validation` if the target does not. Keep the target session and authorization helpers.

Merge exact-first/unambiguous identity resolution, typed parameter extraction, safe workflow bindings, immutable Action Templates, agent scope, communication-policy checks, orchestration, trace capture, learning/deduplication, approval and versioning. Wire actual request/callback events into trace capture and pass complete traces into learning; simply storing tool names is not enough.

### Learning and execution contract

Capture separate call IDs, exact registered agent/tool identities, arguments/results transiently and predecessor relationships. Concurrent requests must not share traces. Persist only the intended structural observation evidence, not raw business rows, credentials or captured values as reusable defaults.

Compile only complete, successful and unambiguous observed workflows. Preserve repeated calls to the same tool. Use current prompt parameters and fresh upstream output mappings. Missing/ambiguous/unextractable mappings remain review-required, not guessed.

Draft Action Templates are proposals. Publish reviewed actions and activate the intent atomically only after validation. New action publication requires a passing independently reviewed Golden suite. Any failure rolls back actions, intent and candidate approval together. Existing rules are not silently rewritten or retroactively approved.

Strict-direct plans pin action versions and registered connections, reject missing/deactivated/mismatched bindings and do not silently fall through to an LLM. Agent/policy evaluation outages block execution. Genuinely unmatched prompts still follow the target's normal configured agent path; do not claim every wording matches without tests.

Preserve version proposals and stale-version checks. Candidate deletion does not delete published actions/intents. Intent revisions survive rule deletion. Restore creates a pending approval proposal; it does not replace the active version immediately. Do not remove stronger current Golden gates on restore.

### Golden tests and frontend

Keep reviewed test expectations independent of actual model output. Golden suites have immutable versions. The simulator must use the real resolver across competing rules and real workflow/DAG execution with only synthetic I/O. Enforce assignments, policy, exact argument types, dependencies and action versions. Never invoke real tool runtimes or providers from simulation. A case requiring model execution is REVIEW, not a false PASS.

Integrate the complete Intent Control page, Action Template Registry, agent enable/scope controls, Learning Queue review, Golden Tests and revision history. Preserve existing user-facing documentation.

Add a separate **Admin > Model Compatibility** sidebar item and `/dashboard/model-compatibility` route. Golden suite authoring stays under Intent Control; both use the same suites. Compare only active registered models, with optional distinct candidate and selected source agent. Require fresh paid-call consent for each run; reset consent on configuration changes and prevent duplicate submissions.

Show bounded-call settings, per-case result table, unknown usage as unknown, safe errors and comparison-only history. Intent simulation history must not mix with provider comparison receipts. Loading the page, refreshing registries or viewing history must never call a provider.

### Provider comparison and Claude protocol

Model comparison bypasses deterministic intent execution and actually calls the selected adapter, but supplies synthetic tool fixtures only. Never import or execute the real tool runtime. Keep model calls/turns/output tokens/time bounded. An unavailable provider must not prevent the other selected model from being evaluated. Do not expose raw provider exception bodies or fabricate zero usage/cost.

Dependencies are scoped by (intent_name, step_id), and calls in one parallel provider turn cannot satisfy each other's unfinished dependencies. Routing-only, other-source-agent, multi-agent and expected-failure cases currently return REVIEW without provider initialization. This is single-agent successful tool-contract preflight, not full production RAG/multi-agent/provider certification.

Merge Claude adapter protocol fixes: system instructions, nested tool schemas, distinct tool-use IDs and matching tool-result IDs, consecutive message roles, signed thinking/redacted-thinking replay, and valid ADK usage metadata. Preserve target provider authentication. Missing or ambiguous tool-result pairing must fail, not attach a result to the wrong call.

## 4. Iterative acceptance tests

Use the supplied tests as contracts and adapt setup/imports to target architecture. Do not delete assertions, skip governance checks or add hard-coded agent names just to turn tests green. Run focused tests, fix defects, rerun the full relevant suite, build, then perform authorized UI/health checks.

Prove at least:

1. Exact bindings survive aliases only when unique; unknown or ambiguous tools block direct compilation/execution.
2. One tool called twice remains two calls. Multi-tool/multi-agent dependencies use fresh results, not previous stored rows.
3. Different values in similar supported prompts produce current validated arguments. Missing/invalid/ambiguous inputs clarify. Optional inputs remain optional.
4. Disabled/scoped agents, changed assignments, blocked policies and runtime failures cannot bypass governance or silently invoke an LLM for a strict-direct rule.
5. Similar compatible candidates update the reviewed intent version without duplicate uncontrolled activation; stale approvals fail.
6. Failed Golden approval leaves no published action/active intent; successful combined approval commits all related records. Wrong arguments, competing intents and dependencies fail.
7. Candidate deletion preserves actions/intents; restore leaves the live rule unchanged; suite versions and intent revisions are retained.
8. Claude system/schema/tool-ID/thinking/usage protocol tests pass with mocked direct Anthropic and Vertex transports.
9. Comparison isolates startup failures, rejects duplicate models, respects budgets and dependency scope, skips unsupported cases and does not store raw provider error details.
10. Both backend and frontend reject non-Admin access. Page load/history cannot charge; consent is per run; double-click creates one request; a failed new test clears any old displayed PASS.
11. Migration upgrade/downgrade/re-upgrade works only in an isolated disposable test database. Do not claim target migration compatibility without examining its actual graph.

Source verification used Python 3.12, google-adk 2.7.1, google-genai 2.18.1, httpx 0.28.1 and pydantic 2.13.4. Check target APIs including Part.part_metadata, FunctionDeclaration.parameters_json_schema and usage metadata. The source's broad minimum dependency versions are not a guarantee for old targets. Do not silently upgrade the whole stack.

## 5. Required handoff

Report the gap map, each changed target file and why, target migration graph/equivalents, exact test/build results, skipped tests, SSO preservation evidence, provider-call disclosure, deployment/rollback plan and unresolved differences. Do not claim 100% compatibility, universal prompt matching, live SQL correctness, live Sonnet success or successful OCP deployment based on source mocks.

This bundle is complete for understanding the feature code, but it is intentionally not a replacement for the target application or its SSO/platform dependencies.
