# Database and OCP deployment guidance

Do not deploy by copying SOURCE_CODE over the application. First merge into a recoverable branch/clone and validate against an isolated database. Preserve current environment secrets and SSO. This bundle contains no auto-apply or auto-upgrade script.

## Migration inventory

The source feature's historical chain is included so Claude can map existing functionality:

| Revision | Purpose |
|---|---|
| 023 | Intent Control schema |
| 024 | Multi-agent/workflow orchestration fields and run storage |
| 025 | Communication policy priority |
| 026 | Universal Action Template Registry |
| 027 | Agent-level intent control and scope |
| 028 | Learning candidate storage |
| 029 | Assurance/shadow/testing support |
| 030 | Historical schema reconciliation: notification subscriptions, configuration.is_secret and wider tool auth_type |
| 031 | Structural observed-call evidence on learning candidates |
| 032 | Intent revisions, Golden suites and Golden evaluation receipts |

The parent of 023 already exists in the source application; earlier platform schema is not a new feature migration. A target may already have these tables/columns under different revision names. Inspect `alembic current`, `heads`, `history` and the real schema. Do not reuse conflicting IDs, repeat existing columns, fabricate missing parents or stamp past missing migrations.

Migration 030 is included because it is a historical parent, not because a model comparison requires new notification behavior. If the target migration chain differs, implement only the missing equivalent feature schema attached to the target's actual head. Existing migration history must not be rewritten. Keep any existing model/registry migrations and credential storage.

For a target already equivalent through 031, only the equivalent of 032 is new. Moving Model Compatibility to its separate Admin page and filtering history requires no additional table change beyond 032.

## Deployment procedure (requires target authorization)

1. Back up code and database; test the merge and migration in a clone first.
2. Use the application's approved Python runtime and frontend build pipeline. Do not overwrite dependency lockfiles from SUPPORTING_REFERENCE.
3. Run the target tests and frontend production build. Check Admin access, existing login/SSO and normal agent/tool operation with approved test sessions.
4. Execute the approved Alembic upgrade once in a controlled OCP migration job before new backend replicas start. Do not let competing replicas independently run upgrades.
5. Deploy the tested backend/frontend images through the existing OCP pipeline. Preserve Secrets, ConfigMaps, service accounts, ingress and routes.
6. Verify health, `/dashboard/intents`, `/dashboard/model-compatibility`, suite APIs and history. No provider call should occur merely by opening these pages.
7. If live provider testing is separately approved, register the exact intended model using the existing registry, create a reviewed synthetic suite, set a small call budget, explicitly consent and inspect receipts. A mock PASS is not a live provider PASS.

## Rollback

Prefer code-only rollback to known-good images while retaining additive validation tables. New approved rules/action versions may not be executable by older code; review/disable/restore incompatible rules before rolling back the runtime. Restoring code alone does not undo approved intent/action changes.

Migration 032 downgrade deletes intent revision, Golden suite and Golden run data. Historical downgrades can remove other feature data. Never downgrade automatically. Back up affected records first and obtain explicit approval for a maintenance-window downgrade or database restore. Restoring an intent revision in the UI creates a proposal; it is not a database rollback.

## Local test commands (after integration)

```bash
python -m pytest tests -q
# Only an approved localhost PostgreSQL test setup; schema changes are rolled back.
INTENT_TEST_LOCAL_DB=1 python -m pytest tests -q
cd frontend
npm run test
npm run build
```

Source tests use mocked providers and synthetic tools. No script in this ZIP starts services, changes a live database, switches a model or deploys to OCP.
