# Intent Control Administrator Guide

## Purpose

Intent Control is a separate **Admin** panel for maintaining deterministic
routing rules. Rules are evaluated before the LLM Concierge. A controlled match
can route directly to a running specialist agent without spending tokens on an
LLM routing decision. If no rule matches, the existing Concierge behavior is
preserved.

Open **Dashboard → Admin → Intent Control**.

## Panel areas

### Rules

Lists every configured intent and shows its matching method, target agent,
confidence threshold, governance classification, response mode, and state.
Administrators can create, edit, enable/disable, search, and delete rules.

### Test Resolution

Runs the deterministic resolver without calling an LLM or invoking a tool. Use
it to verify confidence, extracted parameters, ambiguity behavior, and the
selected agent before enabling a rule.

### Import / Export

Exports a versioned JSON document and imports it on another deployment. Import
can reject duplicate names or update existing rules. Agent and tool references
are validated on import.

## Rule options

### Identity and lifecycle

- **Intent identifier:** Stable identifier such as `incident.search`.
- **Display name:** Human-friendly label.
- **Description:** Administrator notes and purpose.
- **Enabled:** Disabled rules are ignored immediately.
- **Priority:** Tie-breaker when matching confidence is equal.

### Matching

- **Hybrid:** Uses exact, keyword, regex, and example matching together.
- **Exact:** Requires a normalized exact keyword/example match.
- **Keywords:** Matches configured words or phrases.
- **Regular expression:** Uses administrator-defined Python-compatible regex.
- **Examples:** Uses deterministic lexical similarity; it does not call an LLM.
- **Keyword mode:** Require any or all positive keywords.
- **Negative keywords:** Exclude a rule when any configured negative term is
  present.
- **Minimum confidence:** A rule below its own threshold is not selected.
- **Ambiguity margin:** Treat the top two matches as ambiguous when their score
  difference is within this margin.

Ambiguity actions are:

- **Use LLM Concierge:** Preserve normal LLM routing.
- **Ask for clarification:** Return a choice between the leading intents.
- **Use fallback agent:** Route to the configured fallback.
- **Route best match:** Select the highest score despite the close result.
- **Deny:** Block the request.

### Routing and governance

- **Target agent:** Must reference a registered specialized agent. At runtime it
  must be in the `running` state.
- **Fallback agent:** Used when configured for ambiguity or when the target is
  unavailable.
- **Tool allowlist:** Restricts the selected agent to a subset of its active,
  assigned tools. An empty list retains all of that agent's assigned tools.
- **Risk:** `read_only`, `write`, or `execute`.
- **Require confirmation:** Stops the route and returns a confirmation request
  until the resolver receives `confirmed=true`.

Intent Control does not bypass Tool Governance. A tool must still be active and
assigned to the selected agent.

### Parameter extraction

Parameter configuration is JSON. Values supplied explicitly to the resolve API
take precedence. Otherwise, regex capture groups extract values from the user
request. Defaults are applied last.

```json
{
  "required": ["application_code"],
  "properties": {
    "application_code": {
      "type": "string",
      "pattern": "application\\s+([A-Za-z0-9_-]+)",
      "prompt": "What is the application code?"
    },
    "row_limit": {
      "type": "integer",
      "pattern": "(?:limit|rows?)\\s+(\\d+)",
      "default": 100
    }
  }
}
```

Supported coercion types are `string`, `integer`, `number`, and `boolean`. If a
required value is missing, the user receives the configured prompt and routing
does not continue.

### Response policy

Response behavior is maintained per intent rather than hard-coded globally:

- `auto`
- `direct`
- `template`
- `internal_summary`
- `llm_summary`
- `detailed`

The selected mode, template, options, and extracted parameters are passed into
the governed target agent's instruction. `response_options_json` can hold
connector-specific options such as format, columns, grouping, metrics, sorting,
or limits. There is no mandatory 1,000-row limit; administrators configure any
limits needed for the intent and target system.

Example options:

```json
{
  "format": "table",
  "group_by": ["status"],
  "metrics": [{"field": "incident_id", "operation": "count"}],
  "sort": [{"field": "count", "direction": "desc"}],
  "max_rows": 250
}
```

## Recommended rollout

1. Register and start the target specialist agent.
2. Register and assign the tools the agent may use.
3. Create the intent in a disabled state.
4. Test positive, negative, ambiguous, and missing-parameter queries.
5. Confirm the confidence threshold and tool allowlist.
6. Enable the intent.
7. Review `delegation`, `interaction`, and `config_change` events in Audit Log.

Start with high-confidence operational intents. Leave `llm_fallback` enabled for
unmatched requests until deterministic coverage is proven.
