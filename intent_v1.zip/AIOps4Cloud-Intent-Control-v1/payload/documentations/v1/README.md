# AIOps4Cloud v1 Administration Documentation

- [Intent Control administrator guide](intent-control-admin.md)
- [Intent Control architecture and API](intent-control-architecture.md)

These documents describe the database-driven Intent Control feature introduced
by migration `023_intent_control`. Existing authentication code is not
changed by this feature.
