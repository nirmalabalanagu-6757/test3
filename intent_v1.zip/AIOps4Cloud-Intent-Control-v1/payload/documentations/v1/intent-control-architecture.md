# Intent Control Architecture and API

## Runtime architecture

```text
Chat WebSocket
    |
    v
ChatService / AgentRunner
    |
    v
IntentControlService (PostgreSQL intent_rule)
    |-- exact / keyword / regex / example score
    |-- negative-term exclusion
    |-- confidence + ambiguity policy
    |-- parameter extraction
    |-- target availability
    |-- confirmation / risk metadata
    |
    |-- route ----------> Specialist Agent
    |                         |
    |                         v
    |                   Intent tool allowlist
    |                         |
    |                         v
    |                   Existing Tool Governance
    |
    |-- clarify/deny --> Deterministic response
    |
    `-- no match / LLM fallback --> Existing ADK Concierge

Every configuration and runtime decision --> Existing Audit Log
```

This is a hybrid design. It does not replace the Concierge, agent registry,
communication policy, tool registry, assignment checks, or credential handling.
It adds a deterministic control plane before the existing LLM routing plane.

## Database

Migration `023_intent_control` creates `intent_rule`. It does not alter or remove
existing agent, tool, policy, or user tables.

Important JSON columns keep the feature tool-agnostic:

- `keywords_json`
- `negative_keywords_json`
- `regex_patterns_json`
- `examples_json`
- `allowed_tools_json`
- `parameter_config_json`
- `response_options_json`

The table stores configuration only. API, CSV, JSON, or SQL business results are
not persisted by Intent Control.

## Matching scores

- Exact normalized match: `1.00`
- Regex match: `0.97`
- Keyword match: `0.55 + 0.40 × coverage`, capped at `0.95`
- Example similarity: deterministic token/sequence similarity, capped at `0.90`

The highest method score is used. Priority breaks equal scores. A rule must meet
its own `min_confidence`. Negative terms exclude the rule before scoring.

## REST API

All endpoints require the administrator role.

```text
GET    /api/intents
POST   /api/intents
GET    /api/intents/{id}
PUT    /api/intents/{id}
DELETE /api/intents/{id}
POST   /api/intents/resolve
GET    /api/intents/export
POST   /api/intents/import
```

### Test a resolution

```json
POST /api/intents/resolve
{
  "query": "show incidents application APP42 limit 25",
  "parameters": {},
  "confirmed": false
}
```

Possible decisions:

- `route`
- `clarify`
- `confirm`
- `deny`
- `llm_fallback`
- `no_match`
- `unavailable`

The result includes the intent, target agent, confidence, matching candidates,
allowed tools, extracted/missing parameters, risk, and response policy.

## Tool compatibility

Intent Control selects an agent and optionally narrows its tool set by registry
name. Tool invocation remains with the existing dynamic tool layer, so rules are
independent of transport and data format. The selected tools may be REST JSON,
REST CSV, file exchange, MCP, Python, or another registered implementation.

## Token behavior

Deterministic matching and database lookup use no LLM tokens. A matched route
skips the Concierge routing call. The specialist agent may still use LLM tokens
to understand parameters, call tools, or produce its final answer. A `no_match`
or `llm_fallback` decision intentionally invokes the existing Concierge.

## Deployment

```bash
alembic -c backend/migrations/alembic.ini upgrade head
systemctl restart aiops.service
```

Verify:

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/api/intents
```

Rollback only when no later migration depends on this revision:

```bash
alembic -c backend/migrations/alembic.ini downgrade 022_skywise_connector_type
```

Downgrade deletes `intent_rule`, so export rules first if they must be retained.
