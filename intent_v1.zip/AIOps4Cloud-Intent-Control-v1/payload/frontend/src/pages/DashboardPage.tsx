import { useLocation, Link } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import AgentsPage from "./dashboard/AgentsPage";
import DocumentsPage from "./dashboard/DocumentsPage";
import AuditPage from "./dashboard/AuditPage";
import MetricsPage from "./dashboard/MetricsPage";
import PoliciesPage from "./dashboard/PoliciesPage";
import TokensPage from "./dashboard/TokensPage";
import ConfigPage from "./dashboard/ConfigPage";
import ToolsPage from "./dashboard/ToolsPage";
import ModelsPage from "./dashboard/ModelsPage";
import UsersPage from "./dashboard/UsersPage";
import KpisPage from "./dashboard/KpisPage";
import IntentControlPage from "./dashboard/IntentControlPage";

const COMING_SOON_PATHS = new Set([
  "/dashboard/policies",
  "/dashboard/notifications",
  "/dashboard/config",
  "/dashboard/backup",
]);

const sections = [
  { path: "/dashboard/agents", label: "Agent Registry", icon: "\u2699" },
  { path: "/dashboard/documents", label: "Documents", icon: "\u2709" },
  { path: "/dashboard/audit", label: "Audit Log", icon: "\u2691" },
  { path: "/dashboard/tools", label: "Tools", icon: "\u2692" },
  { path: "/dashboard/policies", label: "Policies", icon: "\u229A" },
  { path: "/dashboard/metrics", label: "Performance", icon: "\u2261" },
  { path: "/dashboard/tokens", label: "Token Usage", icon: "\u2296" },
  { path: "/dashboard/notifications", label: "Notifications", icon: "\u2407" },
  { path: "/dashboard/config", label: "Configuration", icon: "\u2638" },
  { path: "/dashboard/backup", label: "Backup", icon: "\u2913" },
  { path: "/dashboard/kpis", label: "KPIs", icon: "\u25c8" },
] as const;

const adminSections = [
  { path: "/dashboard/intents", label: "Intent Control", icon: "◎" },
  { path: "/dashboard/models", label: "Models", icon: "⬣" },
  { path: "/dashboard/users", label: "User Management", icon: "☰" },
] as const;

/** Map sub-route paths to their page components. */
const subRouteComponents: Record<string, React.ComponentType> = {
  "/dashboard/kpis": KpisPage,
  "/dashboard/agents": AgentsPage,
  "/dashboard/documents": DocumentsPage,
  "/dashboard/audit": AuditPage,
  "/dashboard/metrics": MetricsPage,
  "/dashboard/tools": ToolsPage,
  "/dashboard/models": ModelsPage,
  "/dashboard/policies": PoliciesPage,
  "/dashboard/tokens": TokensPage,
  "/dashboard/config": ConfigPage,
  "/dashboard/users": UsersPage,
  "/dashboard/intents": IntentControlPage,
};

function DashboardPage() {
  const location = useLocation();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const isAdminRoute = adminSections.some(s => s.path === location.pathname);
  const isComingSoonRoute = COMING_SOON_PATHS.has(location.pathname);
  const ActiveComponent = isComingSoonRoute ? null : (isAdminRoute && !isAdmin ? null : (subRouteComponents[location.pathname] ?? null));

  return (
    <div style={{ display: "flex", height: "100%", margin: "-1.5rem", overflow: "hidden" }}>
      {/* Left sidebar navigation */}
      <nav
        style={{
          width: "220px",
          minWidth: "220px",
          background: "var(--color-surface)",
          borderRight: "1px solid var(--color-border)",
          display: "flex",
          flexDirection: "column",
          overflow: "auto",
        }}
      >
        <div
          style={{
            padding: "1.25rem 1rem 0.75rem",
            fontSize: "0.6875rem",
            fontWeight: 700,
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            color: "var(--color-text-muted)",
          }}
        >
          Governance
        </div>
        {sections.map((s) => {
          const isActive = location.pathname === s.path;
          const isComingSoon = COMING_SOON_PATHS.has(s.path);
          return (
            <Link
              key={s.path}
              to={s.path}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.625rem",
                padding: "0.5rem 1rem",
                textDecoration: "none",
                fontSize: "0.8125rem",
                fontWeight: isActive && !isComingSoon ? 600 : 400,
                color: isComingSoon
                  ? "#b0b8c4"
                  : isActive
                    ? "var(--color-on-primary)"
                    : "var(--color-text-muted)",
                background: isActive && !isComingSoon ? "var(--color-primary)" : "transparent",
                borderLeft: isActive && !isComingSoon ? "3px solid var(--color-primary-hover)" : "3px solid transparent",
                transition: "background 0.15s, color 0.15s",
              }}
              onMouseEnter={(e) => {
                if (!isActive || isComingSoon) e.currentTarget.style.background = "rgba(0,32,91,0.06)";
              }}
              onMouseLeave={(e) => {
                if (!isActive || isComingSoon) e.currentTarget.style.background = "transparent";
              }}
            >
              <span style={{ fontSize: "1rem", width: "1.25rem", textAlign: "center", opacity: isComingSoon ? 0.4 : 0.8 }}>
                {s.icon}
              </span>
              {s.label}
            </Link>
          );
        })}

        {isAdmin && (
          <>
            <div
              style={{
                padding: "1.25rem 1rem 0.75rem",
                fontSize: "0.6875rem",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                color: "var(--color-text-muted)",
                borderTop: "1px solid var(--color-border)",
                marginTop: "0.5rem",
              }}
            >
              Admin
            </div>
            {adminSections.map((s) => {
              const isActive = location.pathname === s.path;
              return (
                <Link
                  key={s.path}
                  to={s.path}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.625rem",
                    padding: "0.5rem 1rem",
                    textDecoration: "none",
                    fontSize: "0.8125rem",
                    fontWeight: isActive ? 600 : 400,
                    color: isActive ? "var(--color-on-primary)" : "var(--color-text-muted)",
                    background: isActive ? "var(--color-primary)" : "transparent",
                    borderLeft: isActive ? "3px solid var(--color-primary-hover)" : "3px solid transparent",
                    transition: "background 0.15s, color 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    if (!isActive) e.currentTarget.style.background = "rgba(0,32,91,0.06)";
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive) e.currentTarget.style.background = "transparent";
                  }}
                >
                  <span style={{ fontSize: "1rem", width: "1.25rem", textAlign: "center", opacity: 0.8 }}>
                    {s.icon}
                  </span>
                  {s.label}
                </Link>
              );
            })}
          </>
        )}
      </nav>

      {/* Main content area */}
      <div style={{ flex: 1, overflow: "auto", padding: "1.5rem" }}>
        {ActiveComponent ? (
          <ActiveComponent />
        ) : isComingSoonRoute ? (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}>
            <div style={{ textAlign: "center", color: "#b0b8c4" }}>
              <div style={{ fontSize: "2.5rem", marginBottom: "1rem", opacity: 0.5 }}>
                {sections.find(s => s.path === location.pathname)?.icon}
              </div>
              <p style={{ fontSize: "1.125rem", fontWeight: 600, margin: "0 0 0.5rem" }}>
                {sections.find(s => s.path === location.pathname)?.label}
              </p>
              <p style={{ fontSize: "0.875rem", margin: 0 }}>
                Coming in later phases
              </p>
            </div>
          </div>
        ) : (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: "var(--color-text-muted)" }}>
            <p>Select a section from the sidebar to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default DashboardPage;
