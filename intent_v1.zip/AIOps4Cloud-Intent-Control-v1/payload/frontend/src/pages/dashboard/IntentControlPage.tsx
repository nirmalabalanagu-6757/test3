import IntentControlManager from "../../components/dashboard/IntentControlManager";

export default function IntentControlPage() {
  return (
    <div>
      <h2 style={{ marginBottom: "0.25rem", fontSize: "1.25rem" }}>Intent Control</h2>
      <p style={{ margin: "0 0 1rem", color: "var(--color-text-muted)", fontSize: "0.8125rem" }}>
        Maintain deterministic routing rules evaluated before the LLM Concierge.
      </p>
      <IntentControlManager />
    </div>
  );
}
