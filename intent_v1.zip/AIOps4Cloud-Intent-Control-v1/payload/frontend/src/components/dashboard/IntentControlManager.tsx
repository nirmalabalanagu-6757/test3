import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { apiDelete, apiGet, apiPost, apiPut } from "../../api/client";

type MatchStrategy = "hybrid" | "exact" | "keywords" | "regex" | "examples";
type AmbiguityAction = "llm_fallback" | "clarify" | "fallback" | "deny" | "route_best";
type ResponseMode = "auto" | "direct" | "template" | "internal_summary" | "llm_summary" | "detailed";

interface IntentRule {
  id: string;
  name: string;
  display_name: string | null;
  description: string | null;
  enabled: boolean;
  priority: number;
  match_strategy: MatchStrategy;
  keyword_mode: "any" | "all";
  keywords_json: string[];
  negative_keywords_json: string[];
  regex_patterns_json: string[];
  examples_json: string[];
  min_confidence: number;
  ambiguity_margin: number;
  ambiguity_action: AmbiguityAction;
  target_agent: string;
  fallback_agent: string | null;
  allowed_tools_json: string[];
  parameter_config_json: Record<string, unknown>;
  risk_classification: "read_only" | "write" | "execute";
  requires_confirmation: boolean;
  response_mode: ResponseMode;
  response_template: string | null;
  response_options_json: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

interface FormState {
  name: string;
  displayName: string;
  description: string;
  enabled: boolean;
  priority: number;
  matchStrategy: MatchStrategy;
  keywordMode: "any" | "all";
  keywords: string;
  negativeKeywords: string;
  regexPatterns: string;
  examples: string;
  minConfidence: number;
  ambiguityMargin: number;
  ambiguityAction: AmbiguityAction;
  targetAgent: string;
  fallbackAgent: string;
  allowedTools: string[];
  parameterConfig: string;
  riskClassification: "read_only" | "write" | "execute";
  requiresConfirmation: boolean;
  responseMode: ResponseMode;
  responseTemplate: string;
  responseOptions: string;
}

const EMPTY_FORM: FormState = {
  name: "",
  displayName: "",
  description: "",
  enabled: true,
  priority: 100,
  matchStrategy: "hybrid",
  keywordMode: "any",
  keywords: "",
  negativeKeywords: "",
  regexPatterns: "",
  examples: "",
  minConfidence: 0.7,
  ambiguityMargin: 0.1,
  ambiguityAction: "llm_fallback",
  targetAgent: "",
  fallbackAgent: "",
  allowedTools: [],
  parameterConfig: "{\n  \"required\": [],\n  \"properties\": {}\n}",
  riskClassification: "read_only",
  requiresConfirmation: false,
  responseMode: "auto",
  responseTemplate: "",
  responseOptions: "{}",
};

const panelStyle: React.CSSProperties = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-md)",
  padding: "1rem",
};
const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "0.4rem 0.55rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-bg)",
  color: "var(--color-text)",
  fontSize: "0.8125rem",
};
const labelStyle: React.CSSProperties = {
  display: "block",
  marginBottom: "0.25rem",
  color: "var(--color-text-muted)",
  fontSize: "0.72rem",
  fontWeight: 600,
};
const buttonStyle: React.CSSProperties = {
  padding: "0.35rem 0.7rem",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-sm)",
  background: "var(--color-surface)",
  color: "var(--color-text)",
  cursor: "pointer",
  fontSize: "0.75rem",
  fontWeight: 500,
};
const primaryButton: React.CSSProperties = {
  ...buttonStyle,
  background: "var(--color-primary)",
  color: "var(--color-on-primary)",
  border: "1px solid var(--color-primary)",
};
const gridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))",
  gap: "0.75rem",
};

function lines(value: string): string[] {
  return value.split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
}

function parseObject(value: string, label: string): Record<string, unknown> {
  const parsed = JSON.parse(value || "{}");
  if (!parsed || Array.isArray(parsed) || typeof parsed !== "object") {
    throw new Error(`${label} must be a JSON object`);
  }
  return parsed as Record<string, unknown>;
}

function messageFromError(error: unknown): string {
  if (typeof error === "object" && error && "message" in error) {
    const raw = String((error as { message: unknown }).message);
    try {
      const body = JSON.parse(raw);
      return body?.error?.message || body?.detail || raw;
    } catch {
      return raw;
    }
  }
  return "Unexpected error";
}

function fromRule(rule: IntentRule): FormState {
  return {
    name: rule.name,
    displayName: rule.display_name || "",
    description: rule.description || "",
    enabled: rule.enabled,
    priority: rule.priority,
    matchStrategy: rule.match_strategy,
    keywordMode: rule.keyword_mode,
    keywords: rule.keywords_json.join("\n"),
    negativeKeywords: rule.negative_keywords_json.join("\n"),
    regexPatterns: rule.regex_patterns_json.join("\n"),
    examples: rule.examples_json.join("\n"),
    minConfidence: rule.min_confidence,
    ambiguityMargin: rule.ambiguity_margin,
    ambiguityAction: rule.ambiguity_action,
    targetAgent: rule.target_agent,
    fallbackAgent: rule.fallback_agent || "",
    allowedTools: rule.allowed_tools_json,
    parameterConfig: JSON.stringify(rule.parameter_config_json || {}, null, 2),
    riskClassification: rule.risk_classification,
    requiresConfirmation: rule.requires_confirmation,
    responseMode: rule.response_mode,
    responseTemplate: rule.response_template || "",
    responseOptions: JSON.stringify(rule.response_options_json || {}, null, 2),
  };
}

function Field({ label, help, children }: { label: string; help?: string; children: React.ReactNode }) {
  return (
    <label>
      <span style={labelStyle}>{label}</span>
      {children}
      {help && <span style={{ display: "block", marginTop: "0.2rem", color: "var(--color-text-muted)", fontSize: "0.65rem" }}>{help}</span>}
    </label>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section style={{ borderTop: "1px solid var(--color-border)", paddingTop: "0.9rem", marginTop: "0.9rem" }}>
      <h4 style={{ margin: "0 0 0.65rem", fontSize: "0.875rem" }}>{title}</h4>
      {children}
    </section>
  );
}

function RuleEditor({
  rule,
  agents,
  tools,
  onClose,
  onSaved,
}: {
  rule: IntentRule | null;
  agents: string[];
  tools: string[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<FormState>(() => rule ? fromRule(rule) : { ...EMPTY_FORM, targetAgent: agents[0] || "" });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((current) => ({ ...current, [key]: value }));

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      const payload = {
        name: form.name,
        display_name: form.displayName || null,
        description: form.description || null,
        enabled: form.enabled,
        priority: form.priority,
        match_strategy: form.matchStrategy,
        keyword_mode: form.keywordMode,
        keywords_json: lines(form.keywords),
        negative_keywords_json: lines(form.negativeKeywords),
        regex_patterns_json: lines(form.regexPatterns),
        examples_json: lines(form.examples),
        min_confidence: form.minConfidence,
        ambiguity_margin: form.ambiguityMargin,
        ambiguity_action: form.ambiguityAction,
        target_agent: form.targetAgent,
        fallback_agent: form.fallbackAgent || null,
        allowed_tools_json: form.allowedTools,
        parameter_config_json: parseObject(form.parameterConfig, "Parameter configuration"),
        risk_classification: form.riskClassification,
        requires_confirmation: form.requiresConfirmation,
        response_mode: form.responseMode,
        response_template: form.responseTemplate || null,
        response_options_json: parseObject(form.responseOptions, "Response options"),
      };
      if (rule) await apiPut(`/intents/${rule.id}`, payload);
      else await apiPost("/intents", payload);
      onSaved();
    } catch (e) {
      setError(messageFromError(e));
    } finally {
      setSaving(false);
    }
  };

  const toggleTool = (name: string) => {
    set("allowedTools", form.allowedTools.includes(name)
      ? form.allowedTools.filter((item) => item !== name)
      : [...form.allowedTools, name]);
  };

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 1300, background: "rgba(0,0,0,0.35)", display: "flex", justifyContent: "center", alignItems: "center", padding: "1rem" }}>
      <div style={{ width: "min(1000px, 96vw)", maxHeight: "92vh", overflow: "auto", background: "var(--color-bg)", borderRadius: "var(--radius-md)", boxShadow: "var(--shadow-6)", padding: "1rem" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <h3 style={{ margin: 0, fontSize: "1rem" }}>{rule ? `Edit ${rule.name}` : "New Intent Rule"}</h3>
          <button style={buttonStyle} onClick={onClose}>Close</button>
        </div>

        <Section title="Identity and lifecycle">
          <div style={gridStyle}>
            <Field label="Intent identifier" help="Stable name such as incident.search">
              <input style={inputStyle} value={form.name} onChange={(e) => set("name", e.target.value)} />
            </Field>
            <Field label="Display name">
              <input style={inputStyle} value={form.displayName} onChange={(e) => set("displayName", e.target.value)} />
            </Field>
            <Field label="Priority" help="Higher priority wins when confidence is equal">
              <input style={inputStyle} type="number" min={0} value={form.priority} onChange={(e) => set("priority", Number(e.target.value))} />
            </Field>
            <label style={{ display: "flex", alignItems: "center", gap: "0.45rem", paddingTop: "1.25rem" }}>
              <input type="checkbox" checked={form.enabled} onChange={(e) => set("enabled", e.target.checked)} /> Enabled
            </label>
          </div>
          <Field label="Description">
            <textarea style={{ ...inputStyle, minHeight: "60px" }} value={form.description} onChange={(e) => set("description", e.target.value)} />
          </Field>
        </Section>

        <Section title="Matching and ambiguity">
          <div style={gridStyle}>
            <Field label="Match strategy">
              <select style={inputStyle} value={form.matchStrategy} onChange={(e) => set("matchStrategy", e.target.value as MatchStrategy)}>
                <option value="hybrid">Hybrid</option><option value="exact">Exact</option><option value="keywords">Keywords</option>
                <option value="regex">Regular expression</option><option value="examples">Examples</option>
              </select>
            </Field>
            <Field label="Keyword mode">
              <select style={inputStyle} value={form.keywordMode} onChange={(e) => set("keywordMode", e.target.value as "any" | "all")}>
                <option value="any">Any keyword</option><option value="all">All keywords</option>
              </select>
            </Field>
            <Field label="Minimum confidence">
              <input style={inputStyle} type="number" min={0} max={1} step={0.01} value={form.minConfidence} onChange={(e) => set("minConfidence", Number(e.target.value))} />
            </Field>
            <Field label="Ambiguity margin" help="Difference allowed between the top two candidates">
              <input style={inputStyle} type="number" min={0} max={1} step={0.01} value={form.ambiguityMargin} onChange={(e) => set("ambiguityMargin", Number(e.target.value))} />
            </Field>
            <Field label="Ambiguous request action">
              <select style={inputStyle} value={form.ambiguityAction} onChange={(e) => set("ambiguityAction", e.target.value as AmbiguityAction)}>
                <option value="llm_fallback">Use LLM Concierge</option><option value="clarify">Ask for clarification</option>
                <option value="fallback">Use fallback agent</option><option value="route_best">Route best match</option><option value="deny">Deny</option>
              </select>
            </Field>
          </div>
          <div style={{ ...gridStyle, marginTop: "0.75rem" }}>
            <Field label="Positive keywords" help="One keyword or phrase per line"><textarea style={{ ...inputStyle, minHeight: "90px" }} value={form.keywords} onChange={(e) => set("keywords", e.target.value)} /></Field>
            <Field label="Negative keywords" help="Any match excludes this intent"><textarea style={{ ...inputStyle, minHeight: "90px" }} value={form.negativeKeywords} onChange={(e) => set("negativeKeywords", e.target.value)} /></Field>
            <Field label="Regular expressions" help="One Python-compatible expression per line"><textarea style={{ ...inputStyle, minHeight: "90px", fontFamily: "var(--font-family-mono)" }} value={form.regexPatterns} onChange={(e) => set("regexPatterns", e.target.value)} /></Field>
            <Field label="Example requests" help="One representative user request per line"><textarea style={{ ...inputStyle, minHeight: "90px" }} value={form.examples} onChange={(e) => set("examples", e.target.value)} /></Field>
          </div>
        </Section>

        <Section title="Routing and governance">
          <div style={gridStyle}>
            <Field label="Target agent">
              <select style={inputStyle} value={form.targetAgent} onChange={(e) => set("targetAgent", e.target.value)}>
                <option value="">Select an agent</option>{agents.map((agent) => <option key={agent}>{agent}</option>)}
              </select>
            </Field>
            <Field label="Fallback agent">
              <select style={inputStyle} value={form.fallbackAgent} onChange={(e) => set("fallbackAgent", e.target.value)}>
                <option value="">None</option>{agents.filter((a) => a !== form.targetAgent).map((agent) => <option key={agent}>{agent}</option>)}
              </select>
            </Field>
            <Field label="Risk classification">
              <select style={inputStyle} value={form.riskClassification} onChange={(e) => set("riskClassification", e.target.value as FormState["riskClassification"])}>
                <option value="read_only">Read only</option><option value="write">Write</option><option value="execute">Execute</option>
              </select>
            </Field>
            <label style={{ display: "flex", alignItems: "center", gap: "0.45rem", paddingTop: "1.25rem" }}>
              <input type="checkbox" checked={form.requiresConfirmation} onChange={(e) => set("requiresConfirmation", e.target.checked)} /> Require confirmation
            </label>
          </div>
          <div style={{ marginTop: "0.75rem" }}>
            <span style={labelStyle}>Per-intent tool allowlist</span>
            <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap", maxHeight: "120px", overflow: "auto", padding: "0.5rem", border: "1px solid var(--color-border)", borderRadius: "var(--radius-sm)" }}>
              {tools.length === 0 ? <span style={{ color: "var(--color-text-muted)", fontSize: "0.75rem" }}>No tools registered.</span> : tools.map((tool) => (
                <label key={tool} style={{ display: "flex", gap: "0.3rem", alignItems: "center", fontSize: "0.75rem" }}>
                  <input type="checkbox" checked={form.allowedTools.includes(tool)} onChange={() => toggleTool(tool)} /> {tool}
                </label>
              ))}
            </div>
            <span style={{ color: "var(--color-text-muted)", fontSize: "0.65rem" }}>Leave empty to use all active tools already assigned to the target agent.</span>
          </div>
        </Section>

        <Section title="Runtime parameters">
          <Field label="Parameter extraction configuration (JSON)" help={'Supports required[], properties.<name>.pattern/type/default/prompt'}>
            <textarea style={{ ...inputStyle, minHeight: "150px", fontFamily: "var(--font-family-mono)" }} value={form.parameterConfig} onChange={(e) => set("parameterConfig", e.target.value)} />
          </Field>
        </Section>

        <Section title="Response policy">
          <div style={gridStyle}>
            <Field label="Response mode">
              <select style={inputStyle} value={form.responseMode} onChange={(e) => set("responseMode", e.target.value as ResponseMode)}>
                <option value="auto">Auto</option><option value="direct">Direct</option><option value="template">Template</option>
                <option value="internal_summary">Internal summary</option><option value="llm_summary">LLM summary</option><option value="detailed">Detailed analysis</option>
              </select>
            </Field>
            <Field label="Response options (JSON)" help="Optional limits, grouping, columns, sorting, or format">
              <textarea style={{ ...inputStyle, minHeight: "90px", fontFamily: "var(--font-family-mono)" }} value={form.responseOptions} onChange={(e) => set("responseOptions", e.target.value)} />
            </Field>
          </div>
          <Field label="Response template" help="Required only for template mode">
            <textarea style={{ ...inputStyle, minHeight: "80px", fontFamily: "var(--font-family-mono)" }} value={form.responseTemplate} onChange={(e) => set("responseTemplate", e.target.value)} />
          </Field>
        </Section>

        {error && <p role="alert" style={{ color: "var(--color-error)", fontSize: "0.8rem", marginTop: "0.75rem" }}>{error}</p>}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: "0.5rem", marginTop: "1rem" }}>
          <button style={buttonStyle} onClick={onClose}>Cancel</button>
          <button style={primaryButton} disabled={saving} onClick={save}>{saving ? "Saving..." : "Save intent"}</button>
        </div>
      </div>
    </div>
  );
}

function ResolutionTester() {
  const [query, setQuery] = useState("");
  const [parameters, setParameters] = useState("{}");
  const [confirmed, setConfirmed] = useState(false);
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);

  const test = async () => {
    setError(null);
    try {
      const resolved = await apiPost<Record<string, unknown>>("/intents/resolve", {
        query,
        parameters: parseObject(parameters, "Parameters"),
        confirmed,
      });
      setResult(resolved);
    } catch (e) {
      setError(messageFromError(e));
    }
  };

  return (
    <div style={panelStyle}>
      <h3 style={{ margin: "0 0 0.3rem", fontSize: "0.95rem" }}>Test Resolution</h3>
      <p style={{ margin: "0 0 0.75rem", color: "var(--color-text-muted)", fontSize: "0.72rem" }}>No LLM is called. This executes the same deterministic stage used before Concierge routing.</p>
      <Field label="User request"><textarea style={{ ...inputStyle, minHeight: "75px" }} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Show open incidents for the master branch" /></Field>
      <div style={{ ...gridStyle, marginTop: "0.65rem" }}>
        <Field label="Supplied parameters (JSON)"><textarea style={{ ...inputStyle, minHeight: "75px", fontFamily: "var(--font-family-mono)" }} value={parameters} onChange={(e) => setParameters(e.target.value)} /></Field>
        <label style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}><input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} /> Treat request as confirmed</label>
      </div>
      <button style={{ ...primaryButton, marginTop: "0.75rem" }} disabled={!query.trim()} onClick={test}>Resolve intent</button>
      {error && <p role="alert" style={{ color: "var(--color-error)", fontSize: "0.8rem" }}>{error}</p>}
      {result && <pre style={{ marginTop: "0.75rem", padding: "0.75rem", overflow: "auto", background: "var(--color-surface-raised)", borderRadius: "var(--radius-sm)", fontSize: "0.7rem" }}>{JSON.stringify(result, null, 2)}</pre>}
    </div>
  );
}

export default function IntentControlManager() {
  const [intents, setIntents] = useState<IntentRule[]>([]);
  const [agents, setAgents] = useState<string[]>([]);
  const [tools, setTools] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editor, setEditor] = useState<IntentRule | "new" | null>(null);
  const [tab, setTab] = useState<"rules" | "test" | "import">("rules");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | "enabled" | "disabled">("all");
  const [importData, setImportData] = useState("");
  const [replaceExisting, setReplaceExisting] = useState(false);
  const [importResult, setImportResult] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const [intentData, agentData, toolData] = await Promise.all([
        apiGet<{ intents: IntentRule[] }>("/intents"),
        apiGet<{ agents: { name: string; agent_type: string }[] }>("/agents?agent_type=specialized"),
        apiGet<{ tools: { name: string }[] }>("/tools"),
      ]);
      setIntents(intentData.intents);
      setAgents(agentData.agents.map((agent) => agent.name));
      setTools(toolData.tools.map((tool) => tool.name));
      setError(null);
    } catch (e) {
      setError(messageFromError(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => intents.filter((intent) => {
    const matchesText = !search || `${intent.name} ${intent.display_name || ""} ${intent.target_agent}`.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = status === "all" || intent.enabled === (status === "enabled");
    return matchesText && matchesStatus;
  }), [intents, search, status]);

  const toggleEnabled = async (intent: IntentRule) => {
    try { await apiPut(`/intents/${intent.id}`, { enabled: !intent.enabled }); await load(); }
    catch (e) { setError(messageFromError(e)); }
  };

  const remove = async (intent: IntentRule) => {
    if (!window.confirm(`Delete intent '${intent.name}'?`)) return;
    try { await apiDelete(`/intents/${intent.id}`); await load(); }
    catch (e) { setError(messageFromError(e)); }
  };

  const exportRules = async () => {
    try {
      const exported = await apiGet<{ data: string }>("/intents/export");
      const url = URL.createObjectURL(new Blob([exported.data], { type: "application/json" }));
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "intent-control-v1.json";
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (e) { setError(messageFromError(e)); }
  };

  const importRules = async () => {
    setImportResult(null);
    try {
      const result = await apiPost<{ imported: number; updated: number; errors: string[] }>("/intents/import", { data: importData, replace_existing: replaceExisting });
      setImportResult(`Imported ${result.imported}; updated ${result.updated}; errors ${result.errors.length}${result.errors.length ? `: ${result.errors.join(" | ")}` : ""}`);
      await load();
    } catch (e) { setImportResult(messageFromError(e)); }
  };

  const tabButton = (key: typeof tab, label: string) => (
    <button style={{ ...buttonStyle, ...(tab === key ? primaryButton : {}) }} onClick={() => setTab(key)}>{label}</button>
  );

  if (loading) return <p style={{ color: "var(--color-text-muted)" }}>Loading Intent Control...</p>;

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "0.75rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
        <div style={{ display: "flex", gap: "0.35rem" }}>{tabButton("rules", "Rules")}{tabButton("test", "Test Resolution")}{tabButton("import", "Import / Export")}</div>
        <button style={primaryButton} onClick={() => setEditor("new")}>+ New intent</button>
      </div>
      {error && <p role="alert" style={{ color: "var(--color-error)", marginBottom: "0.75rem" }}>{error}</p>}

      {tab === "rules" && (
        <div style={panelStyle}>
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
            <input style={{ ...inputStyle, maxWidth: "320px" }} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search intent or agent" />
            <select style={{ ...inputStyle, width: "150px" }} value={status} onChange={(e) => setStatus(e.target.value as typeof status)}><option value="all">All states</option><option value="enabled">Enabled</option><option value="disabled">Disabled</option></select>
            <span style={{ alignSelf: "center", color: "var(--color-text-muted)", fontSize: "0.75rem" }}>{filtered.length} of {intents.length} rules</span>
          </div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.78rem" }}>
              <thead><tr>{["Intent", "Matching", "Route", "Confidence", "Governance", "Response", "State", "Actions"].map((heading) => <th key={heading} style={{ textAlign: "left", padding: "0.5rem", borderBottom: "2px solid var(--color-border)", color: "var(--color-text-muted)", whiteSpace: "nowrap" }}>{heading}</th>)}</tr></thead>
              <tbody>
                {filtered.map((intent) => (
                  <tr key={intent.id}>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}><strong>{intent.display_name || intent.name}</strong><div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.name} · priority {intent.priority}</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.match_strategy}<div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.keywords_json.length} keywords · {intent.examples_json.length} examples · {intent.regex_patterns_json.length} regex</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}><strong>{intent.target_agent}</strong><div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.allowed_tools_json.length ? `${intent.allowed_tools_json.length} allowed tools` : "all assigned tools"}</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.min_confidence.toFixed(2)}<div style={{ color: "var(--color-text-muted)", fontSize: "0.66rem" }}>{intent.ambiguity_action}</div></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.risk_classification}{intent.requires_confirmation && <div style={{ color: "var(--color-warning)", fontSize: "0.66rem" }}>confirmation</div>}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}>{intent.response_mode}</td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)" }}><button style={{ ...buttonStyle, color: intent.enabled ? "var(--color-success)" : "var(--color-text-muted)" }} onClick={() => toggleEnabled(intent)}>{intent.enabled ? "Enabled" : "Disabled"}</button></td>
                    <td style={{ padding: "0.55rem", borderBottom: "1px solid var(--color-border)", whiteSpace: "nowrap" }}><button style={buttonStyle} onClick={() => setEditor(intent)}>Edit</button> <button style={{ ...buttonStyle, color: "var(--color-error)" }} onClick={() => remove(intent)}>Delete</button></td>
                  </tr>
                ))}
                {filtered.length === 0 && <tr><td colSpan={8} style={{ padding: "1.5rem", textAlign: "center", color: "var(--color-text-muted)" }}>No intent rules match the current filter.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "test" && <ResolutionTester />}

      {tab === "import" && (
        <div style={panelStyle}>
          <h3 style={{ margin: "0 0 0.6rem", fontSize: "0.95rem" }}>Portable Intent Configuration</h3>
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
            <button style={buttonStyle} onClick={exportRules}>Export JSON</button>
            <button style={buttonStyle} onClick={() => fileRef.current?.click()}>Load JSON file</button>
            <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={async (e) => { const file = e.target.files?.[0]; if (file) setImportData(await file.text()); }} />
            <label style={{ display: "flex", gap: "0.35rem", alignItems: "center", fontSize: "0.75rem" }}><input type="checkbox" checked={replaceExisting} onChange={(e) => setReplaceExisting(e.target.checked)} /> Replace rules with the same name</label>
          </div>
          <textarea style={{ ...inputStyle, minHeight: "300px", fontFamily: "var(--font-family-mono)" }} value={importData} onChange={(e) => setImportData(e.target.value)} placeholder='{"version":1,"intents":[]}' />
          <button style={{ ...primaryButton, marginTop: "0.65rem" }} disabled={!importData.trim()} onClick={importRules}>Import configuration</button>
          {importResult && <p style={{ marginTop: "0.6rem", fontSize: "0.75rem" }}>{importResult}</p>}
        </div>
      )}

      {editor && <RuleEditor rule={editor === "new" ? null : editor} agents={agents} tools={tools} onClose={() => setEditor(null)} onSaved={() => { setEditor(null); void load(); }} />}
    </div>
  );
}
