"""Validation schemas for dynamic intent-control administration and resolution."""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

MatchStrategy = Literal["hybrid", "exact", "keywords", "regex", "examples"]
KeywordMode = Literal["any", "all"]
AmbiguityAction = Literal["llm_fallback", "clarify", "fallback", "deny", "route_best"]
RiskClassification = Literal["read_only", "write", "execute"]
ResponseMode = Literal["auto", "direct", "template", "internal_summary", "llm_summary", "detailed"]
DecisionType = Literal[
    "route", "clarify", "confirm", "deny", "llm_fallback", "no_match", "unavailable"
]


class IntentRuleBase(BaseModel):
    """Fields shared by create and response schemas."""

    name: str = Field(
        ...,
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$",
        description="Stable intent identifier, for example incident.search",
    )
    display_name: str | None = Field(None, max_length=160)
    description: str | None = None
    enabled: bool = True
    priority: int = Field(100, ge=0, le=100_000)
    match_strategy: MatchStrategy = "hybrid"
    keyword_mode: KeywordMode = "any"
    keywords_json: list[str] = Field(default_factory=list, max_length=100)
    negative_keywords_json: list[str] = Field(default_factory=list, max_length=100)
    regex_patterns_json: list[str] = Field(default_factory=list, max_length=25)
    examples_json: list[str] = Field(default_factory=list, max_length=100)
    min_confidence: float = Field(0.70, ge=0.0, le=1.0)
    ambiguity_margin: float = Field(0.10, ge=0.0, le=1.0)
    ambiguity_action: AmbiguityAction = "llm_fallback"
    target_agent: str = Field(..., min_length=1, max_length=128)
    fallback_agent: str | None = Field(None, max_length=128)
    allowed_tools_json: list[str] = Field(default_factory=list, max_length=100)
    parameter_config_json: dict[str, Any] = Field(default_factory=dict)
    risk_classification: RiskClassification = "read_only"
    requires_confirmation: bool = False
    response_mode: ResponseMode = "auto"
    response_template: str | None = None
    response_options_json: dict[str, Any] = Field(default_factory=dict)

    @field_validator(
        "keywords_json",
        "negative_keywords_json",
        "regex_patterns_json",
        "examples_json",
        "allowed_tools_json",
    )
    @classmethod
    def clean_string_lists(cls, value: list[str]) -> list[str]:
        """Trim, remove blank entries, and preserve first-occurrence order."""
        cleaned: list[str] = []
        seen: set[str] = set()
        for item in value:
            text = str(item).strip()
            marker = text.casefold()
            if text and marker not in seen:
                cleaned.append(text)
                seen.add(marker)
        return cleaned

    @model_validator(mode="after")
    def validate_match_configuration(self) -> "IntentRuleBase":
        configured = {
            "exact": bool(self.examples_json or self.keywords_json),
            "keywords": bool(self.keywords_json),
            "regex": bool(self.regex_patterns_json),
            "examples": bool(self.examples_json),
            "hybrid": bool(self.keywords_json or self.regex_patterns_json or self.examples_json),
        }
        if not configured[self.match_strategy]:
            raise ValueError(
                f"match_strategy '{self.match_strategy}' requires matching values"
            )
        if self.ambiguity_action == "fallback" and not self.fallback_agent:
            raise ValueError("fallback_agent is required when ambiguity_action is 'fallback'")
        if self.response_mode == "template" and not (self.response_template or "").strip():
            raise ValueError("response_template is required when response_mode is 'template'")
        return self


class IntentRuleCreate(IntentRuleBase):
    """Create an intent rule."""


class IntentRuleUpdate(BaseModel):
    """Update one or more fields on an intent rule."""

    name: str | None = Field(None, min_length=1, max_length=128, pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$")
    display_name: str | None = Field(None, max_length=160)
    description: str | None = None
    enabled: bool | None = None
    priority: int | None = Field(None, ge=0, le=100_000)
    match_strategy: MatchStrategy | None = None
    keyword_mode: KeywordMode | None = None
    keywords_json: list[str] | None = Field(None, max_length=100)
    negative_keywords_json: list[str] | None = Field(None, max_length=100)
    regex_patterns_json: list[str] | None = Field(None, max_length=25)
    examples_json: list[str] | None = Field(None, max_length=100)
    min_confidence: float | None = Field(None, ge=0.0, le=1.0)
    ambiguity_margin: float | None = Field(None, ge=0.0, le=1.0)
    ambiguity_action: AmbiguityAction | None = None
    target_agent: str | None = Field(None, min_length=1, max_length=128)
    fallback_agent: str | None = Field(None, max_length=128)
    allowed_tools_json: list[str] | None = Field(None, max_length=100)
    parameter_config_json: dict[str, Any] | None = None
    risk_classification: RiskClassification | None = None
    requires_confirmation: bool | None = None
    response_mode: ResponseMode | None = None
    response_template: str | None = None
    response_options_json: dict[str, Any] | None = None

    @field_validator(
        "keywords_json",
        "negative_keywords_json",
        "regex_patterns_json",
        "examples_json",
        "allowed_tools_json",
    )
    @classmethod
    def clean_optional_string_lists(cls, value: list[str] | None) -> list[str] | None:
        if value is None:
            return None
        return IntentRuleBase.clean_string_lists(value)


class IntentRuleResponse(IntentRuleBase):
    id: str
    created_by: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class IntentRuleListResponse(BaseModel):
    intents: list[IntentRuleResponse]
    count: int


class IntentCandidate(BaseModel):
    intent_id: str
    intent_name: str
    target_agent: str
    score: float
    priority: int
    matched_by: list[str] = Field(default_factory=list)


class IntentResolveRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=20_000)
    parameters: dict[str, Any] = Field(default_factory=dict)
    confirmed: bool = False


class IntentDecision(BaseModel):
    decision: DecisionType
    intent_id: str | None = None
    intent_name: str | None = None
    target_agent: str | None = None
    allowed_tools: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    reason: str
    extracted_parameters: dict[str, Any] = Field(default_factory=dict)
    missing_parameters: list[str] = Field(default_factory=list)
    clarification_prompt: str | None = None
    risk_classification: RiskClassification | None = None
    requires_confirmation: bool = False
    response_mode: ResponseMode | None = None
    response_template: str | None = None
    response_options: dict[str, Any] = Field(default_factory=dict)
    candidates: list[IntentCandidate] = Field(default_factory=list)


class IntentImportRequest(BaseModel):
    data: str = Field(..., description="JSON document exported by Intent Control")
    replace_existing: bool = False


class IntentImportResponse(BaseModel):
    imported: int
    updated: int
    errors: list[str]


class IntentExportResponse(BaseModel):
    format: Literal["json"] = "json"
    data: str
