"""Database model for administrator-managed intent routing rules."""

import uuid
from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, Float, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from backend.database import Base


class IntentRule(Base):
    """A dynamic intent rule evaluated before the LLM concierge router."""

    __tablename__ = "intent_rule"
    __table_args__ = (
        Index("ix_intent_rule_enabled_priority", "enabled", "priority"),
        Index("ix_intent_rule_target_agent", "target_agent"),
    )

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    name: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    display_name: Mapped[str | None] = mapped_column(String(160), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=100)

    # Matching configuration.
    match_strategy: Mapped[str] = mapped_column(
        String(20), nullable=False, default="hybrid"
    )  # hybrid | exact | keywords | regex | examples
    keyword_mode: Mapped[str] = mapped_column(
        String(10), nullable=False, default="any"
    )  # any | all
    keywords_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    negative_keywords_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    regex_patterns_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    examples_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    min_confidence: Mapped[float] = mapped_column(Float, nullable=False, default=0.70)
    ambiguity_margin: Mapped[float] = mapped_column(Float, nullable=False, default=0.10)
    ambiguity_action: Mapped[str] = mapped_column(
        String(24), nullable=False, default="llm_fallback"
    )  # llm_fallback | clarify | fallback | deny | route_best

    # Routing and governance configuration. Names are validated by the service
    # instead of foreign keys so import/restore order stays flexible.
    target_agent: Mapped[str] = mapped_column(String(128), nullable=False)
    fallback_agent: Mapped[str | None] = mapped_column(String(128), nullable=True)
    allowed_tools_json: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    parameter_config_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    risk_classification: Mapped[str] = mapped_column(
        String(20), nullable=False, default="read_only"
    )
    requires_confirmation: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )

    # The response policy is metadata for the selected agent/tool execution
    # layer. Limits are deliberately optional and administrator-configured.
    response_mode: Mapped[str] = mapped_column(
        String(24), nullable=False, default="auto"
    )  # auto | direct | template | internal_summary | llm_summary | detailed
    response_template: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_options_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

    created_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )
