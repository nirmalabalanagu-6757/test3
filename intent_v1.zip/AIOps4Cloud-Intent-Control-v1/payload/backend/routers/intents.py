"""Administrator APIs for dynamic Intent Control."""

# FastAPI's documented dependency-injection pattern uses calls in defaults.
# ruff: noqa: B008

import logging
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_session
from backend.middleware.auth import require_role
from backend.models.user import User
from backend.schemas.intent import (
    IntentDecision,
    IntentExportResponse,
    IntentImportRequest,
    IntentImportResponse,
    IntentResolveRequest,
    IntentRuleCreate,
    IntentRuleListResponse,
    IntentRuleResponse,
    IntentRuleUpdate,
)
from backend.services.intent_control import (
    IntentConfigurationError,
    IntentControlService,
    IntentNameExistsError,
    IntentNotFoundError,
)

router = APIRouter(
    prefix="/api/intents",
    tags=["intent-control"],
    dependencies=[Depends(require_role("admin"))],
)

_service = IntentControlService()
logger = logging.getLogger(__name__)


def _error(status: int, code: str, message: str, request: Request) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": {},
                "request_id": getattr(request.state, "request_id", "unknown"),
                "timestamp": datetime.now(UTC).isoformat(),
            }
        },
    )


def _invalidate_runtime(*agent_names: str | None) -> None:
    try:
        from backend.services.agent_runner import agent_runner

        agent_runner.invalidate_routing_runners()
        for name in agent_names:
            if name:
                agent_runner.invalidate_runners(name)
    except Exception:
        logger.warning("Failed to invalidate agent runners after intent change", exc_info=True)


@router.get("", response_model=IntentRuleListResponse)
async def list_intents(
    enabled: bool | None = Query(None),
    target_agent: str | None = Query(None),
    session: AsyncSession = Depends(get_session),
) -> Any:
    rules = await _service.list_rules(session, enabled=enabled, target_agent=target_agent)
    return IntentRuleListResponse(
        intents=[IntentRuleResponse.model_validate(rule) for rule in rules],
        count=len(rules),
    )


@router.post("", response_model=IntentRuleResponse, status_code=201)
async def create_intent(
    data: IntentRuleCreate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        rule = await _service.create_rule(session, data, created_by=user.username)
        await session.commit()
        _invalidate_runtime(rule.target_agent)
        return IntentRuleResponse.model_validate(rule)
    except IntentNameExistsError as exc:
        await session.rollback()
        return _error(409, "INTENT_NAME_EXISTS", str(exc), request)
    except IntentConfigurationError as exc:
        await session.rollback()
        return _error(422, "INVALID_INTENT_CONFIGURATION", str(exc), request)


@router.post("/resolve", response_model=IntentDecision)
async def test_resolve_intent(
    data: IntentResolveRequest,
    session: AsyncSession = Depends(get_session),
) -> Any:
    """Resolve a query exactly as the runtime deterministic stage would."""
    return await _service.resolve(
        session,
        data.query,
        parameters=data.parameters,
        confirmed=data.confirmed,
    )


@router.get("/export", response_model=IntentExportResponse)
async def export_intents(session: AsyncSession = Depends(get_session)) -> Any:
    return IntentExportResponse(data=await _service.export_rules(session))


@router.post("/import", response_model=IntentImportResponse)
async def import_intents(
    data: IntentImportRequest,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    imported, updated, errors = await _service.import_rules(
        session,
        data.data,
        replace_existing=data.replace_existing,
        imported_by=user.username,
    )
    await session.commit()
    _invalidate_runtime()
    return IntentImportResponse(imported=imported, updated=updated, errors=errors)


@router.get("/{intent_id}", response_model=IntentRuleResponse)
async def get_intent(
    intent_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> Any:
    try:
        return IntentRuleResponse.model_validate(await _service.get_rule(session, intent_id))
    except IntentNotFoundError as exc:
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)


@router.put("/{intent_id}", response_model=IntentRuleResponse)
async def update_intent(
    intent_id: str,
    data: IntentRuleUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        old_rule = await _service.get_rule(session, intent_id)
        old_target = old_rule.target_agent
        rule = await _service.update_rule(session, intent_id, data, updated_by=user.username)
        await session.commit()
        _invalidate_runtime(old_target, rule.target_agent)
        return IntentRuleResponse.model_validate(rule)
    except IntentNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)
    except IntentNameExistsError as exc:
        await session.rollback()
        return _error(409, "INTENT_NAME_EXISTS", str(exc), request)
    except IntentConfigurationError as exc:
        await session.rollback()
        return _error(422, "INVALID_INTENT_CONFIGURATION", str(exc), request)


@router.delete("/{intent_id}", response_model=IntentRuleResponse)
async def delete_intent(
    intent_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(require_role("admin")),
) -> Any:
    try:
        rule = await _service.delete_rule(session, intent_id, deleted_by=user.username)
        response = IntentRuleResponse.model_validate(rule)
        await session.commit()
        _invalidate_runtime(rule.target_agent)
        return response
    except IntentNotFoundError as exc:
        await session.rollback()
        return _error(404, "INTENT_NOT_FOUND", str(exc), request)
