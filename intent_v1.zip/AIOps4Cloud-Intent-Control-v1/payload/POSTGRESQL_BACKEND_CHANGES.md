# PostgreSQL backend changes

This build makes PostgreSQL 15.12+ mandatory.

- Removed `aiosqlite` runtime dependency.
- Removed SQLite default URLs from backend, systemd, Alembic and environment templates.
- `DATABASE_URL` must use `postgresql+asyncpg://`.
- Backend validates PostgreSQL `server_version_num >= 150012`.
- systemd performs the same version/connectivity check before migrations.
- RHEL installer enables PostgreSQL 15 and refuses packages/servers older than 15.12.
- Local installation creates the `aiops` role/database with SCRAM-SHA-256.
- Dynamic tool credentials use PostgreSQL `pgcrypto` only.
- Built-in primary database backup uses real `pg_dump` custom format.
- Production schema lifecycle is Alembic-managed; FastAPI startup no longer runs `create_all()`.
# Intent Control database addition

Migration `023_intent_control` adds the `intent_rule` configuration table used
by the separate Admin Intent Control panel. It is an additive migration and does
not modify existing user, agent, tool, policy, or credential tables.

The table stores matching, routing, governance, parameter, and response-policy
configuration. External API/CSV/JSON/SQL result data is not stored by this
feature.
