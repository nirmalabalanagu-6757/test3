"""Unit tests for deterministic, database-driven Intent Control."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from backend.models.agent import AgentRegistry
from backend.models.intent import IntentRule
from backend.schemas.intent import IntentRuleCreate
from backend.services.intent_control import IntentControlService


def _rule(**overrides):
    values = {
        "id": "intent-1",
        "name": "incident.search",
        "display_name": "Search incidents",
        "description": "Find operational incidents",
        "enabled": True,
        "priority": 100,
        "match_strategy": "hybrid",
        "keyword_mode": "any",
        "keywords_json": ["incident", "open incidents"],
        "negative_keywords_json": ["delete incident"],
        "regex_patterns_json": [],
        "examples_json": ["show open incidents"],
        "min_confidence": 0.70,
        "ambiguity_margin": 0.10,
        "ambiguity_action": "llm_fallback",
        "target_agent": "incident_agent",
        "fallback_agent": None,
        "allowed_tools_json": ["fetch_incidents"],
        "parameter_config_json": {},
        "risk_classification": "read_only",
        "requires_confirmation": False,
        "response_mode": "auto",
        "response_template": None,
        "response_options_json": {},
    }
    values.update(overrides)
    return IntentRule(**values)


class _ScalarResult:
    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows


class _FakeSession:
    def __init__(self, rules, agents):
        self.rules = rules
        self.agents = agents

    async def execute(self, _statement):
        return _ScalarResult(self.rules)

    async def get(self, model, key):
        if model is AgentRegistry:
            return self.agents.get(key)
        if model is IntentRule:
            return next((rule for rule in self.rules if rule.id == key), None)
        return None


def _agent(name: str, status: str = "running") -> AgentRegistry:
    return AgentRegistry(
        name=name,
        product="operations",
        agent_type="specialized",
        lifecycle_status=status,
        allow_world_knowledge=False,
        health_check_interval_sec=60,
        consecutive_health_failures=0,
    )


def test_keyword_match_and_negative_exclusion():
    rule = _rule()
    match = IntentControlService._score_rule(rule, "Please show the open incidents")
    assert match is not None
    assert match.score >= 0.70
    assert any(label.startswith("keywords") for label in match.matched_by)

    blocked = IntentControlService._score_rule(rule, "delete incident INC-1")
    assert blocked is None


def test_regex_and_exact_matches_are_high_confidence():
    regex_rule = _rule(
        match_strategy="regex",
        keywords_json=[],
        examples_json=[],
        regex_patterns_json=[r"INC-\d+"],
    )
    regex_match = IntentControlService._score_rule(regex_rule, "lookup INC-204")
    assert regex_match is not None
    assert regex_match.score == pytest.approx(0.97)

    exact_rule = _rule(match_strategy="exact", keywords_json=[], examples_json=["show incidents"])
    exact_match = IntentControlService._score_rule(exact_rule, "  SHOW   incidents ")
    assert exact_match is not None
    assert exact_match.score == pytest.approx(1.0)


def test_schema_rejects_incomplete_strategy_and_template():
    with pytest.raises(ValidationError):
        IntentRuleCreate(
            name="bad.intent",
            match_strategy="regex",
            keywords_json=["bad"],
            target_agent="incident_agent",
        )

    with pytest.raises(ValidationError):
        IntentRuleCreate(
            name="bad.template",
            keywords_json=["incident"],
            target_agent="incident_agent",
            response_mode="template",
        )


@pytest.mark.asyncio
async def test_resolve_extracts_parameters_and_routes():
    rule = _rule(
        parameter_config_json={
            "required": ["row_limit"],
            "properties": {
                "row_limit": {
                    "type": "integer",
                    "pattern": r"(?:limit|rows?)\s+(\d+)",
                    "prompt": "How many rows should be returned?",
                }
            },
        }
    )
    service = IntentControlService()
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})

    decision = await service.resolve(session, "show incidents limit 25")
    assert decision.decision == "route"
    assert decision.target_agent == "incident_agent"
    assert decision.extracted_parameters == {"row_limit": 25}
    assert decision.allowed_tools == ["fetch_incidents"]


@pytest.mark.asyncio
async def test_missing_parameter_requests_clarification():
    rule = _rule(
        parameter_config_json={
            "required": ["dataset"],
            "properties": {"dataset": {"prompt": "Which dataset should be used?"}},
        }
    )
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})
    decision = await IntentControlService().resolve(session, "show incidents")
    assert decision.decision == "clarify"
    assert decision.missing_parameters == ["dataset"]
    assert decision.clarification_prompt == "Which dataset should be used?"


@pytest.mark.asyncio
async def test_confirmation_and_unavailable_target_are_enforced():
    rule = _rule(requires_confirmation=True, risk_classification="execute")
    session = _FakeSession([rule], {"incident_agent": _agent("incident_agent")})
    service = IntentControlService()

    pending = await service.resolve(session, "show incidents")
    assert pending.decision == "confirm"

    session.agents["incident_agent"].lifecycle_status = "stopped"
    unavailable = await service.resolve(session, "show incidents", confirmed=True)
    assert unavailable.decision == "unavailable"


@pytest.mark.asyncio
async def test_ambiguity_action_clarifies_between_close_matches():
    first = _rule(id="one", name="incident.search", ambiguity_action="clarify")
    second = _rule(
        id="two",
        name="incident.report",
        target_agent="report_agent",
        keywords_json=["incident"],
        examples_json=["show incident report"],
        priority=90,
    )
    session = _FakeSession(
        [first, second],
        {
            "incident_agent": _agent("incident_agent"),
            "report_agent": _agent("report_agent"),
        },
    )
    decision = await IntentControlService().resolve(session, "incident")
    assert decision.decision == "clarify"
    assert len(decision.candidates) == 2
    assert "Did you mean" in (decision.clarification_prompt or "")
