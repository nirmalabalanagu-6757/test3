AIOps4Cloud Intent Control v1 Patch
===================================

Purpose
-------
Adds a separate Dashboard > Admin > Intent Control panel and a dynamic,
PostgreSQL-backed deterministic routing stage before the existing LLM Concierge.

This patch does NOT change authentication code and does NOT include .env,
credentials, virtual environments, node_modules, caches, logs, or build output.

Apply from Git Bash or Linux
----------------------------
1. Extract this ZIP.
2. Run:

   bash scripts/apply_patch.sh /path/to/AIOps4Cloud

3. Apply the database migration using the target environment:

   cd /path/to/AIOps4Cloud
   alembic -c backend/migrations/alembic.ini upgrade head

   If Alembic is inside a virtual environment, use its full path, for example:

   .venv/bin/alembic -c backend/migrations/alembic.ini upgrade head

4. Build/redeploy the frontend and restart or roll out the application using
   the target platform's normal process.

Optional script actions
-----------------------
The apply script copies and backs up files by default. It can also run runtime
steps when explicitly requested:

   RUN_MIGRATIONS=1 BUILD_FRONTEND=1 bash scripts/apply_patch.sh /path/to/repo

For OCP, normally apply the files to the Git checkout, rebuild the image, apply
the migration through the deployment's approved migration job/process, and roll
out the updated workload.

Rollback
--------
The apply script prints the backup directory it created. Restore files with:

   bash scripts/rollback_patch.sh /path/to/AIOps4Cloud /path/to/backup

Database downgrade is intentionally not automatic. If it is safe and no later
migration depends on 023_intent_control, export all intent rules and run:

   alembic -c backend/migrations/alembic.ini downgrade 022_skywise_connector_type

This removes intent_rule and its data.

Verification
------------
   curl http://127.0.0.1:8000/health
   curl http://127.0.0.1:8000/api/intents

Open Dashboard > Admin > Intent Control and use Test Resolution. No LLM is
called by the test console.

See UPDATED_FILES.txt, PATCH_SUMMARY_FOR_CLAUDE.txt, and TEST_RESULTS.txt.
