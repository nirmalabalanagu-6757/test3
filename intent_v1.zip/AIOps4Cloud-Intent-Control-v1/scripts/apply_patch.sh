#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
PAYLOAD_DIR="${PATCH_ROOT}/payload"
TARGET_DIR="$(cd "${1:-.}" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="${TARGET_DIR}/backups/intent-control-v1-${STAMP}"

FILES=(
  "README.md"
  "POSTGRESQL_BACKEND_CHANGES.md"
  "backend/models/__init__.py"
  "backend/services/agent_runner.py"
  "frontend/src/App.tsx"
  "frontend/src/pages/DashboardPage.tsx"
  "backend/migrations/versions/023_intent_control.py"
  "backend/models/intent.py"
  "backend/routers/intents.py"
  "backend/schemas/intent.py"
  "backend/services/intent_control.py"
  "frontend/src/components/dashboard/IntentControlManager.tsx"
  "frontend/src/pages/dashboard/IntentControlPage.tsx"
  "tests/test_intent_control.py"
  "documentations/v1/README.md"
  "documentations/v1/intent-control-admin.md"
  "documentations/v1/intent-control-architecture.md"
)

if [[ ! -d "${TARGET_DIR}/backend" || ! -d "${TARGET_DIR}/frontend" ]]; then
  echo "ERROR: target does not look like the AIOps4Cloud repository: ${TARGET_DIR}" >&2
  exit 1
fi

if [[ ! -d "${PAYLOAD_DIR}" ]]; then
  echo "ERROR: patch payload is missing: ${PAYLOAD_DIR}" >&2
  exit 1
fi

ALEMBIC_CMD=()
if [[ "${RUN_MIGRATIONS:-0}" == "1" ]]; then
  if [[ -x "${TARGET_DIR}/.venv/bin/alembic" ]]; then
    ALEMBIC_CMD=("${TARGET_DIR}/.venv/bin/alembic")
  elif [[ -x "${TARGET_DIR}/venv/bin/alembic" ]]; then
    ALEMBIC_CMD=("${TARGET_DIR}/venv/bin/alembic")
  elif command -v alembic >/dev/null 2>&1; then
    ALEMBIC_CMD=("$(command -v alembic)")
  else
    echo "ERROR: RUN_MIGRATIONS=1 but Alembic was not found." >&2
    exit 1
  fi
fi

mkdir -p "${BACKUP_DIR}"

for relative in "${FILES[@]}"; do
  source_file="${PAYLOAD_DIR}/${relative}"
  target_file="${TARGET_DIR}/${relative}"
  if [[ ! -f "${source_file}" ]]; then
    echo "ERROR: missing payload file: ${relative}" >&2
    exit 1
  fi
  if [[ -f "${target_file}" ]]; then
    mkdir -p "${BACKUP_DIR}/$(dirname "${relative}")"
    cp -p "${target_file}" "${BACKUP_DIR}/${relative}"
  fi
done

for relative in "${FILES[@]}"; do
  mkdir -p "${TARGET_DIR}/$(dirname "${relative}")"
  cp -p "${PAYLOAD_DIR}/${relative}" "${TARGET_DIR}/${relative}"
done

if [[ "${RUN_MIGRATIONS:-0}" == "1" ]]; then
  (cd "${TARGET_DIR}" && "${ALEMBIC_CMD[@]}" -c backend/migrations/alembic.ini upgrade head)
fi

if [[ "${BUILD_FRONTEND:-0}" == "1" ]]; then
  if ! command -v npm >/dev/null 2>&1; then
    echo "ERROR: BUILD_FRONTEND=1 but npm was not found." >&2
    exit 1
  fi
  (cd "${TARGET_DIR}/frontend" && npm run build)
fi

echo "Intent Control v1 files applied successfully."
echo "Backup directory: ${BACKUP_DIR}"
echo "Next: run migration/build/restart steps described in README_PATCH.txt."
