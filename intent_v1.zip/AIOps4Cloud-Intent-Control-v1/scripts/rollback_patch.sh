#!/usr/bin/env bash
set -euo pipefail

TARGET_DIR="$(cd "${1:?Usage: rollback_patch.sh TARGET_DIR BACKUP_DIR}" && pwd)"
BACKUP_DIR="$(cd "${2:?Usage: rollback_patch.sh TARGET_DIR BACKUP_DIR}" && pwd)"

MODIFIED_FILES=(
  "README.md"
  "POSTGRESQL_BACKEND_CHANGES.md"
  "backend/models/__init__.py"
  "backend/services/agent_runner.py"
  "frontend/src/App.tsx"
  "frontend/src/pages/DashboardPage.tsx"
)

NEW_FILES=(
  "backend/migrations/versions/023_intent_control.py"
  "backend/models/intent.py"
  "backend/routers/intents.py"
  "backend/schemas/intent.py"
  "backend/services/intent_control.py"
  "frontend/src/components/dashboard/IntentControlManager.tsx"
  "frontend/src/pages/dashboard/IntentControlPage.tsx"
  "tests/test_intent_control.py"
  "documentations/v1/README.md"
  "documentations/v1/intent-control-admin.md"
  "documentations/v1/intent-control-architecture.md"
)

for relative in "${MODIFIED_FILES[@]}"; do
  if [[ ! -f "${BACKUP_DIR}/${relative}" ]]; then
    echo "ERROR: backup is missing ${relative}; rollback stopped." >&2
    exit 1
  fi
done

for relative in "${MODIFIED_FILES[@]}"; do
  mkdir -p "${TARGET_DIR}/$(dirname "${relative}")"
  cp -p "${BACKUP_DIR}/${relative}" "${TARGET_DIR}/${relative}"
done

for relative in "${NEW_FILES[@]}"; do
  if [[ -f "${TARGET_DIR}/${relative}" ]]; then
    rm -f -- "${TARGET_DIR}/${relative}"
  fi
done

echo "Intent Control v1 source files rolled back."
echo "Database was not downgraded. See README_PATCH.txt before removing intent_rule."
