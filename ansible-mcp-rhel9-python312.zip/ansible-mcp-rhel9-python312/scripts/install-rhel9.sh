#!/usr/bin/env bash
# Run from the extracted package as its unprivileged owner; never with sudo.
set -Eeuo pipefail
umask 077

fail() {
    printf 'Install stopped: %s\n' "$*" >&2
    exit 1
}

[[ $# -eq 0 ]] || fail 'No arguments are accepted. Configure your approved pip mirror using pip configuration or PIP_INDEX_URL.'
[[ ${EUID} -ne 0 ]] || fail 'Run as a normal user, not root or sudo. Install OS prerequisites separately with your administrator.'
[[ -r /etc/os-release ]] || fail 'Cannot read /etc/os-release; this installer targets RHEL 9.4 or later in the RHEL 9 series.'

read -r package_os_id package_os_version < <(
    . /etc/os-release
    printf '%s %s\n' "${ID:-unknown}" "${VERSION_ID:-unknown}"
)
[[ ${package_os_id} == rhel ]] || fail 'This installer targets Red Hat Enterprise Linux, not an unverified compatible distribution.'
[[ ${package_os_version} =~ ^9\.([0-9]+)(\.[0-9]+)*$ ]] || fail 'RHEL 9.4 or later in the RHEL 9 series is required.'
(( 10#${BASH_REMATCH[1]} >= 4 )) || fail 'RHEL 9.4+ is required for the distribution Python 3.12 packages.'
[[ $(uname -m) == x86_64 ]] || fail 'This release targets x86_64. Other architectures need a separate dependency and runtime validation.'

package_script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
package_root=$(cd -- "${package_script_dir}/.." && pwd -P)
package_python=$(command -v python3.12) || fail 'python3.12 is missing. Ask your administrator to install python3.12 and python3.12-pip.'
"${package_python}" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)' \
    || fail 'The python3.12 executable is not Python 3.12.'
[[ -f ${package_root}/requirements.txt && -f ${package_root}/src/server.py ]] \
    || fail 'The package is incomplete. Extract the complete ZIP into a new user-owned directory.'
[[ -f ${package_root}/requirements-rhel9-py312.lock ]] \
    || fail 'The hashed RHEL Python 3.12 dependency lock is missing. Extract the complete release ZIP.'
[[ -w ${package_root} ]] || fail 'The extracted package must be writable by the current user.'

package_venv=${package_root}/.venv
[[ ! -L ${package_venv} ]] || fail 'Refusing to modify a .venv symbolic link.'
if [[ -e ${package_venv} ]]; then
    [[ -d ${package_venv} && -f ${package_venv}/pyvenv.cfg && -x ${package_venv}/bin/python ]] \
        || fail 'An existing .venv is not a complete virtual environment. Preserve it and extract the package into a new directory.'
else
    printf '%s\n' 'Creating a local Python 3.12 virtual environment.'
    "${package_python}" -m venv "${package_venv}" \
        || fail 'Virtual environment creation failed. Confirm python3.12-pip is installed and this directory is writable.'
fi
"${package_venv}/bin/python" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) and sys.prefix != sys.base_prefix else 1)' \
    || fail 'The existing .venv is not an isolated Python 3.12 environment. Extract into a new directory; it was not deleted.'

printf '%s\n' 'Installing runtime dependencies from your configured Python package index (binary wheels only).'
if ! "${package_venv}/bin/python" -m pip install \
    --require-virtualenv --no-user --disable-pip-version-check --only-binary=:all: --require-hashes \
    -r "${package_root}/requirements-rhel9-py312.lock"; then
    fail 'Dependency installation failed. Check PyPI/approved mirror access, proxy/CA configuration, and availability of Python 3.12 Linux x86_64 wheels. No compiler fallback is attempted. This ZIP is not an offline wheel bundle.'
fi
"${package_venv}/bin/python" -m pip check \
    || fail 'Dependency consistency check failed. Resolve the reported packages before starting the server.'

export PYTHONPATH="${package_root}/src"
cd -- "${package_root}"
package_database=${ANSIBLE_DB_PATH:-${XDG_DATA_HOME:-${HOME}/.local/share}/AnsibleTemplateTools/config.sqlite3}
if [[ -e ${package_database} || -L ${package_database} ]]; then
    # A missing key for an existing database must not be silently replaced on
    # reinstall, even when that database might contain only mock registrations.
    "${package_venv}/bin/python" -m ansible_mcp.key_management check \
        || fail 'An existing database was found but its key is missing or invalid. Restore the matching key; no replacement key was generated.'
else
    "${package_venv}/bin/python" -m ansible_mcp.key_management init \
        || fail 'Credential key initialization failed. Preserve any existing key and check its ownership/permissions; never replace a key needed by an existing database.'
fi
"${package_venv}/bin/python" -m ansible_mcp.key_management check \
    || fail 'Credential key validation failed. Check ownership, permissions, and ANSIBLE_CREDENTIAL_KEY_FILE.'

printf '%s\n' 'Installation complete. No service was started and no firewall or system Python settings were changed.'
printf 'Start with: bash "%s/scripts/run-server.sh"\n' "${package_root}"
printf '%s\n' 'Then open http://127.0.0.1:8000/console (use an SSH tunnel when accessing a remote host).'
