#!/usr/bin/env bash
# Keep this local, unauthenticated administration interface on loopback only.
set -Eeuo pipefail
umask 077

if [[ ${EUID} -eq 0 ]]; then
    printf '%s\n' 'Run this server as its normal user, not root or sudo.' >&2
    exit 1
fi
if [[ $# -ne 0 ]]; then
    printf '%s\n' 'No arguments are accepted. This launcher always binds 127.0.0.1:8000.' >&2
    exit 1
fi
package_script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
package_root=$(cd -- "${package_script_dir}/.." && pwd -P)
package_python=${package_root}/.venv/bin/python
if [[ ! -x ${package_python} ]]; then
    printf '%s\n' 'Local virtual environment is missing. Run bash scripts/install-rhel9.sh first.' >&2
    exit 1
fi
"${package_python}" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) and sys.prefix != sys.base_prefix else 1)' \
    || { printf '%s\n' 'The local virtual environment must use Python 3.12.' >&2; exit 1; }

cd -- "${package_root}"
export PYTHONPATH="${package_root}/src"
export ANSIBLE_MODE="${ANSIBLE_MODE:-auto}"
# Deliberately override inherited listener options. Do not expose this service
# on 0.0.0.0 or a LAN/public interface without a separate authentication design.
export MCP_TRANSPORT=http
export MCP_HOST=127.0.0.1
export MCP_PORT=8000

"${package_python}" -m ansible_mcp.key_management check \
    || { printf '%s\n' 'Credential key check failed. Restore the correct key; do not generate a replacement for an existing encrypted database.' >&2; exit 1; }
exec "${package_python}" src/server.py
