from __future__ import annotations

import asyncio
import json
import os

from fastmcp import Client


async def main() -> None:
    endpoint = os.getenv("MCP_ENDPOINT", "http://127.0.0.1:8000/mcp")
    async with Client(endpoint) as client:
        tools = await client.list_tools()
        print("TOOLS=" + json.dumps([tool.name for tool in tools]))
        result = await client.call_tool(
            "ansible_check_disk_space_101",
            {"environment": "production", "host_group": "web"},
        )
        print("RESULT=" + json.dumps(result.structured_content, sort_keys=True))


if __name__ == "__main__":
    asyncio.run(main())
