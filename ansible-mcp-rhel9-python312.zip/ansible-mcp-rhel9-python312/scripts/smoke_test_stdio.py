from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

from fastmcp import Client
from fastmcp.client.transports import StdioTransport


async def main() -> None:
    plugin_root = Path(__file__).resolve().parents[1]
    transport = StdioTransport(
        command=sys.executable,
        args=["src/server.py"],
        cwd=str(plugin_root),
        env={**os.environ, "ANSIBLE_MODE": "mock", "PYTHONPATH": "src"},
    )
    async with Client(transport) as client:
        tools = await client.list_tools()
        print("TOOLS=" + json.dumps([tool.name for tool in tools]))


if __name__ == "__main__":
    asyncio.run(main())
