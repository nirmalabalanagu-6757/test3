# Install on RHEL 9 with Python 3.12

## Scope and prerequisites

This release targets **RHEL 9.4 or later in the RHEL 9 series, x86_64**. The installer rejects root, older releases, other distributions, and other architectures. It creates a project-local `.venv` and does not replace the operating system's Python.

Red Hat introduced `python3.12` and `python3.12-pip` in RHEL 9.4. They can be installed alongside Python 3.9; there is no need to change `/usr/bin/python3`, alternatives, or existing system tooling. [Red Hat RHEL 9.4 release notes](https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/9.4_release_notes/new-features).

You need:

- A normal user account that will own the package, key file, database, and process.
- Access to the appropriate entitled RHEL BaseOS/AppStream repositories through your subscription or organizational mirror.
- PyPI access or an approved internal Python package index containing the pinned dependencies and compatible Python 3.12 Linux x86_64 wheels.
- HTTPS reachability from this host to your Ansible Automation Controller/AWX instance and a trusted controller certificate.
- Permission to read and execute the selected Ansible job templates. No local Ansible engine or `ansible-runner` installation is required.

This archive is a source/dependency-manifest distribution, not an offline dependency bundle. Installing the OS `python3.12-pip` package alone does not install FastMCP or this application's third-party dependencies.

## 1. Install operating-system prerequisites

Have your administrator run:

```bash
sudo dnf install python3.12 python3.12-pip unzip
python3.12 --version
python3.12 -m pip --version
```

If packages are unavailable, verify the RHEL minor release, subscription, enabled repositories, and organizational mirror contents. Do not replace RHEL's Python 3.9 or install application dependencies into system Python to work around this.

## 2. Extract and install as the application user

Copy `ansible-mcp-rhel9-python312.zip` to a user-owned directory. For the optional service example, extract it in your home directory so the application is at `~/ansible-mcp-rhel9-python312`:

If you received the accompanying `ansible-mcp-rhel9-python312.zip.sha256`, optionally verify the archive before extracting it, from the directory containing both files:

```bash
sha256sum -c ansible-mcp-rhel9-python312.zip.sha256
```

Obtain the checksum through a trusted channel. A checksum detects changed content but does not authenticate the publisher by itself. Then extract and check the included file manifest before installing:

```bash
cd "$HOME"
unzip ansible-mcp-rhel9-python312.zip
cd ansible-mcp-rhel9-python312
sha256sum -c SHA256SUMS
bash scripts/install-rhel9.sh
```

Use a new destination when upgrading instead of unpacking over a running or modified installation. Do not use `sudo` for the installer. It:

1. Verifies RHEL 9.4+, x86_64, and the explicit Python 3.12 interpreter.
2. Creates `.venv`, or reuses an existing valid local Python 3.12 virtual environment without deleting it.
3. Installs the complete pinned `requirements-rhel9-py312.lock` using binary wheels only and required hash verification, then runs `pip check`. The installer fails if the lock file is missing. `requirements.txt` remains available as source dependency information.
4. Initializes and validates the user's Linux credential key for a new database. If a database already exists, it only checks the key and fails when the key is missing or invalid; it never silently creates a replacement key during reinstall. Existing keys are preserved.

It does not run `dnf`, elevate privileges, open firewall ports, install a system service, change system Python, register controller secrets, or launch a playbook.

### Approved internal Python mirror

Configure your normal pip mirror/proxy/CA settings before running the installer. For example, for a mirror that needs no inline credentials:

```bash
export PIP_INDEX_URL=https://python-mirror.example.org/simple
bash scripts/install-rhel9.sh
```

Use your organization's approved secret mechanism if mirror authentication is needed; do not place passwords or API tokens in scripts, chat, shell history, or this archive. Do not disable TLS verification to bypass certificate errors. The installer deliberately uses `--only-binary=:all:` and `--require-hashes`: missing compatible wheels or mismatched hashes cause a clear failure instead of an automatic compiler/source-build fallback. Your mirror must provide the exact locked artifacts. It does not include wheels or promise offline installation.

## 3. Start the server

```bash
bash scripts/run-server.sh
```

Keep this terminal open. Press Ctrl+C to stop the foreground server. The launcher checks the credential key, selects HTTP transport, and always binds **127.0.0.1:8000**, overriding inherited `MCP_HOST` and `MCP_PORT`. It defaults `ANSIBLE_MODE` to `auto` so saved registrations and the console load. Setting `ANSIBLE_MODE=mock` is a developer-only mode that does not restore normal saved registrations or provide the registration console.

On the RHEL host's browser, open [the registration console](http://127.0.0.1:8000/console). Use [the MCP endpoint](http://127.0.0.1:8000/mcp) only from a compatible Streamable HTTP MCP client. Opening `/mcp` directly in a browser may report a missing session ID; use `/console` for the UI.

For a remote RHEL host, run this on your workstation and keep it open:

```bash
ssh -N -o ExitOnForwardFailure=yes -L 8000:127.0.0.1:8000 your-user@your-rhel-host
```

Then open [http://127.0.0.1:8000/console](http://127.0.0.1:8000/console) on your workstation. Close any other local listener on port 8000 first. The backend console accepts its known local port, so do not substitute a different local forwarding port without deliberately updating and reviewing that configuration.

Do not bind to `0.0.0.0`, expose port 8000 through the firewall, publish it through a public reverse proxy, or treat loopback as protection against untrusted local users. There is no network login/authentication layer in this package. A shared multi-user host needs an additional access-control design.

## 4. Register templates as named tools

Select **Add Tool** in the console and provide:

- A unique tool name, such as `check_rhel_disk`.
- A template API URL, for example `https://controller.example.org/api/v2/job_templates/42/` or `https://controller.example.org/api/controller/v2/job_templates/42/`.
- A controller API token with the required read/execute permissions, entered in the masked token field.
- An optional title and optional extra variables as a JSON object, for example `{"environment":"staging","host_group":"web"}`.
- A temporary registration lifetime; the default is 24 hours.

Each tool can have its own controller URL and token. Adding it reads the template details, survey, and launch metadata, then saves the registration; it does not launch a playbook. New tools are added to the running MCP server. Refresh the tool list or reconnect your MCP client to discover them.

Saved extra variables supply defaults, runtime `extra_vars` can override them, and explicit named survey inputs take precedence. The controller must permit arbitrary extra variables at launch, or the values must be accepted enabled-survey variables. Review the generated schema. Tokens and saved variable values are not returned by the console list or exposed as tool-schema defaults.

Registration expiry blocks new launches; it does not revoke the controller token or erase the saved row. Expired/unreachable registrations remain visible for recovery. GUI names are unique and are not silently overwritten. Use the local configuration CLI to manage profiles if needed:

```bash
PYTHONPATH=src .venv/bin/python -m ansible_mcp.configure list
PYTHONPATH=src .venv/bin/python -m ansible_mcp.configure --help
```

Do not place real tokens in command-line arguments or source files.

## 5. Connect an MCP client

The example [examples/mcp-client.json](examples/mcp-client.json) uses the common `mcpServers` configuration shape with a Streamable HTTP URL. Client-specific field names may differ; adapt the example to your AIOps platform's MCP connector.

Use `http://127.0.0.1:8000/mcp` on the RHEL host or on a workstation with the SSH tunnel above. A container or remote AIOps service has its own network namespace: its `127.0.0.1` is not this host. Do not solve that by publicly exposing the unauthenticated server; arrange an authenticated private connection appropriate to that platform first.

## Credential storage and backups

Default Linux paths are:

| Item | Default | Override |
| --- | --- | --- |
| Encryption key | `~/.config/ansible-template-tools/credential.key` | `ANSIBLE_CREDENTIAL_KEY_FILE`; default directory also follows `XDG_CONFIG_HOME` |
| SQLite registration database | `~/.local/share/AnsibleTemplateTools/config.sqlite3` | `ANSIBLE_DB_PATH`; default directory also follows `XDG_DATA_HOME` |

The key is created with mode `0600` in an owner-only `0700` directory. Use absolute paths for any key/database/XDG overrides, and keep them consistent between installation, the launcher, and an optional service. Run the service as the same normal user used for installation. Do not print, email, commit, or package the key. A process that can access both the key and database as that user can decrypt the saved secrets; this is not a hardware-backed secret vault.

Check the key without printing its contents:

```bash
PYTHONPATH=src .venv/bin/python -m ansible_mcp.key_management check
```

Stop the server before taking a consistent database backup. Back up the encrypted database and its matching key separately in approved secure storage, preserving owner-only permissions. Losing or replacing the key makes existing encrypted values unreadable; restore the original matching key or create fresh registrations with new credentials. Do not generate a replacement key over an existing one.

Windows uses user-scoped DPAPI, not this Linux key. A Windows registration database is **not portable to this Linux installation**. Do not copy Windows credential databases or `.venv` directories into the package; register the templates again locally on RHEL.

The application and packaged dependency choices have **not been certified for FIPS compliance**. A RHEL host being configured for FIPS does not establish application certification. Obtain your organization's security review before using this with that requirement.

## Optional: systemd user service

The supplied unit assumes the package is at `~/ansible-mcp-rhel9-python312`. Edit its `WorkingDirectory` and `ExecStart` paths if you chose another directory. Use a **user** service, not a root system service:

```bash
mkdir -p "$HOME/.config/systemd/user"
install -m 0644 systemd/ansible-mcp.service "$HOME/.config/systemd/user/ansible-mcp.service"
systemctl --user daemon-reload
systemctl --user enable --now ansible-mcp.service
systemctl --user status ansible-mcp.service
```

Stop an existing foreground server before enabling the unit. Useful commands:

```bash
journalctl --user -u ansible-mcp.service -f
systemctl --user restart ansible-mcp.service
systemctl --user stop ansible-mcp.service
```

If the service must remain running after logout, ask your administrator whether user lingering is appropriate under your organization's policy. It is not enabled automatically. Custom XDG paths or key/database overrides must also be set in the user unit's environment; never store API tokens in that unit.

## Troubleshooting and validation limits

- **RHEL is below 9.4 or Python 3.12 is missing:** obtain a supported RHEL update and install the distribution Python 3.12 stack. Do not redirect the system Python interpreter.
- **Pip cannot find a dependency/wheel:** check your approved index, outbound access, architecture, Python version, proxy, and CA trust. OS RPM repositories do not replace a Python package index. There is no bundled offline dependency set.
- **Existing `.venv` has another Python version:** preserve it, extract this release into a new user-owned directory, and run the installer there. The script will not delete it.
- **Key check fails:** preserve the existing key and database; verify the same owner account, selected key path, and secure permissions. Restore the original key if it was lost. Do not silently reset it. The installer also refuses to create a key for an existing empty/mock-only database; only after confirming that no encrypted data needs recovery may you deliberately run `PYTHONPATH=src .venv/bin/python -m ansible_mcp.key_management init` and retry.
- **Controller certificate or permissions fail:** use a trusted HTTPS controller and the correct API URL/token permissions. Do not disable certificate validation. No playbook runs during registration.
- **Tool not visible:** check the console status, expiry, and controller access, then refresh/reconnect the MCP client. The seven underlying controller actions are private implementation helpers, not separately published tools.
- **Port 8000 is in use:** stop the other local server/tunnel or choose a separately reviewed deployment configuration. The supplied launcher intentionally uses only loopback port 8000.

This package was prepared on Windows. Cross-target dependency validation successfully downloaded, hash-verified, and installed the **71 locked Linux/pure-Python wheel artifacts** into a verification directory for CPython 3.12, Linux x86_64, and the `manylinux_2_34` target. That checks compatible artifact availability and hashes; it does not execute the application under Linux.

No native RHEL, Docker, Podman, or WSL environment was available for a full RHEL installation/run test. Source-level tests, shell syntax checks, and package checks do not replace a staging deployment on your target RHEL host.

An optional local test run uses a separate environment so development dependencies do not change the locked application runtime:

```bash
python3.12 -m venv .venv-tests
.venv-tests/bin/python -m pip install --require-virtualenv --no-user --only-binary=:all: -r requirements-dev.txt
PYTHONPATH=src .venv-tests/bin/python -m pytest tests -q
```

Tests use temporary storage and mocked controllers; running them does not prove real controller connectivity or launch permissions.
