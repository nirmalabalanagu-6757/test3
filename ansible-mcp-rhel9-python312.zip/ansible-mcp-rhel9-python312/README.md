# Ansible MCP server — RHEL 9 / Python 3.12

This source package runs a local FastMCP server and an Add Tool browser console. Each registered Ansible Automation Controller/AWX job template becomes a named MCP tool. Ansible runs the playbooks on the controller; this package does not require `ansible-runner` or local playbooks.

Target: RHEL 9.4 or newer within RHEL 9, x86_64, using a separate Python 3.12 virtual environment. **This package has not been installed or tested on a native RHEL host in the current development environment.** Follow [INSTALL_RHEL9.md](INSTALL_RHEL9.md) for prerequisites, security notes, troubleshooting, and optional service setup.

After an administrator installs `python3.12`, `python3.12-pip`, and `unzip`, extract the ZIP into your own directory and run as a normal user:

```bash
cd ansible-mcp-rhel9-python312
bash scripts/install-rhel9.sh
bash scripts/run-server.sh
```

The installer needs PyPI or an approved internal Python package mirror. It downloads binary runtime dependencies pinned by `requirements-rhel9-py312.lock` and verifies their hashes; **this is not an offline installer** and includes no Linux virtual environment or wheel bundle.

- Console: [http://127.0.0.1:8000/console](http://127.0.0.1:8000/console)
- MCP endpoint: [http://127.0.0.1:8000/mcp](http://127.0.0.1:8000/mcp) — connect an MCP client; this is not a browser page.
- Remote machine: use an SSH tunnel, not a public listener. See the installation guide.

In **Add Tool**, enter a unique tool name, the full template API URL, an API token with template read/execute permission, and optional saved extra variables as a JSON object. Registering a tool reads metadata; it does not run a playbook. Invoking the tool can launch the Ansible job and waits for its result. Arbitrary extra variables require the controller template to allow variables at launch; enabled survey fields remain supported.

Tokens and saved extra variables are encrypted in a per-user local SQLite database. Linux uses a separate owner-only key file. The key and database are not included in this archive. Do not copy an existing Windows DPAPI database to Linux; create new registrations on the target host. The implementation is not certified for FIPS compliance.

The default 24-hour registration expiry prevents new launches after expiration; it does not erase saved database rows. Keep the service and console available only to trusted local users or through your SSH session.
