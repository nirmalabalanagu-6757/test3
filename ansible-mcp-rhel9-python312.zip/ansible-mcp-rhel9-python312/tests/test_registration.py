from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
import pytest
import respx
from fastmcp import Client

from ansible_mcp import configure
from ansible_mcp.controller import MockControllerClient
from ansible_mcp.execution import execute_template
from ansible_mcp.server import create_server
from ansible_mcp.settings import Settings
from ansible_mcp.storage import LocalStore, StorageError


@pytest.fixture(autouse=True)
def clean_environment(monkeypatch, tmp_path):
    for variable in (
        "ANSIBLE_MODE", "ANSIBLE_CONTROLLER_URL", "ANSIBLE_CONTROLLER_TOKEN",
        "ANSIBLE_TEMPLATE_ALLOWLIST", "ANSIBLE_API_PATH", "ANSIBLE_VERIFY_TLS",
        "ANSIBLE_JOB_TIMEOUT_SECONDS", "ANSIBLE_POLL_INTERVAL_SECONDS",
    ):
        monkeypatch.delenv(variable, raising=False)
    monkeypatch.setenv("ANSIBLE_DB_PATH", str(tmp_path / "registration.sqlite3"))
    monkeypatch.setenv("ANSIBLE_POLL_INTERVAL_SECONDS", "0.001")


def test_empty_database_falls_back_to_mock(tmp_path):
    assert Settings.from_env(tmp_path).mode == "mock"


async def test_saved_custom_tool_name_loads_and_invokes(tmp_path):
    database = LocalStore(tmp_path / "registration.sqlite3")
    database.save_connection("demo", mode="mock", templates=[
        {"id": 101, "tool_name": "my_disk_check", "name": "My Disk Check", "risk": "read-only"},
    ])
    settings = Settings.from_env(tmp_path)
    controller = MockControllerClient()
    server = await create_server(settings, controller)
    async with Client(server) as client:
        tools = await client.list_tools()
        result = await client.call_tool("my_disk_check", {"environment": "development", "host_group": "test"})
    assert [tool.name for tool in tools] == ["my_disk_check"]
    assert tools[0].title == "My Disk Check"
    assert "token" not in tools[0].input_schema["properties"]
    assert result.structured_content["template_id"] == 101
    assert result.structured_content["status"] == "successful"
    assert controller.jobs[5001]["template_id"] == 101


def test_expired_active_database_does_not_silently_fallback(tmp_path):
    old_clock = lambda: datetime.now(timezone.utc) - timedelta(days=2)
    LocalStore(tmp_path / "registration.sqlite3", clock=old_clock).save_connection("old", mode="mock")
    with pytest.raises(StorageError, match="expired"):
        Settings.from_env(tmp_path)


def test_explicit_mock_ignores_expired_database(monkeypatch, tmp_path):
    old_clock = lambda: datetime.now(timezone.utc) - timedelta(days=2)
    LocalStore(tmp_path / "registration.sqlite3", clock=old_clock).save_connection("old", mode="mock")
    monkeypatch.setenv("ANSIBLE_MODE", "mock")
    assert Settings.from_env(tmp_path).mode == "mock"


async def test_expiry_is_checked_at_invocation():
    settings = Settings(expires_at=(datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat())
    controller = MockControllerClient()
    with pytest.raises(ValueError, match="expired"):
        await execute_template(controller, settings, controller.templates[101], {})
    assert controller.jobs == {}


def test_partial_environment_does_not_borrow_saved_token(monkeypatch, tmp_path):
    LocalStore(tmp_path / "registration.sqlite3").save_connection("demo", mode="mock")
    monkeypatch.setenv("ANSIBLE_CONTROLLER_URL", "https://different.example.com")
    with pytest.raises(ValueError, match="TOKEN"):
        Settings.from_env(tmp_path)


def test_token_not_in_settings_repr():
    assert "secret-test-value" not in repr(Settings(controller_token="secret-test-value"))


@pytest.mark.parametrize("value", ["42", "https://controller.example.com/api/v2/job_templates/42/", "https://controller.example.com/api/v2/job_templates/42/launch/"])
def test_template_id_or_api_url(value):
    assert configure.template_id_from_address(value, "https://controller.example.com", "/api/v2/") == 42


@pytest.mark.parametrize("value", ["0", "-1", "https://evil.example.com/api/v2/job_templates/42/", "http://controller.example.com/api/v2/job_templates/42/", "https://controller.example.com/api/v2/job_templates/42/?token=secret", "https://user@controller.example.com/api/v2/job_templates/42/", "https://controller.example.com/#/templates/42"])
def test_rejects_wrong_template_addresses(value):
    with pytest.raises(ValueError):
        configure.template_id_from_address(value, "https://controller.example.com", "/api/v2/")


def test_cli_demo_list_replace_and_delete(tmp_path, capsys):
    assert configure.main(["save-demo", "demo"]) == 0
    assert configure.main(["save-demo", "demo"]) == 1
    assert configure.main(["list"]) == 0
    output = capsys.readouterr().out
    assert '"has_credential": false' in output
    assert '"tool_name": "ansible_check_disk_space_101"' in output
    assert configure.main(["delete", "demo"]) == 0
    assert LocalStore(tmp_path / "registration.sqlite3").load_active() is None


def test_save_cli_uses_hidden_token_prompt(monkeypatch, capsys):
    answers = iter(["https://controller.example.com", "/api/v2/", "24", "42", "my_restart", "My Restart", "n"])
    monkeypatch.setattr("builtins.input", lambda _: next(answers))
    monkeypatch.setattr(configure.getpass, "getpass", lambda _: "hidden-test-token")
    calls = []
    monkeypatch.setattr(LocalStore, "save_connection", lambda self, name, **kwargs: calls.append((name, kwargs)))
    assert configure.main(["save", "controller"]) == 0
    assert calls[0][1]["token"] == "hidden-test-token"
    assert calls[0][1]["templates"][0]["tool_name"] == "my_restart"
    assert "hidden-test-token" not in capsys.readouterr().out


def test_real_controller_rejects_empty_allowlist():
    with pytest.raises(ValueError, match="approved template"):
        Settings(mode="controller", controller_url="https://controller.example.com", controller_token="test").validate()


@respx.mock
async def test_db_controller_custom_tool_only_calls_selected_api(monkeypatch, tmp_path):
    # Fake protector for portable integration; DPAPI itself is covered in storage tests.
    class TestProtector:
        def encrypt(self, value):
            return b"opaque-test-ciphertext"

        def decrypt(self, value):
            assert value == b"opaque-test-ciphertext"
            return "integration-test-token"

    original_init = LocalStore.__init__
    def test_init(self, path=None, **kwargs):
        original_init(self, path, protector=TestProtector(), **kwargs)
    monkeypatch.setattr(LocalStore, "__init__", test_init)
    LocalStore(tmp_path / "registration.sqlite3").save_connection(
        "test", mode="controller", base_url="https://controller.example.com",
        api_path="/api/controller/v2/", token="integration-test-token",
        templates=[{"id": 42, "tool_name": "my_restart"}],
    )
    base = "https://controller.example.com/api/controller/v2/"
    respx.get(base + "job_templates/42/").respond(200, json={"id": 42, "name": "Restart"})
    respx.get(base + "job_templates/42/survey_spec/").respond(200, json={"spec": []})
    respx.get(base + "job_templates/42/launch/").respond(200, json={})
    launch = respx.post(base + "job_templates/42/launch/").respond(201, json={"job": 99})
    respx.get(base + "jobs/99/").respond(200, json={"id": 99, "status": "successful"})
    respx.get(base + "jobs/99/stdout/?format=json").respond(200, json={"content": "done"})
    server = await create_server(Settings.from_env(tmp_path))
    async with Client(server) as client:
        tools = await client.list_tools()
        result = await client.call_tool("my_restart", {})
    assert [tool.name for tool in tools] == ["my_restart"]
    assert result.structured_content["job_id"] == 99
    assert launch.calls[0].request.headers["Authorization"] == "Bearer integration-test-token"
    assert all("integration-test-token" not in json.dumps(tool.model_dump()) for tool in tools)
