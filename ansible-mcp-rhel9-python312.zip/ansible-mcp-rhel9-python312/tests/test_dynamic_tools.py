from __future__ import annotations

from fastmcp import Client

from ansible_mcp.controller import MockControllerClient
from ansible_mcp.server import create_server
from ansible_mcp.settings import Settings


def mock_settings() -> Settings:
    return Settings(
        mode="mock",
        poll_interval_seconds=0.001,
        timeout_seconds=1,
        risk_by_template_id={101: "read-only", 102: "write", 103: "write"},
    )


async def test_registers_templates_as_tools_only() -> None:
    server = await create_server(mock_settings(), MockControllerClient())
    async with Client(server) as client:
        tools = await client.list_tools()

    names = {tool.name for tool in tools}
    assert names == {
        "ansible_check_disk_space_101",
        "ansible_restart_nginx_102",
        "ansible_deploy_application_103",
    }
    assert "launch_template" not in names
    assert "get_job_status" not in names


async def test_generated_schema_contains_survey_fields() -> None:
    server = await create_server(mock_settings(), MockControllerClient())
    async with Client(server) as client:
        tools = await client.list_tools()

    tool = next(item for item in tools if item.name == "ansible_restart_nginx_102")
    assert set(tool.input_schema["required"]) == {"environment", "host_group"}
    assert tool.input_schema["properties"]["environment"]["enum"] == [
        "development",
        "staging",
        "production",
    ]
    assert "extra_vars" in tool.input_schema["properties"]


async def test_template_tool_launches_monitors_and_redacts_output() -> None:
    server = await create_server(mock_settings(), MockControllerClient())
    async with Client(server) as client:
        result = await client.call_tool(
            "ansible_check_disk_space_101",
            {"environment": "production", "host_group": "web"},
        )

    assert result.is_error is False
    assert result.structured_content["status"] == "successful"
    assert result.structured_content["job_id"] == 5001
    assert "[REDACTED]" in result.structured_content["output"]["content"]
    assert "secret=redacted-by-server" not in result.structured_content["output"]["content"]
