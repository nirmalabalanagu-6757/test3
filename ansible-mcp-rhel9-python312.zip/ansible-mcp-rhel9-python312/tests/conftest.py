"""Keep Linux credential tests independent of the developer's real key file."""

from __future__ import annotations

import os

import pytest


@pytest.fixture(autouse=True)
def isolated_posix_credential_key(monkeypatch, tmp_path):
    if os.name == "posix":
        from ansible_mcp.posix_secrets import initialize_key

        key_path = tmp_path / "private-credentials" / "credential.key"
        monkeypatch.setenv("ANSIBLE_CREDENTIAL_KEY_FILE", str(key_path))
        initialize_key(key_path)
