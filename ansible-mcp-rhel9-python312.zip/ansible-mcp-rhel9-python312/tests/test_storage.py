from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from ansible_mcp.storage import (
    LocalStore, StorageError, WindowsDPAPIProtector, validate_extra_vars, validate_templates,
)


class FakeProtector:
    """Test double only: production always defaults to Windows DPAPI."""

    def __init__(self) -> None:
        self.decrypt_calls = 0

    def encrypt(self, value: str) -> bytes:
        return b"test-protected:" + value[::-1].encode()

    def decrypt(self, value: bytes) -> str:
        self.decrypt_calls += 1
        assert value.startswith(b"test-protected:")
        return value[len(b"test-protected:"):].decode()[::-1]


class TestClock:
    __test__ = False

    def __init__(self) -> None:
        self.value = datetime(2026, 9, 22, 12, tzinfo=timezone.utc)

    def __call__(self) -> datetime:
        return self.value


@pytest.fixture
def local_store(tmp_path: Path):
    protector = FakeProtector()
    clock = TestClock()
    return LocalStore(tmp_path / "config.sqlite3", protector=protector, clock=clock), protector, clock


def save_controller(store: LocalStore, name: str = "production", **overrides) -> None:
    options = {
        "mode": "controller", "base_url": "https://controller.example.com/",
        "token": "not-a-real-token-SECRET-MARKER", "templates": [
            {"id": 42, "name": "Check Disk", "risk": "read-only", "tool_name": "Check_Disk"},
            {"id": 58},
        ],
    }
    options.update(overrides)
    store.save_connection(name, **options)


def test_encrypted_roundtrip_and_sanitized_list(local_store) -> None:
    store, protector, clock = local_store
    save_controller(store)
    loaded = store.load_active()
    assert loaded is not None
    assert loaded.name == "production"
    assert loaded.mode == "controller"
    assert loaded.base_url == "https://controller.example.com"
    assert loaded.api_path == "/api/v2/"
    assert loaded.token == "not-a-real-token-SECRET-MARKER"
    assert loaded.expires_at == "2026-09-23T12:00:00Z"
    assert loaded.verify_tls and loaded.active
    assert loaded.templates[0]["tool_name"] == "Check_Disk"
    assert loaded.templates[1] == {"id": 58, "risk": "write"}
    assert "SECRET-MARKER" not in repr(loaded)
    assert b"SECRET-MARKER" not in store.path.read_bytes()
    records = store.list_connections()
    assert protector.decrypt_calls == 1  # Listing never unlocks any token.
    assert records[0]["has_credential"] is True
    assert records[0]["active"] is True
    assert records[0]["expired"] is False
    assert "token" not in records[0] and "credential" not in records[0]
    assert "SECRET-MARKER" not in json.dumps(records)
    assert "test-protected" not in json.dumps(records)
    with sqlite3.connect(store.path) as database:
        encrypted = database.execute("SELECT credential FROM connections").fetchone()[0]
        assert isinstance(encrypted, bytes)
        assert encrypted != loaded.token.encode()


def test_empty_and_mock_store_need_no_encryption(tmp_path: Path) -> None:
    class ForbiddenProtector:
        def encrypt(self, value):
            pytest.fail("Mock connections must not encrypt credentials")

        def decrypt(self, value):
            pytest.fail("Mock connections must not decrypt credentials")

    store = LocalStore(tmp_path / "nested" / "config.sqlite3", protector=ForbiddenProtector())
    assert store.path.is_absolute()
    assert store.load_active() is None
    assert store.list_connections() == []
    store.save_connection("demo", mode="mock", templates=[{"id": 101, "tool_name": "check_disk"}])
    loaded = store.load_active()
    assert loaded is not None and loaded.mode == "mock"
    assert loaded.token is None and loaded.base_url is None
    assert store.list_connections()[0]["has_credential"] is False


def test_expired_active_connection_fails_closed(local_store) -> None:
    store, protector, clock = local_store
    store.save_connection("demo", mode="mock", ttl_hours=48)
    save_controller(store, ttl_hours=1)
    clock.value += timedelta(hours=1)
    records = store.list_connections()
    assert records[1]["active"] is True and records[1]["expired"] is True
    with pytest.raises(StorageError, match="expired"):
        store.load_active()
    with pytest.raises(StorageError, match="expired"):
        store.activate("production")
    assert protector.decrypt_calls == 0
    save_controller(store, ttl_hours=1)
    assert store.load_active().name == "production"


def test_upsert_replaces_credential_and_template_selection(local_store) -> None:
    store, _, clock = local_store
    save_controller(store)
    clock.value += timedelta(minutes=30)
    save_controller(store, token="replacement-token", templates=[{"id": 73, "tool_name": "deploy_app"}], api_path="/api/controller/v2")
    connection = store.load_active()
    assert connection.token == "replacement-token"
    assert connection.api_path == "/api/controller/v2/"
    assert connection.templates == [{"id": 73, "risk": "write", "tool_name": "deploy_app"}]
    metadata = store.list_connections()
    assert len(metadata) == 1
    assert metadata[0]["created_at"] == "2026-09-22T12:00:00Z"
    assert metadata[0]["updated_at"] == "2026-09-22T12:30:00Z"
    assert b"replacement-token" not in store.path.read_bytes()


def test_create_only_across_stores_preserves_existing_registration(local_store) -> None:
    first, protector, clock = local_store
    second = LocalStore(first.path, protector=protector, clock=clock)
    save_controller(first, create_only=True, templates=[
        {"id": 42, "tool_name": "Check_Disk", "extra_vars": {"key": "ORIGINAL-VARS"}}, {"id": 58},
    ])
    second.save_connection("demo", mode="mock", create_only=True)
    before = first.list_connections()
    with pytest.raises(StorageError, match="already exists") as raised:
        save_controller(second, token="NEVER-REPLACE-TOKEN", create_only=True,
                        templates=[{"id": 99, "tool_name": "replacement", "extra_vars": {"key": "REPLACED-VARS"}}])
    assert "NEVER-REPLACE-TOKEN" not in str(raised.value)
    assert first.list_connections() == before
    original = first.load_connection("production")
    assert original.token == "not-a-real-token-SECRET-MARKER"
    assert [item["id"] for item in original.templates] == [42, 58]
    assert original.templates[0]["tool_name"] == "Check_Disk"
    assert original.templates[0]["extra_vars"] == {"key": "ORIGINAL-VARS"}
    assert first.load_active().name == "demo"
    assert second.load_active().name == "demo"


def test_switch_and_delete_connections_decrypt_only_active(local_store) -> None:
    store, protector, _ = local_store
    save_controller(store)
    save_controller(store, "other", token="other-token", activate=False)
    assert store.load_active().name == "production"
    assert protector.decrypt_calls == 1
    store.activate("other")
    assert store.load_active().token == "other-token"
    store.delete_connection("production")
    assert store.load_active().name == "other"
    store.delete_connection("other")
    assert store.load_active() is None
    assert store.list_connections() == []
    with sqlite3.connect(store.path) as database:
        assert database.execute("SELECT COUNT(*) FROM templates").fetchone()[0] == 0
    store.delete_connection("absent")
    with pytest.raises(StorageError, match="does not exist"):
        store.activate("absent")


def test_load_inactive_connection_does_not_switch_or_decrypt_active(local_store) -> None:
    store, protector, _ = local_store
    save_controller(store)
    save_controller(store, "gui-check-disk", token="gui-TOKEN-MARKER", activate=False,
                    templates=[{"id": 73, "tool_name": "chosen_tool"}])
    metadata_before = store.list_connections()
    connection = store.load_connection("gui-check-disk")
    assert connection is not None
    assert connection.name == "gui-check-disk" and connection.active is False
    assert connection.token == "gui-TOKEN-MARKER"
    assert connection.templates == [{"id": 73, "risk": "write", "tool_name": "chosen_tool"}]
    assert protector.decrypt_calls == 1
    assert "gui-TOKEN-MARKER" not in repr(connection)
    assert b"gui-TOKEN-MARKER" not in store.path.read_bytes()
    assert store.list_connections() == metadata_before
    active = store.load_active()
    assert active is not None and active.name == "production" and active.active is True
    assert active.token == "not-a-real-token-SECRET-MARKER"
    assert store.load_connection("production").active is True


def test_load_named_connection_without_any_active_selection(local_store) -> None:
    store, _, _ = local_store
    store.save_connection("gui-demo", mode="mock", activate=False)
    connection = store.load_connection("gui-demo")
    assert connection is not None and connection.mode == "mock"
    assert connection.active is False and connection.token is None
    assert store.load_active() is None


def test_load_missing_or_invalid_named_connection_does_not_change_active(local_store) -> None:
    store, protector, _ = local_store
    store.save_connection("demo", mode="mock")
    assert store.load_connection("gui-missing") is None
    assert protector.decrypt_calls == 0
    with pytest.raises(StorageError, match="Connection names"):
        store.load_connection("../production")
    assert store.load_active().name == "demo"


def test_load_expired_named_connection_refuses_before_decryption(local_store) -> None:
    store, protector, clock = local_store
    store.save_connection("demo", mode="mock", ttl_hours=48)
    save_controller(store, "gui-expiring", ttl_hours=1, activate=False)
    clock.value += timedelta(hours=1)
    with pytest.raises(StorageError, match="selected local connection has expired"):
        store.load_connection("gui-expiring")
    assert protector.decrypt_calls == 0
    assert store.load_active().name == "demo"


def test_named_connection_validates_saved_data_without_switching(local_store) -> None:
    store, _, _ = local_store
    store.save_connection("demo", mode="mock")
    save_controller(store, "gui-corrupt", activate=False)
    with sqlite3.connect(store.path) as database:
        database.execute("UPDATE connections SET api_path = '/api/../private/' WHERE name = 'gui-corrupt'")
    with pytest.raises(StorageError, match="API path"):
        store.load_connection("gui-corrupt")
    assert store.load_active().name == "demo"


@pytest.mark.parametrize("url", [
    "http://controller.example.com", "https://user:password@controller.example.com",
    "https://controller.example.com/api/v2/", "https://controller.example.com?token=secret",
    "https://controller.example.com#fragment", "https://controller.example.com?",
    "https://controller.example.com#", "https://controller.example.com:70000",
    "https://controller.example.com\\@other.example.com", "https://controller.example.com\n",
    "https://", "controller.example.com", None,
])
def test_rejects_unsafe_controller_urls(local_store, url) -> None:
    store, _, _ = local_store
    with pytest.raises(StorageError, match="HTTPS origin"):
        save_controller(store, base_url=url)
    assert store.list_connections() == []


@pytest.mark.parametrize("api_path", [
    "https://elsewhere.example.com/api/v2/", "//elsewhere/api/v2/", "/api/../v2/",
    "/api/%2e%2e/v2/", "/api/v2/?token=secret", "/api//v2/", "api/v2/", "/other/v2/",
    "/api\\v2/", "/api/", None,
])
def test_rejects_arbitrary_or_traversal_api_paths(local_store, api_path) -> None:
    with pytest.raises(StorageError, match="API path"):
        save_controller(local_store[0], api_path=api_path)


@pytest.mark.parametrize("templates", [
    [], [{"id": 0}], [{"id": -1}], [{"id": True}], [{"id": "42"}], [{"id": 2**63}],
    [{"id": 42}, {"id": 42}], [{"id": 42, "risk": "admin"}], [{"id": 42, "risk": []}],
    [{"id": 42, "url": "https://elsewhere.example.com"}], [{"id": 42, "name": ""}],
    [{"id": 42, "tool_name": "bad-name"}], [{"id": 42, "tool_name": "9bad"}],
    [{"id": 42, "tool_name": "a" * 65}], [{"id": 42, "tool_name": "x"}, {"id": 58, "tool_name": "x"}],
])
def test_rejects_invalid_selected_templates(local_store, templates) -> None:
    with pytest.raises(StorageError):
        save_controller(local_store[0], templates=templates)


@pytest.mark.parametrize("options", [
    {"mode": "other"}, {"mode": []}, {"ttl_hours": 0}, {"ttl_hours": -1},
    {"ttl_hours": float("inf")}, {"ttl_hours": float("nan")}, {"ttl_hours": True},
    {"ttl_hours": "24"}, {"ttl_hours": 1e300}, {"ttl_hours": 10**1000}, {"token": ""}, {"token": "\nsecret"},
    {"token": " padded "}, {"verify_tls": "false"}, {"activate": "true"}, {"create_only": "true"},
])
def test_rejects_invalid_settings_without_saving(local_store, options) -> None:
    with pytest.raises(StorageError):
        save_controller(local_store[0], **options)
    assert local_store[0].list_connections() == []


@pytest.mark.parametrize("name", ["", "../production", "prod name", "name;DROP", "a" * 65])
def test_rejects_invalid_connection_names(local_store, name) -> None:
    with pytest.raises(StorageError, match="Connection names"):
        save_controller(local_store[0], name)


def test_mock_mode_refuses_credentials_and_urls(local_store) -> None:
    store, _, _ = local_store
    with pytest.raises(StorageError, match="Mock connections"):
        store.save_connection("demo", mode="mock", token="secret")
    with pytest.raises(StorageError, match="Mock connections"):
        store.save_connection("demo", mode="mock", base_url="https://example.com")


def test_database_failure_rolls_back_replacement_and_active_switch(local_store) -> None:
    store, _, _ = local_store
    save_controller(store)
    store.save_connection("demo", mode="mock")
    with sqlite3.connect(store.path) as database:
        database.execute(
            "CREATE TRIGGER reject_test_template BEFORE INSERT ON templates "
            "WHEN NEW.template_id = 999 BEGIN SELECT RAISE(ABORT, 'secret-error-test'); END"
        )
    with pytest.raises(StorageError) as raised:
        save_controller(store, token="not-saved-token", templates=[{"id": 999}])
    assert "secret-error-test" not in str(raised.value)
    assert store.load_active().name == "demo"
    store.activate("production")
    restored = store.load_active()
    assert restored.token == "not-a-real-token-SECRET-MARKER"
    assert [item["id"] for item in restored.templates] == [42, 58]


def test_failed_encryption_does_not_change_saved_configuration(local_store) -> None:
    store, _, _ = local_store
    save_controller(store)

    class BrokenProtector:
        def encrypt(self, value):
            raise RuntimeError(value)

    failing = LocalStore(store.path, protector=BrokenProtector())
    with pytest.raises(StorageError) as raised:
        save_controller(failing, token="sensitive-new-token")
    assert "sensitive-new-token" not in str(raised.value)
    assert store.load_active().token == "not-a-real-token-SECRET-MARKER"


@pytest.mark.parametrize("version", [0, 3, 999])
def test_unknown_schema_version_fails_closed(local_store, version) -> None:
    store, _, _ = local_store
    save_controller(store)
    with sqlite3.connect(store.path) as database:
        database.execute(f"PRAGMA user_version = {version}")
    with pytest.raises(StorageError, match="schema"):
        LocalStore(store.path, protector=FakeProtector())


def test_wrong_schema_with_matching_version_is_rejected(tmp_path: Path) -> None:
    path = tmp_path / "wrong.sqlite3"
    with sqlite3.connect(path) as database:
        database.execute("CREATE TABLE connections (name TEXT)")
        database.execute("PRAGMA user_version = 1")
    with pytest.raises(StorageError, match="schema"):
        LocalStore(path, protector=FakeProtector())


def test_corrupt_ciphertext_reports_no_secret(local_store) -> None:
    store, _, _ = local_store
    save_controller(store)
    with sqlite3.connect(store.path) as database:
        database.execute("UPDATE connections SET credential = ?", (b"SECRET-CORRUPT",))
    with pytest.raises(StorageError) as raised:
        store.load_active()
    assert "SECRET-CORRUPT" not in str(raised.value)


def test_secure_delete_enabled_for_each_database_connection(local_store) -> None:
    with local_store[0]._connection() as database:
        assert database.execute("PRAGMA secure_delete").fetchone()[0] == 1
        assert database.execute("PRAGMA foreign_keys").fetchone()[0] == 1


@pytest.mark.skipif(os.name != "nt", reason="Windows DPAPI integration test")
def test_real_windows_dpapi_roundtrip_uses_current_user(tmp_path: Path) -> None:
    store = LocalStore(tmp_path / "windows.sqlite3")
    save_controller(store, token="real-dpapi-test-marker-\u20ac", templates=[
        {"id": 42, "extra_vars": {"secret": "real-extra-var-marker-\u20ac"}},
    ])
    assert store.load_active().token == "real-dpapi-test-marker-\u20ac"
    assert store.load_active().templates[0]["extra_vars"] == {"secret": "real-extra-var-marker-\u20ac"}
    assert b"real-dpapi-test-marker" not in store.path.read_bytes()
    assert b"real-extra-var-marker" not in store.path.read_bytes()


@pytest.mark.skipif(os.name == "nt", reason="Non-Windows behavior")
def test_non_windows_rejects_credential_encryption() -> None:
    with pytest.raises(StorageError, match="Windows DPAPI"):
        WindowsDPAPIProtector().encrypt("secret")


def test_extra_vars_are_encrypted_reloaded_and_not_listed(local_store) -> None:
    store, protector, clock = local_store
    variables = {"environment": "production", "nested": {"value": "SECRET-EXTRA-MARKER"},
                 "flags": [True, False, None, 5, 1.25, {"region": "eu"}]}
    save_controller(store, templates=[{"id": 42, "tool_name": "disk_check", "extra_vars": variables}, {"id": 58}])
    records = store.list_connections()
    assert protector.decrypt_calls == 0
    assert records[0]["templates"][0] == {"id": 42, "risk": "write", "tool_name": "disk_check", "has_extra_vars": True}
    assert records[0]["templates"][1] == {"id": 58, "risk": "write"}
    assert "SECRET-EXTRA-MARKER" not in json.dumps(records)
    assert "nested" not in json.dumps(records)
    assert "test-protected" not in json.dumps(records)
    with sqlite3.connect(store.path) as database:
        ciphertext = database.execute("SELECT extra_vars FROM templates WHERE template_id = 42").fetchone()[0]
        assert isinstance(ciphertext, bytes) and ciphertext.startswith(b"test-protected:")
        assert database.execute("SELECT extra_vars FROM templates WHERE template_id = 58").fetchone()[0] is None
    assert b"SECRET-EXTRA-MARKER" not in store.path.read_bytes()
    reopened = LocalStore(store.path, protector=protector, clock=clock)
    loaded = reopened.load_connection("production")
    assert loaded.templates[0]["extra_vars"] == variables
    assert "SECRET-EXTRA-MARKER" not in repr(loaded)
    assert reopened.load_active().templates[0]["extra_vars"] == variables
    variables["nested"]["value"] = "mutated"
    assert loaded.templates[0]["extra_vars"]["nested"]["value"] == "SECRET-EXTRA-MARKER"


def test_validate_extra_vars_returns_detached_nested_json() -> None:
    value = {"count": 5, "ratio": 1.5, "enabled": True, "missing": None,
             "items": ["x", False, {"nested": "value"}]}
    detached = validate_extra_vars(value)
    assert detached == value and detached is not value
    assert detached["items"] is not value["items"]
    detached["items"][2]["nested"] = "changed"
    assert value["items"][2]["nested"] == "value"


@pytest.mark.parametrize("value", [
    None, [], "{\"x\":1}", True, 3, {3: "value"}, {"nested": {False: 1}},
    {"value": float("nan")}, {"nested": [float("inf")]}, {"value": float("-inf")},
    {"value": b"SECRET-BYTES"}, {"value": (1, 2)}, {"value": {1, 2}},
    {"value": "\ud800"}, {"\ud800": "value"}, {"value": 10**5000},
])
def test_extra_vars_reject_nonobjects_and_invalid_json(value) -> None:
    with pytest.raises(StorageError) as raised:
        validate_extra_vars(value)
    assert "SECRET-BYTES" not in str(raised.value)


def test_extra_vars_size_limit_counts_utf8_bytes() -> None:
    accepted = {"x": "a" * (16 * 1024 - len('{"x":""}'))}
    assert validate_extra_vars(accepted) == accepted
    with pytest.raises(StorageError, match="16 KiB"):
        validate_extra_vars({"x": accepted["x"] + "a"})
    with pytest.raises(StorageError, match="16 KiB"):
        validate_extra_vars({"x": "\u20ac" * 6000})


def test_extra_vars_depth_limit_and_cycles_fail_safely() -> None:
    value: dict = {}
    for _ in range(19):
        value = {"nested": value}
    assert validate_extra_vars(value) == value
    with pytest.raises(StorageError, match="nesting depth"):
        validate_extra_vars({"too_deep": value})
    cyclic = {}
    cyclic["self"] = cyclic
    with pytest.raises(StorageError, match="nesting depth"):
        validate_extra_vars(cyclic)


def test_empty_extra_vars_preserve_portable_mock_records(tmp_path: Path) -> None:
    class ForbiddenProtector:
        def encrypt(self, value):
            pytest.fail("Empty extra vars must not require credential protection")

        def decrypt(self, value):
            pytest.fail("Empty extra vars must not require credential protection")

    store = LocalStore(tmp_path / "empty-vars.sqlite3", protector=ForbiddenProtector())
    store.save_connection("demo", mode="mock", templates=[{"id": 101, "extra_vars": {}}])
    assert store.load_active().templates == [{"id": 101, "risk": "write"}]
    assert store.list_connections()[0]["templates"] == [{"id": 101, "risk": "write"}]
    assert validate_templates([{"id": 101, "extra_vars": {}}]) == [{"id": 101, "risk": "write"}]
    with pytest.raises(StorageError, match="JSON object"):
        store.save_connection("invalid", mode="mock", templates=[{"id": 101, "extra_vars": None}])


def test_extra_vars_encrypt_failure_does_not_change_existing_connection(local_store) -> None:
    store, protector, clock = local_store
    save_controller(store)

    class BrokenExtraVarProtector(FakeProtector):
        def encrypt(self, value):
            if value.startswith("{"):
                raise RuntimeError(value)
            return super().encrypt(value)

    failing = LocalStore(store.path, protector=BrokenExtraVarProtector(), clock=clock)
    before = store.list_connections()
    with pytest.raises(StorageError) as raised:
        save_controller(failing, templates=[{"id": 99, "extra_vars": {"secret": "FAILED-VARS-MARKER"}}])
    assert "FAILED-VARS-MARKER" not in str(raised.value)
    assert store.list_connections() == before
    assert store.load_active().templates[0]["id"] == 42


def test_corrupt_extra_vars_are_not_disclosed_and_metadata_does_not_decrypt(local_store) -> None:
    store, protector, _ = local_store
    save_controller(store, templates=[{"id": 42, "extra_vars": {"key": "value"}}])
    with sqlite3.connect(store.path) as database:
        database.execute("UPDATE templates SET extra_vars = ?", (b"CORRUPT-SECRET-MARKER",))
    assert store.list_connections()[0]["templates"][0]["has_extra_vars"] is True
    assert protector.decrypt_calls == 0
    with pytest.raises(StorageError) as raised:
        store.load_active()
    assert "CORRUPT-SECRET-MARKER" not in str(raised.value)


def _write_version_one_database(path: Path, protector: FakeProtector, *, tool_name_type: str = "TEXT") -> bytes:
    ciphertext = protector.encrypt("legacy-TOKEN-MARKER")
    with sqlite3.connect(path) as database:
        database.execute(
            "CREATE TABLE connections (name TEXT PRIMARY KEY, mode TEXT NOT NULL CHECK(mode IN ('mock', 'controller')), "
            "base_url TEXT, api_path TEXT NOT NULL, credential BLOB, verify_tls INTEGER NOT NULL CHECK(verify_tls IN (0, 1)), "
            "created_at TEXT NOT NULL, updated_at TEXT NOT NULL, expires_at TEXT NOT NULL)"
        )
        database.execute(
            "CREATE TABLE templates (connection_name TEXT NOT NULL REFERENCES connections(name) ON DELETE CASCADE, "
            "template_id INTEGER NOT NULL CHECK(template_id > 0), display_name TEXT, "
            f"risk TEXT NOT NULL CHECK(risk IN ('read-only', 'write')), tool_name {tool_name_type}, "
            "PRIMARY KEY(connection_name, template_id), UNIQUE(connection_name, tool_name))"
        )
        database.execute("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        database.execute("PRAGMA user_version = 1")
        database.execute(
            "INSERT INTO connections VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("legacy", "controller", "https://legacy.example.com", "/api/v2/", ciphertext, 1,
             "2026-09-22T12:00:00Z", "2026-09-22T12:00:00Z", "2026-09-23T12:00:00Z"),
        )
        database.execute("INSERT INTO templates VALUES ('legacy', 42, 'Legacy tool', 'write', 'legacy_tool')")
        database.execute("INSERT INTO settings VALUES ('active_connection', 'legacy')")
    return ciphertext


def test_version_one_migration_preserves_credentials_templates_and_active(tmp_path: Path) -> None:
    path = tmp_path / "legacy.sqlite3"
    protector = FakeProtector()
    original_ciphertext = _write_version_one_database(path, protector)
    store = LocalStore(path, protector=protector, clock=TestClock())
    assert protector.decrypt_calls == 0  # Migration never unlocks credentials.
    with sqlite3.connect(path) as database:
        assert database.execute("PRAGMA user_version").fetchone()[0] == 2
        assert database.execute("SELECT credential FROM connections").fetchone()[0] == original_ciphertext
        assert database.execute("SELECT extra_vars FROM templates").fetchone()[0] is None
        assert database.execute("SELECT value FROM settings WHERE key = 'active_connection'").fetchone()[0] == "legacy"
    loaded = store.load_active()
    assert loaded.name == "legacy" and loaded.active is True
    assert loaded.token == "legacy-TOKEN-MARKER"
    assert loaded.templates == [{"id": 42, "name": "Legacy tool", "risk": "write", "tool_name": "legacy_tool"}]
    # Both migrated and newly created databases support the new encrypted field.
    save_controller(store, "legacy", templates=[{"id": 42, "extra_vars": {"secret": "POST-MIGRATION-MARKER"}}])
    assert store.load_active().templates[0]["extra_vars"] == {"secret": "POST-MIGRATION-MARKER"}
    assert b"POST-MIGRATION-MARKER" not in path.read_bytes()


def test_malformed_version_one_schema_is_not_migrated(tmp_path: Path) -> None:
    path = tmp_path / "malformed-legacy.sqlite3"
    protector = FakeProtector()
    original_ciphertext = _write_version_one_database(path, protector)
    with sqlite3.connect(path) as database:
        database.execute("ALTER TABLE templates ADD COLUMN unexpected TEXT")
    with pytest.raises(StorageError, match="schema"):
        LocalStore(path, protector=protector, clock=TestClock())
    with sqlite3.connect(path) as database:
        assert database.execute("PRAGMA user_version").fetchone()[0] == 1
        assert database.execute("SELECT credential FROM connections").fetchone()[0] == original_ciphertext
        assert "extra_vars" not in {row[1] for row in database.execute("PRAGMA table_info(templates)")}
        assert database.execute("SELECT value FROM settings").fetchone()[0] == "legacy"


def test_version_one_column_type_mismatch_is_not_migrated(tmp_path: Path) -> None:
    path = tmp_path / "wrong-type-legacy.sqlite3"
    protector = FakeProtector()
    _write_version_one_database(path, protector, tool_name_type="BLOB")
    with pytest.raises(StorageError, match="schema"):
        LocalStore(path, protector=protector, clock=TestClock())
    with sqlite3.connect(path) as database:
        assert database.execute("PRAGMA user_version").fetchone()[0] == 1
        assert "extra_vars" not in {row[1] for row in database.execute("PRAGMA table_info(templates)")}


def test_migration_rolls_back_when_post_alter_validation_fails(tmp_path: Path, monkeypatch) -> None:
    path = tmp_path / "rollback-legacy.sqlite3"
    protector = FakeProtector()
    original_ciphertext = _write_version_one_database(path, protector)
    original_check = LocalStore._check_schema

    def fail_after_alter(database, expected_columns=None):
        original_check(database, expected_columns)
        if expected_columns is None:
            raise StorageError("Simulated post-migration validation failure")

    monkeypatch.setattr(LocalStore, "_check_schema", staticmethod(fail_after_alter))
    with pytest.raises(StorageError, match="post-migration"):
        LocalStore(path, protector=protector, clock=TestClock())
    with sqlite3.connect(path) as database:
        assert database.execute("PRAGMA user_version").fetchone()[0] == 1
        assert "extra_vars" not in {row[1] for row in database.execute("PRAGMA table_info(templates)")}
        assert database.execute("SELECT credential FROM connections").fetchone()[0] == original_ciphertext
        assert database.execute("SELECT value FROM settings").fetchone()[0] == "legacy"
