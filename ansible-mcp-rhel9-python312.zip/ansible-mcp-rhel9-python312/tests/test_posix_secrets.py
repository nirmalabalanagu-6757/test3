from __future__ import annotations

import os
import stat
from pathlib import Path
from types import SimpleNamespace

import pytest
from cryptography.fernet import Fernet

from ansible_mcp import key_management, posix_secrets
from ansible_mcp.posix_secrets import FernetProtector, check_key, initialize_key
from ansible_mcp.storage import LocalStore, StorageError, WindowsDPAPIProtector


POSIX_ONLY = pytest.mark.skipif(os.name != "posix", reason="Requires real POSIX file ownership and permission semantics")


def test_fernet_roundtrip_and_authentication_with_injected_key(tmp_path: Path, monkeypatch) -> None:
    key = Fernet.generate_key()
    monkeypatch.setattr(posix_secrets, "_read_key", lambda path: key)
    protector = FernetProtector(tmp_path / "unused-key")
    protected = protector.encrypt("SECRET-POSIX-MARKER-\u20ac")
    assert protected.startswith(b"FERNET1:")
    assert b"SECRET-POSIX-MARKER" not in protected
    assert protector.decrypt(protected) == "SECRET-POSIX-MARKER-\u20ac"
    assert not (tmp_path / "unused-key").exists()
    changed = protected[:-2] + b"XX"
    with pytest.raises(StorageError, match="correct credential key"):
        protector.decrypt(changed)
    monkeypatch.setattr(posix_secrets, "_read_key", lambda path: Fernet.generate_key())
    with pytest.raises(StorageError, match="correct credential key"):
        protector.decrypt(protected)


def test_windows_and_posix_ciphertexts_cannot_be_silently_mixed(tmp_path: Path) -> None:
    with pytest.raises(StorageError, match="different platform"):
        FernetProtector(tmp_path / "absent").decrypt(b"DPAPI-or-unknown")
    with pytest.raises(StorageError, match="POSIX encryption"):
        WindowsDPAPIProtector().decrypt(b"FERNET1:some-ciphertext")


def test_missing_key_encrypt_and_decrypt_never_initialize(tmp_path: Path, monkeypatch) -> None:
    def absent(path):
        raise StorageError("The credential key is missing.")

    def forbidden():
        pytest.fail("Encryption/decryption must never generate a new key")

    monkeypatch.setattr(posix_secrets, "_read_key", absent)
    monkeypatch.setattr(Fernet, "generate_key", forbidden)
    protector = FernetProtector(tmp_path / "absent-key")
    with pytest.raises(StorageError, match="missing"):
        protector.encrypt("NOT-SAVED-SECRET")
    with pytest.raises(StorageError, match="missing"):
        protector.decrypt(b"FERNET1:existing-data")
    assert not (tmp_path / "absent-key").exists()


def test_fernet_storage_roundtrip_with_injected_key(tmp_path: Path, monkeypatch) -> None:
    key = Fernet.generate_key()
    monkeypatch.setattr(posix_secrets, "_read_key", lambda path: key)
    protector = FernetProtector(tmp_path / "external-key")
    database = tmp_path / "fernet.sqlite3"
    store = LocalStore(database, protector=protector)
    store.save_connection("linux", mode="controller", base_url="https://controller.example.com",
                          token="FERNET-TOKEN-MARKER", templates=[
                              {"id": 42, "tool_name": "linux_tool", "extra_vars": {"secret": "FERNET-VARS-MARKER"}},
                          ])
    reopened = LocalStore(database, protector=FernetProtector(tmp_path / "external-key"))
    loaded = reopened.load_active()
    assert loaded.token == "FERNET-TOKEN-MARKER"
    assert loaded.templates[0]["extra_vars"] == {"secret": "FERNET-VARS-MARKER"}
    assert b"FERNET-TOKEN-MARKER" not in database.read_bytes()
    assert b"FERNET-VARS-MARKER" not in database.read_bytes()
    assert "FERNET-VARS-MARKER" not in str(store.list_connections())
    assert "FERNET-TOKEN-MARKER" not in repr(loaded)


def test_key_path_configuration_is_separate_from_database(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.delenv("ANSIBLE_CREDENTIAL_KEY_FILE", raising=False)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
    assert posix_secrets.default_key_path() == tmp_path / "config" / "ansible-template-tools" / "credential.key"
    chosen = tmp_path / "elsewhere" / "private.key"
    monkeypatch.setenv("ANSIBLE_CREDENTIAL_KEY_FILE", str(chosen))
    assert posix_secrets.default_key_path() == chosen
    assert FernetProtector().path == chosen
    assert not chosen.exists()


def test_key_cli_reports_only_path_and_safe_errors(tmp_path: Path, monkeypatch, capsys) -> None:
    chosen = tmp_path / "credential.key"
    calls = []
    monkeypatch.setattr(key_management, "initialize_key", lambda path: calls.append(("init", path)) or chosen)
    monkeypatch.setattr(key_management, "check_key", lambda path: calls.append(("check", path)) or chosen)
    assert key_management.main(["init", "--path", str(chosen)]) == 0
    assert key_management.main(["check", "--path", str(chosen)]) == 0
    output = capsys.readouterr()
    assert output.out.count("Credential key ready:") == 2
    assert calls == [("init", chosen), ("check", chosen)]

    def broken(path):
        raise StorageError("The credential key is missing.")

    monkeypatch.setattr(key_management, "check_key", broken)
    assert key_management.main(["check"]) == 1
    assert "missing" in capsys.readouterr().err


@POSIX_ONLY
def test_real_posix_initialize_is_private_atomic_and_idempotent(tmp_path: Path) -> None:
    path = tmp_path / "private" / "credential.key"
    original_parent_mode = stat.S_IMODE(tmp_path.stat().st_mode)
    assert initialize_key(path) == path
    original = path.read_bytes()
    assert len(original) == 44
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    assert stat.S_IMODE(path.parent.stat().st_mode) == 0o700
    assert stat.S_IMODE(tmp_path.stat().st_mode) == original_parent_mode
    assert initialize_key(path) == path
    assert path.read_bytes() == original
    assert check_key(path) == path
    assert list(path.parent.iterdir()) == [path]
    protector = FernetProtector(path)
    assert protector.decrypt(protector.encrypt("secret")) == "secret"


@POSIX_ONLY
def test_real_posix_concurrent_initializers_preserve_one_key(tmp_path: Path) -> None:
    from concurrent.futures import ThreadPoolExecutor

    path = tmp_path / "private" / "credential.key"
    with ThreadPoolExecutor(max_workers=4) as pool:
        paths = list(pool.map(lambda _: initialize_key(path), range(8)))
    assert paths == [path] * 8
    assert check_key(path) == path
    assert list(path.parent.iterdir()) == [path]


@POSIX_ONLY
def test_real_posix_missing_key_is_not_recreated_by_protector(tmp_path: Path) -> None:
    path = tmp_path / "private" / "credential.key"
    with pytest.raises(StorageError, match="missing"):
        FernetProtector(path).encrypt("secret")
    assert not path.exists() and not path.parent.exists()
    initialize_key(path)
    ciphertext = FernetProtector(path).encrypt("secret")
    path.unlink()
    with pytest.raises(StorageError, match="missing"):
        FernetProtector(path).decrypt(ciphertext)
    assert not path.exists()


@POSIX_ONLY
@pytest.mark.parametrize("mode", [0o644, 0o660, 0o700])
def test_real_posix_key_permissions_rejected_without_chmod(tmp_path: Path, mode: int) -> None:
    path = tmp_path / "private" / "credential.key"
    initialize_key(path)
    original = path.read_bytes()
    path.chmod(mode)
    with pytest.raises(StorageError, match="0600"):
        initialize_key(path)
    with pytest.raises(StorageError, match="0600"):
        check_key(path)
    assert stat.S_IMODE(path.stat().st_mode) == mode and path.read_bytes() == original


@POSIX_ONLY
def test_real_posix_unsafe_directory_is_rejected_not_repaired(tmp_path: Path) -> None:
    directory = tmp_path / "shared"
    directory.mkdir(mode=0o755)
    directory.chmod(0o755)
    with pytest.raises(StorageError, match="0700"):
        initialize_key(directory / "credential.key")
    assert stat.S_IMODE(directory.stat().st_mode) == 0o755
    assert not (directory / "credential.key").exists()


@POSIX_ONLY
def test_real_posix_symlink_key_and_parent_are_rejected(tmp_path: Path) -> None:
    path = tmp_path / "private" / "credential.key"
    initialize_key(path)
    original = path.read_bytes()
    linked = path.parent / "link.key"
    linked.symlink_to(path)
    with pytest.raises(StorageError, match="symbolic links"):
        initialize_key(linked)
    with pytest.raises(StorageError, match="symbolic links"):
        check_key(linked)
    directory_link = tmp_path / "linked-directory"
    directory_link.symlink_to(path.parent, target_is_directory=True)
    with pytest.raises(StorageError, match="symbolic links"):
        initialize_key(directory_link / "different.key")
    assert path.read_bytes() == original


@POSIX_ONLY
def test_real_posix_nonregular_and_invalid_key_files_rejected(tmp_path: Path) -> None:
    directory = tmp_path / "private"
    directory.mkdir(mode=0o700)
    fifo = directory / "pipe.key"
    os.mkfifo(fifo, 0o600)
    with pytest.raises(StorageError, match="regular file"):
        check_key(fifo)
    path = directory / "invalid.key"
    path.write_bytes(b"not-a-valid-key")
    path.chmod(0o600)
    with pytest.raises(StorageError, match="invalid"):
        initialize_key(path)
    assert path.read_bytes() == b"not-a-valid-key"


@POSIX_ONLY
def test_real_posix_owner_validation(tmp_path: Path, monkeypatch) -> None:
    path = tmp_path / "private" / "credential.key"
    initialize_key(path)
    actual = path.stat()
    wrong_owner = SimpleNamespace(st_mode=actual.st_mode, st_uid=os.geteuid() + 1)
    with pytest.raises(StorageError, match="owned"):
        posix_secrets._check_private_stat(wrong_owner, directory=False)


@POSIX_ONLY
def test_real_posix_default_storage_uses_fernet_and_private_db(tmp_path: Path, monkeypatch) -> None:
    path = tmp_path / "private" / "credential.key"
    initialize_key(path)
    monkeypatch.setenv("ANSIBLE_CREDENTIAL_KEY_FILE", str(path))
    database = tmp_path / "state" / "config.sqlite3"
    store = LocalStore(database)
    assert isinstance(store._protector, FernetProtector)
    assert stat.S_IMODE(database.stat().st_mode) == 0o600
    store.save_connection("demo", mode="mock", templates=[{"id": 101, "extra_vars": {"value": "linux-secret"}}])
    assert store.load_active().templates[0]["extra_vars"] == {"value": "linux-secret"}


@POSIX_ONLY
def test_real_posix_cli_never_prints_key(tmp_path: Path, capsys) -> None:
    path = tmp_path / "private" / "credential.key"
    assert key_management.main(["init", "--path", str(path)]) == 0
    key = path.read_text()
    assert key_management.main(["check", "--path", str(path)]) == 0
    output = capsys.readouterr()
    assert key not in output.out and key not in output.err
