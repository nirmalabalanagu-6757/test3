from __future__ import annotations

import httpx
import pytest
import respx

from ansible_mcp.controller import AutomationControllerClient, ControllerError


@respx.mock
async def test_controller_launch_and_status_calls() -> None:
    base = "https://controller.example.com"
    launch = respx.post(f"{base}/api/v2/job_templates/42/launch/").mock(
        return_value=httpx.Response(201, json={"job": 9001, "status": "pending"})
    )
    status = respx.get(f"{base}/api/v2/jobs/9001/").mock(
        return_value=httpx.Response(200, json={"id": 9001, "status": "running"})
    )
    client = AutomationControllerClient(base, "test-token")

    launched = await client.launch_template(42, {"environment": "production"})
    current = await client.get_job_status(9001)
    await client.close()

    assert launch.called
    assert status.called
    assert launched["job"] == 9001
    assert current["status"] == "running"
    assert launch.calls[0].request.headers["Authorization"] == "Bearer test-token"
    assert launch.calls[0].request.content == b'{"extra_vars":{"environment":"production"}}'


@respx.mock
async def test_custom_api_prefix_is_used_for_all_actions() -> None:
    prefix = "https://controller.example.com/api/controller/v2/"
    routes = [
        respx.get(f"{prefix}job_templates/?page_size=200").respond(
            200, json={"results": [{"id": 42}], "next": None}
        ),
        respx.get(f"{prefix}job_templates/42/").respond(200, json={"id": 42}),
        respx.get(f"{prefix}job_templates/42/survey_spec/").respond(200, json={"spec": []}),
        respx.get(f"{prefix}job_templates/42/launch/").respond(200, json={"can_start_without_user_input": True}),
        respx.post(f"{prefix}job_templates/42/launch/").respond(201, json={"job": 9001}),
        respx.get(f"{prefix}jobs/9001/").respond(200, json={"status": "running"}),
        respx.get(f"{prefix}jobs/9001/stdout/?format=json").respond(200, json={"content": "output"}),
        respx.post(f"{prefix}jobs/9001/cancel/").respond(202, json={}),
    ]
    client = AutomationControllerClient(
        "https://controller.example.com", "test-token", api_path="/api/controller/v2/"
    )
    assert await client.list_templates() == [{"id": 42}]
    assert await client.get_template_details(42) == {"id": 42}
    assert (await client.get_template_launch_schema(42))["survey"] == {"spec": []}
    assert await client.launch_template(42, {}) == {"job": 9001}
    assert await client.get_job_status(9001) == {"status": "running"}
    assert await client.get_job_output(9001) == {"content": "output"}
    assert await client.cancel_job(9001) == {}
    await client.close()
    assert all(route.called for route in routes)
    assert all(call.request.headers["Authorization"] == "Bearer test-token" for call in respx.calls)


@pytest.mark.parametrize(
    "next_url",
    [
        "http://controller.example.com/api/v2/job_templates/?page=2",
        "https://evil.example.com/api/v2/job_templates/?page=2",
        "//evil.example.com/api/v2/job_templates/?page=2",
        "https://controller.example.com:8443/api/v2/job_templates/?page=2",
        "https://user:password@controller.example.com/api/v2/job_templates/?page=2",
        "https://controller.example.com/not-api/?page=2",
        "https://controller.example.com/api/v2/%2e%2e/other/?page=2",
        123,
    ],
)
@respx.mock
async def test_unsafe_pagination_is_rejected_before_sending_credentials(next_url) -> None:
    respx.get("https://controller.example.com/api/v2/job_templates/?page_size=200").respond(
        200, json={"results": [], "next": next_url}
    )
    client = AutomationControllerClient("https://controller.example.com", "private-test-token")
    with pytest.raises(ControllerError, match="unsafe request URL") as error:
        await client.list_templates()
    assert "private-test-token" not in str(error.value)
    assert len(respx.calls) == 1


@pytest.mark.parametrize(
    "next_url",
    [
        "?page=2",
        "/api/v2/job_templates/?page=2",
        "https://controller.example.com/api/v2/job_templates/?page=2",
        "https://controller.example.com:443/api/v2/job_templates/?page=2",
    ],
)
@respx.mock
async def test_same_origin_pagination(next_url: str) -> None:
    respx.get("https://controller.example.com/api/v2/job_templates/?page_size=200").respond(
        200, json={"results": [{"id": 1}], "next": next_url}
    )
    second = respx.get("https://controller.example.com/api/v2/job_templates/?page=2").respond(
        200, json={"results": [{"id": 2}], "next": None}
    )
    client = AutomationControllerClient("https://controller.example.com", "test-token")
    assert await client.list_templates() == [{"id": 1}, {"id": 2}]
    assert second.called


@pytest.mark.parametrize(
    "base_url",
    [
        "http://controller.example.com", "controller.example.com", "https://",
        "https://user:pass@controller.example.com", "https://controller.example.com/api/v2/",
        "https://controller.example.com/?token=secret", "https://controller.example.com/#fragment",
        "https://controller.example.com:invalid", "https://controller.example.com\\evil",
        "https://controller.example.com\n",
    ],
)
def test_invalid_controller_origin_is_rejected(base_url: str) -> None:
    with pytest.raises(ValueError, match="HTTPS origin"):
        AutomationControllerClient(base_url, "test-token")


@pytest.mark.parametrize("api_path", ["/api/v2", "/api/../v2/", "/api/%2e%2e/v2/", "https://other/api/v2/", "/v2/", "/api/v2/?q=1"])
def test_invalid_api_prefix_is_rejected(api_path: str) -> None:
    with pytest.raises(ValueError, match="API path"):
        AutomationControllerClient("https://controller.example.com", "test-token", api_path=api_path)


@respx.mock
async def test_redirects_are_not_followed() -> None:
    respx.get("https://controller.example.com/api/v2/job_templates/42/").respond(
        302, headers={"Location": "https://evil.example.com/api/v2/job_templates/42/"}
    )
    client = AutomationControllerClient("https://controller.example.com", "test-token")
    with pytest.raises(ControllerError, match="HTTP 302"):
        await client.get_template_details(42)
    assert len(respx.calls) == 1


@pytest.mark.parametrize("payload", [[{"id": 1}], "invalid"])
@respx.mock
async def test_non_object_response_is_safe_error(payload) -> None:
    respx.get("https://controller.example.com/api/v2/job_templates/42/").respond(200, json=payload)
    client = AutomationControllerClient("https://controller.example.com", "test-token")
    with pytest.raises(ControllerError, match="Controller request failed"):
        await client.get_template_details(42)
