from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json

import httpx
import pytest
import respx
from fastmcp import Client

from ansible_mcp.console import _profile_name
from ansible_mcp.controller import ControllerError, MockControllerClient
from ansible_mcp.server import create_server
from ansible_mcp.settings import Settings
from ansible_mcp.storage import LocalStore


class FakeProtector:
    def encrypt(self, value: str) -> bytes:
        return b"test-encrypted:" + bytes(character ^ 0x5A for character in value.encode())

    def decrypt(self, value: bytes) -> str:
        return bytes(character ^ 0x5A for character in value.removeprefix(b"test-encrypted:")).decode()


def local_store(tmp_path, *, clock=None):
    return LocalStore(tmp_path / "console.sqlite3", protector=FakeProtector(), clock=clock)


async def server_for(store, *, factory=None):
    return await create_server(
        Settings(mode="mock", poll_interval_seconds=0.001, timeout_seconds=1),
        MockControllerClient(), console_store=store,
        console_controller_factory=factory,
        console_allowed_hosts={"127.0.0.1:8000"},
    )


def http_client(server, *, client_ip="127.0.0.1"):
    return httpx.AsyncClient(
        transport=httpx.ASGITransport(app=server.http_app(), client=(client_ip, 12345)),
        base_url="http://127.0.0.1:8000",
    )


async def csrf(client):
    response = await client.get("/console/api/tools")
    assert response.status_code == 200, response.text
    return response.json()["csrf_token"]


def mock_payload(name="my_disk_check", template_id=101):
    return {"mode": "mock", "tool_name": name, "template_api_url": f"mock://templates/{template_id}", "api_token": "", "title": "My Disk Check", "ttl_hours": 24}


async def test_console_registers_named_tool_live_and_after_restart(tmp_path):
    store = local_store(tmp_path)
    server = await server_for(store)
    async with http_client(server) as web:
        initial = (await web.get("/console/api/tools")).json()
        assert len(initial["tools"]) == 3
        response = await web.post("/console/api/tools", json=mock_payload(), headers={"X-CSRF-Token": initial["csrf_token"]})
        assert response.status_code == 201, response.text
        entries = (await web.get("/console/api/tools")).json()["tools"]
        assert len(entries) == 4
        saved = next(tool for tool in entries if tool["name"] == "my_disk_check")
        assert saved["registered"] is True
        assert saved["template_api_url"] == "mock://templates/101"
        assert saved["title"] == "My Disk Check"
    assert store.load_active() is None  # GUI registrations do not replace active config.
    async with Client(server) as mcp:
        result = await mcp.call_tool("my_disk_check", {"environment": "development", "host_group": "test"})
        assert result.structured_content["template_id"] == 101
        assert result.structured_content["status"] == "successful"
    restarted = await server_for(store)
    async with Client(restarted) as mcp:
        assert "my_disk_check" in {tool.name for tool in await mcp.list_tools()}


async def test_two_gui_tools_keep_their_individual_controller_and_credentials(tmp_path):
    store = local_store(tmp_path)
    seen_settings = []
    controllers = []

    def factory(settings):
        seen_settings.append(settings)
        controller = MockControllerClient()
        controllers.append(controller)
        return controller

    server = await server_for(store, factory=factory)
    async with http_client(server) as web:
        security_token = await csrf(web)
        for name, host, template_id, token in [("disk_a", "a.example.com", 101, "secret-token-a"), ("restart_b", "b.example.com", 102, "secret-token-b")]:
            response = await web.post("/console/api/tools", json={
                "mode": "controller", "tool_name": name,
                "template_api_url": f"https://{host}/api/controller/v2/job_templates/{template_id}/launch/",
                "api_token": token, "ttl_hours": 24,
            }, headers={"X-CSRF-Token": security_token})
            assert response.status_code == 201, response.text
            assert token not in response.text
        state = await web.get("/console/api/tools")
        assert "secret-token" not in state.text
        assert "credential" not in state.text
    assert [settings.controller_url for settings in seen_settings] == ["https://a.example.com", "https://b.example.com"]
    assert [settings.controller_token for settings in seen_settings] == ["secret-token-a", "secret-token-b"]
    assert all(settings.api_path == "/api/controller/v2/" for settings in seen_settings)
    assert all(not controller.jobs for controller in controllers)  # Registration is read-only.
    assert b"secret-token" not in store.path.read_bytes()
    async with Client(server) as mcp:
        result = await mcp.call_tool("restart_b", {"environment": "staging", "host_group": "test"})
        assert result.structured_content["template_id"] == 102
    assert not controllers[0].jobs
    assert len(controllers[1].jobs) == 1


@pytest.mark.parametrize("name", ["ansible_check_disk_space_101", "my_disk_check"])
async def test_duplicate_names_never_overwrite(tmp_path, name):
    store = local_store(tmp_path)
    server = await server_for(store)
    async with http_client(server) as web:
        headers = {"X-CSRF-Token": await csrf(web)}
        if name == "my_disk_check":
            assert (await web.post("/console/api/tools", json=mock_payload(name), headers=headers)).status_code == 201
        before = store.list_connections()
        response = await web.post("/console/api/tools", json=mock_payload(name, 102), headers=headers)
        assert response.status_code == 409
        assert store.list_connections() == before


async def test_concurrent_profile_creation_is_never_overwritten_or_deleted(tmp_path):
    store = local_store(tmp_path)
    competitor = local_store(tmp_path)
    profile = _profile_name("my_disk_check")

    class ConcurrentRegistration(MockControllerClient):
        async def get_template_details(self, template_id):
            # Another process writes after the console's duplicate-name check,
            # while read-only controller validation is still in progress.
            competitor.save_connection(
                profile, mode="mock", templates=[{
                    "id": 102, "tool_name": "my_disk_check", "name": "Competing registration",
                }], activate=False,
            )
            return await super().get_template_details(template_id)

    server = await server_for(store, factory=lambda settings: ConcurrentRegistration())
    async with http_client(server) as web:
        response = await web.post("/console/api/tools", json=mock_payload(), headers={"X-CSRF-Token": await csrf(web)})
        assert response.status_code == 400
    saved = competitor.load_connection(profile)
    assert saved is not None
    assert saved.templates == [{"id": 102, "risk": "write", "name": "Competing registration", "tool_name": "my_disk_check"}]
    async with Client(server) as client:
        assert "my_disk_check" not in {tool.name for tool in await client.list_tools()}


async def test_unreachable_registration_does_not_save_or_publish(tmp_path):
    class Disconnected(MockControllerClient):
        async def get_template_details(self, template_id):
            raise ControllerError("Secret failure content must never reach browser: supersecret")

    store = local_store(tmp_path)
    server = await server_for(store, factory=lambda settings: Disconnected())
    async with http_client(server) as web:
        response = await web.post("/console/api/tools", json=mock_payload(), headers={"X-CSRF-Token": await csrf(web)})
        assert response.status_code == 502
        assert "supersecret" not in response.text
    assert store.list_connections() == []
    async with Client(server) as mcp:
        assert "my_disk_check" not in {tool.name for tool in await mcp.list_tools()}


async def test_unreachable_saved_tool_remains_available_for_recovery_console(tmp_path):
    store = local_store(tmp_path)
    store.save_connection(_profile_name("saved_tool"), mode="mock", templates=[{"id": 101, "tool_name": "saved_tool"}], activate=False)

    class Disconnected(MockControllerClient):
        async def get_template_details(self, template_id):
            raise ControllerError("not connected")

    server = await server_for(store, factory=lambda settings: Disconnected())
    async with http_client(server) as web:
        response = await web.get("/console/api/tools")
        entry = next(item for item in response.json()["tools"] if item["name"] == "saved_tool")
        assert entry["registered"] is False
        assert "Unavailable" in entry["status"]
    assert len(store.list_connections()) == 1


async def test_expired_saved_gui_tool_is_not_published(tmp_path):
    current = datetime.now(timezone.utc) - timedelta(days=2)
    store = local_store(tmp_path, clock=lambda: current)
    store.save_connection(_profile_name("old_tool"), mode="mock", templates=[{"id": 101, "tool_name": "old_tool"}], activate=False)
    current = datetime.now(timezone.utc)
    server = await server_for(store)
    async with http_client(server) as web:
        entry = next(item for item in (await web.get("/console/api/tools")).json()["tools"] if item["name"] == "old_tool")
        assert entry["registered"] is False
        assert "Expired" in entry["status"]
    async with Client(server) as mcp:
        assert "old_tool" not in {tool.name for tool in await mcp.list_tools()}


@pytest.mark.parametrize("headers", [{}, {"X-CSRF-Token": "wrong"}, {"Origin": "https://evil.example"}, {"Origin": "null"}, {"Host": "evil.example"}, {"Sec-Fetch-Site": "cross-site"}])
async def test_mutations_require_local_host_origin_and_csrf(tmp_path, headers):
    store = local_store(tmp_path)
    server = await server_for(store)
    async with http_client(server) as web:
        if any(key in headers for key in ("Origin", "Host", "Sec-Fetch-Site")):
            headers = {"X-CSRF-Token": await csrf(web), **headers}
        response = await web.post("/console/api/tools", json=mock_payload(), headers=headers)
        assert response.status_code == 403
    assert store.list_connections() == []


@pytest.mark.parametrize("headers", [{"Host": "evil.example"}, {"Origin": "http://evil.example"}, {"Origin": "null"}])
async def test_state_does_not_disclose_csrf_to_foreign_origin(tmp_path, headers):
    server = await server_for(local_store(tmp_path))
    async with http_client(server) as web:
        response = await web.get("/console/api/tools", headers=headers)
        assert response.status_code == 403
        assert "csrf_token" not in response.text


async def test_non_loopback_client_is_denied(tmp_path):
    server = await server_for(local_store(tmp_path))
    async with http_client(server, client_ip="192.0.2.10") as web:
        assert (await web.get("/console/api/tools")).status_code == 403


async def test_requests_are_bounded_json_only_and_security_headers_present(tmp_path):
    store = local_store(tmp_path)
    server = await server_for(store)
    async with http_client(server) as web:
        security_token = await csrf(web)
        response = await web.post("/console/api/tools", content="{}", headers={"X-CSRF-Token": security_token, "Content-Type": "text/plain"})
        assert response.status_code == 415
        response = await web.post("/console/api/tools", content=" " * 33000, headers={"X-CSRF-Token": security_token, "Content-Type": "application/json"})
        assert response.status_code == 413
        response = await web.get("/console/api/tools")
        assert response.headers["cache-control"] == "no-store"
        assert response.headers["referrer-policy"] == "no-referrer"
        assert response.headers["x-frame-options"] == "DENY"
        assert "script-src 'self'" in response.headers["content-security-policy"]
        assert "access-control-allow-origin" not in response.headers


@pytest.mark.parametrize("change", [
    {"tool_name": "bad-name"}, {"tool_name": None}, {"ttl_hours": -1}, {"ttl_hours": True},
    {"template_api_url": "mock://templates/999"}, {"api_token": "secret-not-accepted-in-mock"},
    {"mode": "controller", "template_api_url": "http://example.com/api/v2/job_templates/101/", "api_token": "private-token"},
    {"mode": "controller", "template_api_url": "https://user:password@example.com/api/v2/job_templates/101/", "api_token": "private-token"},
    {"mode": "controller", "template_api_url": "https://example.com/api/v2/job_templates/101/?token=private-token", "api_token": "private-token"},
])
async def test_bad_inputs_never_save_and_do_not_echo_secrets(tmp_path, change):
    store = local_store(tmp_path)
    server = await server_for(store)
    async with http_client(server) as web:
        response = await web.post("/console/api/tools", json={**mock_payload(), **change}, headers={"X-CSRF-Token": await csrf(web)})
        assert response.status_code in {400, 502}
        assert "private-token" not in response.text
        assert "secret-not-accepted" not in response.text
    assert store.list_connections() == []


async def test_explicit_mock_settings_do_not_open_default_database(tmp_path, monkeypatch):
    target = tmp_path / "must-not-exist.sqlite3"
    monkeypatch.setenv("ANSIBLE_DB_PATH", str(target))
    await create_server(Settings(mode="mock"), MockControllerClient())
    assert not target.exists()


async def test_static_console_assets(tmp_path, monkeypatch):
    from ansible_mcp import console

    # Tests read committed assets when present; no browser or unrelated DB access.
    server = await server_for(local_store(tmp_path))
    if not (console.WEB_ROOT / "console.html").exists():
        pytest.skip("Frontend assets are being developed separately")
    async with http_client(server) as web:
        for path, content_type in [("/console", "text/html"), ("/console/console.js", "text/javascript"), ("/console/console.css", "text/css")]:
            response = await web.get(path)
            assert response.status_code == 200
            assert content_type in response.headers["content-type"]
        assert (await web.get("/console/storage.py")).status_code == 404


async def test_non_ascii_csrf_is_rejected_without_error(tmp_path):
    store = local_store(tmp_path)
    server = await server_for(store)
    async with http_client(server) as web:
        response = await web.post("/console/api/tools", json=mock_payload(), headers=[(b"X-CSRF-Token", b"\xff")])
        assert response.status_code == 403
    assert store.list_connections() == []


async def test_base_tool_expiry_is_reflected_in_console_state(tmp_path):
    settings = Settings(mode="mock", expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    server = await create_server(settings, MockControllerClient(), console_store=local_store(tmp_path))
    # Simulate elapsed time without sleeping or changing the server's execution guard.
    from ansible_mcp import console

    original = console.datetime

    class FutureDatetime(datetime):
        @classmethod
        def now(cls, tz=None):
            return original.now(tz) + timedelta(hours=2)

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(console, "datetime", FutureDatetime)
        async with http_client(server) as web:
            entries = (await web.get("/console/api/tools")).json()["tools"]
            assert all(not entry["registered"] for entry in entries)
            assert all("Expired" in entry["status"] for entry in entries)


def auto_environment(monkeypatch, store):
    monkeypatch.setenv("ANSIBLE_MODE", "auto")
    monkeypatch.setenv("ANSIBLE_DB_PATH", str(store.path))
    monkeypatch.delenv("ANSIBLE_CONTROLLER_URL", raising=False)
    monkeypatch.delenv("ANSIBLE_CONTROLLER_TOKEN", raising=False)


async def test_expired_active_connection_keeps_recovery_console_without_mock_tools(tmp_path, monkeypatch):
    past = datetime.now(timezone.utc) - timedelta(days=2)
    store = local_store(tmp_path, clock=lambda: past)
    store.save_connection("expired-active", mode="mock", templates=[{"id": 101, "tool_name": "expired_base"}])
    store = local_store(tmp_path)
    auto_environment(monkeypatch, store)
    server = await create_server()
    async with http_client(server) as web:
        state = (await web.get("/console/api/tools")).json()
        assert state["tools"] == []
        assert "warning" in state
        response = await web.post("/console/api/tools", json=mock_payload(), headers={"X-CSRF-Token": state["csrf_token"]})
        assert response.status_code == 201
    assert any(row["name"] == "expired-active" for row in store.list_connections())
    async with Client(server) as client:
        assert {tool.name for tool in await client.list_tools()} == {"my_disk_check"}


async def test_unreadable_active_credential_keeps_recovery_console(tmp_path, monkeypatch):
    store = local_store(tmp_path)
    # A fake-encrypted credential cannot decrypt with the runtime's Windows DPAPI.
    store.save_connection("unreadable", mode="controller", base_url="https://example.com", token="private-token", templates=[{"id": 101, "tool_name": "unavailable"}])
    auto_environment(monkeypatch, store)
    server = await create_server()
    async with http_client(server) as web:
        response = await web.get("/console/api/tools")
        assert response.status_code == 200
        assert response.json()["tools"] == []
        assert "warning" in response.json()
        assert "private-token" not in response.text
    assert len(store.list_connections()) == 1


async def test_disconnected_active_controller_does_not_publish_partial_tools(tmp_path, monkeypatch):
    class PartiallyDisconnected(MockControllerClient):
        async def get_template_details(self, template_id):
            if template_id == 102:
                raise ControllerError("controller disconnected")
            return await super().get_template_details(template_id)

    store = local_store(tmp_path)
    auto_environment(monkeypatch, store)
    settings = Settings(mode="controller", controller_url="https://example.com", controller_token="private-token", allowed_template_ids={101, 102})
    monkeypatch.setattr(Settings, "from_env", classmethod(lambda cls, root: settings))
    server = await create_server(controller=PartiallyDisconnected(), console_store=store)
    async with http_client(server) as web:
        state = (await web.get("/console/api/tools")).json()
        assert state["tools"] == []
        assert "warning" in state
    async with Client(server) as client:
        assert await client.list_tools() == []


@respx.mock
async def test_saved_extra_vars_launch_defaults_overrides_and_restart_without_disclosure(tmp_path):
    store = local_store(tmp_path)
    server = await server_for(store)
    base = "https://controller.example.com/api/controller/v2/"
    survey = (await MockControllerClient().get_template_launch_schema(101))["survey"]
    respx.get(f"{base}job_templates/101/").respond(200, json={"id": 101, "name": "Disk check", "description": "Approved disk check"})
    respx.get(f"{base}job_templates/101/survey_spec/").respond(200, json=survey)
    respx.get(f"{base}job_templates/101/launch/").respond(200, json={"can_start_without_user_input": False, "variables_needed_to_start": ["environment", "host_group"], "ask_variables_on_launch": True})
    launched = respx.post(f"{base}job_templates/101/launch/").respond(201, json={"job": 9001})
    respx.get(f"{base}jobs/9001/").respond(200, json={"id": 9001, "status": "successful"})
    respx.get(f"{base}jobs/9001/stdout/?format=json").respond(200, json={"content": "done"})
    saved_vars = {
        "environment": "development", "host_group": "saved-private-host-774",
        "deployment": {"path": "saved-private-value-882", "enabled": True},
    }
    async with http_client(server) as web:
        response = await web.post("/console/api/tools", json={
            "mode": "controller", "tool_name": "configured_disk_check",
            "template_api_url": f"{base}job_templates/101/", "api_token": "registration-token",
            "extra_vars": saved_vars,
        }, headers={"X-CSRF-Token": await csrf(web)})
        assert response.status_code == 201, response.text
        assert not launched.called  # Saving never launches a playbook.
        state = await web.get("/console/api/tools")
        entry = next(item for item in state.json()["tools"] if item["name"] == "configured_disk_check")
        assert entry["has_extra_vars"] is True
        assert "extra_vars" not in entry
        assert "saved-private" not in state.text
        assert "registration-token" not in state.text
    assert b"saved-private" not in store.path.read_bytes()
    async with Client(server) as client:
        registered = next(tool for tool in await client.list_tools() if tool.name == "configured_disk_check")
        assert "saved-private" not in json.dumps(registered.input_schema)
        assert "host_group" not in registered.input_schema.get("required", [])
        assert "environment" not in registered.input_schema.get("required", [])
        result = await client.call_tool("configured_disk_check", {})
        assert result.is_error is False
        assert json.loads(launched.calls[-1].request.content) == {"extra_vars": saved_vars}
        result = await client.call_tool("configured_disk_check", {
            "environment": "production", "host_group": "named-host",
            "extra_vars": {"environment": "staging", "host_group": "generic-host", "deployment": {"path": "runtime-path"}, "additional": "runtime-only"},
        })
        assert result.is_error is False
        assert json.loads(launched.calls[-1].request.content) == {"extra_vars": {
            "environment": "production", "host_group": "named-host",
            "deployment": {"path": "runtime-path"}, "additional": "runtime-only",
        }}
    restarted = await server_for(store)
    async with Client(restarted) as client:
        registered = next(tool for tool in await client.list_tools() if tool.name == "configured_disk_check")
        assert "saved-private" not in json.dumps(registered.input_schema)
        assert (await client.call_tool("configured_disk_check", {})).is_error is False
        assert json.loads(launched.calls[-1].request.content) == {"extra_vars": saved_vars}


@pytest.mark.parametrize("invalid_vars", [
    None, [], "{\"private\":\"value\"}", 42,
    {"private": float("nan")}, {"private": {"nested": float("inf")}},
    {"private": "private-value-" + "x" * (17 * 1024)},
])
async def test_invalid_extra_vars_are_rejected_before_controller_reads_or_storage(tmp_path, invalid_vars):
    store = local_store(tmp_path)
    reads = []

    def factory(settings):
        reads.append(settings)
        return MockControllerClient()

    server = await server_for(store, factory=factory)
    async with http_client(server) as web:
        response = await web.post(
            "/console/api/tools", content=json.dumps({**mock_payload(), "extra_vars": invalid_vars}),
            headers={"X-CSRF-Token": await csrf(web), "Content-Type": "application/json"},
        )
        assert response.status_code == 400
        assert "private-value" not in response.text
    assert reads == []
    assert store.list_connections() == []


async def test_malformed_extra_vars_json_is_rejected_before_controller_reads(tmp_path):
    store = local_store(tmp_path)
    reads = []
    server = await server_for(store, factory=lambda settings: reads.append(settings))
    async with http_client(server) as web:
        response = await web.post(
            "/console/api/tools", content='{"extra_vars":{"private":"value"}',
            headers={"X-CSRF-Token": await csrf(web), "Content-Type": "application/json"},
        )
        assert response.status_code == 400
    assert reads == []
    assert store.list_connections() == []


async def test_base_tool_extra_vars_metadata_is_boolean_only(tmp_path):
    settings = Settings(
        mode="mock", poll_interval_seconds=0.001, timeout_seconds=1,
        tool_name_by_template_id={102: "custom_restart"},
        extra_vars_by_template_id={101: {"host_group": "private-disk-host"}, 102: {"host_group": "private-restart-host"}},
    )
    server = await create_server(settings, MockControllerClient(), console_store=local_store(tmp_path))
    async with http_client(server) as web:
        response = await web.get("/console/api/tools")
        entries = {item["name"]: item for item in response.json()["tools"]}
        assert entries["ansible_check_disk_space_101"]["has_extra_vars"] is True
        assert entries["custom_restart"]["has_extra_vars"] is True
        assert entries["ansible_deploy_application_103"]["has_extra_vars"] is False
        assert "private-disk-host" not in response.text
        assert "private-restart-host" not in response.text
