from __future__ import annotations

import inspect
import json
from copy import deepcopy

import pytest
from fastmcp import Client

from ansible_mcp.controller import ControllerError, MockControllerClient
from ansible_mcp.execution import execute_template
from ansible_mcp.registry import build_template_function
from ansible_mcp.server import create_server
from ansible_mcp.settings import Settings
from ansible_mcp.storage import StorageError


def settings_with(saved=None):
    return Settings(
        mode="mock", allowed_template_ids={101}, poll_interval_seconds=0.001,
        timeout_seconds=1, extra_vars_by_template_id={101: saved or {}},
    )


async def call_once(controller, settings, arguments):
    server = await create_server(settings, controller)
    async with Client(server) as client:
        tools = await client.list_tools()
        result = await client.call_tool(tools[0].name, arguments)
    return result, tools[0]


async def test_saved_values_supply_required_survey_without_schema_disclosure():
    controller = MockControllerClient()
    saved = {"environment": "staging", "host_group": "private-host-name", "db_password": "private-db-password"}
    settings = settings_with(saved)
    result, tool = await call_once(controller, settings, {})
    assert result.is_error is False
    assert controller.jobs[5001]["inputs"] == saved
    assert not tool.input_schema.get("required")
    public_schema = json.dumps(tool.model_dump())
    assert "private-host-name" not in public_schema
    assert "private-db-password" not in public_schema
    assert "private-db-password" not in json.dumps(result.structured_content)
    assert "private-db-password" not in repr(settings)
    assert "extra_vars" in tool.input_schema["properties"]


async def test_merge_precedence_does_not_use_pydantic_none_defaults():
    controller = MockControllerClient()
    controller.surveys[101][0]["default"] = "development"
    controller.surveys[101][1]["default"] = "controller-hosts"
    saved = {"environment": "staging", "host_group": "saved-hosts", "release": "saved"}
    result, _ = await call_once(controller, settings_with(saved), {
        "extra_vars": {"environment": "production", "host_group": "runtime-hosts", "release": "runtime"},
        "host_group": "explicit-hosts",
    })
    assert result.is_error is False
    assert controller.jobs[5001]["inputs"] == {
        "environment": "production", "host_group": "explicit-hosts", "release": "runtime",
    }


async def test_controller_survey_defaults_are_applied_internally():
    controller = MockControllerClient()
    controller.surveys[101][0]["default"] = "development"
    controller.surveys[101][1]["default"] = "controller-private-default"
    _, tool = await call_once(controller, settings_with(), {})
    assert controller.jobs[5001]["inputs"] == {
        "environment": "development", "host_group": "controller-private-default",
    }
    assert "controller-private-default" not in json.dumps(tool.model_dump())


async def test_generic_nested_values_false_zero_empty_and_null_are_preserved():
    controller = MockControllerClient()
    saved = {"environment": "staging", "host_group": "hosts", "nested": {"old": True}}
    runtime = {"nested": {"values": [False, 0, "", None, {"more": [1, 2]}]}, "empty": [], "nullable": None}
    original = deepcopy(runtime)
    await call_once(controller, settings_with(saved), {"extra_vars": runtime})
    assert controller.jobs[5001]["inputs"] == {**saved, **runtime}
    controller.jobs[5001]["inputs"]["nested"]["values"].append("mutated")
    assert runtime == original
    assert saved["nested"] == {"old": True}


async def test_optional_survey_false_zero_empty_list_defaults_are_preserved():
    controller = MockControllerClient()
    controller.surveys[101] = [
        {"variable": "enabled", "type": "boolean", "default": False},
        {"variable": "count", "type": "integer", "default": 0},
        {"variable": "text", "type": "text", "default": ""},
        {"variable": "selected", "type": "multiselect", "choices": ["a", "b"], "default": []},
    ]
    await call_once(controller, settings_with(), {})
    assert controller.jobs[5001]["inputs"] == {"enabled": False, "count": 0, "text": "", "selected": []}


async def test_blank_controller_numeric_default_means_omitted_not_invalid_integer():
    controller = MockControllerClient()
    controller.surveys[101] = [{"variable": "count", "type": "integer", "default": ""}]
    await call_once(controller, settings_with(), {})
    assert controller.jobs[5001]["inputs"] == {}


async def test_required_multiselect_without_selection_remains_required():
    controller = MockControllerClient()
    controller.surveys[101] = [{"variable": "selected", "type": "multiselect", "required": True, "default": [], "choices": ["a", "b"]}]
    _, tool = await call_once(controller, settings_with(), {"selected": ["a"]})
    assert tool.input_schema["required"] == ["selected"]


async def test_unsaved_required_fields_remain_named_required():
    controller = MockControllerClient()
    server = await create_server(settings_with(), controller)
    async with Client(server) as client:
        tools = await client.list_tools()
        assert set(tools[0].input_schema["required"]) == {"environment", "host_group"}
        with pytest.raises(Exception):
            await client.call_tool(tools[0].name, {"extra_vars": {"environment": "staging", "host_group": "hosts"}})
    assert controller.jobs == {}


@pytest.mark.parametrize("variables, alias", [
    (["extra_vars"], "additional_extra_vars"),
    (["extra_vars", "additional_extra_vars"], "additional_extra_vars_2"),
    (["extra_vars", "additional_extra_vars", "additional_extra_vars_2"], "additional_extra_vars_3"),
])
async def test_survey_variable_collision_uses_documented_alias(variables, alias):
    controller = MockControllerClient()
    controller.surveys[101] = [{"variable": name, "type": "text", "required": True} for name in variables]
    named = {name: "survey-value" for name in variables}
    _, tool = await call_once(controller, settings_with(), {**named, alias: {"arbitrary": 10}})
    assert controller.jobs[5001]["inputs"] == {**named, "arbitrary": 10}
    assert alias in tool.description
    assert set(tool.input_schema["required"]) == set(variables)


@pytest.mark.parametrize("question, value", [
    ({"type": "integer"}, True),
    ({"type": "integer"}, "private-invalid"),
    ({"type": "float"}, "private-invalid"),
    ({"type": "text"}, 17),
    ({"type": "text", "min": 5}, "tiny"),
    ({"type": "text", "max": 2}, "private-invalid"),
    ({"type": "multiplechoice", "choices": ["a", "b"]}, "private-invalid"),
    ({"type": "multiselect", "choices": ["a", "b"]}, ["private-invalid"]),
    ({"type": "multiselect"}, "private-invalid"),
    ({"type": "text", "required": True}, None),
    ({"type": "text", "required": True}, ""),
    ({"type": "multiselect", "required": True}, []),
])
async def test_invalid_saved_survey_values_fail_safely_before_registration(question, value):
    controller = MockControllerClient()
    controller.surveys[101] = [{"variable": "private", **question}]
    with pytest.raises(ControllerError) as error:
        await create_server(settings_with({"private": value}), controller)
    assert "private-invalid" not in str(error.value)
    assert controller.jobs == {}


@pytest.mark.parametrize("value", [float("nan"), float("inf"), {1, 2}, object()])
async def test_bad_json_runtime_vars_rejected_before_launch(value):
    controller = MockControllerClient()
    settings = settings_with()
    function = build_template_function(controller, settings, controller.templates[101], controller.surveys[101])
    with pytest.raises(StorageError):
        await function(environment="staging", host_group="hosts", extra_vars={"value": value})
    assert controller.jobs == {}


async def test_invalid_runtime_survey_override_is_rejected_without_value_in_error():
    controller = MockControllerClient()
    settings = settings_with({"environment": "staging", "host_group": "hosts"})
    function = build_template_function(controller, settings, controller.templates[101], controller.surveys[101])
    with pytest.raises(ControllerError) as error:
        await function(extra_vars={"environment": "private-invalid"})
    assert "private-invalid" not in str(error.value)
    assert controller.jobs == {}


async def test_explicit_ask_variables_false_rejects_saved_non_survey_vars():
    controller = MockControllerClient()
    controller.templates[101]["ask_variables_on_launch"] = False
    with pytest.raises(ControllerError, match="Prompt on launch"):
        await create_server(settings_with({"environment": "staging", "host_group": "hosts", "extra": "value"}), controller)
    assert controller.jobs == {}


async def test_explicit_ask_variables_false_rejects_runtime_non_survey_vars():
    controller = MockControllerClient()
    controller.templates[101]["ask_variables_on_launch"] = False
    settings = settings_with({"environment": "staging", "host_group": "hosts"})
    function = build_template_function(controller, settings, controller.templates[101], controller.surveys[101])
    with pytest.raises(ControllerError, match="Prompt on launch"):
        await function(extra_vars={"extra": "value"})
    assert controller.jobs == {}
    await function(extra_vars={"host_group": "allowed-survey-override"})
    assert controller.jobs[5001]["inputs"]["host_group"] == "allowed-survey-override"


async def test_disabled_survey_does_not_grant_permission_for_extra_vars():
    controller = MockControllerClient()
    controller.templates[101].update(ask_variables_on_launch=False, survey_enabled=False)
    with pytest.raises(ControllerError, match="Prompt on launch"):
        await create_server(settings_with({"environment": "staging", "host_group": "hosts"}), controller)


async def test_disabled_survey_fields_are_not_exposed_or_required():
    controller = MockControllerClient()
    controller.templates[101].update(ask_variables_on_launch=False, survey_enabled=False)
    _, tool = await call_once(controller, settings_with(), {})
    assert not tool.input_schema.get("required")
    assert set(tool.input_schema["properties"]) == {"extra_vars"}
    assert controller.jobs[5001]["inputs"] == {}


async def test_direct_execution_merges_saved_inputs_without_mutation():
    controller = MockControllerClient()
    saved = {"nested": {"items": ["original"]}}
    settings = settings_with(saved)
    await execute_template(controller, settings, controller.templates[101], {"other": 0})
    assert controller.jobs[5001]["inputs"] == {**saved, "other": 0}
    controller.jobs[5001]["inputs"]["nested"]["items"].clear()
    assert saved["nested"]["items"] == ["original"]


def test_saved_values_never_become_signature_defaults():
    controller = MockControllerClient()
    function = build_template_function(controller, settings_with({"environment": "staging", "host_group": "private-saved"}), controller.templates[101], controller.surveys[101])
    assert all(parameter.default is None for parameter in inspect.signature(function).parameters.values())


def test_settings_plaintext_allowlist_does_not_load_extra_vars(tmp_path):
    allowlist = tmp_path / "templates.json"
    allowlist.write_text(json.dumps({"allowed_template_ids": [101], "extra_vars_by_template_id": {"101": {"secret": "do-not-load"}}}), encoding="utf-8")
    settings = Settings(allowlist_path=allowlist)
    settings.load_allowlist()
    assert settings.extra_vars_by_template_id == {}
