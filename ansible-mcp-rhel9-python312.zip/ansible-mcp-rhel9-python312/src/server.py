from __future__ import annotations

import asyncio
import os

from ansible_mcp.server import create_server


mcp = asyncio.run(create_server())


if __name__ == "__main__":
    transport = os.getenv("MCP_TRANSPORT", "stdio")
    if transport == "http":
        mcp.run(
            transport="http",
            host=os.getenv("MCP_HOST", "127.0.0.1"),
            port=int(os.getenv("MCP_PORT", "8000")),
        )
    else:
        mcp.run(transport="stdio")
