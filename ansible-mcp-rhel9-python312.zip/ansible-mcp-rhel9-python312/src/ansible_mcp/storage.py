"""Local connection registration with platform-specific credential encryption.

The SQLite file contains configuration and ciphertext, never a token or an
encryption key. Windows uses per-user DPAPI. POSIX uses a separately initialized
private Fernet key file; secret-free mock registrations need no key.
"""

from __future__ import annotations

import ctypes
import json
import math
import os
import re
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterator, Protocol
from urllib.parse import urlsplit


class StorageError(RuntimeError):
    """A safe-to-display registration or storage error."""


class CredentialProtector(Protocol):
    def encrypt(self, value: str) -> bytes: ...

    def decrypt(self, value: bytes) -> str: ...


class WindowsDPAPIProtector:
    """Use Windows DPAPI in current-user scope, with all prompts disabled."""

    @staticmethod
    def _transform(value: bytes, *, decrypt: bool) -> bytes:
        if os.name != "nt":
            raise StorageError(
                "Credential storage requires Windows DPAPI on this installation. "
                "Mock connections can be stored without credentials."
            )
        from ctypes import wintypes

        class DataBlob(ctypes.Structure):
            _fields_ = [
                ("cbData", wintypes.DWORD),
                ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
            ]

        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        input_buffer = (ctypes.c_ubyte * len(value)).from_buffer_copy(value)
        input_blob = DataBlob(len(value), input_buffer)
        output_blob = DataBlob()
        function = crypt32.CryptUnprotectData if decrypt else crypt32.CryptProtectData
        function.argtypes = [
            ctypes.POINTER(DataBlob),
            ctypes.c_void_p,
            ctypes.POINTER(DataBlob),
            ctypes.c_void_p,
            ctypes.c_void_p,
            wintypes.DWORD,
            ctypes.POINTER(DataBlob),
        ]
        function.restype = wintypes.BOOL
        kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        kernel32.LocalFree.restype = ctypes.c_void_p
        if not function(
            ctypes.byref(input_blob), None, None, None, None, 1,
            ctypes.byref(output_blob),
        ):
            raise StorageError(
                "Windows could not protect or unlock the stored credential. "
                "Use the original Windows account or save the credential again."
            )
        try:
            return ctypes.string_at(output_blob.pbData, output_blob.cbData)
        finally:
            if output_blob.pbData:
                ctypes.memset(output_blob.pbData, 0, output_blob.cbData)
                kernel32.LocalFree(ctypes.cast(output_blob.pbData, ctypes.c_void_p))

    def encrypt(self, value: str) -> bytes:
        return self._transform(value.encode("utf-8"), decrypt=False)

    def decrypt(self, value: bytes) -> str:
        if isinstance(value, bytes) and value.startswith(b"FERNET1:"):
            raise StorageError("The stored value uses POSIX encryption. Use its original platform and key, or register it again on Windows.")
        try:
            return self._transform(value, decrypt=True).decode("utf-8")
        except UnicodeError:
            raise StorageError("The stored credential could not be decoded. Save it again.") from None


@dataclass(slots=True)
class StoredConnection:
    name: str
    mode: str
    base_url: str | None = None
    api_path: str = "/api/v2/"
    token: str | None = field(default=None, repr=False)
    verify_tls: bool = True
    expires_at: str | None = None
    templates: list[dict[str, Any]] = field(default_factory=list, repr=False)
    active: bool = False


def default_storage_path() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    else:
        root = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return root / "AnsibleTemplateTools" / "config.sqlite3"


def validate_controller_url(base_url: str) -> str:
    """Return an HTTPS origin; credentials, paths and URL overrides are rejected."""
    try:
        if not isinstance(base_url, str) or base_url != base_url.strip():
            raise ValueError
        if any(ord(char) < 33 for char in base_url) or "\\" in base_url:
            raise ValueError
        parsed = urlsplit(base_url)
        if (
            parsed.scheme != "https" or not parsed.hostname
            or parsed.username is not None or parsed.password is not None
            or parsed.query or parsed.fragment or "?" in base_url or "#" in base_url
            or parsed.path not in {"", "/"}
            or "%" in parsed.netloc
        ):
            raise ValueError
        _ = parsed.port  # Force validation of an invalid/out-of-range port.
        return f"https://{parsed.netloc}".rstrip("/")
    except (ValueError, TypeError):
        raise StorageError(
            "Controller URL must be an HTTPS origin, such as https://controller.example.com, "
            "without credentials, a path, query, or fragment."
        ) from None


def validate_api_path(api_path: str) -> str:
    if not isinstance(api_path, str) or not re.fullmatch(r"/api/(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_-]+/?", api_path):
        raise StorageError("API path must start with /api/ and contain plain path segments, for example /api/v2/.")
    return api_path.rstrip("/") + "/"


def validate_extra_vars(value: Any) -> dict[str, Any]:
    """Validate and detach an extra-variable JSON object without echoing values.

    Objects must have string keys; values may be JSON objects, arrays, strings,
    finite numbers, booleans, or null. At most 20 nested containers and 16 KiB of
    compact UTF-8 JSON are allowed. A fresh JSON-roundtripped dictionary is
    returned so later caller mutations cannot alter a validated registration.
    """
    if type(value) is not dict:
        raise StorageError("Extra variables must be a JSON object with string keys.")

    def check(item: Any, depth: int) -> None:
        kind = type(item)
        if kind in {dict, list}:
            if depth > 20:
                raise StorageError("Extra variables exceed the maximum nesting depth of 20.")
            if kind is dict:
                for key, child in item.items():
                    if type(key) is not str:
                        raise StorageError("Extra-variable object keys must be strings.")
                    check(child, depth + 1)
            else:
                for child in item:
                    check(child, depth + 1)
        elif kind is float:
            if not math.isfinite(item):
                raise StorageError("Extra-variable numbers must be finite JSON numbers.")
        elif kind not in {str, int, bool, type(None)}:
            raise StorageError("Extra variables may contain only JSON values.")

    check(value, 1)
    try:
        serialized = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        if len(serialized.encode("utf-8")) > 16 * 1024:
            raise StorageError("Extra variables exceed the 16 KiB JSON size limit.")
        return json.loads(serialized)
    except (ValueError, TypeError, UnicodeError, RecursionError):
        raise StorageError("Extra variables must contain valid UTF-8 JSON values.") from None


def validate_templates(templates: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    if templates is None:
        return []
    if not isinstance(templates, list):
        raise StorageError("Templates must be a list of selected template records.")
    normalized: list[dict[str, Any]] = []
    ids: set[int] = set()
    tool_names: set[str] = set()
    for item in templates:
        if not isinstance(item, dict) or set(item) - {"id", "name", "risk", "tool_name", "extra_vars"}:
            raise StorageError("Template records accept only id, name, risk, tool_name, and extra_vars.")
        template_id = item.get("id")
        if type(template_id) is not int or not 0 < template_id <= 2**63 - 1:
            raise StorageError("Every selected template requires a positive integer ID.")
        if template_id in ids:
            raise StorageError("Selected template IDs must be unique.")
        ids.add(template_id)
        risk = item.get("risk", "write")
        if not isinstance(risk, str) or risk not in {"read-only", "write"}:
            raise StorageError("Template risk must be read-only or write.")
        record: dict[str, Any] = {"id": template_id, "risk": risk}
        name = item.get("name")
        if name is not None:
            if not isinstance(name, str) or not name.strip() or len(name) > 256 or any(ord(c) < 32 for c in name):
                raise StorageError("Template names must contain 1-256 printable characters.")
            record["name"] = name.strip()
        tool_name = item.get("tool_name")
        if tool_name is not None:
            if not isinstance(tool_name, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", tool_name):
                raise StorageError("Tool names must start with a letter and contain up to 64 letters, digits, or underscores.")
            if tool_name in tool_names:
                raise StorageError("Selected tool names must be unique within a connection.")
            tool_names.add(tool_name)
            record["tool_name"] = tool_name
        if "extra_vars" in item:
            extra_vars = validate_extra_vars(item["extra_vars"])
            if extra_vars:
                record["extra_vars"] = extra_vars
        normalized.append(record)
    return normalized


_SCHEMA_VERSION = 2
_V1_TABLE_COLUMNS = {
    "connections": {"name", "mode", "base_url", "api_path", "credential", "verify_tls", "created_at", "updated_at", "expires_at"},
    "templates": {"connection_name", "template_id", "display_name", "risk", "tool_name"},
    "settings": {"key", "value"},
}
_TABLE_COLUMNS = dict(_V1_TABLE_COLUMNS, templates=_V1_TABLE_COLUMNS["templates"] | {"extra_vars"})
_COLUMN_SHAPES = {
    "connections": {
        "name": ("TEXT", 0, 1), "mode": ("TEXT", 1, 0), "base_url": ("TEXT", 0, 0),
        "api_path": ("TEXT", 1, 0), "credential": ("BLOB", 0, 0), "verify_tls": ("INTEGER", 1, 0),
        "created_at": ("TEXT", 1, 0), "updated_at": ("TEXT", 1, 0), "expires_at": ("TEXT", 1, 0),
    },
    "templates": {
        "connection_name": ("TEXT", 1, 1), "template_id": ("INTEGER", 1, 2),
        "display_name": ("TEXT", 0, 0), "risk": ("TEXT", 1, 0), "tool_name": ("TEXT", 0, 0),
        "extra_vars": ("BLOB", 0, 0),
    },
    "settings": {"key": ("TEXT", 0, 1), "value": ("TEXT", 1, 0)},
}


class LocalStore:
    def __init__(
        self, path: Path | None = None, *,
        protector: CredentialProtector | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.path = (Path(path) if path is not None else default_storage_path()).resolve()
        if protector is not None:
            self._protector = protector
        elif os.name == "nt":
            self._protector = WindowsDPAPIProtector()
        else:
            from .posix_secrets import FernetProtector

            self._protector = FernetProtector()
        self._clock = clock if clock is not None else lambda: datetime.now(timezone.utc)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            if os.name == "posix":
                # Make only new database files private; do not chmod existing
                # user files or broad ancestor directories.
                try:
                    descriptor = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                except FileExistsError:
                    pass
                else:
                    os.close(descriptor)
            with self._connection():
                pass
        except OSError:
            raise StorageError("Could not open the local registration database. Check the storage directory permissions.") from None

    def _now(self) -> datetime:
        value = self._clock()
        if not isinstance(value, datetime) or value.tzinfo is None:
            raise StorageError("The storage clock must return a timezone-aware datetime.")
        return value.astimezone(timezone.utc)

    @staticmethod
    def _timestamp(value: datetime) -> str:
        return value.isoformat().replace("+00:00", "Z")

    @staticmethod
    def _parse_timestamp(value: str) -> datetime:
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                raise ValueError
            return parsed.astimezone(timezone.utc)
        except (ValueError, TypeError, AttributeError):
            raise StorageError("A stored connection has an invalid expiry. Save the connection again.") from None

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        database: sqlite3.Connection | None = None
        try:
            database = sqlite3.connect(self.path, timeout=10)
            database.row_factory = sqlite3.Row
            database.execute("PRAGMA foreign_keys = ON")
            database.execute("PRAGMA secure_delete = ON")
            with database:
                database.execute("BEGIN IMMEDIATE")
                version = database.execute("PRAGMA user_version").fetchone()[0]
                tables = {
                    row[0] for row in database.execute(
                        "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"
                    )
                }
                if version == 0 and not tables:
                    self._create_schema(database)
                elif version == 1:
                    # Validate before touching the existing records. ALTER and
                    # user_version share this transaction and roll back together.
                    self._check_schema(database, _V1_TABLE_COLUMNS)
                    database.execute("ALTER TABLE templates ADD COLUMN extra_vars BLOB")
                    database.execute(f"PRAGMA user_version = {_SCHEMA_VERSION}")
                elif version != _SCHEMA_VERSION:
                    raise StorageError("Unsupported local database schema version. Use a compatible application version or a new database path.")
                self._check_schema(database)
            # Keep related reads (credentials and template selections) in one
            # snapshot while another process may be updating the registration.
            with database:
                database.execute("BEGIN")
                yield database
        except sqlite3.Error:
            raise StorageError("The local registration database operation failed; no credentials were displayed. Check the database and directory permissions.") from None
        finally:
            if database is not None:
                database.close()

    @staticmethod
    def _create_schema(database: sqlite3.Connection) -> None:
        database.execute(
            "CREATE TABLE connections (name TEXT PRIMARY KEY, mode TEXT NOT NULL CHECK(mode IN ('mock', 'controller')), "
            "base_url TEXT, api_path TEXT NOT NULL, credential BLOB, verify_tls INTEGER NOT NULL CHECK(verify_tls IN (0, 1)), "
            "created_at TEXT NOT NULL, updated_at TEXT NOT NULL, expires_at TEXT NOT NULL)"
        )
        database.execute(
            "CREATE TABLE templates (connection_name TEXT NOT NULL REFERENCES connections(name) ON DELETE CASCADE, "
            "template_id INTEGER NOT NULL CHECK(template_id > 0), display_name TEXT, "
            "risk TEXT NOT NULL CHECK(risk IN ('read-only', 'write')), tool_name TEXT, extra_vars BLOB, "
            "PRIMARY KEY(connection_name, template_id), UNIQUE(connection_name, tool_name))"
        )
        database.execute("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        database.execute(f"PRAGMA user_version = {_SCHEMA_VERSION}")

    @staticmethod
    def _check_schema(
        database: sqlite3.Connection, expected_columns: dict[str, set[str]] | None = None,
    ) -> None:
        expected_columns = expected_columns if expected_columns is not None else _TABLE_COLUMNS
        tables = {
            row[0] for row in database.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"
            )
        }
        if tables != set(expected_columns):
            raise StorageError("The local database schema is incompatible. Use a compatible database or a new database path.")
        for table, columns in expected_columns.items():
            details = list(database.execute(f"PRAGMA table_info({table})"))
            actual = {row[1] for row in details}
            if actual != columns or any(
                (row[2].upper(), row[3], row[5]) != _COLUMN_SHAPES[table][row[1]] or row[4] is not None
                for row in details
            ):
                raise StorageError("The local database schema is incompatible. Use a compatible database or a new database path.")

    @staticmethod
    def _validate_name(name: str) -> str:
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", name):
            raise StorageError("Connection names must contain 1-64 letters, digits, underscores, hyphens, or dots, starting with a letter or digit.")
        return name

    @staticmethod
    def _active_name(database: sqlite3.Connection) -> str | None:
        row = database.execute("SELECT value FROM settings WHERE key = 'active_connection'").fetchone()
        return row[0] if row else None

    def _template_records(
        self, database: sqlite3.Connection, name: str, *, include_extra_vars: bool = True,
    ) -> list[dict[str, Any]]:
        records = []
        protected_values: dict[int, bytes] = {}
        for row in database.execute(
            "SELECT template_id, display_name, risk, tool_name, extra_vars FROM templates WHERE connection_name = ? ORDER BY template_id", (name,)
        ):
            item = {"id": row["template_id"], "risk": row["risk"]}
            if row["display_name"] is not None:
                item["name"] = row["display_name"]
            if row["tool_name"] is not None:
                item["tool_name"] = row["tool_name"]
            if row["extra_vars"] is not None:
                protected_values[row["template_id"]] = row["extra_vars"]
            records.append(item)
        records = validate_templates(records)
        for item in records:
            if item["id"] not in protected_values:
                continue
            if not include_extra_vars:
                item["has_extra_vars"] = True
                continue
            try:
                ciphertext = protected_values[item["id"]]
                if not isinstance(ciphertext, bytes) or not ciphertext:
                    raise ValueError
                extra_vars = validate_extra_vars(json.loads(self._protector.decrypt(ciphertext)))
            except Exception:
                raise StorageError("Could not unlock the saved extra variables. Use the original account and credential key, or save them again.") from None
            if extra_vars:
                item["extra_vars"] = extra_vars
        return records

    def save_connection(
        self, name: str, *, mode: str, base_url: str | None = None,
        api_path: str = "/api/v2/", token: str | None = None,
        verify_tls: bool = True, templates: list[dict[str, Any]] | None = None,
        ttl_hours: float = 24, activate: bool = True, create_only: bool = False,
    ) -> None:
        name = self._validate_name(name)
        if not isinstance(mode, str) or mode not in {"mock", "controller"}:
            raise StorageError("Connection mode must be mock or controller.")
        if type(verify_tls) is not bool or type(activate) is not bool or type(create_only) is not bool:
            raise StorageError("verify_tls, activate, and create_only must be boolean values.")
        try:
            valid_ttl = not isinstance(ttl_hours, bool) and isinstance(ttl_hours, (int, float)) and math.isfinite(ttl_hours) and ttl_hours > 0
        except OverflowError:
            valid_ttl = False
        if not valid_ttl:
            raise StorageError("Connection expiry must be a finite, positive number of hours.")
        api_path = validate_api_path(api_path)
        selected = validate_templates(templates)
        if mode == "mock":
            if token is not None or base_url is not None:
                raise StorageError("Mock connections do not accept a controller URL or credential.")
        else:
            base_url = validate_controller_url(base_url)  # type: ignore[arg-type]
            if not isinstance(token, str) or not token.strip() or token != token.strip() or any(ord(c) < 32 or ord(c) == 127 for c in token):
                raise StorageError("Controller connections require a nonempty token without whitespace padding or control characters.")
            if not selected:
                raise StorageError("Select at least one approved template for a controller connection.")
        now = self._now()
        try:
            expiry = now + timedelta(hours=ttl_hours)
        except OverflowError:
            raise StorageError("Connection expiry is too large. Choose a shorter duration.") from None
        credential = None
        if token is not None:
            try:
                credential = self._protector.encrypt(token)
                if not isinstance(credential, bytes) or not credential or credential == token.encode("utf-8"):
                    raise ValueError
            except StorageError:
                raise
            except Exception:
                raise StorageError("Could not encrypt the credential. The connection was not saved.") from None
        protected_values: dict[int, bytes] = {}
        for item in selected:
            if "extra_vars" not in item:
                continue
            serialized = json.dumps(item["extra_vars"], ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            try:
                ciphertext = self._protector.encrypt(serialized)
                if not isinstance(ciphertext, bytes) or not ciphertext or ciphertext == serialized.encode("utf-8"):
                    raise ValueError
            except StorageError:
                raise
            except Exception:
                raise StorageError("Could not encrypt the extra variables. The connection was not saved.") from None
            protected_values[item["id"]] = ciphertext
        with self._connection() as database, database:
            insert_sql = (
                "INSERT INTO connections (name, mode, base_url, api_path, credential, verify_tls, created_at, updated_at, expires_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            )
            if not create_only:
                insert_sql += (
                    " ON CONFLICT(name) DO UPDATE SET mode=excluded.mode, base_url=excluded.base_url, api_path=excluded.api_path, "
                    "credential=excluded.credential, verify_tls=excluded.verify_tls, updated_at=excluded.updated_at, expires_at=excluded.expires_at"
                )
            try:
                # INSERT itself arbitrates competing processes. A separate
                # existence check cannot safely provide create-only semantics.
                database.execute(
                    insert_sql,
                    (name, mode, base_url, api_path, credential, int(verify_tls), self._timestamp(now), self._timestamp(now), self._timestamp(expiry)),
                )
            except sqlite3.IntegrityError as exc:
                if create_only and exc.sqlite_errorcode == sqlite3.SQLITE_CONSTRAINT_PRIMARYKEY:
                    raise StorageError("That connection already exists. Choose a different name or explicitly replace it.") from None
                raise
            database.execute("DELETE FROM templates WHERE connection_name = ?", (name,))
            database.executemany(
                "INSERT INTO templates (connection_name, template_id, display_name, risk, tool_name, extra_vars) VALUES (?, ?, ?, ?, ?, ?)",
                [(name, item["id"], item.get("name"), item["risk"], item.get("tool_name"), protected_values.get(item["id"])) for item in selected],
            )
            if activate:
                database.execute(
                    "INSERT INTO settings(key, value) VALUES ('active_connection', ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (name,)
                )

    def load_active(self) -> StoredConnection | None:
        with self._connection() as database:
            name = self._active_name(database)
            if name is None:
                return None
            connection = self._load_connection(database, name, active=True)
            if connection is None:
                raise StorageError("The active local connection is missing. Save or activate a connection again.")
            return connection

    def load_connection(self, name: str) -> StoredConnection | None:
        """Load only the named connection without changing the active selection.

        This returns decrypted credentials for internal use; use
        ``list_connections`` for metadata intended for a console response.
        """
        name = self._validate_name(name)
        with self._connection() as database:
            return self._load_connection(database, name, active=name == self._active_name(database))

    def _load_connection(
        self, database: sqlite3.Connection, name: str, *, active: bool,
    ) -> StoredConnection | None:
        row = database.execute("SELECT * FROM connections WHERE name = ?", (name,)).fetchone()
        if row is None:
            return None
        if self._parse_timestamp(row["expires_at"]) <= self._now():
            if active:
                raise StorageError("The active local connection has expired. Save its credentials again and re-activate it.")
            raise StorageError("The selected local connection has expired. Save its credentials again before using it.")
        mode = row["mode"]
        selected = self._template_records(database, name)
        api_path = validate_api_path(row["api_path"])
        base_url = row["base_url"]
        token = None
        if mode == "controller":
            base_url = validate_controller_url(base_url)
            if not selected or not isinstance(row["credential"], bytes) or not row["credential"]:
                raise StorageError("The stored controller registration is incomplete. Save the connection again.")
            try:
                token = self._protector.decrypt(row["credential"])
                if not isinstance(token, str) or not token.strip():
                    raise ValueError
            except StorageError:
                raise
            except Exception:
                raise StorageError("Could not unlock the stored credential. Use the original account and credential key, or save it again.") from None
        elif mode != "mock" or base_url is not None or row["credential"] is not None:
            raise StorageError("The stored connection mode is invalid. Save the connection again.")
        return StoredConnection(
            name=name, mode=mode, base_url=base_url, api_path=api_path,
            token=token, verify_tls=bool(row["verify_tls"]), expires_at=row["expires_at"],
            templates=selected, active=active,
        )

    def list_connections(self) -> list[dict[str, Any]]:
        with self._connection() as database:
            active_name = self._active_name(database)
            now = self._now()
            records = []
            for row in database.execute(
                "SELECT name, mode, base_url, api_path, verify_tls, created_at, updated_at, expires_at, "
                "(credential IS NOT NULL) AS has_credential FROM connections ORDER BY name"
            ):
                record = dict(row)
                record["verify_tls"] = bool(record["verify_tls"])
                record["has_credential"] = bool(record["has_credential"])
                record["active"] = row["name"] == active_name
                record["expired"] = self._parse_timestamp(row["expires_at"]) <= now
                record["templates"] = self._template_records(database, row["name"], include_extra_vars=False)
                records.append(record)
            return records

    def activate(self, name: str) -> None:
        name = self._validate_name(name)
        with self._connection() as database, database:
            row = database.execute("SELECT expires_at FROM connections WHERE name = ?", (name,)).fetchone()
            if row is None:
                raise StorageError("The requested connection does not exist. Save it first.")
            if self._parse_timestamp(row["expires_at"]) <= self._now():
                raise StorageError("The requested connection has expired. Save it again before activation.")
            database.execute(
                "INSERT INTO settings(key, value) VALUES ('active_connection', ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (name,)
            )

    def delete_connection(self, name: str) -> None:
        name = self._validate_name(name)
        with self._connection() as database, database:
            database.execute("DELETE FROM settings WHERE key = 'active_connection' AND value = ?", (name,))
            database.execute("DELETE FROM connections WHERE name = ?", (name,))
