"""Initialize or verify the POSIX credential key without displaying its bytes."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .posix_secrets import check_key, initialize_key
from .storage import StorageError


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Manage the local POSIX credential key.")
    parser.add_argument("command", choices=("init", "check"))
    parser.add_argument("--path", type=Path, help="Override ANSIBLE_CREDENTIAL_KEY_FILE.")
    args = parser.parse_args(argv)
    try:
        selected = initialize_key(args.path) if args.command == "init" else check_key(args.path)
    except StorageError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(f"Credential key ready: {selected}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
