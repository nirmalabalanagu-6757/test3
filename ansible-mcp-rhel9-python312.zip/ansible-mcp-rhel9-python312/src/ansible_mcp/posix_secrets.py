"""POSIX credential encryption with a separately managed, private key file.

The key is created only by explicit initialization. Encryption and decryption
never generate a replacement key, so a missing key cannot silently orphan data.
Permission checks use POSIX owner/mode bits; administrators must also ensure
that inherited or named filesystem ACLs do not grant additional access.
"""

from __future__ import annotations

import os
import secrets
import stat
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from cryptography.fernet import Fernet, InvalidToken


PREFIX = b"FERNET1:"


def _error(message: str):
    # Storage imports this module lazily after defining StorageError.
    from .storage import StorageError

    return StorageError(message)


def default_key_path() -> Path:
    override = os.environ.get("ANSIBLE_CREDENTIAL_KEY_FILE")
    if override:
        return Path(override).expanduser().absolute()
    root = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    return (root / "ansible-template-tools" / "credential.key").expanduser().absolute()


def _path(path: Path | None) -> Path:
    # Do not resolve symlinks: validation must see and reject the original path.
    return Path(path).expanduser().absolute() if path is not None else default_key_path()


def _reject_symlinks(path: Path) -> None:
    for component in (path, *path.parents):
        try:
            details = component.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(details.st_mode):
            raise _error("The credential key path must not contain symbolic links.")


def _check_private_stat(details: os.stat_result, *, directory: bool) -> None:
    expected_mode = 0o700 if directory else 0o600
    expected_type = stat.S_ISDIR if directory else stat.S_ISREG
    if not expected_type(details.st_mode):
        raise _error("The credential key must be a regular file in a private directory.")
    if details.st_uid != os.geteuid() or stat.S_IMODE(details.st_mode) != expected_mode:
        raise _error("The credential key must be owned by the current user with mode 0600, in a user-owned 0700 directory.")


@contextmanager
def _directory(path: Path, *, create: bool = False) -> Iterator[int]:
    if os.name != "posix":
        raise _error("File-key initialization is for POSIX systems; Windows uses per-user DPAPI.")
    _reject_symlinks(path)
    if create:
        # Only the dedicated final directory receives 0700; existing ancestors
        # such as ~/.config are never chmod-ed or otherwise modified.
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    _reject_symlinks(path)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
    descriptor = os.open(path, flags)
    try:
        _check_private_stat(os.fstat(descriptor), directory=True)
        yield descriptor
    finally:
        os.close(descriptor)


def _read_from_directory(directory: int, name: str) -> bytes:
    flags = os.O_RDONLY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0) | os.O_NONBLOCK
    descriptor = os.open(name, flags, dir_fd=directory)
    try:
        details = os.fstat(descriptor)
        _check_private_stat(details, directory=False)
        if details.st_size != 44:
            raise _error("The credential key file is invalid. Restore the original key; do not replace it for an existing database.")
        value = os.read(descriptor, 65)
        if len(value) != 44:
            raise _error("The credential key file is invalid. Restore the original key.")
        try:
            Fernet(value)
        except (ValueError, TypeError):
            raise _error("The credential key file is invalid. Restore the original key.") from None
        return value
    finally:
        os.close(descriptor)


def _read_key(path: Path) -> bytes:
    try:
        _reject_symlinks(path)
        with _directory(path.parent) as directory:
            return _read_from_directory(directory, path.name)
    except FileNotFoundError:
        raise _error(
            "The credential key is missing. Restore the original key for existing data, "
            "or run key_management init before saving a new registration."
        ) from None
    except OSError:
        raise _error("Could not read the credential key securely. Check its ownership, permissions, and path.") from None


def check_key(path: Path | None = None) -> Path:
    """Verify an existing key without changing it or returning its contents."""
    selected = _path(path)
    _read_key(selected)
    return selected


def initialize_key(path: Path | None = None) -> Path:
    """Atomically publish a new key only when absent; validate/reuse an existing key."""
    selected = _path(path)
    try:
        _reject_symlinks(selected)
        with _directory(selected.parent, create=True) as directory:
            try:
                _read_from_directory(directory, selected.name)
                return selected
            except FileNotFoundError:
                pass
            temporary_name = f".credential-key-{secrets.token_hex(16)}.tmp"
            descriptor = os.open(
                temporary_name,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0),
                0o600, dir_fd=directory,
            )
            try:
                try:
                    # fchmod applies only to this newly created dedicated file.
                    os.fchmod(descriptor, 0o600)
                    data = Fernet.generate_key()
                    written = 0
                    while written < len(data):
                        count = os.write(descriptor, data[written:])
                        if count <= 0:
                            raise OSError("Key write failed")
                        written += count
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
                try:
                    # Hard-link publication is atomic and fails if destination
                    # exists; it never replaces an existing credential key.
                    os.link(temporary_name, selected.name, src_dir_fd=directory,
                            dst_dir_fd=directory, follow_symlinks=False)
                except FileExistsError:
                    pass  # Another initializer won; validate its key below.
            finally:
                os.unlink(temporary_name, dir_fd=directory)
            os.fsync(directory)
            _read_from_directory(directory, selected.name)
        return selected
    except OSError:
        raise _error("Could not initialize the credential key securely. Check the dedicated directory and permissions; an existing key was not replaced.") from None


class FernetProtector:
    """Versioned authenticated ciphertext protected by the configured POSIX key."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = _path(path)

    def encrypt(self, value: str) -> bytes:
        cipher = Fernet(_read_key(self.path))
        try:
            return PREFIX + cipher.encrypt(value.encode("utf-8"))
        except (ValueError, TypeError, UnicodeError):
            raise _error("Could not encrypt the stored value.") from None

    def decrypt(self, value: bytes) -> str:
        if not isinstance(value, bytes) or not value.startswith(PREFIX):
            raise _error("The stored value uses a different platform or unsupported encryption format. Use the original platform or register it again.")
        cipher = Fernet(_read_key(self.path))
        try:
            return cipher.decrypt(value[len(PREFIX):]).decode("utf-8")
        except (InvalidToken, ValueError, TypeError, UnicodeError):
            raise _error("Could not unlock the stored value. Restore the correct credential key or register the connection again.") from None
