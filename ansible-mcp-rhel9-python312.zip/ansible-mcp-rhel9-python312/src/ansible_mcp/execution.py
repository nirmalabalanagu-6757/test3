from __future__ import annotations

import asyncio
import math
import re
from typing import Any

from .controller import ControllerClient, ControllerError, TERMINAL_STATES
from .settings import Settings
from .storage import validate_extra_vars


SECRET_PATTERN = re.compile(
    r"(?i)\b(token|password|secret|api[_-]?key)\s*[=:]\s*[^\s,}\]]+"
)


def redact(value: Any, *, secret_values: set[str] | None = None) -> Any:
    if isinstance(value, str):
        for secret in sorted(secret_values or (), key=len, reverse=True):
            value = value.replace(secret, "[REDACTED]")
        return SECRET_PATTERN.sub(lambda match: f"{match.group(1)}=[REDACTED]", value)
    if isinstance(value, list):
        return [redact(item, secret_values=secret_values) for item in value]
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            if any(word in key.lower() for word in ("token", "password", "secret", "key")):
                result[key] = "[REDACTED]"
            else:
                result[key] = redact(item, secret_values=secret_values)
        return result
    return value


def _secret_strings(value: Any, *, sensitive: bool = False) -> set[str]:
    """Best-effort output protection for secret-shaped input keys, including nested ones."""
    if isinstance(value, dict):
        secrets: set[str] = set()
        for key, item in value.items():
            secret_key = sensitive or any(
                word in key.lower() for word in ("token", "password", "secret", "api_key", "apikey", "api-key")
            )
            secrets.update(_secret_strings(item, sensitive=secret_key))
        return secrets
    if isinstance(value, list):
        secrets = set()
        for item in value:
            secrets.update(_secret_strings(item, sensitive=sensitive))
        return secrets
    return {value} if sensitive and isinstance(value, str) and value else set()


def survey_defaults(questions: list[dict[str, Any]]) -> dict[str, Any]:
    """Keep controller defaults private; a required blank default means unset."""
    defaults: dict[str, Any] = {}
    for question in questions:
        value = question.get("default")
        if not question.get("variable") or value is None:
            continue
        kind = question.get("type", "text")
        if value == "" and (question.get("required") or kind not in {"text", "textarea", "password"}):
            continue
        if value == [] and question.get("required"):
            continue
        defaults[question["variable"]] = value
    return defaults


def validate_survey_values(
    values: dict[str, Any],
    questions: list[dict[str, Any]],
    *,
    require_required: bool,
) -> None:
    """Validate without placing potentially secret values in exception messages."""
    for question in questions:
        variable = question["variable"]
        if variable not in values:
            if require_required and question.get("required"):
                raise ControllerError("A required Ansible survey variable is missing")
            continue
        value = values[variable]
        kind = question.get("type", "text")
        valid = False
        if kind == "integer":
            valid = type(value) is int
        elif kind == "float":
            valid = type(value) in {int, float} and math.isfinite(value)
        elif kind in {"boolean", "checkbox"}:
            valid = type(value) is bool
        elif kind == "multiselect":
            valid = isinstance(value, list) and all(isinstance(item, str) for item in value)
        else:
            valid = isinstance(value, str)
        if not valid:
            raise ControllerError("An extra variable has an invalid Ansible survey type")
        if kind in {"multiplechoice", "select", "multiselect"}:
            choices = question.get("choices", [])
            if isinstance(choices, str):
                choices = [item.strip() for item in choices.splitlines() if item.strip()]
            if choices:
                selected = value if kind == "multiselect" else [value]
                if any(item not in choices for item in selected):
                    raise ControllerError("An extra variable is not an allowed Ansible survey choice")
        if question.get("required") and value in ("", []):
            raise ControllerError("A required Ansible survey variable cannot be empty")
        measurement = len(value) if isinstance(value, (str, list)) else value
        if type(measurement) in {int, float}:
            for bound, compare in (("min", lambda a, b: a < b), ("max", lambda a, b: a > b)):
                limit = question.get(bound)
                if type(limit) in {int, float} and compare(measurement, limit):
                    raise ControllerError("An extra variable is outside an Ansible survey limit")


def validate_extra_vars_allowed(
    template: dict[str, Any],
    questions: list[dict[str, Any]],
    values: dict[str, Any],
) -> None:
    if template.get("ask_variables_on_launch") is False:
        survey_variables = (
            {question["variable"] for question in questions}
            if template.get("survey_enabled") is not False else set()
        )
        if values.keys() - survey_variables:
            raise ControllerError(
                "This template does not allow non-survey extra variables. "
                "Enable Prompt on launch for Variables in Ansible or use only survey fields."
            )


async def execute_template(
    controller: ControllerClient,
    settings: Settings,
    template: dict[str, Any],
    inputs: dict[str, Any],
    *,
    survey_questions: list[dict[str, Any]] | None = None,
    runtime_extra_vars: dict[str, Any] | None = None,
) -> dict[str, Any]:
    settings.assert_not_expired()
    template_id = int(template["id"])
    if not settings.permits(template_id):
        raise ControllerError("Template is not allowed")

    questions = survey_questions or []
    saved = validate_extra_vars(settings.extra_vars_by_template_id.get(template_id, {}))
    additional = validate_extra_vars(runtime_extra_vars if runtime_extra_vars is not None else {})
    named = validate_extra_vars(inputs)
    merged = validate_extra_vars({**survey_defaults(questions), **saved, **additional, **named})
    validate_extra_vars_allowed(template, questions, merged)
    validate_survey_values(merged, questions, require_required=True)
    secrets = _secret_strings(merged)
    launch = await controller.launch_template(template_id, merged)
    job_id = int(launch.get("job") or launch.get("id"))

    try:
        async with asyncio.timeout(settings.timeout_seconds):
            while True:
                status = await controller.get_job_status(job_id)
                if status.get("status") in TERMINAL_STATES:
                    output = await controller.get_job_output(job_id)
                    return redact(
                        {
                            "template_id": template_id,
                            "template": template["name"],
                            "job_id": job_id,
                            "status": status.get("status"),
                            "started": status.get("started"),
                            "finished": status.get("finished"),
                            "output": output,
                        },
                        secret_values=secrets,
                    )
                await asyncio.sleep(settings.poll_interval_seconds)
    except asyncio.CancelledError:
        await controller.cancel_job(job_id)
        raise
    except TimeoutError as exc:
        await controller.cancel_job(job_id)
        raise ControllerError(
            f"Ansible job {job_id} exceeded the configured timeout"
        ) from exc
