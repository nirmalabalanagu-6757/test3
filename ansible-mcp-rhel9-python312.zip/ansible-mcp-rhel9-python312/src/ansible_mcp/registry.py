from __future__ import annotations

import inspect
import keyword
import re
from copy import deepcopy
from typing import Any, Literal

from fastmcp import FastMCP
from pydantic import StrictBool, StrictFloat, StrictInt, StrictStr

from .controller import ControllerClient
from .execution import (
    execute_template, survey_defaults, validate_extra_vars_allowed, validate_survey_values,
)
from .settings import Settings
from .storage import validate_extra_vars


def tool_name(template: dict[str, Any]) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", template["name"].lower()).strip("_")
    return f"ansible_{slug}_{int(template['id'])}"


def _choices(question: dict[str, Any]) -> list[str]:
    value = question.get("choices", [])
    if isinstance(value, str):
        return [item.strip() for item in value.splitlines() if item.strip()]
    return [str(item) for item in value]


def _annotation(question: dict[str, Any]) -> Any:
    question_type = question.get("type", "text")
    if question_type == "integer":
        return StrictInt
    if question_type == "float":
        return StrictFloat
    if question_type in {"boolean", "checkbox"}:
        return StrictBool
    if question_type == "multiselect":
        choices = _choices(question)
        return list[Literal.__getitem__(tuple(choices))] if choices else list[StrictStr]
    if question_type in {"multiplechoice", "select"}:
        choices = _choices(question)
        return Literal.__getitem__(tuple(choices)) if choices else StrictStr
    return StrictStr


def build_template_function(
    controller: ControllerClient,
    settings: Settings,
    template: dict[str, Any],
    survey_questions: list[dict[str, Any]],
):
    survey_questions = deepcopy(survey_questions)
    template = deepcopy(template)
    variables: set[str] = set()
    for question in survey_questions:
        variable = question.get("variable", "")
        if not isinstance(variable, str) or not variable.isidentifier() or keyword.iskeyword(variable):
            raise ValueError("Ansible survey has an invalid variable name")
        if variable in variables:
            raise ValueError("Ansible survey variable names must be unique")
        variables.add(variable)
    extra_parameter = "extra_vars"
    if extra_parameter in variables:
        extra_parameter = "additional_extra_vars"
        suffix = 2
        while extra_parameter in variables:
            extra_parameter = f"additional_extra_vars_{suffix}"
            suffix += 1
    saved = validate_extra_vars(settings.extra_vars_by_template_id.get(int(template["id"]), {}))
    defaults = validate_extra_vars(survey_defaults(survey_questions))
    validate_extra_vars_allowed(template, survey_questions, saved)
    validate_survey_values(saved, survey_questions, require_required=False)
    validate_survey_values({**defaults, **saved}, survey_questions, require_required=False)

    async def run_template(**kwargs: Any) -> dict[str, Any]:
        extra_vars = kwargs.pop(extra_parameter, None)
        # Pydantic supplies signature defaults for omitted optional arguments.
        # None is only a named-field omission sentinel, never a saved value.
        named = {key: value for key, value in kwargs.items() if value is not None}
        return await execute_template(
            controller, settings, template, named,
            survey_questions=survey_questions, runtime_extra_vars=extra_vars,
        )

    parameters = []
    annotations: dict[str, Any] = {}
    for question in survey_questions:
        variable = question["variable"]
        annotation = _annotation(question)
        required = question.get("required") and variable not in saved and variable not in defaults
        if not required:
            annotation = annotation | None
        annotations[variable] = annotation
        parameters.append(
            inspect.Parameter(
                variable,
                inspect.Parameter.KEYWORD_ONLY,
                default=inspect.Parameter.empty if required else None,
                annotation=annotation,
            )
        )
    annotations[extra_parameter] = dict[str, Any] | None
    parameters.append(inspect.Parameter(
        extra_parameter, inspect.Parameter.KEYWORD_ONLY, default=None,
        annotation=annotations[extra_parameter],
    ))

    run_template.__name__ = settings.tool_name_by_template_id.get(int(template["id"]), tool_name(template))
    description = template.get("description") or (
        f"Launch the approved Ansible template {template['name']}."
    )
    run_template.__doc__ = (
        f"{description}\nUse {extra_parameter} for additional variables or to override saved defaults. "
        "Explicit named survey arguments take precedence. Required named survey fields must "
        "still be supplied as named arguments, not only inside the extra variables object."
    )
    run_template.__signature__ = inspect.Signature(  # type: ignore[attr-defined]
        parameters=parameters,
        return_annotation=dict[str, Any],
    )
    annotations["return"] = dict[str, Any]
    run_template.__annotations__ = annotations
    return run_template


async def register_templates(
    mcp: FastMCP,
    controller: ControllerClient,
    settings: Settings,
) -> list[str]:
    registered: list[str] = []
    # Registered IDs do not require controller-wide list permission.
    candidates = (
        [{"id": item} for item in sorted(settings.allowed_template_ids)]
        if settings.allowed_template_ids
        else await controller.list_templates()
    )
    for discovered in candidates:
        template_id = int(discovered["id"])
        if not settings.permits(template_id):
            continue
        details = await controller.get_template_details(template_id)
        if int(details.get("id", -1)) != template_id:
            raise ValueError("Controller returned a different template ID")
        if template_id in settings.display_name_by_template_id:
            details = dict(details, name=settings.display_name_by_template_id[template_id])
        schema = await controller.get_template_launch_schema(template_id)
        questions = schema.get("survey", {}).get("spec", []) if details.get("survey_enabled") is not False else []
        function = build_template_function(controller, settings, details, questions)
        risk = settings.risk_for(template_id)
        mcp.tool(
            name=function.__name__,
            title=details["name"],
            description=function.__doc__,
            annotations={
                "readOnlyHint": risk == "read-only",
                "destructiveHint": risk != "read-only",
                "idempotentHint": risk == "read-only",
                "openWorldHint": True,
            },
        )(function)
        registered.append(function.__name__)
    return registered
