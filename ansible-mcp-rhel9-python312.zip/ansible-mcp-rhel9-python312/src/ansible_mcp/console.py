"""Loopback-only registration console; controller secrets never leave the backend."""
from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import math
import os
import re
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable
from urllib.parse import urlsplit

from fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from .controller import AutomationControllerClient, ControllerClient, MockControllerClient
from .registry import register_templates
from .settings import Settings
from .storage import LocalStore, StorageError, validate_controller_url, validate_extra_vars, validate_templates


WEB_ROOT = Path(__file__).parent / "web"
MAX_REQUEST_BYTES = 32 * 1024
SECURITY_HEADERS = {
    "Cache-Control": "no-store",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
}


class RegistrationError(ValueError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def _controller(settings: Settings) -> ControllerClient:
    if settings.mode == "mock":
        return MockControllerClient()
    return AutomationControllerClient(
        settings.controller_url or "", settings.controller_token or "",
        api_path=settings.api_path, verify_tls=settings.verify_tls,
        timeout_seconds=10,
    )


def _template_address(value: str, mode: str) -> tuple[str | None, str, int]:
    if not isinstance(value, str):
        raise RegistrationError("Enter a valid template API URL.")
    if mode == "mock":
        match = re.fullmatch(r"mock://templates/([1-9][0-9]*)", value)
        if not match:
            raise RegistrationError("Mock templates use mock://templates/101, 102, or 103.")
        return None, "/api/v2/", int(match.group(1))
    if value != value.strip() or "?" in value or "#" in value or "\\" in value:
        raise RegistrationError("Use an exact HTTPS job-template API URL without a query or fragment.")
    parsed = urlsplit(value)
    origin = validate_controller_url(f"{parsed.scheme}://{parsed.netloc}")
    match = re.fullmatch(r"(/api/(?:[A-Za-z0-9_-]+/)+)job_templates/([1-9][0-9]*)/(?:launch/)?", parsed.path)
    if not match:
        raise RegistrationError("Use an API URL ending in job_templates/<id>/ or job_templates/<id>/launch/.")
    return origin, match.group(1), int(match.group(2))


def _profile_name(tool_name: str) -> str:
    return "gui-" + hashlib.sha256(tool_name.encode("utf-8")).hexdigest()[:40]


def _api_url(mode: str, base_url: str | None, api_path: str, template_id: int) -> str:
    if mode == "mock":
        return f"mock://templates/{template_id}"
    return f"{base_url}{api_path}job_templates/{template_id}/"


class RegistrationConsole:
    def __init__(self, mcp: FastMCP, store: LocalStore, base_settings: Settings,
                 controller_factory: Callable[[Settings], ControllerClient] | None,
                 allowed_hosts: set[str] | None, startup_warning: str | None = None):
        self.mcp = mcp
        self.store = store
        self.base_settings = base_settings
        self.controller_factory = controller_factory or _controller
        port = os.getenv("MCP_PORT", "8000")
        self.allowed_hosts = allowed_hosts if allowed_hosts is not None else {f"localhost:{port}", f"127.0.0.1:{port}"}
        self.csrf_token = secrets.token_urlsafe(32)
        self.lock = asyncio.Lock()
        self.base_tools: dict[str, dict] = {}
        self.registered_profiles: set[str] = set()
        self.unavailable_profiles: set[str] = set()
        self.startup_warning = startup_warning

    def _settings(self, connection) -> Settings:
        settings = Settings(
            mode=connection.mode, controller_url=connection.base_url,
            controller_token=connection.token, api_path=connection.api_path,
            verify_tls=connection.verify_tls, expires_at=connection.expires_at,
            connection_name=connection.name,
            timeout_seconds=self.base_settings.timeout_seconds,
            poll_interval_seconds=self.base_settings.poll_interval_seconds,
            allowed_template_ids={item["id"] for item in connection.templates},
            risk_by_template_id={item["id"]: item.get("risk", "write") for item in connection.templates},
            tool_name_by_template_id={item["id"]: item["tool_name"] for item in connection.templates if item.get("tool_name")},
            display_name_by_template_id={item["id"]: item["name"] for item in connection.templates if item.get("name")},
            extra_vars_by_template_id={item["id"]: item["extra_vars"] for item in connection.templates if item.get("extra_vars")},
        )
        settings.validate()
        return settings

    async def _build_tools(self, settings: Settings):
        temporary = FastMCP("Validate template registration", on_duplicate="error")
        controller = self.controller_factory(settings)
        try:
            async with asyncio.timeout(30):
                await register_templates(temporary, controller, settings)
            return await temporary.list_tools()
        finally:
            # The controller has no retained HTTP pool; tool closures can reuse it.
            await controller.close()

    async def restore(self) -> None:
        named_template_ids = {name: template_id for template_id, name in self.base_settings.tool_name_by_template_id.items()}
        for tool in await self.mcp.list_tools():
            template_id = named_template_ids.get(tool.name)
            if template_id is None and tool.name.startswith("ansible_"):
                suffix = tool.name.rsplit("_", 1)[-1]
                if suffix.isdecimal() and int(suffix) not in self.base_settings.tool_name_by_template_id:
                    template_id = int(suffix)
            self.base_tools[tool.name] = {
                "name": tool.name, "title": tool.title or tool.name,
                "mode": self.base_settings.mode, "template_api_url": None,
                "expires_at": self.base_settings.expires_at, "registered": True,
                "has_extra_vars": bool(self.base_settings.extra_vars_by_template_id.get(template_id)),
            }
        # Each GUI tool has its own connection, template ID, and encrypted token.
        for metadata in self.store.list_connections():
            name = metadata["name"]
            if not name.startswith("gui-") or metadata["expired"]:
                continue
            if name == self.base_settings.connection_name and all(
                item.get("tool_name") in self.base_tools for item in metadata["templates"]
            ):
                self.registered_profiles.add(name)
                continue
            try:
                connection = self.store.load_connection(name)
                settings = self._settings(connection)
                current_names = {tool.name for tool in await self.mcp.list_tools()}
                if current_names.intersection(settings.tool_name_by_template_id.values()):
                    raise ValueError("Duplicate tool name")
                built = await self._build_tools(settings)
                for tool in built:
                    self.mcp.add_tool(tool)
                self.registered_profiles.add(name)
            except Exception:
                # A disconnected controller must not take down the recovery console.
                self.unavailable_profiles.add(name)

    def _guard(self, request: Request, *, mutation: bool = False) -> Response | None:
        hosts = request.headers.getlist("host")
        if len(hosts) != 1 or hosts[0].lower() not in self.allowed_hosts:
            return self._error("This console is available only through its local address.", 403)
        if request.client is not None:
            try:
                if not ipaddress.ip_address(request.client.host).is_loopback:
                    raise ValueError
            except ValueError:
                return self._error("This console accepts only loopback connections.", 403)
        origin = request.headers.get("origin")
        if origin is not None and origin != f"http://{hosts[0].lower()}":
            return self._error("Foreign browser origins are not allowed.", 403)
        if request.headers.get("sec-fetch-site") == "cross-site":
            return self._error("Cross-site requests are not allowed.", 403)
        if mutation:
            supplied_token = request.headers.get("x-csrf-token", "")
            if not supplied_token.isascii() or not secrets.compare_digest(supplied_token, self.csrf_token):
                return self._error("Invalid console security token. Reload the console.", 403)
            if request.headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/json":
                return self._error("Send application/json.", 415)
        return None

    @staticmethod
    def _error(message: str, status: int = 400) -> JSONResponse:
        return JSONResponse({"error": message}, status_code=status, headers=SECURITY_HEADERS)

    async def assets(self, request: Request) -> Response:
        denied = self._guard(request)
        if denied is not None:
            return denied
        file_name = request.path_params.get("asset", "console.html")
        mime_types = {"console.html": "text/html", "console.css": "text/css", "console.js": "text/javascript"}
        if file_name not in mime_types:
            return self._error("Not found.", 404)
        try:
            body = (WEB_ROOT / file_name).read_text(encoding="utf-8")
        except OSError:
            return self._error("Console assets are unavailable.", 503)
        return Response(body, media_type=mime_types[file_name], headers=SECURITY_HEADERS)

    async def state(self, request: Request) -> Response:
        denied = self._guard(request)
        if denied is not None:
            return denied
        try:
            entries = [dict(entry) for entry in self.base_tools.values()]
            for entry in entries:
                if entry["expires_at"] and datetime.now(timezone.utc) >= datetime.fromisoformat(entry["expires_at"].replace("Z", "+00:00")):
                    entry["registered"] = False
                    entry["status"] = "Expired. Renew locally and restart to register again."
            for metadata in self.store.list_connections():
                profile = metadata["name"]
                if not profile.startswith("gui-"):
                    continue
                for template in metadata["templates"]:
                    name = template.get("tool_name")
                    if not name:
                        continue
                    if profile == self.base_settings.connection_name:
                        entries = [entry for entry in entries if entry["name"] != name]
                    entry = {
                        "name": name, "title": template.get("name", name), "mode": metadata["mode"],
                        "template_api_url": _api_url(metadata["mode"], metadata["base_url"], metadata["api_path"], template["id"]),
                        "expires_at": metadata["expires_at"],
                        "registered": profile in self.registered_profiles and not metadata["expired"],
                        "has_extra_vars": bool(template.get("has_extra_vars", False)),
                    }
                    if metadata["expired"]:
                        entry["status"] = "Expired. Renew locally and restart to register again."
                    elif profile in self.unavailable_profiles:
                        entry["status"] = "Unavailable. Check controller access and restart."
                    entries.append(entry)
            payload = {"tools": entries, "csrf_token": self.csrf_token}
            if self.startup_warning:
                payload["warning"] = self.startup_warning
            return JSONResponse(payload, headers=SECURITY_HEADERS)
        except StorageError:
            return self._error("Could not read local registrations. Check the local database.", 503)

    async def _json_body(self, request: Request) -> dict:
        length = request.headers.get("content-length")
        if length is not None:
            try:
                if int(length) < 0 or int(length) > MAX_REQUEST_BYTES:
                    raise ValueError
            except ValueError:
                raise RegistrationError("Request is too large or has an invalid length.", 413) from None
        body = bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body) > MAX_REQUEST_BYTES:
                raise RegistrationError("Request is too large.", 413)
        try:
            data = json.loads(body)
        except (ValueError, UnicodeError):
            raise RegistrationError("Enter a valid JSON registration.") from None
        if not isinstance(data, dict) or set(data) - {"tool_name", "template_api_url", "api_token", "title", "ttl_hours", "mode", "extra_vars"}:
            raise RegistrationError("Registration contains unsupported fields.")
        return data

    async def save(self, request: Request) -> Response:
        denied = self._guard(request, mutation=True)
        if denied is not None:
            return denied
        try:
            data = await self._json_body(request)
            mode = data.get("mode", "controller")
            if mode not in {"controller", "mock"}:
                raise RegistrationError("Choose controller or mock mode.")
            base_url, api_path, template_id = _template_address(data.get("template_api_url"), mode)
            template = {"id": template_id, "tool_name": data.get("tool_name"), "risk": "write"}
            try:
                extra_vars = validate_extra_vars(data.get("extra_vars", {}))
            except StorageError:
                raise RegistrationError("Extra variables must be a JSON object with finite values, at most 16 KiB and no more than 20 levels deep.") from None
            if extra_vars:
                template["extra_vars"] = extra_vars
            if data.get("title"):
                template["name"] = data["title"]
            selected = validate_templates([template])
            if not selected[0].get("tool_name"):
                raise RegistrationError("Enter a tool name using letters, digits, and underscores.")
            name = selected[0]["tool_name"]
            token = data.get("api_token")
            if mode == "mock":
                if token not in {None, ""}:
                    raise RegistrationError("Mock tools do not accept API tokens.")
                token = None
            elif not isinstance(token, str) or not token.strip() or token != token.strip() or any(ord(c) < 32 or ord(c) == 127 for c in token):
                raise RegistrationError("Enter a valid API token without whitespace padding.")
            ttl = data.get("ttl_hours", 24)
            if isinstance(ttl, bool) or not isinstance(ttl, (int, float)) or not math.isfinite(ttl) or ttl <= 0:
                raise RegistrationError("Expiry hours must be a finite positive number.")
            try:
                expiry = (datetime.now(timezone.utc) + timedelta(hours=ttl)).isoformat()
            except OverflowError:
                raise RegistrationError("Choose a shorter expiry duration.") from None
            profile = _profile_name(name)
            settings = Settings(
                mode=mode, controller_url=base_url, controller_token=token,
                api_path=api_path, verify_tls=True, expires_at=expiry,
                connection_name=profile, allowed_template_ids={template_id},
                tool_name_by_template_id={template_id: name},
                display_name_by_template_id={template_id: selected[0]["name"]} if selected[0].get("name") else {},
                extra_vars_by_template_id={template_id: extra_vars} if extra_vars else {},
                risk_by_template_id={template_id: "write"},
                timeout_seconds=self.base_settings.timeout_seconds,
                poll_interval_seconds=self.base_settings.poll_interval_seconds,
            )
            settings.validate()
            async with self.lock:
                saved = self.store.list_connections()
                names = {tool.name for tool in await self.mcp.list_tools()}
                names.update(item.get("tool_name") for row in saved for item in row["templates"])
                if name in names or any(row["name"] == profile for row in saved):
                    raise RegistrationError("That tool name is already registered. Choose a different name.", 409)
                try:
                    built = await self._build_tools(settings)
                    if len(built) != 1 or built[0].name != name:
                        raise ValueError
                except Exception:
                    raise RegistrationError("Could not validate the template and extra variables. Check the API URL, token permissions, variable types/choices, and Prompt on launch settings.", 502) from None
                # Preserve the discovered title for the console even if a future
                # restart cannot reach the controller to recover its metadata.
                selected[0].setdefault("name", (built[0].title or name)[:256])
                # Persist only after all read-only controller/schema checks succeeded.
                self.store.save_connection(
                    profile, mode=mode, base_url=base_url, api_path=api_path,
                    token=token, templates=selected, ttl_hours=ttl, activate=False,
                    create_only=True,
                )
                try:
                    settings.expires_at = self.store.load_connection(profile).expires_at
                    self.mcp.add_tool(built[0])
                except Exception:
                    self.store.delete_connection(profile)
                    raise RegistrationError("Tool publication failed; the new registration was removed.", 500) from None
                self.registered_profiles.add(profile)
            return JSONResponse({"name": name, "message": "Tool saved and registered. Refresh the tool list or reconnect your MCP client."}, status_code=201, headers=SECURITY_HEADERS)
        except RegistrationError as exc:
            return self._error(str(exc), exc.status)
        except (StorageError, ValueError, TypeError):
            return self._error("Registration was not saved. Check the URL, tool name, token, expiry, and local database.")


async def attach_console(mcp: FastMCP, store: LocalStore, *, base_settings: Settings,
                         controller_factory: Callable[[Settings], ControllerClient] | None = None,
                         allowed_hosts: set[str] | None = None,
                         startup_warning: str | None = None) -> RegistrationConsole:
    console = RegistrationConsole(mcp, store, base_settings, controller_factory, allowed_hosts, startup_warning)
    await console.restore()
    mcp.custom_route("/console", methods=["GET"])(console.assets)
    mcp.custom_route("/console/", methods=["GET"])(console.assets)
    mcp.custom_route("/console/api/tools", methods=["GET"])(console.state)
    mcp.custom_route("/console/api/tools", methods=["POST"])(console.save)
    mcp.custom_route("/console/{asset}", methods=["GET"])(console.assets)
    return console
