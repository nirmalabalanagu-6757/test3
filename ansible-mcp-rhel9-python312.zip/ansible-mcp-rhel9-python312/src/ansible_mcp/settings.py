from __future__ import annotations

import json
import math
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


def _as_bool(value: str | None, default: bool = True) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(slots=True)
class Settings:
    mode: str = "mock"
    controller_url: str | None = None
    controller_token: str | None = field(default=None, repr=False)
    api_path: str = "/api/v2/"
    verify_tls: bool = True
    allowlist_path: Path | None = None
    timeout_seconds: float = 900.0
    poll_interval_seconds: float = 2.0
    allowed_template_ids: set[int] = field(default_factory=set)
    risk_by_template_id: dict[int, str] = field(default_factory=dict)
    tool_name_by_template_id: dict[int, str] = field(default_factory=dict)
    display_name_by_template_id: dict[int, str] = field(default_factory=dict)
    extra_vars_by_template_id: dict[int, dict[str, Any]] = field(default_factory=dict, repr=False)
    expires_at: str | None = None
    connection_name: str | None = None

    @classmethod
    def from_env(cls, plugin_root: Path) -> "Settings":
        mode = os.getenv("ANSIBLE_MODE", "auto").strip().lower()
        if mode not in {"auto", "mock", "controller"}:
            raise ValueError("ANSIBLE_MODE must be 'auto', 'mock', or 'controller'")
        url = os.getenv("ANSIBLE_CONTROLLER_URL")
        token = os.getenv("ANSIBLE_CONTROLLER_TOKEN")
        if mode == "auto" and not (url or token):
            from .storage import LocalStore

            path = os.getenv("ANSIBLE_DB_PATH")
            connection = LocalStore(Path(path) if path else None).load_active()
            if connection is not None:
                settings = cls(
                    mode=connection.mode,
                    controller_url=connection.base_url,
                    controller_token=connection.token,
                    api_path=connection.api_path,
                    verify_tls=connection.verify_tls,
                    expires_at=connection.expires_at,
                    connection_name=connection.name,
                    allowed_template_ids={item["id"] for item in connection.templates},
                    risk_by_template_id={item["id"]: item.get("risk", "write") for item in connection.templates},
                    tool_name_by_template_id={item["id"]: item["tool_name"] for item in connection.templates if item.get("tool_name")},
                    display_name_by_template_id={item["id"]: item["name"] for item in connection.templates if item.get("name")},
                    extra_vars_by_template_id={item["id"]: item["extra_vars"] for item in connection.templates if "extra_vars" in item},
                    timeout_seconds=float(os.getenv("ANSIBLE_JOB_TIMEOUT_SECONDS", "900")),
                    poll_interval_seconds=float(os.getenv("ANSIBLE_POLL_INTERVAL_SECONDS", "2")),
                )
                settings.validate()
                return settings
        if mode == "auto":
            mode = "controller" if url or token else "mock"
        configured_path = os.getenv(
            "ANSIBLE_TEMPLATE_ALLOWLIST", "config/templates.json"
        )
        allowlist_path = Path(configured_path)
        if not allowlist_path.is_absolute():
            allowlist_path = plugin_root / allowlist_path

        settings = cls(
            mode=mode,
            controller_url=url if mode == "controller" else None,
            controller_token=token if mode == "controller" else None,
            api_path=os.getenv("ANSIBLE_API_PATH", "/api/v2/"),
            verify_tls=_as_bool(os.getenv("ANSIBLE_VERIFY_TLS")),
            allowlist_path=allowlist_path,
            timeout_seconds=float(os.getenv("ANSIBLE_JOB_TIMEOUT_SECONDS", "900")),
            poll_interval_seconds=float(
                os.getenv("ANSIBLE_POLL_INTERVAL_SECONDS", "2")
            ),
        )
        settings.load_allowlist()
        settings.validate()
        return settings

    def load_allowlist(self) -> None:
        if not self.allowlist_path or not self.allowlist_path.exists():
            return
        data = json.loads(self.allowlist_path.read_text(encoding="utf-8"))
        self.allowed_template_ids = {
            int(item) for item in data.get("allowed_template_ids", [])
        }
        self.risk_by_template_id = {
            int(key): str(value)
            for key, value in data.get("risk_by_template_id", {}).items()
        }
        self.tool_name_by_template_id = {
            int(key): str(value)
            for key, value in data.get("tool_name_by_template_id", {}).items()
        }

    def validate(self) -> None:
        from .storage import validate_extra_vars

        if self.mode not in {"mock", "controller"}:
            raise ValueError("ANSIBLE_MODE must be 'mock' or 'controller'")
        if not all(math.isfinite(value) and value > 0 for value in (self.timeout_seconds, self.poll_interval_seconds)):
            raise ValueError("Job timeout and polling interval must be positive")
        if any(type(item) is not int or item <= 0 for item in self.allowed_template_ids):
            raise ValueError("Template IDs must be positive integers")
        if any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", name) for name in self.tool_name_by_template_id.values()):
            raise ValueError("Tool names must start with a letter and use only letters, digits, and underscores (max 64)")
        if len(set(self.tool_name_by_template_id.values())) != len(self.tool_name_by_template_id):
            raise ValueError("Tool names must be unique")
        if any(type(item) is not int or item <= 0 for item in self.extra_vars_by_template_id):
            raise ValueError("Extra variable template IDs must be positive integers")
        self.extra_vars_by_template_id = {
            key: validate_extra_vars(value)
            for key, value in self.extra_vars_by_template_id.items()
        }
        self.assert_not_expired()
        if self.mode == "mock":
            return
        if not self.controller_url or not self.controller_token:
            raise ValueError(
                "Controller mode requires ANSIBLE_CONTROLLER_URL and "
                "ANSIBLE_CONTROLLER_TOKEN"
            )
        parsed = urlparse(self.controller_url)
        if (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password
                or parsed.path not in {"", "/"} or parsed.query or parsed.fragment):
            raise ValueError("Controller URL must be an HTTPS origin, without a path or embedded credentials")
        if not self.allowed_template_ids:
            raise ValueError("Select at least one approved template ID before using a real controller")

    def assert_not_expired(self) -> None:
        if self.expires_at and datetime.now(timezone.utc) >= datetime.fromisoformat(self.expires_at.replace("Z", "+00:00")):
            raise ValueError("Saved connection has expired. Save it again locally and restart the MCP server.")

    def permits(self, template_id: int) -> bool:
        return not self.allowed_template_ids or template_id in self.allowed_template_ids

    def risk_for(self, template_id: int) -> str:
        return self.risk_by_template_id.get(template_id, "write")
