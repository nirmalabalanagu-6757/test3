from __future__ import annotations

import asyncio
import itertools
import re
from abc import ABC, abstractmethod
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx


TERMINAL_STATES = {"successful", "failed", "error", "canceled"}


class ControllerError(RuntimeError):
    """A safe, user-facing controller error."""


class ControllerClient(ABC):
    @abstractmethod
    async def list_templates(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def get_template_details(self, template_id: int) -> dict[str, Any]: ...

    @abstractmethod
    async def get_template_launch_schema(self, template_id: int) -> dict[str, Any]: ...

    @abstractmethod
    async def launch_template(
        self, template_id: int, inputs: dict[str, Any]
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def get_job_status(self, job_id: int) -> dict[str, Any]: ...

    @abstractmethod
    async def get_job_output(self, job_id: int) -> dict[str, Any]: ...

    @abstractmethod
    async def cancel_job(self, job_id: int) -> dict[str, Any]: ...

    async def close(self) -> None:
        return None


class AutomationControllerClient(ControllerClient):
    def __init__(
        self,
        base_url: str,
        token: str,
        *,
        api_path: str = "/api/v2/",
        verify_tls: bool = True,
        timeout_seconds: float = 30.0,
    ) -> None:
        try:
            parsed = urlparse(base_url)
            if (
                parsed.scheme != "https"
                or not parsed.hostname
                or parsed.username is not None
                or parsed.password is not None
                or parsed.path not in {"", "/"}
                or parsed.query
                or parsed.fragment
                or "\\" in base_url
                or any(character.isspace() or ord(character) < 32 for character in base_url)
            ):
                raise ValueError
            parsed.port  # Reject malformed ports before accepting the origin.
            canonical = httpx.URL(base_url)
        except (ValueError, httpx.InvalidURL) as exc:
            raise ValueError("Controller URL must be an HTTPS origin without credentials or a path") from exc
        if not re.fullmatch(r"/api/(?:[A-Za-z0-9_-]+/)+", api_path):
            raise ValueError("Controller API path must be a safe /api/.../ prefix")
        if not isinstance(token, str) or not token.strip() or any(ord(c) < 32 for c in token):
            raise ValueError("A valid controller token is required")
        self.base_url = str(canonical).rstrip("/") + "/"
        self.api_path = api_path
        self._base_origin = (canonical.scheme, canonical.host, canonical.port or 443)
        self._token = token
        self._verify_tls = verify_tls
        self._timeout_seconds = timeout_seconds

    def _safe_url(self, path: str, *, relative_to: str | None = None) -> str:
        """Validate every destination before attaching controller credentials."""
        try:
            if not isinstance(path, str) or "\\" in path or any(
                character.isspace() or ord(character) < 32 for character in path
            ):
                raise ValueError
            absolute = urljoin(relative_to or self.base_url, path)
            parsed = urlparse(absolute)
            if parsed.username is not None or parsed.password is not None or parsed.fragment:
                raise ValueError
            url = httpx.URL(absolute)
            origin = (url.scheme, url.host, url.port or 443)
            if (
                origin != self._base_origin
                or not parsed.path.startswith(self.api_path)
                or "%" in parsed.path
                or any(part in {".", ".."} for part in parsed.path.split("/"))
            ):
                raise ValueError
            return str(url)
        except (ValueError, httpx.InvalidURL) as exc:
            raise ControllerError("Controller returned an unsafe request URL") from exc

    async def _request(
        self, method: str, path: str, *, json: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        destination = self._safe_url(path)
        try:
            # Discovery and tool execution can run on different event loops.
            # Scope the connection pool to one request so it never crosses loops.
            async with httpx.AsyncClient(
                headers={"Authorization": f"Bearer {self._token}", "Accept": "application/json"},
                verify=self._verify_tls,
                timeout=self._timeout_seconds,
                follow_redirects=False,
            ) as client:
                response = await client.request(method, destination, json=json)
            response.raise_for_status()
            if not response.content:
                return {}
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError
            return data
        except httpx.HTTPStatusError as exc:
            raise ControllerError(
                f"Controller request failed with HTTP {exc.response.status_code}"
            ) from exc
        except (httpx.HTTPError, ValueError) as exc:
            raise ControllerError("Controller request failed") from exc

    async def list_templates(self) -> list[dict[str, Any]]:
        templates: list[dict[str, Any]] = []
        next_path: str | None = f"{self.api_path}job_templates/?page_size=200"
        pages = 0
        while next_path and pages < 20:
            data = await self._request("GET", next_path)
            results = data.get("results", [])
            if not isinstance(results, list) or not all(isinstance(item, dict) for item in results):
                raise ControllerError("Controller returned an invalid template list")
            templates.extend(results)
            next_value = data.get("next")
            if next_value:
                next_path = self._safe_url(next_value, relative_to=self._safe_url(next_path))
            else:
                next_path = None
            pages += 1
        return templates

    async def get_template_details(self, template_id: int) -> dict[str, Any]:
        return await self._request("GET", f"{self.api_path}job_templates/{template_id}/")

    async def get_template_launch_schema(self, template_id: int) -> dict[str, Any]:
        survey, launch = await asyncio.gather(
            self._request("GET", f"{self.api_path}job_templates/{template_id}/survey_spec/"),
            self._request("GET", f"{self.api_path}job_templates/{template_id}/launch/"),
        )
        return {"survey": survey, "launch": launch}

    async def launch_template(
        self, template_id: int, inputs: dict[str, Any]
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            f"{self.api_path}job_templates/{template_id}/launch/",
            json={"extra_vars": inputs},
        )

    async def get_job_status(self, job_id: int) -> dict[str, Any]:
        return await self._request("GET", f"{self.api_path}jobs/{job_id}/")

    async def get_job_output(self, job_id: int) -> dict[str, Any]:
        return await self._request(
            "GET", f"{self.api_path}jobs/{job_id}/stdout/?format=json"
        )

    async def cancel_job(self, job_id: int) -> dict[str, Any]:
        return await self._request("POST", f"{self.api_path}jobs/{job_id}/cancel/")


class MockControllerClient(ControllerClient):
    """Deterministic local controller used for development and tests."""

    def __init__(self) -> None:
        self.templates = {
            101: {
                "id": 101,
                "name": "Check Disk Space",
                "description": "Check disk utilization on approved hosts.",
            },
            102: {
                "id": 102,
                "name": "Restart Nginx",
                "description": "Restart Nginx on an approved host group.",
            },
            103: {
                "id": 103,
                "name": "Deploy Application",
                "description": "Deploy an approved application release.",
            },
        }
        self.surveys = {
            101: [
                {
                    "question_name": "Environment",
                    "variable": "environment",
                    "type": "multiplechoice",
                    "required": True,
                    "choices": "development\nstaging\nproduction",
                },
                {
                    "question_name": "Host group",
                    "variable": "host_group",
                    "type": "text",
                    "required": True,
                    "min": 1,
                    "max": 64,
                },
            ],
            102: [
                {
                    "question_name": "Environment",
                    "variable": "environment",
                    "type": "multiplechoice",
                    "required": True,
                    "choices": "development\nstaging\nproduction",
                },
                {
                    "question_name": "Host group",
                    "variable": "host_group",
                    "type": "text",
                    "required": True,
                },
            ],
            103: [
                {
                    "question_name": "Application",
                    "variable": "application",
                    "type": "text",
                    "required": True,
                },
                {
                    "question_name": "Release version",
                    "variable": "release_version",
                    "type": "text",
                    "required": True,
                },
            ],
        }
        self._job_ids = itertools.count(5001)
        self.jobs: dict[int, dict[str, Any]] = {}

    async def list_templates(self) -> list[dict[str, Any]]:
        return list(self.templates.values())

    async def get_template_details(self, template_id: int) -> dict[str, Any]:
        try:
            return self.templates[template_id]
        except KeyError as exc:
            raise ControllerError("Template is not available") from exc

    async def get_template_launch_schema(self, template_id: int) -> dict[str, Any]:
        return {
            "survey": {"spec": self.surveys.get(template_id, [])},
            "launch": {"can_start_without_user_input": True},
        }

    async def launch_template(
        self, template_id: int, inputs: dict[str, Any]
    ) -> dict[str, Any]:
        await self.get_template_details(template_id)
        job_id = next(self._job_ids)
        self.jobs[job_id] = {
            "id": job_id,
            "template_id": template_id,
            "status": "pending",
            "polls": 0,
            "inputs": inputs,
        }
        return {"id": job_id, "job": job_id, "status": "pending"}

    async def get_job_status(self, job_id: int) -> dict[str, Any]:
        job = self.jobs[job_id]
        job["polls"] += 1
        if job["status"] != "canceled":
            job["status"] = "running" if job["polls"] == 1 else "successful"
        return {
            "id": job_id,
            "status": job["status"],
            "started": "2026-09-22T15:00:00Z",
            "finished": (
                "2026-09-22T15:00:02Z"
                if job["status"] in TERMINAL_STATES
                else None
            ),
            "failed": job["status"] != "successful",
        }

    async def get_job_output(self, job_id: int) -> dict[str, Any]:
        job = self.jobs[job_id]
        template = self.templates[job["template_id"]]
        return {
            "content": (
                f"{template['name']} completed in mock mode for "
                f"{job['inputs']}. secret=redacted-by-server"
            )
        }

    async def cancel_job(self, job_id: int) -> dict[str, Any]:
        self.jobs[job_id]["status"] = "canceled"
        return {"id": job_id, "status": "canceled"}
