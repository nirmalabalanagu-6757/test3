"use strict";

const dialog = document.getElementById("tool-dialog");
const form = document.getElementById("tool-form");
const mode = document.getElementById("connection-type");
const token = document.getElementById("api-token");
const templateUrl = document.getElementById("template-url");
const saveButton = document.getElementById("save-tool");
const extraVars = document.getElementById("extra-vars");
let csrfToken = "";
let saving = false;

document.getElementById("endpoint").textContent = `${window.location.origin}/mcp`;

function message(id, text, isError = false) {
  const element = document.getElementById(id);
  element.textContent = text;
  element.classList.toggle("error", isError);
  element.hidden = !text;
}

function node(tag, className, text) {
  const element = document.createElement(tag);
  element.className = className;
  element.textContent = text;
  return element;
}

function renderTools(tools) {
  const list = document.getElementById("tool-list");
  list.replaceChildren();
  document.getElementById("tool-count").textContent = tools.length;
  if (!tools.length) {
    list.append(node("p", "empty", "No tools registered yet. Click Add Tool to connect your first Ansible template."));
    return;
  }
  for (const tool of tools) {
    const card = node("article", "tool-card", "");
    const top = node("div", "card-top", "");
    top.append(node("span", "tool-icon", "{ }"));
    top.append(node("span", `badge ${tool.registered ? "live" : "warning"}`, tool.registered ? "Available" : "Not available"));
    card.append(top, node("h3", "", tool.title || tool.name), node("code", "tool-name", tool.name));
    card.append(node("p", "card-detail", tool.status || tool.template_api_url || (tool.mode === "mock" ? "Local demo template · no controller credentials" : "Registered controller template")));
    if (tool.has_extra_vars) card.append(node("p", "vars-badge", "Saved extra variables · encrypted"));
    const footer = node("div", "card-footer", "");
    footer.append(node("span", "", tool.mode === "mock" ? "Demo" : "Ansible controller"));
    const expires = tool.expires_at ? new Date(tool.expires_at) : null;
    footer.append(node("span", "", expires && !Number.isNaN(expires.valueOf()) ? `Expires ${expires.toLocaleString([], {month:"short", day:"numeric", hour:"2-digit", minute:"2-digit"})}` : "MCP tool"));
    card.append(footer);
    list.append(card);
  }
}

async function loadTools() {
  const response = await fetch("/console/api/tools", {cache: "no-store", credentials: "same-origin"});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Could not load registered tools.");
  csrfToken = data.csrf_token;
  renderTools(data.tools);
  if (data.warning) message("page-message", data.warning, true);
}

function updateMode() {
  const isMock = mode.value === "mock";
  document.getElementById("token-field").hidden = isMock;
  token.required = !isMock;
  token.value = "";
  templateUrl.value = isMock ? "mock://templates/101" : "";
  templateUrl.placeholder = isMock ? "mock://templates/101" : "https://controller.example.com/api/v2/job_templates/42/";
  document.getElementById("url-help").textContent = isMock ? "Demo IDs: 101 — disk check, 102 — restart Nginx, 103 — deployment. No real playbooks run." : "Paste the template API address, not the Ansible GUI page.";
}

function closeDialog() {
  if (saving) return;
  token.value = "";
  extraVars.value = "{}";
  dialog.close();
}

document.getElementById("add-tool").addEventListener("click", () => {
  form.reset();
  updateMode();
  message("form-message", "");
  dialog.showModal();
  document.getElementById("tool-name").focus();
});
document.getElementById("close-dialog").addEventListener("click", closeDialog);
document.getElementById("cancel-dialog").addEventListener("click", closeDialog);
dialog.addEventListener("cancel", event => {
  if (saving) event.preventDefault();
  else { token.value = ""; extraVars.value = "{}"; }
});
mode.addEventListener("change", updateMode);
document.getElementById("refresh-tools").addEventListener("click", async () => {
  try { await loadTools(); message("page-message", "Tool list refreshed. MCP clients can refresh their tool list or reconnect."); }
  catch (error) { message("page-message", error.message, true); }
});

form.addEventListener("submit", async event => {
  event.preventDefault();
  if (saving || !form.reportValidity()) return;
  if (!csrfToken) {
    message("form-message", "The console is not connected. Refresh the page and try again.", true);
    return;
  }
  let parsedExtraVars;
  try {
    parsedExtraVars = JSON.parse(extraVars.value.trim() || "{}", (_key, value) => {
      if (typeof value === "number" && !Number.isFinite(value)) throw new Error("Non-finite number");
      return value;
    });
    if (parsedExtraVars === null || Array.isArray(parsedExtraVars) || typeof parsedExtraVars !== "object") throw new Error("Object required");
    if (new TextEncoder().encode(JSON.stringify(parsedExtraVars)).length > 16384) throw new Error("Too large");
  } catch {
    message("form-message", "Extra variables must be a valid JSON object (up to 16 KB), for example {\"environment\":\"development\"}.", true);
    extraVars.focus();
    return;
  }
  saving = true;
  saveButton.disabled = true;
  saveButton.textContent = "Checking template…";
  document.getElementById("cancel-dialog").disabled = true;
  document.getElementById("close-dialog").disabled = true;
  message("form-message", "");
  try {
    const response = await fetch("/console/api/tools", {
      method: "POST", credentials: "same-origin", cache: "no-store",
      headers: {"Content-Type": "application/json", "X-CSRF-Token": csrfToken},
      body: JSON.stringify({
        tool_name: document.getElementById("tool-name").value.trim(),
        title: document.getElementById("display-title").value.trim(),
        mode: mode.value,
        template_api_url: templateUrl.value.trim(),
        api_token: token.value,
        ttl_hours: Number(document.getElementById("expiry-hours").value),
        extra_vars: parsedExtraVars,
      }),
    });
    const data = await response.json();
    token.value = "";
    if (!response.ok) throw new Error(data.error || "Registration failed. Check your template address and permissions.");
    extraVars.value = "{}";
    dialog.close();
    message("page-message", `Tool “${data.name}” is registered. Refresh tools or reconnect in MCP Inspector/AIOps to discover it. Saving did not run a playbook.`);
    await loadTools();
  } catch (error) {
    token.value = "";
    message(dialog.open ? "form-message" : "page-message", error.message || "Could not reach the local MCP server.", true);
  } finally {
    saving = false;
    saveButton.disabled = false;
    saveButton.textContent = "Save tool";
    document.getElementById("cancel-dialog").disabled = false;
    document.getElementById("close-dialog").disabled = false;
  }
});

loadTools().catch(error => message("page-message", error.message, true));
