"""Dynamic Ansible Controller template tools for MCP."""

from .server import create_server

__all__ = ["create_server"]
