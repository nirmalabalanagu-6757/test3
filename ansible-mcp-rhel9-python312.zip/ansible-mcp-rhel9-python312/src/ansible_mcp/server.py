from __future__ import annotations

from pathlib import Path
import os
from typing import Callable

from fastmcp import FastMCP

from .controller import AutomationControllerClient, ControllerClient, MockControllerClient
from .registry import register_templates
from .settings import Settings
from .storage import LocalStore, StorageError


PLUGIN_ROOT = Path(__file__).resolve().parents[2]


async def create_server(
    settings: Settings | None = None,
    controller: ControllerClient | None = None,
    *,
    console_store: LocalStore | None = None,
    console_allowed_hosts: set[str] | None = None,
    console_controller_factory: Callable[[Settings], ControllerClient] | None = None,
) -> FastMCP:
    supplied_settings = settings is not None
    raw_mode = os.getenv("ANSIBLE_MODE", "auto").strip().lower()
    recover_default = not supplied_settings and raw_mode == "auto" and not (
        os.getenv("ANSIBLE_CONTROLLER_URL") or os.getenv("ANSIBLE_CONTROLLER_TOKEN")
    )
    startup_warning = None
    publish_base = True
    try:
        settings = settings or Settings.from_env(PLUGIN_ROOT)
        settings.validate()
    except (StorageError, ValueError):
        if not recover_default:
            raise
        # This placeholder config supplies defaults only: never publish mock tools
        # in place of an expired or unreadable saved controller registration.
        settings = Settings(mode="mock")
        publish_base = False
        startup_warning = "The active saved connection is unavailable or expired. Its tools were not published. Add a new registration or repair the local connection and restart."

    mcp = FastMCP(
        name="Ansible Template Tools",
        instructions=(
            "Each exposed tool is an approved Ansible Controller job template. "
            "Use the generated input schema and explain the returned job result."
        ),
        on_duplicate="error",
    )
    if publish_base:
        try:
            if controller is None:
                if settings.mode == "mock":
                    controller = MockControllerClient()
                else:
                    controller = AutomationControllerClient(
                        settings.controller_url or "", settings.controller_token or "",
                        verify_tls=settings.verify_tls, api_path=settings.api_path,
                    )
            # Build as a batch so a failure never publishes a partial legacy list.
            candidate = FastMCP("Validate active registration", on_duplicate="error")
            await register_templates(candidate, controller, settings)
            for tool in await candidate.list_tools():
                mcp.add_tool(tool)
        except Exception:
            if not recover_default:
                raise
            startup_warning = "The active saved controller could not be read. Its tools were not published. Check controller access or add a new registration."
    if console_store is not None or (not supplied_settings and raw_mode != "mock"):
        from .console import attach_console

        if console_store is None:
            configured = os.getenv("ANSIBLE_DB_PATH")
            console_store = LocalStore(Path(configured) if configured else None)
        await attach_console(mcp, console_store, base_settings=settings,
                             controller_factory=console_controller_factory,
                             allowed_hosts=console_allowed_hosts,
                             startup_warning=startup_warning)
    return mcp
