"""Local-only registration CLI. API tokens are accepted only by a hidden prompt."""
from __future__ import annotations

import argparse
import getpass
import json
import os
import re
import warnings
from pathlib import Path
from urllib.parse import urlparse

from .storage import LocalStore, StorageError, validate_api_path, validate_controller_url, validate_templates


def template_id_from_address(value: str, base_url: str, api_path: str) -> int:
    """Accept an ID or an exact template API URL for the registered controller."""
    value = value.strip()
    if value.isascii() and value.isdecimal() and int(value) > 0:
        return int(value)
    address, base = urlparse(value), urlparse(base_url)
    if (address.scheme != base.scheme or address.hostname != base.hostname
            or (address.port or 443) != (base.port or 443)
            or address.username or address.password or address.query or address.fragment):
        raise ValueError("Template API URL must belong to the registered controller")
    match = re.fullmatch(re.escape(api_path) + r"job_templates/([1-9][0-9]*)/(?:launch/)?", address.path)
    if not match:
        raise ValueError("Enter a positive template ID or a matching job_templates/<id>/ API URL")
    return int(match.group(1))


def _prompt(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    return input(f"{label}{suffix}: ").strip() or default


def _save_interactive(store: LocalStore, name: str, replace: bool) -> None:
    _check_new_name(store, name, replace)
    base_url = validate_controller_url(_prompt("Controller origin (https://your-controller)"))
    api_path = validate_api_path(_prompt("API base path", "/api/v2/"))
    ttl_hours = float(_prompt("Expire this saved connection after hours", "24"))
    templates: list[dict] = []
    print("Register one or more templates. These are the only published MCP tools.")
    while True:
        template_id = template_id_from_address(
            _prompt("Template ID or full template API URL"), base_url, api_path
        )
        tool_name = _prompt("MCP tool name (letters, digits, underscores; start with a letter)")
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", tool_name):
            raise ValueError("Invalid tool name: use up to 64 letters, digits, underscores, starting with a letter")
        item = {"id": template_id, "tool_name": tool_name, "risk": "write"}
        title = _prompt("Display title (blank uses the Ansible template name)")
        if title:
            item["name"] = title
        templates.append(item)
        if _prompt("Add another template? y/n", "n").lower() not in {"y", "yes"}:
            break
    templates = validate_templates(templates)
    # Never fall back to an echoed prompt, e.g. when stdin is redirected.
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        token = getpass.getpass("Ansible controller API token (hidden): ")
    store.save_connection(
        name, mode="controller", base_url=base_url, api_path=api_path,
        token=token, verify_tls=True, templates=templates, ttl_hours=ttl_hours,
    )
    print(f"Saved and activated connection {name!r} with {len(templates)} tool(s).")
    print("Restart the MCP server and reconnect Inspector to load this registration.")


def _check_new_name(store: LocalStore, name: str, replace: bool) -> None:
    if not replace and any(item["name"] == name for item in store.list_connections()):
        raise ValueError("Connection already exists. Use --replace to replace its token and complete template list.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, help="Override local SQLite database path")
    sub = parser.add_subparsers(dest="command", required=True)
    for command in ("save", "save-demo"):
        command_parser = sub.add_parser(command)
        command_parser.add_argument("name")
        command_parser.add_argument("--replace", action="store_true")
    for command in ("use", "delete"):
        sub.add_parser(command).add_argument("name")
    sub.add_parser("list")
    sub.add_parser("path")
    args = parser.parse_args(argv)
    try:
        configured = os.getenv("ANSIBLE_DB_PATH")
        store = LocalStore(args.db or (Path(configured) if configured else None))
        if args.command == "path":
            print(store.path)
        elif args.command == "list":
            print(json.dumps(store.list_connections(), indent=2))
        elif args.command == "save":
            _save_interactive(store, args.name, args.replace)
        elif args.command == "save-demo":
            _check_new_name(store, args.name, args.replace)
            store.save_connection(args.name, mode="mock", templates=[
                {"id": 101, "name": "Check Disk Space", "tool_name": "ansible_check_disk_space_101", "risk": "read-only"},
                {"id": 102, "name": "Restart Nginx", "tool_name": "ansible_restart_nginx_102", "risk": "write"},
                {"id": 103, "name": "Deploy Application", "tool_name": "ansible_deploy_application_103", "risk": "write"},
            ])
            print(f"Saved and activated mock connection {args.name!r}; no credentials stored. Expires in 24 hours.")
        elif args.command == "use":
            store.activate(args.name)
            print("Active connection changed. Restart the MCP server to apply.")
        elif args.command == "delete":
            store.delete_connection(args.name)
            print("Connection removed from this database. Restart any running server to stop using its in-memory copy.")
        return 0
    except getpass.GetPassWarning:
        print("Cannot hide input in this terminal. Run registration in an interactive terminal; no token was saved.")
    except StorageError as exc:
        print(f"Configuration was not applied: {exc}")
    except ValueError:
        # Do not echo submitted values or crypto errors, which could include a secret.
        print("Configuration was not applied. Check the connection name, HTTPS origin, API path, unique tool names/IDs, token, and expiry. Existing names require --replace.")
    except (EOFError, KeyboardInterrupt):
        print("Registration canceled; no new configuration saved.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
