# AIOps + Ansible MCP integration

This update adds **Connect MCP**, **Sync MCP Tools**, input-schema display, and governed remote execution to the AIOps tool browser at `/dashboard/tools`.

It is an overlay for the AIOps4Cloud source in the supplied `1.zip`, not a complete application or container image. Extract it over a **copy** of that source; it replaces the files listed in `PACKAGE_FILES.txt`. Review and merge through your normal source-control process. The original archive is unchanged. No cluster deployment, Git push, or real Ansible job was performed while preparing this update.

## Architecture

```text
Administrator -> MCP console -> registered Ansible templates + encrypted credentials
Administrator -> AIOps Tools -> Connect / Sync -> pending tools -> approve -> assign
AIOps agent -> governed MCP client -> HTTPS mcp-ansible:8443/mcp -> Ansible Controller API
```

AIOps and MCP stay in namespace `ca55-d`, in separate Deployments/pods. AIOps stores connection identifiers, tool names, schemas, availability, approval state, and assignments in its existing database. Controller tokens and the encryption key stay with the MCP server. AIOps receives only the MCP bearer token, mounted from a Secret.

Each registered template is imported as a separate tool, for example `mcp_ansible__restart_service`. The local name is a stable, provider-compatible alias; the original remote name is retained in its binding. The generic controller operations are not automatically registered as seven additional tools. AIOps forwards the arguments advertised by each template's schema, including `extra_vars` when present.

## Requirements

- Existing AIOps source matching the supplied archive, database backup, and an administrator account.
- Python 3.12; the connection was tested with Google ADK 2.3.0 and MCP Python SDK 1.30.0. These are pinned in `pyproject.toml`. AIOps is a client and does **not** need `ansible-runner` or the separate `fastmcp` package.
- Deploy the previously supplied `mcp-ansible-openshift-ca55-d.zip` first. Its service must serve HTTPS on port 8443 and require the bearer token.
- Existing namespace objects: `mcp-ansible-secrets` (key `mcp-token`), `mcp-ansible-service-ca` (key `service-ca.crt`), and Service `mcp-ansible`.
- Access to your approved Python/npm mirrors and existing build pipeline. The baseline frontend lockfile still uses its corporate registry; no registry/security-policy bypass is part of this overlay.

**Baseline build warning:** the supplied source's `.s2i/bin/assemble` contains a graphviz dependency stub referring to an Xray policy block. This overlay does not include or modify that script. Have your platform/security owner resolve that existing build issue through an approved dependency or policy decision before production rollout; do not use a stub to bypass a policy block.

## 1. Merge and build the updated AIOps source

Extract the overlay into the root containing `pyproject.toml`, `backend`, `agents`, and `frontend`. Back up any overlapping local edits first. Review the changes and publish them through your approved AIOps source workflow. Ensure the existing BuildConfigs select the updated commit/branch; starting a build against unchanged Git source will not include this update.

Local verification (PowerShell uses `.venv/Scripts/python.exe` instead of `.venv/bin/python`):

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -e '.[dev]'
.venv/bin/python -m pip check
.venv/bin/python -m pytest tests_mcp -q
cd frontend
npm ci
npm test
npm run build
cd ..
```

The frontend preview fixture is development-only at `/mcp-preview.html` when running Vite. It contains mock data and never calls AIOps or Ansible. It is not a production entry point.

Use your normal controlled build/release process for both `aiops-backend` and `aiops-frontend`. For the supplied BuildConfig names, after their Git source points to the reviewed changes:

```bash
oc -n ca55-d start-build aiops-backend --follow
oc -n ca55-d start-build aiops-frontend --follow
```

These commands build from configured Git source, not this local folder. Do not upload a working directory containing virtual environments, `.env` files, databases, or credentials as a binary build context. Confirm the deployed image digest is the newly built image; restarting an unchanged image does not install this update.

## 2. Prepare the database before the updated backend serves traffic

Back up the existing database and follow your maintenance-window/migration procedure. Two new tables are required: `mcp_server_connection` and `mcp_tool_binding`; existing tool and assignment tables remain intact.

For an Alembic-managed installation already at revision `017_add_generate_content_config_json`, run from the **updated backend image/source**, in a migration job with the existing database connection supplied securely:

```bash
python -m alembic -c backend/migrations/alembic.ini current
python -m alembic -c backend/migrations/alembic.ini upgrade 018_mcp_connections
```

Do not run the migration command from the old pod image: it has no migration 018. Do not put a database password in a command history or this guide.

**Existing-schema cautions:**

- If the application previously created its tables through `Base.metadata.create_all` and has no Alembic history, do not blindly run all historical migrations or stamp a revision. Have the database owner reconcile that baseline. The existing development startup path can create the two missing tables, but it is not a substitute for an approved production migration history.
- Baseline revision 017 has a 36-character identifier, longer than Alembic's default 32-character version column. A PostgreSQL installation must already support that identifier (for example, an approved enlargement of `alembic_version.version_num`). Resolve this baseline issue before migration; this update does not rewrite migration history.
- Do not downgrade migration 018 on a used production database without exporting the bindings first: downgrade removes the two new tables. Restore the database backup as part of a coordinated rollback if necessary.

## 3. Configure the approved MCP connection

Review `openshift/mcp-connector-config.yaml`. The supplied profile is:

```json
{
  "servers": [{
    "profile_id": "ansible",
    "display_name": "Ansible MCP",
    "server_url": "https://mcp-ansible.ca55-d.svc:8443/mcp",
    "token_file": "/etc/aiops-mcp/token/mcp-token",
    "ca_file": "/etc/aiops-mcp/ca/service-ca.crt",
    "timeout_seconds": 1200
  }]
}
```

The URL is configuration, not hard-coded Python. Add approved profiles here when needed (up to 16); use distinct IDs matching `[a-z][a-z0-9_]{0,31}`. The browser only selects an approved ID; it cannot submit arbitrary endpoints, file paths, or credentials. `MCP_SERVERS_CONFIG_FILE` points to this JSON file.

Apply the ConfigMap and strategic merge patch to the **updated AIOps backend Deployment**:

```bash
oc -n ca55-d apply -f openshift/mcp-connector-config.yaml
oc -n ca55-d patch deployment aiops-backend --type=strategic --patch-file openshift/mcp-backend-patch.yaml
oc -n ca55-d rollout status deployment/aiops-backend
```

The patch is **not** a standalone Deployment manifest. It merges into the existing container named `backend` and preserves its other environment variables and mounts. It mounts only `mcp-token` from the MCP Secret, not `credential.key`. Token permissions are 0440; confirm your cluster's assigned volume group allows the non-root backend to read it. Do not print the token for testing.

The token must match the existing MCP package's URL-safe token format (43–512 characters). Use that package's secret-generation process; never paste tokens into the UI or chat. TLS uses the mounted service CA for this client only. Existing corporate CA/proxy settings are left intact, while MCP traffic deliberately bypasses ambient proxies and refuses redirects.

The supplied MCP NetworkPolicy admits same-namespace AIOps backend pods carrying `app=aiops-governance` and `component=backend`; the existing backend manifest has these labels. Also check any existing AIOps egress policy permits service port 8443 and cluster DNS. Do not disable policies or TLS to resolve connection errors.

## 4. Register templates and import them into AIOps

1. In the MCP console, register the Ansible template URL/ID, its tool name, required credentials, and permitted extra variables. Keep console access restricted as documented in the MCP package.
2. Sign in to AIOps as an administrator. Open **Tools** (`/dashboard/tools`).
3. Click **Connect MCP**, select **Ansible MCP**, optionally change the display name, then **Connect and import tools**.
4. Each discovered template appears as its own `mcp` tool with risk `execute` and status `pending_approval`. Connecting and syncing never launch playbooks.
5. Open **View Details** to inspect the description, remote name, input schema, and availability. **Check Availability** performs discovery only; it is not a launch test.
6. Review and **Approve** the intended tools, then assign them to the intended AIOps agent using the existing assignment controls. Approval does not assign a tool automatically.
7. After adding/changing templates in the MCP console, click **Sync MCP Tools** on its connection card. Automatic background synchronization is not enabled.
8. Test one approved, non-production template through its assigned agent with explicit input, and verify the returned Ansible job ID/status on the controller.

Example arguments, only if the tool schema advertises `extra_vars`:

```json
{"extra_vars": {"service_name": "demo-service", "target_host": "test-host"}}
```

Use controller-managed credentials for secrets instead of placing passwords in model-visible variables. Job-status/output capabilities depend on the registered tool's advertised schema; this connector does not invent extra actions.

## Governance and operational behavior

- Unchanged definitions preserve approval, assignments, and manually disabled status. Changed definitions/endpoints or reappearing tools require renewed approval.
- Missing tools are marked unavailable and disabled, retaining their bindings/assignments for review. Failed discovery reports an error and does not disable every existing tool.
- Every execution checks approval, assignment, availability, endpoint, input schema, and the freshly discovered definition. It rechecks database authorization immediately before dispatch. Cache revisions refresh newly approved/assigned tools on the next agent request, including other workers.
- Only trusted MCP servers belong in the approved profile file. Discovery is not a transaction lock on the remote controller; a server changing behavior after validation cannot be made atomic by the client. Server-side Ansible permissions, template change control, and execution approvals remain necessary.
- No automatic retry of `tools/call`. A timeout may occur after a job started. Check controller job history before retrying to avoid duplicate launches.
- The audit records dispatch intent and counts attempts, not confirmed job completion. Arguments, token values, and raw remote output are not stored in connector audit entries. Normal conversation/LLM handling may still retain model-visible arguments/results under your existing policies.
- A registration expiration/removal will prevent invocation even before the next sync. Sync updates the table display.
- The shared MCP token lets the AIOps backend access tools published by that server; AIOps approval/assignment is an additional control, not per-user controller impersonation. Use a least-privilege controller account and separate profiles/servers where isolation is required.
- For MCP bearer-token rotation, coordinate the Secret update with the MCP server restart (its token is loaded at startup). Projected files may update asynchronously. Do not change the credential encryption key without the MCP package's key-rotation procedure.

## Troubleshooting and verification scope

| Symptom | Check |
|---|---|
| No approved profiles | ConfigMap mount and `MCP_SERVERS_CONFIG_FILE`; missing configuration is not an empty remote catalog. |
| Profile unavailable | Mounted token/CA exist and are readable; never dump their contents. |
| Connection/TLS failure | Service DNS/port, certificate hostname/service CA, NetworkPolicies, server token. HTTP and redirects are intentionally rejected. |
| Tool is visible but blocked | Approve it, assign the correct agent, ensure it is available, then refresh the conversation/request. |
| Changed schema or endpoint | Sync and review approval again; cached tools cannot silently use a new definition. |
| Launch timed out | Inspect controller job history before any retry. |
| Opening `/mcp` in a browser says missing session ID | `/mcp` is a protocol endpoint, not the GUI. Use the MCP console or the AIOps Tools screen. |

Verification covers isolated SQLite database tests, PostgreSQL offline migration SQL, real local TLS MCP protocol sessions, frontend unit tests, production frontend compilation, and a mock-data browser preview. It does not certify a live OpenShift deployment, corporate mirror availability, an actual Ansible Controller, or real LLM execution. The final cluster acceptance test must be performed with your own approved credentials and a non-production template.

### Local verification record

- 98 focused MCP/backend tests passed, including a real TLS end-to-end mock job and SDK 1.30 client interoperability with a separately installed FastMCP 4 server.
- 14 runner-cache tests passed; 20 frontend tests passed; frontend production build passed (existing bundle-size advisory only).
- A clean Python 3.12 environment installed successfully and `pip check` found no broken requirements.
- Browser preview verified Connect/import, repeated sync, pending approval, and the read-only availability check. No real Ansible job or live LLM call was used.
- The broader legacy test run is **not fully green**: unchanged docstring-introspection tests and older fake-ADK/ADC test assumptions fail in this environment. Those unrelated baseline issues were not modified to make the integration tests pass.

The optional FastMCP 4 interoperability test runs only when `MCP_V4_TEST_PYTHON` names an executable in a separate environment with FastMCP 4 installed. Without it, that one test is skipped; the other 97 tests still run. Do not install FastMCP 4 into the AIOps environment, since its SDK dependency conflicts with this tested ADK version.
