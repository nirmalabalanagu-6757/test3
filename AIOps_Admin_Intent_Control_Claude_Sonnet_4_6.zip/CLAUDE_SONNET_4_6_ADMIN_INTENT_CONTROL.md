
# AIOps Admin Intent Control — Claude Sonnet 4.6 Integration Brief

## Context

The existing AIOps frontend already contains a left navigation with **GOVERNANCE** and **ADMIN** sections. The current screenshot shows items such as Agent Registry, Documents, Audit Log, Tools, Policies, Performance, Token Usage, Prompt Tokens, Cache Management, Models, User Management, and Agent Traces.

Do **not** redesign the whole application. Extend the existing UI.

## Required navigation change

Under the existing `ADMIN` section, add:

```text
ADMIN
- Models
- User Management
- Intent Control      <-- NEW
- Agent Traces
```

If the project has a better naming convention, `Dynamic Routing` or `Intent Registry` is acceptable, but use one consistent label.

## Intent Control page

The page must be agent-scoped.

Top controls:

```text
Intent Control
Manage dynamic intents, actions, SQL templates, response templates and mappings by agent.

Agent: [Backup ▼]      Search registry...      [Refresh]  [+ Register]
```

Tabs:

```text
Intents
Actions
SQL Templates
Response Templates
Mappings
Audit
```

## Agent-scoped control

An administrator chooses an agent, for example:

```text
Backup
Snow Inventory Agent
Mr. Backup
Concierge
Scheduling
DB Assistant
PSL FAQs
FinOps
R2P
...
```

The page must show only registry items assigned/owned by that agent unless a user explicitly switches to a global/all-agents view.

## Intents tab

Columns:

```text
Intent
Domain
Status
Enabled
Confidence
Margin
Actions
Templates
Version
Controls
```

Controls:

```text
View
Edit
ON/OFF
New Version
Delete
```

Turning OFF an intent must immediately remove it from runtime routing after registry-cache invalidation.

## Actions tab

Columns:

```text
Action
Type
Policy
Status
Enabled
Used By
Version
Controls
```

Action types may include:

```text
SQL
REST_API
PYTHON_TOOL
ANSIBLE
MCP
WORKFLOW
MONITORING
```

Execution policy must be visible:

```text
READ_ONLY
SAFE_WRITE
APPROVAL_REQUIRED
DESTRUCTIVE
```

## SQL Templates tab

The admin must be able to inspect exactly what SQL has been registered.

Columns:

```text
SQL Template
Database
Connection
Read Only
Status
Enabled
Used By
Version
Controls
```

The SQL detail drawer/modal should show:

```text
SQL name
Agent
Database type
Connection reference
Parameter schema
Read-only flag
Max rows
Statement timeout
SQL text
Current version
Status
Dependencies / used-by mappings
Created by / updated by
Audit history
```

Never expose raw credentials.

## Response Templates tab

Columns:

```text
Template
Render Type
Status
Enabled
Used By
Version
Controls
```

Detail view should show:

```text
title template
body template
column configuration
chart configuration
conditional rules
UI follow-up actions
empty state
version
dependencies
audit
```

## Mappings tab

This is critical for understanding runtime behavior.

Example:

```text
Intent          Mode      Action                    SQL                 Template
backup_query    DETAIL    skywise_backup_query      failed_backup_v2    failed_table_v3
backup_query    SUMMARY   skywise_backup_summary    backup_summary_v3   summary_card_v2
backup_query    TREND     backup_trend              trend_sql_v1        trend_chart_v1
```

Admins must be able to see the full dependency chain.

## Delete behavior

Use soft delete by default.

Allowed states:

```text
DRAFT
ACTIVE
DISABLED
DEPRECATED
DELETED
```

Do not permanently delete a registry item while it has active dependencies.

Example HTTP behavior:

```text
DELETE /api/admin/intent-control/sql-templates/44

409 Conflict

{
  "error": "dependency_conflict",
  "message": "SQL template is referenced by active mappings.",
  "dependencies": [
    {
      "agent": "Backup",
      "intent": "backup_query",
      "presentation_mode": "SUMMARY"
    }
  ]
}
```

The UI should display those dependencies and instruct the admin to disable/remove mappings first.

## Enable/disable behavior

Runtime loaders must only consider records satisfying:

```sql
enabled = TRUE
AND status = 'ACTIVE'
AND deleted_at IS NULL
```

After an admin enables/disables/versions/deletes a registry record, invalidate the appropriate runtime registry cache immediately.

## Audit requirements

Every create/update/enable/disable/version/delete/restore operation must generate an audit entry.

Store:

```text
entity_type
entity_id
action
old_value
new_value
performed_by
performed_at
```

## Permissions

Reuse the existing user-management/auth model.

Recommended logical permissions:

```text
VIEW
CREATE
EDIT
ENABLE_DISABLE
VERSION
DELETE
APPROVE
EXECUTE
```

Do not implement a parallel identity system.

## Required backend API surface

Adapt names to the current API conventions.

Reference endpoints:

```text
GET    /api/admin/agents

GET    /api/admin/intent-control/agents/{agent_id}/intents
GET    /api/admin/intent-control/agents/{agent_id}/actions
GET    /api/admin/intent-control/agents/{agent_id}/sql-templates
GET    /api/admin/intent-control/agents/{agent_id}/response-templates
GET    /api/admin/intent-control/agents/{agent_id}/mappings
GET    /api/admin/intent-control/agents/{agent_id}/audit

PATCH  /api/admin/intent-control/intents/{id}
PATCH  /api/admin/intent-control/actions/{id}
PATCH  /api/admin/intent-control/sql-templates/{id}
PATCH  /api/admin/intent-control/response-templates/{id}

POST   /api/admin/intent-control/...      # create
POST   /api/admin/intent-control/.../{id}/versions
POST   /api/admin/intent-control/.../{id}/restore

DELETE /api/admin/intent-control/intents/{id}
DELETE /api/admin/intent-control/actions/{id}
DELETE /api/admin/intent-control/sql-templates/{id}
DELETE /api/admin/intent-control/response-templates/{id}
```

## Claude Sonnet 4.6 implementation instruction

Before changing code:

1. inspect the current left-navigation component;
2. inspect current router definitions;
3. inspect Agent Registry UI patterns;
4. inspect existing table/modal/drawer components;
5. inspect API client/error/toast conventions;
6. inspect current auth/role checks;
7. inspect current `agent_registry`, `tool_registry`, tool assignment, audit and trace models;
8. identify which existing tables/models can be reused;
9. produce a file-by-file integration plan;
10. only then implement.

Do not create a duplicate admin shell, duplicate sidebar, duplicate API client, duplicate audit framework, or duplicate user/role model.

## Compatibility priority

The existing AIOps application is the implementation source of truth.

This reference component is intentionally framework-light. Map it onto existing project conventions.

Preferred result:

```text
Existing AIOps UI
   |
   +-- existing sidebar
   |      +-- ADMIN
   |            +-- Intent Control
   |
   +-- existing route framework
   |
   +-- existing API client
   |
   +-- existing auth/RBAC
   |
   +-- existing table/modal components
   |
   +-- new intent-control page/features
```

not:

```text
Existing AIOps UI
+
separate new admin framework
```
