
import React, { useEffect, useMemo, useState } from "react";

/**
 * Reference page for the existing AIOps Admin UI.
 *
 * IMPORTANT:
 * - Adapt imports, route registration, API client, table, modal, toast, and auth components
 *   to the existing repository.
 * - Do NOT introduce a second design system if the project already has one.
 * - This file intentionally uses plain React/HTML so Claude can map it to the current codebase.
 */

type LifecycleStatus = "DRAFT" | "ACTIVE" | "DISABLED" | "DEPRECATED" | "DELETED";

type AgentOption = {
  id: number | string;
  name: string;
  product?: string;
};

type IntentRow = {
  intentId: number;
  agentId: number | string;
  domain: string;
  intentName: string;
  description?: string;
  enabled: boolean;
  status: LifecycleStatus;
  confidenceThreshold: number;
  minimumMargin: number;
  version: number;
  actionCount: number;
  templateCount: number;
  updatedAt?: string;
};

type ActionRow = {
  actionId: number;
  actionName: string;
  actionType: string;
  executionPolicy: string;
  enabled: boolean;
  status: LifecycleStatus;
  version: number;
  usedByCount: number;
};

type SqlTemplateRow = {
  sqlTemplateId: number;
  sqlName: string;
  databaseType?: string;
  connectionRef?: string;
  readOnly: boolean;
  enabled: boolean;
  status: LifecycleStatus;
  version: number;
  usedByCount: number;
};

type ResponseTemplateRow = {
  templateId: number;
  templateName: string;
  renderType: string;
  enabled: boolean;
  status: LifecycleStatus;
  version: number;
  usedByCount: number;
};

type MappingRow = {
  mappingId: number;
  intentName: string;
  presentationMode: string;
  actionName: string;
  sqlName?: string;
  templateName: string;
  enabled: boolean;
};

type AuditRow = {
  auditId: number;
  entityType: string;
  entityId: number;
  action: string;
  performedBy: string;
  performedAt: string;
};

type TabKey =
  | "intents"
  | "actions"
  | "sql"
  | "templates"
  | "mappings"
  | "audit";

const tabs: { key: TabKey; label: string }[] = [
  { key: "intents", label: "Intents" },
  { key: "actions", label: "Actions" },
  { key: "sql", label: "SQL Templates" },
  { key: "templates", label: "Response Templates" },
  { key: "mappings", label: "Mappings" },
  { key: "audit", label: "Audit" },
];

/**
 * Replace these fetch calls with the existing project's API client.
 * Endpoints are REFERENCE CONTRACTS only.
 */
async function apiGet<T>(path: string): Promise<T> {
  const r = await fetch(path, { credentials: "include" });
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  return r.json();
}

async function apiPatch<T>(path: string, body: unknown): Promise<T> {
  const r = await fetch(path, {
    method: "PATCH",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  return r.json();
}

async function apiDelete<T>(path: string): Promise<T> {
  const r = await fetch(path, {
    method: "DELETE",
    credentials: "include",
  });
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  return r.json();
}

function StatusBadge({ status, enabled }: { status: LifecycleStatus; enabled: boolean }) {
  const text = !enabled && status === "ACTIVE" ? "DISABLED" : status;
  return (
    <span
      style={{
        display: "inline-block",
        padding: "2px 8px",
        borderRadius: 12,
        border: "1px solid #c8c8c8",
        fontSize: 12,
        fontWeight: 600,
      }}
    >
      {text}
    </span>
  );
}

function Toggle({
  checked,
  onChange,
  disabled,
}: {
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onChange}
      disabled={disabled}
      aria-pressed={checked}
      style={{
        minWidth: 62,
        padding: "4px 8px",
        cursor: disabled ? "not-allowed" : "pointer",
      }}
    >
      {checked ? "ON" : "OFF"}
    </button>
  );
}

function Empty({ text }: { text: string }) {
  return <div style={{ padding: 32, textAlign: "center", opacity: 0.7 }}>{text}</div>;
}

export default function AdminIntentControlPage() {
  const [agents, setAgents] = useState<AgentOption[]>([]);
  const [selectedAgentId, setSelectedAgentId] = useState<string>("");
  const [tab, setTab] = useState<TabKey>("intents");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [intents, setIntents] = useState<IntentRow[]>([]);
  const [actions, setActions] = useState<ActionRow[]>([]);
  const [sqlTemplates, setSqlTemplates] = useState<SqlTemplateRow[]>([]);
  const [responseTemplates, setResponseTemplates] = useState<ResponseTemplateRow[]>([]);
  const [mappings, setMappings] = useState<MappingRow[]>([]);
  const [auditRows, setAuditRows] = useState<AuditRow[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const data = await apiGet<AgentOption[]>("/api/admin/agents");
        setAgents(data);
        if (data.length) setSelectedAgentId(String(data[0].id));
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      }
    })();
  }, []);

  async function reload() {
    if (!selectedAgentId) return;
    setLoading(true);
    setError("");
    try {
      const base = `/api/admin/intent-control/agents/${encodeURIComponent(selectedAgentId)}`;
      const [
        intentData,
        actionData,
        sqlData,
        templateData,
        mappingData,
        auditData,
      ] = await Promise.all([
        apiGet<IntentRow[]>(`${base}/intents`),
        apiGet<ActionRow[]>(`${base}/actions`),
        apiGet<SqlTemplateRow[]>(`${base}/sql-templates`),
        apiGet<ResponseTemplateRow[]>(`${base}/response-templates`),
        apiGet<MappingRow[]>(`${base}/mappings`),
        apiGet<AuditRow[]>(`${base}/audit?limit=100`),
      ]);

      setIntents(intentData);
      setActions(actionData);
      setSqlTemplates(sqlData);
      setResponseTemplates(templateData);
      setMappings(mappingData);
      setAuditRows(auditData);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    reload();
  }, [selectedAgentId]);

  async function toggleEntity(
    entity: "intents" | "actions" | "sql-templates" | "response-templates",
    id: number,
    enabled: boolean
  ) {
    await apiPatch(`/api/admin/intent-control/${entity}/${id}`, { enabled });
    await reload();
  }

  async function safeDelete(
    entity: "intents" | "actions" | "sql-templates" | "response-templates",
    id: number
  ) {
    /**
     * Backend MUST dependency-check.
     * DELETE should be soft-delete by default.
     * If references exist, backend should return 409 with dependency details.
     */
    try {
      await apiDelete(`/api/admin/intent-control/${entity}/${id}`);
      await reload();
    } catch (e) {
      alert(
        "Delete blocked or failed. Check active dependencies/mappings first.\n\n" +
          (e instanceof Error ? e.message : String(e))
      );
    }
  }

  const normalizedSearch = search.trim().toLowerCase();

  const filteredIntents = useMemo(
    () =>
      intents.filter((x) =>
        `${x.intentName} ${x.domain} ${x.description ?? ""}`
          .toLowerCase()
          .includes(normalizedSearch)
      ),
    [intents, normalizedSearch]
  );

  const filteredActions = useMemo(
    () =>
      actions.filter((x) =>
        `${x.actionName} ${x.actionType} ${x.executionPolicy}`
          .toLowerCase()
          .includes(normalizedSearch)
      ),
    [actions, normalizedSearch]
  );

  const filteredSql = useMemo(
    () =>
      sqlTemplates.filter((x) =>
        `${x.sqlName} ${x.databaseType ?? ""} ${x.connectionRef ?? ""}`
          .toLowerCase()
          .includes(normalizedSearch)
      ),
    [sqlTemplates, normalizedSearch]
  );

  const filteredTemplates = useMemo(
    () =>
      responseTemplates.filter((x) =>
        `${x.templateName} ${x.renderType}`.toLowerCase().includes(normalizedSearch)
      ),
    [responseTemplates, normalizedSearch]
  );

  return (
    <div style={{ padding: 24 }}>
      <div style={{ marginBottom: 18 }}>
        <h1 style={{ marginBottom: 4 }}>Intent Control</h1>
        <div style={{ opacity: 0.75 }}>
          Manage dynamic intents, actions, SQL templates, response templates and mappings by agent.
        </div>
      </div>

      <div
        style={{
          display: "flex",
          gap: 12,
          alignItems: "center",
          flexWrap: "wrap",
          marginBottom: 16,
        }}
      >
        <label>
          Agent{" "}
          <select
            value={selectedAgentId}
            onChange={(e) => setSelectedAgentId(e.target.value)}
          >
            {agents.map((a) => (
              <option key={String(a.id)} value={String(a.id)}>
                {a.name}{a.product ? ` — ${a.product}` : ""}
              </option>
            ))}
          </select>
        </label>

        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search registry..."
          style={{ minWidth: 260 }}
        />

        <button type="button" onClick={reload}>
          Refresh
        </button>

        <div style={{ marginLeft: "auto" }}>
          {/* Replace with existing modal/form */}
          <button type="button">+ Register</button>
        </div>
      </div>

      <div
        style={{
          display: "flex",
          gap: 8,
          borderBottom: "1px solid #ddd",
          marginBottom: 16,
          flexWrap: "wrap",
        }}
      >
        {tabs.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            style={{
              padding: "8px 12px",
              border: "none",
              borderBottom: tab === t.key ? "3px solid currentColor" : "3px solid transparent",
              background: "transparent",
              fontWeight: tab === t.key ? 700 : 400,
              cursor: "pointer",
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {error && (
        <div style={{ padding: 12, border: "1px solid #d99", marginBottom: 12 }}>
          {error}
        </div>
      )}

      {loading ? (
        <div>Loading…</div>
      ) : (
        <>
          {tab === "intents" && (
            <RegistryTable
              headers={[
                "Intent",
                "Domain",
                "Status",
                "Enabled",
                "Confidence",
                "Margin",
                "Actions",
                "Templates",
                "Version",
                "Controls",
              ]}
              rows={filteredIntents.map((x) => [
                x.intentName,
                x.domain,
                <StatusBadge status={x.status} enabled={x.enabled} />,
                <Toggle
                  checked={x.enabled}
                  onChange={() => toggleEntity("intents", x.intentId, !x.enabled)}
                />,
                x.confidenceThreshold.toFixed(2),
                x.minimumMargin.toFixed(2),
                x.actionCount,
                x.templateCount,
                `v${x.version}`,
                <RowControls
                  onView={() => alert(`Open intent ${x.intentId}`)}
                  onEdit={() => alert(`Edit intent ${x.intentId}`)}
                  onVersion={() => alert(`Version intent ${x.intentId}`)}
                  onDelete={() => safeDelete("intents", x.intentId)}
                />,
              ])}
            />
          )}

          {tab === "actions" && (
            <RegistryTable
              headers={[
                "Action",
                "Type",
                "Policy",
                "Status",
                "Enabled",
                "Used By",
                "Version",
                "Controls",
              ]}
              rows={filteredActions.map((x) => [
                x.actionName,
                x.actionType,
                x.executionPolicy,
                <StatusBadge status={x.status} enabled={x.enabled} />,
                <Toggle
                  checked={x.enabled}
                  onChange={() => toggleEntity("actions", x.actionId, !x.enabled)}
                />,
                x.usedByCount,
                `v${x.version}`,
                <RowControls
                  onView={() => alert(`Open action ${x.actionId}`)}
                  onEdit={() => alert(`Edit action ${x.actionId}`)}
                  onVersion={() => alert(`Version action ${x.actionId}`)}
                  onDelete={() => safeDelete("actions", x.actionId)}
                />,
              ])}
            />
          )}

          {tab === "sql" && (
            <RegistryTable
              headers={[
                "SQL Template",
                "Database",
                "Connection",
                "Read Only",
                "Status",
                "Enabled",
                "Used By",
                "Version",
                "Controls",
              ]}
              rows={filteredSql.map((x) => [
                x.sqlName,
                x.databaseType ?? "-",
                x.connectionRef ?? "-",
                x.readOnly ? "Yes" : "No",
                <StatusBadge status={x.status} enabled={x.enabled} />,
                <Toggle
                  checked={x.enabled}
                  onChange={() =>
                    toggleEntity("sql-templates", x.sqlTemplateId, !x.enabled)
                  }
                />,
                x.usedByCount,
                `v${x.version}`,
                <RowControls
                  onView={() => alert(`Open SQL ${x.sqlTemplateId}`)}
                  onEdit={() => alert(`Edit SQL ${x.sqlTemplateId}`)}
                  onVersion={() => alert(`Version SQL ${x.sqlTemplateId}`)}
                  onDelete={() => safeDelete("sql-templates", x.sqlTemplateId)}
                />,
              ])}
            />
          )}

          {tab === "templates" && (
            <RegistryTable
              headers={[
                "Response Template",
                "Render Type",
                "Status",
                "Enabled",
                "Used By",
                "Version",
                "Controls",
              ]}
              rows={filteredTemplates.map((x) => [
                x.templateName,
                x.renderType,
                <StatusBadge status={x.status} enabled={x.enabled} />,
                <Toggle
                  checked={x.enabled}
                  onChange={() =>
                    toggleEntity("response-templates", x.templateId, !x.enabled)
                  }
                />,
                x.usedByCount,
                `v${x.version}`,
                <RowControls
                  onView={() => alert(`Open template ${x.templateId}`)}
                  onEdit={() => alert(`Edit template ${x.templateId}`)}
                  onVersion={() => alert(`Version template ${x.templateId}`)}
                  onDelete={() => safeDelete("response-templates", x.templateId)}
                />,
              ])}
            />
          )}

          {tab === "mappings" && (
            <RegistryTable
              headers={[
                "Intent",
                "Mode",
                "Action",
                "SQL",
                "Response Template",
                "Enabled",
              ]}
              rows={mappings.map((x) => [
                x.intentName,
                x.presentationMode,
                x.actionName,
                x.sqlName ?? "-",
                x.templateName,
                x.enabled ? "Yes" : "No",
              ])}
            />
          )}

          {tab === "audit" && (
            <RegistryTable
              headers={["Entity", "ID", "Action", "Performed By", "Time"]}
              rows={auditRows.map((x) => [
                x.entityType,
                x.entityId,
                x.action,
                x.performedBy,
                x.performedAt,
              ])}
            />
          )}
        </>
      )}
    </div>
  );
}

function RegistryTable({
  headers,
  rows,
}: {
  headers: string[];
  rows: React.ReactNode[][];
}) {
  if (!rows.length) return <Empty text="No records found." />;

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            {headers.map((h) => (
              <th
                key={h}
                style={{
                  textAlign: "left",
                  borderBottom: "1px solid #ccc",
                  padding: 8,
                  whiteSpace: "nowrap",
                }}
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, r) => (
            <tr key={r}>
              {row.map((cell, c) => (
                <td
                  key={c}
                  style={{
                    padding: 8,
                    borderBottom: "1px solid #eee",
                    verticalAlign: "top",
                  }}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function RowControls({
  onView,
  onEdit,
  onVersion,
  onDelete,
}: {
  onView: () => void;
  onEdit: () => void;
  onVersion: () => void;
  onDelete: () => void;
}) {
  return (
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
      <button type="button" onClick={onView}>View</button>
      <button type="button" onClick={onEdit}>Edit</button>
      <button type="button" onClick={onVersion}>New Version</button>
      <button type="button" onClick={onDelete}>Delete</button>
    </div>
  );
}
