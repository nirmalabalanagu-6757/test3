#!/usr/bin/env bash
# Run only from a reviewed, extracted deployment package after oc login.
set -Eeuo pipefail
package_script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
package_python=${PYTHON:-python3.12}
command -v "${package_python}" >/dev/null 2>&1 || {
    printf '%s\n' 'Python 3.12 is required. Set PYTHON to its executable if needed.' >&2
    exit 1
}
exec "${package_python}" "${package_script_dir}/deploy.py" "$@"
