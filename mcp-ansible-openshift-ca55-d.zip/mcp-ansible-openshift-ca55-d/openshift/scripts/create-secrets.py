#!/usr/bin/env python3
"""Create/reuse the OpenShift bootstrap Secret without printing secret values."""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import secrets
import subprocess
import sys


NAMESPACE = "ca55-d"
SECRET_NAME = "mcp-ansible-secrets"
PVC_NAME = "mcp-ansible-data"


class ProvisionError(RuntimeError):
    pass


def _oc(arguments: list[str], *, payload: dict | None = None, oc: str = "oc") -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            [oc, "--namespace", NAMESPACE, *arguments],
            input=json.dumps(payload) if payload is not None else None,
            text=True, capture_output=True, check=False, timeout=60,
        )
    except (OSError, subprocess.SubprocessError):
        raise ProvisionError("Could not contact OpenShift using oc. Check the executable, current login, and namespace permissions.") from None


def _get_resource(kind: str, name: str, *, oc: str = "oc") -> dict | None:
    result = _oc(["get", kind, name, "--ignore-not-found", "-o", "json"], oc=oc)
    if result.returncode != 0:
        raise ProvisionError("OpenShift resource lookup failed. Check current login and namespace permissions.")
    if not result.stdout.strip():
        return None
    try:
        value = json.loads(result.stdout)
        if not isinstance(value, dict) or value.get("metadata", {}).get("name") != name or value.get("metadata", {}).get("namespace") != NAMESPACE:
            raise ValueError
        return value
    except (ValueError, TypeError, AttributeError):
        raise ProvisionError("OpenShift returned an invalid resource response.") from None


def _validate_secret(secret: dict) -> None:
    try:
        if secret.get("kind") != "Secret" or secret.get("type") != "Opaque":
            raise ValueError
        data = secret["data"]
        key = base64.b64decode(data["credential.key"], validate=True)
        token = base64.b64decode(data["mcp-token"], validate=True)
        decoded_key = base64.b64decode(key, altchars=b"-_", validate=True)
        if len(key) != 44 or len(decoded_key) != 32 or base64.urlsafe_b64encode(decoded_key) != key:
            raise ValueError
        if not re.fullmatch(rb"[A-Za-z0-9_-]{43,512}", token):
            raise ValueError
    except (ValueError, TypeError, KeyError):
        raise ProvisionError("The existing Secret is invalid. Restore the original valid Secret; it was not changed.") from None


def provision(*, oc: str = "oc") -> bool:
    """Return True when created, False when an existing valid Secret is reused."""
    existing = _get_resource("secret", SECRET_NAME, oc=oc)
    if existing is not None:
        _validate_secret(existing)
        return False
    if _get_resource("pvc", PVC_NAME, oc=oc) is not None:
        raise ProvisionError("The Secret is missing while the data PVC exists. Restore the original Secret from backup; a replacement key was not generated.")
    key = base64.urlsafe_b64encode(os.urandom(32))
    token = secrets.token_urlsafe(32).encode("ascii")
    document = {
        "apiVersion": "v1", "kind": "Secret", "type": "Opaque",
        "metadata": {"name": SECRET_NAME, "namespace": NAMESPACE},
        "data": {
            "credential.key": base64.b64encode(key).decode("ascii"),
            "mcp-token": base64.b64encode(token).decode("ascii"),
        },
    }
    result = _oc(["create", "-f", "-"], payload=document, oc=oc)
    if result.returncode == 0:
        return True
    # A competing initializer may have created it; reuse only a valid Secret.
    existing = _get_resource("secret", SECRET_NAME, oc=oc)
    if existing is not None:
        _validate_secret(existing)
        return False
    raise ProvisionError("Secret creation failed. Check namespace permissions and cluster availability; no existing Secret was overwritten.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Create or verify mcp-ansible-secrets without revealing its values.")
    parser.add_argument("--namespace", choices=[NAMESPACE], default=NAMESPACE)
    parser.add_argument("--oc", default="oc", help="Path to the oc executable.")
    args = parser.parse_args(argv)
    if not args.oc:
        parser.error("--oc requires an executable path")
    try:
        created = provision(oc=args.oc)
    except ProvisionError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(f"Secret {'created' if created else 'validated and reused unchanged'} in {NAMESPACE}. No secret values were displayed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
