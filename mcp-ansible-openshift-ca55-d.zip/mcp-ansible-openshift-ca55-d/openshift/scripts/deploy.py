"""Explicit, fixed-scope deployment; preflight is read-only and is the default."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys


NAMESPACE = "ca55-d"
NAME = "mcp-ansible"
HERE = Path(__file__).resolve().parent
MANIFESTS = HERE.parent / "manifests"
CONTEXT = HERE.parents[1] / "build-context"
FILES = (
    "imagestream.yaml", "buildconfig.yaml", "configmap.yaml", "serviceaccount.yaml",
    "storage.yaml", "service.yaml", "networkpolicy.yaml", "deployment.yaml",
)


class DeploymentError(Exception):
    pass


def command(oc: str, *args: str, capture: bool = False, payload: str | None = None) -> str:
    process = subprocess.run([oc, *args], input=payload, text=True,
                             stdout=subprocess.PIPE if capture else None,
                             stderr=subprocess.PIPE if capture else None, check=False)
    if process.returncode:
        # Do not echo server responses: they can include configuration or secrets.
        raise DeploymentError(f"OpenShift command failed ({args[0]}). Check your login, permissions, and cluster events.")
    return process.stdout.strip() if capture else ""


def preflight(oc: str) -> None:
    if sys.version_info[:2] != (3, 12):
        raise DeploymentError("Use Python 3.12 for these deployment scripts.")
    for filename in FILES:
        if not (MANIFESTS / filename).is_file():
            raise DeploymentError(f"Missing manifest: {filename}")
    for name in ("src/ansible_mcp/server.py", "runtime/server.py", "requirements.txt", ".s2i/bin/assemble", ".s2i/bin/run"):
        if not (CONTEXT / name).is_file():
            raise DeploymentError("Run from the complete extracted OpenShift ZIP. Build it with scripts/build_openshift_zip.py first.")
    # Never pass the whole developer checkout to a binary build.
    for path in CONTEXT.rglob("*"):
        if (path.is_symlink() or any(part in {".git", ".venv", "__pycache__"} for part in path.parts)
                or path.name == ".env" or path.suffix in {".key", ".db", ".sqlite3", ".pyc", ".pem"}):
            raise DeploymentError("Build context contains unexpected local runtime data. Use a fresh extracted ZIP.")
    print("Checking current OpenShift login and the existing ca55-d namespace.", flush=True)
    command(oc, "whoami")
    command(oc, "whoami", "--show-server")
    command(oc, "get", "namespace", NAMESPACE, "-o", "name")
    command(oc, "get", "imagestreamtag", "airbus-python-312-ubi9:latest", "-n", "openshift", "-o", "name")
    for filename in FILES:
        command(oc, "apply", "--dry-run=server", "-n", NAMESPACE, "-f", str(MANIFESTS / filename))
    print("Preflight passed. No resources were persisted. Verify storage class, image availability, and the permitted AIOps pod labels.", flush=True)


def built_image(build: dict) -> str:
    if build.get("metadata", {}).get("namespace") != NAMESPACE:
        raise DeploymentError("Build namespace mismatch.")
    if build.get("metadata", {}).get("labels", {}).get("openshift.io/build-config.name") != NAME:
        raise DeploymentError("Build does not belong to mcp-ansible.")
    status = build.get("status", {})
    digest = status.get("output", {}).get("to", {}).get("imageDigest", "")
    if status.get("phase") != "Complete" or not re.fullmatch(r"sha256:[0-9a-f]{64}", digest):
        raise DeploymentError("Build is not complete or its immutable image digest is unavailable; deployment was not applied.")
    return f"image-registry.openshift-image-registry.svc:5000/{NAMESPACE}/{NAME}@{digest}"


def deploy(oc: str) -> None:
    preflight(oc)
    print("Deploying only mcp-ansible resources; no AIOps resources will be changed.", flush=True)
    provision = subprocess.run([sys.executable, str(HERE / "create-secrets.py"), "--oc", oc,
                                "--namespace", NAMESPACE], check=False)
    if provision.returncode:
        raise DeploymentError("Secret provisioning failed. Existing data and keys must be preserved.")
    for filename in FILES[:-1]:
        command(oc, "apply", "-n", NAMESPACE, "-f", str(MANIFESTS / filename))
    build_name = command(oc, "start-build", NAME, "-n", NAMESPACE, f"--from-dir={CONTEXT}", "-o", "name", capture=True)
    if not re.fullmatch(r"build(?:\.build\.openshift\.io)?/mcp-ansible-[0-9]+", build_name):
        raise DeploymentError("Unexpected build identity; deployment was not changed.")
    command(oc, "logs", "-f", build_name, "-n", NAMESPACE)
    command(oc, "wait", "--for=jsonpath={.status.phase}=Complete", build_name,
            "-n", NAMESPACE, "--timeout=20m")
    image = built_image(json.loads(command(oc, "get", build_name, "-n", NAMESPACE, "-o", "json", capture=True)))
    deployment = json.loads(command(oc, "create", "--dry-run=client", "-f",
                                     str(MANIFESTS / "deployment.yaml"), "-o", "json", capture=True))
    if (deployment.get("kind") != "Deployment" or deployment.get("metadata", {}).get("name") != NAME
            or deployment.get("metadata", {}).get("namespace") != NAMESPACE):
        raise DeploymentError("Unexpected deployment target; refusing to apply it.")
    containers = deployment["spec"]["template"]["spec"]["containers"]
    if len(containers) != 1 or containers[0].get("name") != NAME:
        raise DeploymentError("Unexpected deployment container layout.")
    containers[0]["image"] = image
    command(oc, "apply", "-n", NAMESPACE, "-f", "-", payload=json.dumps(deployment))
    command(oc, "rollout", "status", f"deployment/{NAME}", "-n", NAMESPACE, "--timeout=10m")
    command(oc, "get", "pods", "-n", NAMESPACE, "-l", "app.kubernetes.io/name=mcp-ansible", "-o", "wide")
    print("Deployed the separate MCP application. Console: oc -n ca55-d port-forward deployment/mcp-ansible 8000:8000")
    print("AIOps endpoint: https://mcp-ansible.ca55-d.svc:8443/mcp (bearer token and service CA trust required).")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", nargs="?", choices=("preflight", "deploy"), default="preflight")
    parser.add_argument("--oc", default=os.environ.get("OC", "oc"))
    args = parser.parse_args()
    try:
        (deploy if args.action == "deploy" else preflight)(args.oc)
    except (DeploymentError, OSError, ValueError, KeyError) as exc:
        if isinstance(exc, DeploymentError):
            print(f"Stopped: {exc}", file=sys.stderr)
        else:
            print("Stopped: deployment command or response could not be processed. Check oc availability and cluster access.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
