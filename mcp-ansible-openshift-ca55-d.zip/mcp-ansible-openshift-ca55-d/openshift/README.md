# Separate Ansible MCP service in OpenShift namespace `ca55-d`

This package adds a separate `mcp-ansible` Deployment beside the existing AIOps application. It does **not** rebuild, restart, patch, or reuse AIOps Deployments, ConfigMaps, Secrets, Services, Routes, or storage. The namespace must already exist. Pod names will look like `mcp-ansible-<replica-hash>-<suffix>`.

The supplied AIOps archive was used only to identify the namespace, approved Python builder image, internal package index, and backend pod labels. Its Git build source, dependency stub, TLS-verification bypass, and AIOps credentials are not copied.

**Nothing has been deployed to the cluster from this development environment.** `oc`, Docker, and a connected OpenShift test environment were unavailable. Local source tests, shell/YAML checks, and artifact validation do not prove that cluster admission, the private builder, storage, or controller connectivity will succeed.

## What runs where

| Interface | Address | Access |
| --- | --- | --- |
| Machine MCP endpoint | `https://mcp-ansible.ca55-d.svc:8443/mcp` | AIOps backend pods in `ca55-d`; bearer token and service-CA TLS trust required |
| Browser registration console | Pod loopback `127.0.0.1:8000/console` | Operator `oc port-forward`; not exposed by the Service |
| Health check | HTTPS port `8443`, `/healthz` | Readiness/liveness only; no secret or tool data |

There is no public Route. The public listener does not serve the console and rejects browser-origin requests; the admin listener does not expose MCP. An empty/new deployment publishes no demonstration tools. Register approved Ansible templates through the console before connecting AIOps.

The NetworkPolicy selects only `app: mcp-ansible` and allows port 8443 from pods with both `app: aiops-governance` and `component: backend` in the same namespace. It does not isolate or change AIOps pods and does not introduce an egress policy. Existing namespace policies may still restrict AIOps egress or controller/DNS connectivity. NetworkPolicies are additive: another policy selecting these MCP pods may allow additional traffic; review the effective policy set. [Kubernetes NetworkPolicy semantics](https://kubernetes.io/docs/concepts/services-networking/network-policies/).

## Package contents

The downloadable archive has this structure:

```text
mcp-ansible-openshift-ca55-d/
  build-context/
    src/                     # Ansible template tools and registration UI
    config/
    runtime/                 # OpenShift TLS/auth/bootstrap entry point
    requirements.txt         # Complete hashed Python 3.12/Linux dependency lock
    .s2i/bin/assemble
    .s2i/bin/run
  openshift/
    README.md
    manifests/
    scripts/deploy.sh
    scripts/deploy.py
    scripts/create-secrets.py
  BUILD_INFO.json
```

Run the deployment wrapper from this extracted package. It uploads **only** `build-context/`, never the developer repository, local `.venv`, SQLite files, or saved credentials. A Binary Source build does not need an unpushed Git commit, Git repository credentials, or a source webhook.

## Prerequisites and decisions before deployment

- Log in to the intended cluster using your approved `oc` process. Verify that `ca55-d` is the correct existing development namespace.
- Use a local shell with Bash, Python 3.12 for the deployment helpers, and `oc`. `PYTHON=python3.12` and `OC=/path/to/oc` can select explicit binaries.
- Your account must be authorized to inspect the namespace/builder, dry-run and manage the named application resources, create/use binary builds, and manage the new application Secret. Console operators also need pod port-forward permission.
- Confirm the existing builder `openshift/airbus-python-312-ubi9:latest` is available and usable from `ca55-d`. The manifests select Linux `amd64` nodes to match the supplied CPython 3.12 dependency lock.
- Review namespace quotas, admission policy, registry access, service-CA operation, and the resource requests/limits in the manifests.
- Select and validate a StorageClass for the SQLite PVC before first installation. `storage.yaml` deliberately omits `storageClassName`, so the namespace/cluster default is used only if one exists and is suitable. You may add an approved explicit class before deployment.
- Verify access from build pods to the configured internal Python package index and from the runtime pod to the chosen Ansible controller over trusted HTTPS. DNS and any required organizational proxy/egress configuration must be provided through reviewed, MCP-specific settings.

Do not assume that the reference application's `trident`/RWX storage supports SQLite's locking and durability requirements. Use storage with tested filesystem locking and `fsync` semantics. Keep **one replica**, `Recreate`, and `ReadWriteOnce`; do not add an HPA or multiple writers. Plan a different database architecture before horizontal scaling.

The build uses the internal HTTPS index recorded in the reference:

```text
https://artifactory.2b82.aws.cloud.airbus.corp/artifactory/api/pypi/pypi/simple
```

The approved builder must trust this endpoint using its CA bundle (`/etc/pki/tls/certs/ca-bundle.crt` by default). Build dependencies require exact hashes and binary wheels. A missing/rejected artifact or an untrusted certificate is a failure to resolve with the platform/security team, not a reason to add a package stub, `--trusted-host`, `--insecure`, or an alternate unapproved index. This is not an offline build bundle.

## 1. Preflight without deployment

From the extracted package root:

```bash
oc whoami
oc get namespace ca55-d
PYTHON=python3.12 bash openshift/scripts/deploy.sh preflight
```

`preflight` is also the wrapper's default action. It checks access, namespace/builder availability, and server-side dry-run validation of the fixed manifest set. It does not create a namespace, switch the current project, apply resources, build an image, or generate a Secret. Server dry-run is a diagnostic request and is not evidence of a successful build or rollout.

Review any failures before continuing. The script always targets `ca55-d` explicitly; a different namespace is not silently inferred from your current `oc project`.

## 2. Deploy when you are ready

This command creates/updates only the named MCP resources in `ca55-d` and starts a build:

```bash
PYTHON=python3.12 bash openshift/scripts/deploy.sh deploy
```

The deployment flow validates or generates `mcp-ansible-secrets` **before** creating the PVC, applies supporting resources, runs the binary S2I build, waits for success, pins the Deployment to that Build's exact output image digest, applies it, and waits for rollout. A failed build does not replace the running Deployment image. BuildConfig triggers are empty; future image changes do not automatically launch unreviewed builds or rollouts.

The generated user Secret has exactly these application values:

- `credential.key`: the database encryption key, used only by MCP.
- `mcp-token`: the bearer credential required by the machine-facing MCP endpoint.

No real values are embedded in YAML, source, archive, or command-line examples. The helper passes secret material without printing it. An existing valid Secret is reused unchanged. If the data PVC already exists but the Secret is missing, provisioning stops; restore the original Secret instead of generating a replacement encryption key.

Do not apply a fabricated placeholder Secret, manually replace the key, or delete the PVC to get past a startup error. Deployment is not an uninstall or data-reset operation.

## 3. Verify the separate workload

```bash
oc -n ca55-d get deployment mcp-ansible
oc -n ca55-d get pods -l app.kubernetes.io/name=mcp-ansible
oc -n ca55-d get service mcp-ansible
oc -n ca55-d get pvc mcp-ansible-data
oc -n ca55-d rollout status deployment/mcp-ansible --timeout=600s
oc -n ca55-d logs deployment/mcp-ansible
```

The Service requests a serving certificate in Secret `mcp-ansible-tls`. The separate `mcp-ansible-service-ca` ConfigMap requests the public CA bundle under `service-ca.crt`. OpenShift's service-CA controller manages these through annotations; a pending serving certificate can keep the pod from starting. [OpenShift service certificates and CA injection](https://docs.redhat.com/en/documentation/openshift_container_platform/4.18/html/security_and_compliance/configuring-certificates).

The health endpoint becomes ready only when the shared MCP lifecycle and both listeners have started. Health does not prove that every saved Ansible controller/template is reachable. Check console registration status separately.

## 4. Open the registration console safely

On your trusted workstation, with authorized cluster access:

```bash
oc -n ca55-d port-forward deployment/mcp-ansible 8000:8000 --address=127.0.0.1
```

Keep that command running and open [http://127.0.0.1:8000/console](http://127.0.0.1:8000/console). Free local port 8000 first. Do not bind the forwarding process to all interfaces, expose this port through a Service/Route, or forward it from an untrusted shared workstation.

Select **Add Tool** and enter a unique tool name, the exact Ansible template API URL, a controller token, optional display title, optional JSON extra variables, and the temporary registration lifetime. Supported API URL examples are:

```text
https://controller.example.org/api/v2/job_templates/42/
https://controller.example.org/api/controller/v2/job_templates/42/
```

Registration reads metadata and saves the encrypted connection; it does not launch a playbook. Each tool can use its own controller/token. A subsequent MCP invocation can launch the job. Saved extra variables provide defaults, generic runtime extra variables override saved values, and named survey inputs take precedence. The controller must permit the requested variables.

The controller token entered here is **different from** `mcp-token`, which authenticates the AIOps-to-MCP connection. Neither is the Kubernetes service-account token; automatic service-account token mounting is disabled.

Temporary registrations expire by default after 24 hours. Expiry blocks new launches but does not revoke controller tokens or erase encrypted database rows. Restarting the pod reloads saved registrations from the PVC. Missing keys, unsupported storage, or invalid secrets fail closed rather than creating a fresh secret over existing data.

### Job dashboard

Keep the same port-forward running and open
[Jobs](http://127.0.0.1:8000/console#jobs). The dashboard is part of this separate
MCP Deployment; it requires no additional Service, Route, or AIOps UI patch.
It records calls made through the existing MCP tools (including AIOps calls)
and explicit launches from **Template tools → Run Tool**. It does not import
unrelated jobs from Ansible, and only records executions after this update.

1. Select **Run Tool**, inspect its schema, enter the complete JSON arguments,
   including required named survey fields and optional `extra_vars`, and confirm.
   Console launches run in the background. Existing MCP/AIOps calls still wait
   for their normal final result; their contract is unchanged.
2. In **Jobs**, filter by tool/status and select a record to see job IDs,
   timestamps, source, and best-effort redacted output. Large results are shown
   as bounded previews. The visible list refreshes local cached records every
   five seconds; **Refresh status** explicitly contacts the original controller.
3. Use **Cancel job** only when authorized, then confirm. Refresh to verify the
   controller's result; "Cancel requested" does not mean cancellation succeeded.

Console confirmation is a trusted local-operator control, not a substitute for
AIOps approval policies or controller permissions. The public 8443 listener
does not expose any dashboard endpoint, even with a valid MCP bearer token.

The same launch request ID cannot launch twice. After an ambiguous response,
the open browser can retry the same request; a page reload loses that browser
state. Inspect history and Ansible before making a new launch. **Unknown** means
the outcome is uncertain, not that no job ran. Restart recovery never relaunches
jobs. Shutdown/timeouts retain best-effort remote cancellation from the existing
executor; check Ansible before retrying a job interrupted by a rollout.

The existing PVC now holds both `/var/lib/mcp-ansible/config.sqlite3` and
`/var/lib/mcp-ansible/config.jobs.sqlite3`, using the original `credential.key`.
The registration database schema is unchanged. Back up both databases and the
matching key. Job result bodies/controller details are encrypted; basic history
metadata is not. Redaction cannot guarantee secret-free playbook output: retain
`no_log`, safe logging, and restricted operator access.

Keep one process/replica. The server permits eight concurrent executions and
up to 10,000 history records; reaching either limit blocks new launches. There
is no automatic history deletion or archival UI. Arrange approved maintenance
before the history limit, rather than deleting the PVC, database, or key.
Expired/changed registrations block controller refresh/cancel actions, while
cached history stays available. Source labels are not per-user audit identity.

For an existing MCP installation, back up its data/key and drain active work,
then run the same reviewed `preflight` and `deploy` steps using this updated
package. The deployment reuses the existing Secret/PVC. Do not recreate them.
This dashboard has been tested locally with mocks, not against a live Ansible
controller or OpenShift cluster.

## 5. AIOps connection handoff — no automatic AIOps changes

Configure an AIOps component that supports Streamable HTTP MCP with:

- URL: `https://mcp-ansible.ca55-d.svc:8443/mcp`.
- Header: `Authorization: Bearer <the mcp-token value>`.
- TLS trust: the service CA from `mcp-ansible-service-ca` key `service-ca.crt`, preserving any other trust roots that the connector needs.
- Pod labels: the permitted existing backend labels `app=aiops-governance` and `component=backend` in `ca55-d`.

Have the authorized platform owner deliver the bearer token through your approved secret-management workflow and make the public CA available to the connector. Do not print or paste the Secret into chat or Git, disable TLS validation, expose the encryption key to AIOps, or overwrite AIOps's existing global CA configuration.

This package intentionally does **not** modify an AIOps ConfigMap, Secret, workload, tool database, or UI. The address above is a connection handoff, not a claim that the existing AIOps application automatically supports MCP. Any connector/configuration change requires a separate reviewed change to that application. After that integration, refresh its MCP tool list to discover registered template names.

## Security, storage, and operations

The pod uses an arbitrary non-root OpenShift UID, no fixed `runAsUser`, no `anyuid` grant, dropped Linux capabilities, no privilege escalation, a runtime-default seccomp profile, and a read-only image filesystem. Only `/tmp` and the dedicated PVC are writable. S2I installs dependencies into its own virtual environment and makes image files readable/executable for runtime UIDs. The storage driver/SCC must still supply a usable writable PVC; this package does not grant broader permissions to work around admission failures. [OpenShift image guidance for arbitrary UIDs and S2I](https://docs.redhat.com/en/documentation/openshift_container_platform/4.18/html/images/creating-images).

Kubernetes projects the new application Secret read-only; the runtime copies only the encryption key into an owned `0700` temporary directory with a `0600` file and checks the matching key against existing ciphertext before startup. No key file is written into the PVC or image. The projected files are readable inside this single-purpose container to support arbitrary UIDs; protect access to the pod and its Secret through cluster RBAC.

Back up the SQLite data and matching `mcp-ansible-secrets` through approved, separate protected backup workflows. Quiesce the single writer before a filesystem-level database backup. A PVC alone cannot recover encrypted registrations without the original encryption key. Windows DPAPI databases are not portable to this workload; create new registrations here. Deleting either resource can cause data loss, and no cleanup command is included by default.

Plan explicit coordinated rollouts for serving-certificate, bearer-token, or encryption-key changes; do not assume running listeners reload projected files automatically. Do not rotate the encryption key without a supported re-encryption/migration procedure. A shared bearer token is not per-user authorization or a complete audit system, and this application is not certified for FIPS compliance.

If deployment fails, inspect the new MCP Build, pod events, PVC state, and safe logs. Common causes include an unavailable private builder/index, a blocked pinned artifact, CA trust, insufficient RBAC/quota, an unsuitable or unbound storage class, a pending service certificate, and existing network restrictions. Fix those specifically; do not relax TLS, security context, or policies globally or change the existing AIOps deployment as a workaround.
