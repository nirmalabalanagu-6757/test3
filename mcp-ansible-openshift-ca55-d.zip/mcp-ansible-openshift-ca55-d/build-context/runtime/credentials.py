"""Bridge projected OpenShift Secrets to the application's strict POSIX store."""

from __future__ import annotations

import base64
import hmac
import os
import re
import secrets
import sqlite3
import stat
from contextlib import closing
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

from ansible_mcp import posix_secrets
from ansible_mcp.storage import LocalStore, StorageError, _V1_TABLE_COLUMNS


DEFAULT_SECRET_DIRECTORY = Path("/var/run/mcp-ansible-secrets")
DEFAULT_KEY_PATH = Path("/tmp/mcp-ansible-credentials/credential.key")
DEFAULT_DATABASE_PATH = Path("/var/lib/mcp-ansible/config.sqlite3")


class BootstrapError(RuntimeError):
    """Safe startup error that never includes secret contents."""


def _secret_directory(value: Path | None = None) -> Path:
    return Path(value) if value is not None else Path(os.environ.get("MCP_SECRET_DIR", DEFAULT_SECRET_DIRECTORY))


def _read_projected_secret(directory: Path, name: str, *, maximum: int) -> bytes:
    """Allow Kubernetes' ..data links only within the mounted Secret directory."""
    try:
        root = directory.resolve(strict=True)
        selected = (directory / name).resolve(strict=True)
        if not selected.is_relative_to(root):
            raise BootstrapError("Projected Secret files must stay inside their mounted directory.")
        descriptor = os.open(selected, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
        try:
            details = os.fstat(descriptor)
            if not stat.S_ISREG(details.st_mode) or not 0 < details.st_size <= maximum:
                raise BootstrapError("The projected Secret contains an invalid file.")
            value = os.read(descriptor, maximum + 1)
            if not value or len(value) > maximum:
                raise BootstrapError("The projected Secret contains an invalid file.")
            return value
        finally:
            os.close(descriptor)
    except (OSError, ValueError):
        raise BootstrapError("Required projected Secret files are unavailable. Restore mcp-ansible-secrets before starting.") from None


def _validate_key(value: bytes) -> bytes:
    try:
        raw = base64.b64decode(value, altchars=b"-_", validate=True)
        if len(value) != 44 or len(raw) != 32 or base64.urlsafe_b64encode(raw) != value:
            raise ValueError
        Fernet(value)
        return value
    except (ValueError, TypeError):
        raise BootstrapError("The projected credential key is invalid. Restore the original Secret.") from None


def load_runtime_token(*, secret_dir: Path | None = None) -> str:
    value = _read_projected_secret(_secret_directory(secret_dir), "mcp-token", maximum=512)
    if not re.fullmatch(rb"[A-Za-z0-9_-]{43,512}", value):
        raise BootstrapError("The projected MCP access token is invalid. Restore a valid Secret.")
    return value.decode("ascii")


def _verify_existing_database(path: Path, key: bytes) -> None:
    """Authenticate every stored ciphertext, including expired registrations.

    This opens SQLite read-only and never migrates, decrypts to a response, or
    relies on active-profile/expiry rules that could skip older credentials.
    """
    try:
        if path.is_symlink():
            raise BootstrapError("The registration database must not be a symbolic link.")
        if not path.exists():
            return
        if not path.is_file():
            raise BootstrapError("The registration database is not a regular file.")
        cipher = Fernet(key)
        with closing(sqlite3.connect(path.absolute().as_uri() + "?mode=ro", uri=True, timeout=10)) as database:
            database.execute("PRAGMA query_only = ON")
            database.execute("PRAGMA trusted_schema = OFF")
            database.execute("BEGIN")
            version = database.execute("PRAGMA user_version").fetchone()[0]
            tables = list(database.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))
            if version == 0 and not tables:
                return
            if version not in {1, 2}:
                raise BootstrapError("The existing registration database has an unsupported schema.")
            LocalStore._check_schema(database, _V1_TABLE_COLUMNS if version == 1 else None)
            queries = ["SELECT credential FROM connections WHERE credential IS NOT NULL"]
            if version == 2:
                queries.append("SELECT extra_vars FROM templates WHERE extra_vars IS NOT NULL")
            for query in queries:
                for (value,) in database.execute(query):
                    if not isinstance(value, bytes) or not value.startswith(posix_secrets.PREFIX):
                        raise BootstrapError("The database uses a different credential format. Restore its original platform/key or register a new database.")
                    cipher.decrypt(value[len(posix_secrets.PREFIX):])
    except InvalidToken:
        raise BootstrapError("The projected key does not match existing encrypted registrations. Restore the original Secret; the database was not changed.") from None
    except (sqlite3.Error, StorageError, OSError, ValueError):
        raise BootstrapError("Could not safely verify the existing registration database. Preserve the database and restore its matching Secret.") from None


def _publish_private_key(path: Path, key: bytes) -> None:
    """Copy exactly the supplied key; never generate or replace key material."""
    try:
        posix_secrets._reject_symlinks(path)
        with posix_secrets._directory(path.parent, create=True) as directory:
            try:
                existing = posix_secrets._read_from_directory(directory, path.name)
            except FileNotFoundError:
                existing = None
            if existing is not None:
                if not hmac.compare_digest(existing, key):
                    raise BootstrapError("The private runtime key differs from the projected Secret. Restart with matching credentials; no key was replaced.")
                return
            temporary = f".projected-key-{secrets.token_hex(16)}.tmp"
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
            try:
                try:
                    os.fchmod(descriptor, 0o600)
                    offset = 0
                    while offset < len(key):
                        written = os.write(descriptor, key[offset:])
                        if written <= 0:
                            raise OSError("Key copy failed")
                        offset += written
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
                try:
                    os.link(temporary, path.name, src_dir_fd=directory, dst_dir_fd=directory, follow_symlinks=False)
                except FileExistsError:
                    pass
            finally:
                os.unlink(temporary, dir_fd=directory)
            os.fsync(directory)
            if not hmac.compare_digest(posix_secrets._read_from_directory(directory, path.name), key):
                raise BootstrapError("A different runtime key already exists. No existing key was replaced.")
    except (OSError, StorageError):
        raise BootstrapError("Could not create the private runtime key. Check the temporary directory ownership, permissions, and available space.") from None


def prepare_runtime_credentials(
    *, secret_dir: Path | None = None, key_path: Path | None = None,
    database_path: Path | None = None,
) -> None:
    source = _secret_directory(secret_dir)
    destination = Path(key_path if key_path is not None else os.environ.get("ANSIBLE_CREDENTIAL_KEY_FILE", DEFAULT_KEY_PATH)).absolute()
    database = Path(database_path if database_path is not None else os.environ.get("ANSIBLE_DB_PATH", DEFAULT_DATABASE_PATH)).absolute()
    key = _validate_key(_read_projected_secret(source, "credential.key", maximum=44))
    load_runtime_token(secret_dir=source)
    _verify_existing_database(database, key)
    _publish_private_key(destination, key)
    os.environ["ANSIBLE_CREDENTIAL_KEY_FILE"] = str(destination)
    os.environ["ANSIBLE_DB_PATH"] = str(database)
