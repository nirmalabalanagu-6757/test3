"""One MCP registry, a TLS machine endpoint, and a loopback-only admin console.

The shared MCP ASGI lifespan is entered exactly once by ``serve``. Both Uvicorn
listeners disable their own lifespan and signal handling. No public request is
ever dispatched to a console route, regardless of Host or forwarding headers.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import re
import secrets
import signal
import ssl
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncIterator, Iterator

import uvicorn
from fastmcp import FastMCP
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send


TLS_CERTIFICATE = Path("/var/run/mcp-ansible-tls/tls.crt")
TLS_PRIVATE_KEY = Path("/var/run/mcp-ansible-tls/tls.key")
TOKEN_PATTERN = re.compile(r"[A-Za-z0-9_-]{43,512}\Z", re.ASCII)
BEARER_PATTERN = re.compile(rb"(?i:Bearer) ([A-Za-z0-9_-]{43,512})\Z", re.ASCII)


@dataclass(slots=True)
class RuntimeState:
    lifespan_active: bool = False
    listeners_ready: bool = False

    @property
    def ready(self) -> bool:
        return self.lifespan_active and self.listeners_ready


async def _reject(scope: Scope, receive: Receive, send: Send, status: int) -> None:
    headers = {"Cache-Control": "no-store"}
    if status == 401:
        headers["WWW-Authenticate"] = 'Bearer realm="mcp-ansible"'
    await JSONResponse({"error": {401: "Unauthorized", 403: "Forbidden", 404: "Not found", 503: "Not ready"}[status]},
                       status_code=status, headers=headers)(scope, receive, send)


class PublicGateway:
    """Positive path allowlist and strict bearer authentication, outside routing."""

    def __init__(self, app: ASGIApp, token: str, state: RuntimeState):
        if not isinstance(token, str) or not TOKEN_PATTERN.fullmatch(token):
            raise ValueError("A valid URL-safe MCP token of 43-512 characters is required")
        self.app = app
        self._token = token.encode("ascii")
        self.state = state

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
            return
        if scope["type"] != "http":
            raise RuntimeError("The process manager must own the shared application lifespan")
        path = scope.get("path", "")
        if path == "/healthz" and scope["method"] in {"GET", "HEAD"}:
            ready = self.state.ready
            await JSONResponse({"status": "ok" if ready else "not-ready"},
                               status_code=200 if ready else 503,
                               headers={"Cache-Control": "no-store"})(scope, receive, send)
            return
        if path not in {"/mcp", "/mcp/"}:
            await _reject(scope, receive, send, 404)
            return
        # This endpoint is for machine MCP clients, not browser JavaScript.
        # Authentication is never inferred from cookies or proxy headers.
        headers = scope.get("headers", [])
        if any(name.lower() == b"origin" for name, _ in headers):
            await _reject(scope, receive, send, 403)
            return
        authorization = [value for name, value in headers if name.lower() == b"authorization"]
        candidate = BEARER_PATTERN.fullmatch(authorization[0]) if len(authorization) == 1 else None
        if candidate is None or not secrets.compare_digest(candidate[1], self._token):
            await _reject(scope, receive, send, 401)
            return
        if not self.state.ready:
            await _reject(scope, receive, send, 503)
            return
        if path == "/mcp/":
            scope = dict(scope, path="/mcp", raw_path=b"/mcp")
        await self.app(scope, receive, send)


class AdminGateway:
    """The admin listener exposes console routes only; their own guard stays on."""

    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
            return
        if scope["type"] != "http":
            raise RuntimeError("The process manager must own the shared application lifespan")
        path = scope.get("path", "")
        if path == "/console" or path.startswith("/console/"):
            await self.app(scope, receive, send)
            return
        await _reject(scope, receive, send, 404)


@dataclass(slots=True)
class RuntimeApps:
    shared: Any
    public: PublicGateway
    admin: AdminGateway
    state: RuntimeState

    @contextlib.asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        if self.state.lifespan_active:
            raise RuntimeError("The shared MCP lifespan is already active")
        async with self.shared.lifespan(self.shared):
            self.state.lifespan_active = True
            try:
                yield
            finally:
                self.state.listeners_ready = False
                self.state.lifespan_active = False


def build_apps(mcp: FastMCP, token: str) -> RuntimeApps:
    # HostOriginGuard's auto loopback detection conflicts with the shared app's
    # two addresses. The public gateway requires a non-cookie bearer and rejects
    # all browser Origins; the console retains its stricter local-only guard.
    shared = mcp.http_app(path="/mcp", json_response=True, stateless_http=False,
                          host_origin_protection=False, session_idle_timeout=300)
    state = RuntimeState()
    return RuntimeApps(shared, PublicGateway(shared, token, state), AdminGateway(shared), state)


def validate_tls_files(certificate: Path, private_key: Path) -> None:
    """Fail before opening listeners; never include key contents in an error."""
    try:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        # Reject encrypted keys without prompting on stdin during pod startup.
        context.load_cert_chain(str(certificate), str(private_key), password=lambda: "")
    except (OSError, ssl.SSLError, ValueError):
        raise RuntimeError("A readable, matching TLS certificate and unencrypted private key are required") from None


class ManagedServer(uvicorn.Server):
    async def serve(self, sockets=None) -> None:
        try:
            await super().serve(sockets=sockets)
        except SystemExit:
            # Uvicorn uses sys.exit for bind failures. Convert it so failure in
            # either listener can shut its sibling down under our coordinator.
            raise RuntimeError("The listener could not start") from None

    @contextlib.contextmanager
    def capture_signals(self) -> Iterator[None]:
        # A process-wide coordinator owns both listeners and restores signals.
        yield


@contextlib.contextmanager
def _stop_on_signals(stop: asyncio.Event) -> Iterator[None]:
    if threading.current_thread() is not threading.main_thread():
        yield
        return
    loop = asyncio.get_running_loop()
    previous = {}
    try:
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous[signum] = signal.signal(signum, lambda *_: loop.call_soon_threadsafe(stop.set))
        yield
    finally:
        for signum, handler in previous.items():
            signal.signal(signum, handler)


async def _wait_started(server: Any, task: asyncio.Task, stop: asyncio.Event,
                        timeout: float, peers: tuple[asyncio.Task, ...] = ()) -> bool:
    async with asyncio.timeout(timeout):
        while not server.started:
            if stop.is_set():
                return False
            failed = next((item for item in (task, *peers) if item.done()), None)
            if failed is not None:
                # Retrieve exceptions but do not expose arbitrary exception text.
                if not failed.cancelled():
                    failed.exception()
                raise RuntimeError("A listener failed before startup completed")
            await asyncio.sleep(0.02)
    return True


async def run_listeners(apps: RuntimeApps, public: Any, admin: Any, *,
                        stop: asyncio.Event | None = None, startup_timeout: float = 30,
                        shutdown_timeout: float = 25) -> None:
    """Start public first, mark ready after both start, and stop both together."""
    stop = stop or asyncio.Event()
    tasks: list[asyncio.Task] = []
    stop_task: asyncio.Task | None = None
    with _stop_on_signals(stop):
        try:
            public_task = asyncio.create_task(public.serve(), name="mcp-public-listener")
            tasks.append(public_task)
            if not await _wait_started(public, public_task, stop, startup_timeout):
                return
            admin_task = asyncio.create_task(admin.serve(), name="mcp-admin-listener")
            tasks.append(admin_task)
            if not await _wait_started(admin, admin_task, stop, startup_timeout, (public_task,)):
                return
            apps.state.listeners_ready = True
            stop_task = asyncio.create_task(stop.wait(), name="mcp-runtime-stop")
            await asyncio.wait([*tasks, stop_task], return_when=asyncio.FIRST_COMPLETED)
            if not stop.is_set():
                raise RuntimeError("An MCP listener stopped unexpectedly")
        finally:
            apps.state.listeners_ready = False
            public.should_exit = True
            admin.should_exit = True
            if stop_task is not None:
                stop_task.cancel()
            if tasks:
                _, pending = await asyncio.wait(tasks, timeout=shutdown_timeout)
                for task in pending:
                    task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
            if stop_task is not None:
                await asyncio.gather(stop_task, return_exceptions=True)


async def serve() -> None:
    from ansible_mcp.server import create_server
    from .credentials import load_runtime_token, prepare_runtime_credentials

    prepare_runtime_credentials()
    token = load_runtime_token()
    validate_tls_files(TLS_CERTIFICATE, TLS_PRIVATE_KEY)
    # This runtime always restores registration state and the admin console.
    os.environ["ANSIBLE_MODE"] = "auto"
    os.environ["MCP_PORT"] = "8000"
    mcp = await create_server(publish_demo_tools=False,
                              console_allowed_hosts={"localhost:8000", "127.0.0.1:8000"})
    apps = build_apps(mcp, token)
    common = dict(lifespan="off", proxy_headers=False, access_log=False,
                  server_header=False, ws="none", timeout_graceful_shutdown=20)
    public = ManagedServer(uvicorn.Config(apps.public, host="0.0.0.0", port=8443,
        ssl_certfile=str(TLS_CERTIFICATE), ssl_keyfile=str(TLS_PRIVATE_KEY), **common))
    admin = ManagedServer(uvicorn.Config(apps.admin, host="127.0.0.1", port=8000, **common))
    async with apps.lifespan():
        await run_listeners(apps, public, admin)


def main() -> None:
    try:
        asyncio.run(serve())
    except (OSError, ValueError, RuntimeError):
        # Startup failures are deliberately generic: no tokens, DB values, or
        # private-key diagnostics are printed by this process entrypoint.
        raise SystemExit("MCP cluster runtime failed. Check mounted secrets, TLS, storage permissions, and listener availability.") from None


if __name__ == "__main__":
    main()
