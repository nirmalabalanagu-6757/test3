"""Cluster-only runtime; the normal local MCP application remains unchanged."""
