"""Persistent, fail-closed tracking around the existing synchronous MCP tools."""
from __future__ import annotations

import asyncio
import hashlib
import json
from contextvars import ContextVar
from contextlib import asynccontextmanager
from copy import deepcopy
from dataclasses import dataclass, field, replace
from typing import Any, Awaitable, Callable, TYPE_CHECKING
from uuid import UUID

from .controller import ControllerClient, MockControllerClient, TERMINAL_STATES
from .execution import execute_template, redact
from .job_store import MAX_RESULT_BYTES
from .settings import Settings
from .storage import LocalStore, validate_extra_vars

if TYPE_CHECKING:
    from .job_store import JobStore


_allocated: ContextVar[tuple[object, str] | None] = ContextVar("allocated_console_job", default=None)
_REMOTE_STATES = TERMINAL_STATES | {"new", "pending", "waiting", "running"}


class JobError(RuntimeError):
    """Only fixed, credential-free messages may cross the console boundary."""

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


@dataclass(slots=True, repr=False)
class _Binding:
    controller: ControllerClient
    settings: Settings
    template: dict[str, Any]
    target: tuple = field(init=False)

    def __post_init__(self):
        self.target = self.current_target()

    def current_target(self) -> tuple:
        settings = self.settings
        return (
            settings.mode, settings.controller_url, settings.api_path, settings.connection_name,
            settings.controller_token, settings.verify_tls, int(self.template["id"]),
        )

    def assert_current(self) -> None:
        # Expiry may be updated after durable registration; the destination and
        # credential associated with an already-built controller may not change.
        if self.current_target() != self.target:
            raise JobError("The registered controller binding changed. Register the tool again before launching.", 409)


class JobManager:
    def __init__(
        self, store: JobStore, registration_store: LocalStore,
        controller_factory: Callable[[Settings], ControllerClient], base_settings: Settings,
        *, max_concurrent: int = 8,
        max_live_mock_jobs: int = 1000,
    ) -> None:
        self.store = store
        self.registration_store = registration_store
        self.controller_factory = controller_factory
        self.base_settings = base_settings
        self.max_concurrent = max_concurrent
        self.max_live_mock_jobs = max_live_mock_jobs
        self._bindings: dict[str, _Binding] = {}
        self._live: dict[str, _Binding] = {}
        self._tasks: dict[str, asyncio.Task] = {}
        self._active: set[str] = set()
        self._locks: dict[str, tuple[asyncio.Lock, int]] = {}
        self._closing = False
        # A launch may have reached Ansible before a process stopped. Never retry it.
        self.store.mark_interrupted()

    def has_binding(self, tool_name: str) -> bool:
        return tool_name in self._bindings

    def bind(self, tool_name: str, controller: ControllerClient, settings: Settings, template: dict[str, Any]) -> None:
        if self.has_binding(tool_name):
            raise JobError("That tool already has a job binding.", 409)
        self._bindings[tool_name] = _Binding(controller, settings, deepcopy(template))

    def unbind(self, tool_names) -> None:
        for name in tool_names:
            self._bindings.pop(name, None)

    def get(self, job_id: str, *, include_result: bool = True) -> dict[str, Any]:
        result = self.store.get(job_id, include_result=include_result)
        if result is None:
            raise JobError("Job not found.", 404)
        return result

    def list(self, **filters: Any) -> dict[str, Any]:
        return self.store.list(**filters)

    def _private(self, job_id: str) -> dict[str, Any]:
        record = self.store.private(job_id)
        if record is None:
            raise JobError("Job not found.", 404)
        return record

    def _capacity(self) -> None:
        if self._closing or len(self._active) >= self.max_concurrent:
            raise JobError("The job runner is busy. Try again after an existing job finishes.", 503)

    @asynccontextmanager
    async def _job_lock(self, job_id: str):
        # Validate existence before allocating any synchronization state, including
        # for repeated invalid IDs. Count waiters so a lock is never replaced early.
        self._private(job_id)
        lock, users = self._locks.get(job_id, (asyncio.Lock(), 0))
        self._locks[job_id] = (lock, users + 1)
        try:
            async with lock:
                yield
        finally:
            _, users = self._locks[job_id]
            if users == 1:
                del self._locks[job_id]
            else:
                self._locks[job_id] = (lock, users - 1)

    def _retain_mock(self, job_id: str, binding: _Binding) -> None:
        if binding.settings.mode == "mock":
            self._live[job_id] = binding
        self._trim_mock_history()

    def _trim_mock_history(self) -> None:
        for job_id in list(self._live):
            if len(self._live) <= self.max_live_mock_jobs:
                break
            if job_id in self._active:
                continue
            binding = self._live.pop(job_id)
            record = self.store.get(job_id)
            # The development controller retains synthetic inputs in memory.
            # Drop those together with evicted history handles, never real jobs.
            if record and isinstance(binding.controller, MockControllerClient):
                binding.controller.jobs.pop(record.get("remote_job_id"), None)

    @staticmethod
    def _dashboard_result(result: dict[str, Any]) -> dict[str, Any]:
        """Bound only the journal preview. The caller retains its full MCP result.

        This receives an already-redacted result: cutting first could retain a
        secret prefix that no longer matches the complete known secret value.
        """
        encoded = json.dumps(result, ensure_ascii=False, allow_nan=False).encode("utf-8")
        if len(encoded) <= MAX_RESULT_BYTES:
            return result
        preview = {key: value for key, value in result.items() if key != "output"}
        output = result.get("output")
        content = output.get("content") if isinstance(output, dict) else None
        if not isinstance(content, str):
            content = json.dumps(output, ensure_ascii=False, allow_nan=False)
        # JSON quoting can expand control characters sixfold. Encode a candidate
        # preview and shrink it until the complete UTF-8 JSON fits the store cap.
        content = content[:MAX_RESULT_BYTES]
        while True:
            preview["output"] = {"content": content, "truncated": True}
            size = len(json.dumps(preview, ensure_ascii=False, allow_nan=False).encode("utf-8"))
            if size <= MAX_RESULT_BYTES:
                return preview
            content = content[:max(0, len(content) - max(1024, (size - MAX_RESULT_BYTES) // 2))]
            if not content:
                preview["output"] = {"content": "Output exceeds the dashboard preview limit.", "truncated": True}
                return preview

    @staticmethod
    def _same_endpoint(record: dict[str, Any], settings: Settings) -> bool:
        return (
            record["mode"] == settings.mode
            and (record.get("controller_url") or "").rstrip("/") == (settings.controller_url or "").rstrip("/")
            and record["api_path"] == settings.api_path
        )

    def _current_settings(self, record: dict[str, Any]) -> Settings:
        try:
            if record.get("connection_name"):
                saved = self.registration_store.load_connection(record["connection_name"])
                if saved is None:
                    raise ValueError
                settings = replace(
                    self.base_settings, mode=saved.mode, controller_url=saved.base_url,
                    controller_token=saved.token, api_path=saved.api_path, verify_tls=saved.verify_tls,
                    connection_name=saved.name, expires_at=saved.expires_at,
                    allowed_template_ids={item["id"] for item in saved.templates},
                    tool_name_by_template_id={item["id"]: item["tool_name"] for item in saved.templates if item.get("tool_name")},
                    extra_vars_by_template_id={},
                )
            else:
                settings = self.base_settings
            settings.assert_not_expired()
            if not self._same_endpoint(record, settings) or not settings.permits(record["template_id"]):
                raise ValueError
            configured_name = settings.tool_name_by_template_id.get(record["template_id"])
            if configured_name is not None and configured_name != record["tool_name"]:
                raise ValueError
            return settings
        except Exception:
            raise JobError("The original job registration is unavailable, changed, or expired. Restore it before refreshing or canceling.", 409) from None

    def _create(self, name: str, binding: _Binding, *, source: str, request_id=None, fingerprint=None):
        binding.assert_current()
        settings, template = binding.settings, binding.template
        record = {
            "tool_name": name, "title": str(template.get("name", name)),
            "template_id": int(template["id"]), "mode": settings.mode,
            "connection_name": settings.connection_name, "controller_url": settings.controller_url,
            "api_path": settings.api_path,
        }
        settings.assert_not_expired()
        self._current_settings(record)
        return self.store.create(
            **record, source=source, secrets=[settings.controller_token] if settings.controller_token else [],
            request_id=request_id, request_fingerprint=fingerprint,
        )

    async def start(
        self, tool_name: str, args: dict[str, Any], request_id: str,
        invoke_async: Callable[[str, dict[str, Any]], Awaitable[Any]],
    ) -> dict[str, Any]:
        try:
            request_id = str(UUID(request_id))
            arguments = validate_extra_vars(args)
            fingerprint = hashlib.sha256(json.dumps(
                [tool_name, arguments], sort_keys=True, separators=(",", ":"), allow_nan=False,
            ).encode()).hexdigest()
        except Exception:
            raise JobError("Provide a valid request identifier and JSON tool arguments.") from None
        previous = self.store.lookup_request(request_id)
        if previous is not None:
            private = self._private(previous["id"])
            if private.get("request_fingerprint") != fingerprint:
                raise JobError("That request identifier was already used for different arguments.", 409)
            return previous
        binding = self._bindings.get(tool_name)
        if binding is None:
            raise JobError("That registered tool is unavailable.", 404)
        self._capacity()
        record = self._create(tool_name, binding, source="console", request_id=request_id, fingerprint=fingerprint)
        job_id = record["id"]
        self._active.add(job_id)
        self._retain_mock(job_id, binding)

        async def run() -> None:
            token = _allocated.set((self, job_id))
            try:
                await invoke_async(tool_name, arguments)
                # Validation/framework failures can occur without entering execute().
                current = self._private(job_id)
                if current["status"] == "queued":
                    self.store.update(job_id, status="error", error="Tool validation failed; no job was launched.")
            except asyncio.CancelledError:
                if self._private(job_id)["status"] not in TERMINAL_STATES:
                    self.store.update(job_id, status="unknown", error="The local runner stopped. Refresh to check Ansible; this job will not be relaunched.")
            except Exception:
                self._record_failure(job_id)
            finally:
                _allocated.reset(token)
                self._active.discard(job_id)
                self._tasks.pop(job_id, None)
                self._trim_mock_history()

        self._tasks[job_id] = asyncio.create_task(run(), name=f"ansible-job-{job_id}")
        return record

    def _record_failure(self, job_id: str) -> None:
        record = self._private(job_id)
        if record["status"] in TERMINAL_STATES:
            return
        if record["status"] == "cancel_requested":
            message = "Cancellation was requested. Refresh to confirm Ansible's final status."
            state = "cancel_requested"
        elif record.get("remote_job_id") or record["status"] in {"launching", "unknown"}:
            message = "The job outcome is unknown. Refresh if a job ID is available; do not retry a launch without checking Ansible."
            state = "unknown"
        else:
            message, state = "Tool validation failed; no job was launched.", "error"
        self.store.update(job_id, status=state, error=message)

    def _status(
        self, job_id: str, status: Any, started: Any = None, finished: Any = None,
        *, remote_job_id: Any = None, template_id: Any = None,
    ) -> None:
        if not isinstance(status, str) or status not in _REMOTE_STATES:
            raise JobError("Ansible returned an invalid job status.", 502)
        current = self._private(job_id)
        if (
            type(remote_job_id) is not int or remote_job_id != current.get("remote_job_id")
            or type(template_id) is not int or template_id != current["template_id"]
        ):
            raise JobError("Ansible returned a different job or template. The response was not accepted.", 502)
        if current["status"] in TERMINAL_STATES and status not in TERMINAL_STATES:
            return
        if current["status"] == "cancel_requested" and status not in TERMINAL_STATES:
            status = "cancel_requested"
        # Only timestamps/status, never the raw status response (which may include extra_vars).
        self.store.update(job_id, status=status, started=started, finished=finished, error=None)

    async def execute(
        self, controller: ControllerClient, settings: Settings, template: dict[str, Any], inputs: dict[str, Any],
        *, survey_questions=None, runtime_extra_vars=None, tool_name: str,
    ) -> dict[str, Any]:
        allocated = _allocated.get()
        own_slot = allocated is None or allocated[0] is not self
        binding = _Binding(controller, settings, template)
        registered = self._bindings.get(tool_name)
        if registered is not None:
            registered.assert_current()
            if registered.target != binding.target or registered.controller is not controller:
                raise JobError("The tool controller no longer matches its registered binding.", 409)
        if own_slot:
            self._capacity()
            record = self._create(tool_name, binding, source="mcp")
            job_id = record["id"]
            self._active.add(job_id)
        else:
            job_id = allocated[1]
            record = self._private(job_id)
            if record["tool_name"] != tool_name or record["status"] != "queued":
                raise JobError("The allocated job does not match this tool.", 409)
        self._retain_mock(job_id, binding)

        async def observe(event: str, payload: dict[str, Any]) -> None:
            if event == "before_launch":
                self._current_settings(self._private(job_id))
                self.store.add_secrets(job_id, sorted(payload["secrets"]))
                self.store.update(job_id, status="launching")
            elif event == "launched":
                self.store.update(job_id, remote_job_id=payload["remote_job_id"], status="pending")
            elif event == "status":
                self._status(job_id, **payload)
            elif event == "result":
                self.store.save_result(job_id, self._dashboard_result(payload["result"]))
            elif event == "cancel_requested":
                if self._private(job_id)["status"] not in TERMINAL_STATES:
                    self.store.update(job_id, status="cancel_requested")

        try:
            return await execute_template(
                controller, settings, template, inputs, survey_questions=survey_questions,
                runtime_extra_vars=runtime_extra_vars, job_observer=observe,
            )
        except asyncio.CancelledError:
            self._record_failure(job_id)
            raise
        except Exception:
            self._record_failure(job_id)
            raise JobError("Ansible job execution could not be completed. Check its recorded status before retrying.", 502) from None
        finally:
            if own_slot:
                self._active.discard(job_id)
                self._trim_mock_history()

    def _remote_binding(self, record: dict[str, Any]) -> tuple[ControllerClient, Settings, bool]:
        settings = self._current_settings(record)
        if not record.get("remote_job_id"):
            raise JobError("No confirmed Ansible job ID is available. Check Ansible before launching again.", 409)
        if settings.mode == "mock":
            live = self._live.get(record["id"])
            if live is None:
                raise JobError("This mock job is no longer retained after a server restart or history eviction.", 409)
            return live.controller, settings, False
        try:
            return self.controller_factory(settings), settings, True
        except Exception:
            raise JobError("The original job controller is unavailable.", 502) from None

    async def refresh(self, job_id: str) -> dict[str, Any]:
        async with self._job_lock(job_id):
            record = self._private(job_id)
            controller, settings, close = self._remote_binding(record)
            try:
                self.store.add_secrets(job_id, [settings.controller_token] if settings.controller_token else [])
                async with asyncio.timeout(min(settings.timeout_seconds, 15)):
                    status = await controller.get_job_status(record["remote_job_id"])
                    self._status(
                        job_id, status.get("status"), status.get("started"), status.get("finished"),
                        remote_job_id=status.get("id"), template_id=status.get("job_template", status.get("template_id")),
                    )
                    if status.get("status") in TERMINAL_STATES:
                        output = await controller.get_job_output(record["remote_job_id"])
                        result = {
                            "template_id": record["template_id"], "template": record["title"],
                            "job_id": record["remote_job_id"], "status": status["status"],
                            "started": status.get("started"), "finished": status.get("finished"), "output": output,
                        }
                        cleaned = redact(result, secret_values=set(self._private(job_id).get("secrets") or []))
                        self.store.save_result(job_id, self._dashboard_result(cleaned))
                return self.get(job_id)
            except JobError:
                raise
            except Exception:
                raise JobError("Could not refresh this Ansible job. Its cached status is unchanged unless a confirmed status was received.", 502) from None
            finally:
                if close:
                    await controller.close()

    async def cancel(self, job_id: str) -> dict[str, Any]:
        async with self._job_lock(job_id):
            record = self._private(job_id)
            if record["status"] in TERMINAL_STATES or record["status"] == "cancel_requested":
                return self.get(job_id)
            controller, settings, close = self._remote_binding(record)
            try:
                async with asyncio.timeout(min(settings.timeout_seconds, 15)):
                    status = await controller.get_job_status(record["remote_job_id"])
                    self._status(
                        job_id, status.get("status"), status.get("started"), status.get("finished"),
                        remote_job_id=status.get("id"), template_id=status.get("job_template", status.get("template_id")),
                    )
                    if status.get("status") in TERMINAL_STATES:
                        return self.get(job_id)
                    # Persist before the network mutation. A timeout may mean the
                    # controller accepted it; another request must not retry it.
                    self.store.update(job_id, status="cancel_requested", error=None)
                    await controller.cancel_job(record["remote_job_id"])
                if self._private(job_id)["status"] not in TERMINAL_STATES:
                    self.store.update(job_id, status="cancel_requested", error=None)
                return self.get(job_id)
            except Exception:
                if self._private(job_id)["status"] == "cancel_requested":
                    self.store.update(job_id, error="The cancellation request outcome is uncertain. Refresh to confirm Ansible's status.")
                raise JobError("Cancellation could not be confirmed. Refresh this job before trying again.", 502) from None
            finally:
                if close:
                    await controller.close()

    async def shutdown(self) -> None:
        self._closing = True
        tasks = list(self._tasks.values())
        for task in tasks:
            task.cancel()
        if tasks:
            done, pending = await asyncio.wait(tasks, timeout=5)
            for task in pending:
                task.cancel()
            for task in done:
                if not task.cancelled():
                    task.exception()
        for job_id in list(self._active):
            try:
                if self._private(job_id)["status"] not in TERMINAL_STATES:
                    self.store.update(job_id, status="unknown", error="The local runner stopped. Refresh to check Ansible; this job will not be relaunched.")
            except Exception:
                pass
