"use strict";

// All history reads use local cached records. Only explicit actions POST.
(() => {
  const element = id => document.getElementById(id);
  const activeStatuses = new Set(["queued", "launching", "new", "pending", "waiting", "running", "cancel_requested"]);
  const attentionStatuses = new Set(["failed", "error", "unknown"]);
  const knownStatuses = new Set([...activeStatuses, ...attentionStatuses, "successful", "canceled"]);
  const limit = 25;
  let offset = 0;
  let count = 0;
  let rows = [];
  let selected = null;
  let listLoading = false;
  let listVersion = 0;
  let detailVersion = 0;
  let actionBusy = false;
  let timer = null;
  let launchTool = null;
  let launchReady = false;
  let launchBusy = false;
  let launchVersion = 0;
  let requestId = "";
  let launchPayload = null;
  const unresolvedLaunches = new Map();
  const toolNames = new Set();

  function jobsVisible() {
    return window.location.hash === "#jobs" && !document.hidden;
  }

  function dateText(value) {
    if (!value) return "—";
    const date = new Date(value);
    return Number.isNaN(date.valueOf()) ? "—" : date.toLocaleString();
  }

  function statusText(status) {
    return knownStatuses.has(status) ? status.replaceAll("_", " ") : "unknown";
  }

  function statusBadge(status) {
    const safeStatus = knownStatuses.has(status) ? status : "unknown";
    return node("span", `status-badge status-${safeStatus}`, statusText(safeStatus));
  }

  function uuid() {
    if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 15) | 64;
    bytes[8] = (bytes[8] & 63) | 128;
    const hex = Array.from(bytes, value => value.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }

  async function api(path, body) {
    const options = {credentials: "same-origin", cache: "no-store"};
    if (body !== undefined) {
      if (!csrfToken) throw new Error("The console is not connected. Refresh the tool list before trying again.");
      options.method = "POST";
      options.headers = {"Content-Type": "application/json", "X-CSRF-Token": csrfToken};
      options.body = JSON.stringify(body);
    }
    let response;
    try {
      response = await fetch(path, options);
    } catch {
      throw new Error("Could not reach the local MCP server.");
    }
    let data;
    try { data = await response.json(); }
    catch { throw new Error("The local MCP server returned an unreadable response."); }
    if (!response.ok) {
      const error = new Error(typeof data.error === "string" ? data.error.slice(0, 500) : "The request could not be completed.");
      error.status = response.status;
      throw error;
    }
    return data;
  }

  function setTools(tools) {
    for (const tool of tools) toolNames.add(tool.name);
    updateToolFilter();
  }

  function updateToolFilter() {
    const filter = element("job-tool-filter");
    const value = filter.value;
    if (value) toolNames.add(value);
    filter.replaceChildren(node("option", "", "All tools"));
    filter.firstChild.value = "";
    for (const name of [...toolNames].sort()) {
      const option = node("option", "", name);
      option.value = name;
      filter.append(option);
    }
    filter.value = value;
  }

  function renderRows() {
    const body = element("jobs-rows");
    body.replaceChildren();
    element("jobs-total").textContent = String(count);
    element("jobs-active").textContent = String(rows.filter(job => activeStatuses.has(job.status)).length);
    element("jobs-attention").textContent = String(rows.filter(job => attentionStatuses.has(job.status)).length);
    for (const job of rows) {
      toolNames.add(job.tool_name);
      const row = node("tr", selected?.id === job.id ? "selected" : "", "");
      const toolCell = node("td", "", "");
      const button = node("button", "job-select", job.title || job.tool_name);
      button.type = "button";
      button.setAttribute("aria-label", `View job ${job.remote_job_id ?? job.id} for ${job.tool_name}`);
      button.addEventListener("click", () => selectJob(job.id));
      toolCell.append(button, node("code", "job-local-id", job.tool_name));
      const idCell = node("td", "", job.remote_job_id == null ? "Not assigned" : String(job.remote_job_id));
      idCell.append(node("code", "job-local-id", `Local ${String(job.id).slice(0, 10)}…`));
      const statusCell = node("td", "", "");
      statusCell.append(statusBadge(job.status));
      row.append(toolCell, idCell, statusCell, node("td", "", job.source === "mcp" ? "MCP" : "Console"), node("td", "", dateText(job.created_at)));
      body.append(row);
    }
    if (!rows.length) {
      const row = node("tr", "", "");
      const cell = node("td", "empty", "No jobs match these filters. Launch a registered tool to start tracking jobs.");
      cell.colSpan = 5;
      row.append(cell);
      body.append(row);
    }
    updateToolFilter();
    element("jobs-page").textContent = count ? `${offset + 1}–${Math.min(offset + rows.length, count)} of ${count}` : "No jobs";
    element("jobs-prev").disabled = offset === 0 || listLoading;
    element("jobs-next").disabled = offset + limit >= count || listLoading;
  }

  async function loadJobs(force = false) {
    if (listLoading && !force) return;
    const version = ++listVersion;
    listLoading = true;
    element("refresh-jobs").disabled = true;
    const query = new URLSearchParams({limit: String(limit), offset: String(offset)});
    if (element("job-status-filter").value) query.set("status", element("job-status-filter").value);
    if (element("job-tool-filter").value) query.set("tool_name", element("job-tool-filter").value);
    try {
      const data = await api(`/console/api/jobs?${query}`);
      if (version !== listVersion) return;
      rows = data.jobs;
      count = data.count;
      if (offset > 0 && offset >= count) {
        offset = Math.max(0, Math.ceil(count / limit) - 1) * limit;
        return await loadJobs(true);
      }
      message("jobs-message", "");
      const updated = selected && rows.find(job => job.id === selected.id);
      if (jobsVisible() && !actionBusy && selected && (
        activeStatuses.has(selected.status) || selected.status === "unknown" ||
        (updated && (updated.updated_at !== selected.updated_at || updated.status !== selected.status || updated.result_available !== selected.result_available))
      )) {
        // GET details also reads the local record; it does not query Ansible.
        void selectJob(selected.id, false);
      }
    } catch (error) {
      if (version === listVersion) message("jobs-message", error.message, true);
    } finally {
      if (version === listVersion) {
        listLoading = false;
        element("refresh-jobs").disabled = false;
        renderRows();
      }
    }
  }

  function renderDetails() {
    if (!selected) return;
    element("job-details").hidden = false;
    element("job-detail-heading").textContent = selected.title || selected.tool_name;
    const metadata = element("job-metadata");
    metadata.replaceChildren();
    const fields = [
      ["Tool", selected.tool_name], ["Status", statusText(selected.status)],
      ["Controller job ID", selected.remote_job_id ?? "Not assigned"], ["Local job ID", selected.id],
      ["Template ID", selected.template_id], ["Source", selected.source === "mcp" ? "MCP" : "Console"],
      ["Mode", selected.mode === "mock" ? "Local demo" : "Ansible controller"], ["Created", dateText(selected.created_at)],
      ["Updated", dateText(selected.updated_at)], ["Started", dateText(selected.started)], ["Finished", dateText(selected.finished)],
    ];
    for (const [label, value] of fields) {
      const field = node("div", "", "");
      field.append(node("dt", "", label), node("dd", "", value == null ? "—" : String(value)));
      metadata.append(field);
    }
    let warning = selected.error || "";
    if (selected.status === "unknown") {
      warning = "The launch or job outcome is unknown. Check Ansible Controller before starting another run; retrying as a new job could run the playbook twice." + (warning ? ` ${warning}` : "");
    } else if (selected.status === "cancel_requested") {
      warning = "Cancellation was requested. It is not confirmed until the controller reports a final status.";
    }
    message("job-warning", warning);
    let output = selected.result == null ? "No output available yet. The background runner updates local records; Refresh status explicitly checks the controller." : typeof selected.result === "string" ? selected.result : JSON.stringify(selected.result, null, 2);
    if (output.length > 200000) output = output.slice(0, 200000) + "\n\n[Display limited to 200,000 characters.]";
    element("job-output").textContent = output;
    element("job-refresh").disabled = actionBusy || selected.remote_job_id == null;
    element("job-cancel").disabled = actionBusy || !activeStatuses.has(selected.status) || selected.status === "cancel_requested";
    renderRows();
  }

  async function selectJob(id, focus = true) {
    const version = ++detailVersion;
    try {
      const data = await api(`/console/api/jobs/${encodeURIComponent(id)}`);
      if (version !== detailVersion) return;
      selected = data.job;
      if (focus) message("job-action-message", "");
      renderDetails();
      if (focus) element("job-details").scrollIntoView({behavior: "smooth", block: "nearest"});
    } catch (error) {
      if (version === detailVersion) message("jobs-message", error.message, true);
    }
  }

  async function jobAction(action) {
    if (!selected || actionBusy) return;
    const id = selected.id;
    if (action === "cancel" && !window.confirm(`Request cancellation of ${selected.tool_name}, job ${selected.remote_job_id ?? id}? Ansible may already have changed its targets. Cancellation does not undo those changes.`)) return;
    actionBusy = true;
    ++detailVersion;
    renderDetails();
    message("job-action-message", "");
    try {
      const data = await api(`/console/api/jobs/${encodeURIComponent(id)}/${action}`, {});
      if (selected?.id === id) {
        ++detailVersion;
        selected = data.job;
        message("job-action-message", action === "cancel" ? "Cancellation request sent. Check the reported status; this does not undo completed tasks." : "Job status refreshed.");
      }
      await loadJobs(true);
      if (selected?.id === id) await selectJob(id, false);
    } catch (error) {
      if (selected?.id === id) message("job-action-message", error.message, true);
    } finally {
      actionBusy = false;
      renderDetails();
    }
  }

  function updatePolling() {
    if (timer) clearInterval(timer);
    timer = null;
    if (jobsVisible()) timer = setInterval(() => { if (jobsVisible()) void loadJobs(); }, 5000);
  }

  function updateView() {
    const jobs = window.location.hash === "#jobs";
    element("tools-view").hidden = jobs;
    element("jobs-view").hidden = !jobs;
    element("current-view").textContent = jobs ? "Jobs" : "Template tools";
    for (const [id, active] of [["tools-nav", !jobs], ["jobs-nav", jobs], ["tools-tab", !jobs], ["jobs-tab", jobs]]) {
      element(id).classList.toggle("active", active);
      if (active) element(id).setAttribute("aria-current", "page");
      else element(id).removeAttribute("aria-current");
    }
    updatePolling();
    if (jobsVisible()) void loadJobs(true);
  }

  function launchState() {
    element("submit-launch").disabled = launchBusy || !launchReady;
    element("submit-launch").textContent = launchBusy ? "Submitting…" : launchPayload ? "Retry same request" : "Launch job";
    element("launch-arguments").readOnly = launchBusy || Boolean(launchPayload);
    element("close-launch").disabled = launchBusy;
    element("cancel-launch").disabled = launchBusy;
  }

  async function openLaunch(tool) {
    if (!tool.registered || launchBusy) return;
    launchTool = tool;
    launchReady = false;
    const version = ++launchVersion;
    const pending = unresolvedLaunches.get(tool.name);
    requestId = pending?.request_id || uuid();
    launchPayload = pending || null;
    element("launch-title").textContent = `Run ${tool.title || tool.name}`;
    element("launch-tool-name").textContent = tool.name;
    element("launch-arguments").value = JSON.stringify(pending?.arguments || {}, null, 2);
    element("launch-confirm").checked = false;
    element("launch-schema").textContent = "Loading schema…";
    message("launch-message", pending ? "An earlier submission was not confirmed. Check Jobs and the controller before starting a new run. Retrying here reuses exactly the same request ID and arguments." : "", Boolean(pending));
    element("launch-dialog").showModal();
    launchState();
    try {
      const data = await api(`/console/api/tools/${encodeURIComponent(tool.name)}/schema`);
      if (version !== launchVersion || !element("launch-dialog").open) return;
      element("launch-schema").textContent = JSON.stringify(data.input_schema, null, 2);
      const required = Array.isArray(data.input_schema?.required) ? data.input_schema.required : [];
      element("launch-arguments-help").textContent = required.length ? `Required inputs: ${required.join(", ")}. Use the types shown in the schema. Saved defaults need not be re-entered.` : "Use the field names and types in the schema. Saved defaults need not be re-entered. An empty object is valid only when the tool has no required inputs.";
      launchReady = true;
    } catch (error) {
      if (version === launchVersion) message("launch-message", error.message, true);
    } finally {
      if (version === launchVersion) launchState();
    }
  }

  function closeLaunch() {
    if (launchBusy) return;
    ++launchVersion;
    element("launch-dialog").close();
    element("launch-arguments").value = "{}";
    element("launch-confirm").checked = false;
    launchTool = null;
    launchReady = false;
  }

  async function submitLaunch(event) {
    event.preventDefault();
    if (launchBusy || !launchReady || !launchTool || !element("launch-form").reportValidity()) return;
    if (!csrfToken) {
      message("launch-message", "The console is not connected. Refresh the tool list before trying again.", true);
      return;
    }
    if (!launchPayload) {
      try {
        const args = JSON.parse(element("launch-arguments").value, (_key, value) => {
          if (typeof value === "number" && !Number.isFinite(value)) throw new Error("Invalid number");
          return value;
        });
        if (args === null || Array.isArray(args) || typeof args !== "object") throw new Error("Object required");
        const payload = {tool_name: launchTool.name, arguments: args, request_id: requestId};
        if (new TextEncoder().encode(JSON.stringify(payload)).length > 32768) throw new Error("Too large");
        launchPayload = payload;
      } catch {
        message("launch-message", "Arguments must be a valid JSON object with finite values. The complete request must be at most 32 KB.", true);
        element("launch-arguments").focus();
        return;
      }
    }
    launchBusy = true;
    const toolName = launchTool.name;
    unresolvedLaunches.set(toolName, launchPayload);
    launchState();
    message("launch-message", "");
    try {
      const data = await api("/console/api/jobs", launchPayload);
      if (!data.job?.id) throw new Error("The server did not confirm a job record.");
      unresolvedLaunches.delete(toolName);
      launchBusy = false;
      closeLaunch();
      offset = 0;
      element("job-status-filter").value = "";
      element("job-tool-filter").value = "";
      window.location.hash = "jobs";
      updateView();
      await selectJob(data.job.id);
    } catch (error) {
      // A definite client error did not accept this request. Network/server
      // failures retain the exact payload and UUID, including after reopening.
      if (error.status >= 400 && error.status < 500 && error.status !== 409) {
        unresolvedLaunches.delete(toolName);
        launchPayload = null;
      }
      const advice = launchPayload ? " The outcome is not confirmed. Check Jobs before starting another run. Retry here to reuse the same request ID and arguments." : " Check the input schema and try again.";
      message("launch-message", error.message + advice, true);
    } finally {
      launchBusy = false;
      launchState();
    }
  }

  element("refresh-jobs").addEventListener("click", () => loadJobs(true));
  for (const id of ["job-status-filter", "job-tool-filter"]) {
    element(id).addEventListener("change", () => { offset = 0; void loadJobs(true); });
  }
  element("jobs-prev").addEventListener("click", () => { if (offset > 0) { offset = Math.max(0, offset - limit); void loadJobs(true); } });
  element("jobs-next").addEventListener("click", () => { if (offset + limit < count) { offset += limit; void loadJobs(true); } });
  element("job-refresh").addEventListener("click", () => jobAction("refresh"));
  element("job-cancel").addEventListener("click", () => jobAction("cancel"));
  element("close-job-details").addEventListener("click", () => { selected = null; ++detailVersion; element("job-details").hidden = true; renderRows(); });
  element("close-launch").addEventListener("click", closeLaunch);
  element("cancel-launch").addEventListener("click", closeLaunch);
  element("launch-dialog").addEventListener("cancel", event => { event.preventDefault(); closeLaunch(); });
  element("launch-form").addEventListener("submit", submitLaunch);
  window.addEventListener("hashchange", updateView);
  document.addEventListener("visibilitychange", () => { updatePolling(); if (jobsVisible()) void loadJobs(true); });
  window.MCPJobs = {openLaunch, setTools};
  setTools(registeredTools);
  updateView();
})();
