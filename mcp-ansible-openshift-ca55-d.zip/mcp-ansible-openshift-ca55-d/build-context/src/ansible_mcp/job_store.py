"""Separate durable job journal with encrypted private metadata and results.

The registration database is never opened by this module. Callers provide its
existing credential protector, not a token or a newly generated encryption key.
"""
from __future__ import annotations

import json
import math
import os
import re
import sqlite3
import stat
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterator

from .storage import CredentialProtector, StorageError, validate_api_path, validate_controller_url


class JobStoreError(StorageError):
    """Safe-to-display job validation/storage failure without private values."""


STATUSES = frozenset({
    "queued", "launching", "new", "pending", "waiting", "running", "cancel_requested",
    "successful", "failed", "error", "canceled", "unknown",
})
TERMINAL_STATUSES = frozenset({"successful", "failed", "error", "canceled"})
MAX_RESULT_BYTES = 256 * 1024
MAX_PRIVATE_BYTES = 384 * 1024
MAX_JOBS = 10_000
_PUBLIC_FIELDS = (
    "id", "tool_name", "title", "template_id", "mode", "source", "remote_job_id", "status",
    "created_at", "updated_at", "started", "finished", "error", "result_available",
)
_COLUMNS = {
    "id": ("TEXT", 0, 1), "tool_name": ("TEXT", 1, 0), "title": ("TEXT", 1, 0),
    "template_id": ("INTEGER", 1, 0), "mode": ("TEXT", 1, 0), "source": ("TEXT", 1, 0),
    "remote_job_id": ("INTEGER", 0, 0), "status": ("TEXT", 1, 0),
    "created_at": ("TEXT", 1, 0), "updated_at": ("TEXT", 1, 0),
    "started": ("TEXT", 0, 0), "finished": ("TEXT", 0, 0), "error": ("TEXT", 0, 0),
    "result_available": ("INTEGER", 1, 0), "request_id": ("TEXT", 0, 0),
    "private_payload": ("BLOB", 1, 0),
}


def _text(value: Any, maximum: int, *, optional: bool = False) -> str | None:
    if value is None and optional:
        return None
    if type(value) is not str or not 1 <= len(value) <= maximum or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise JobStoreError("Job text must be bounded printable text.")
    return value


def _tool_name(value: Any) -> str:
    if type(value) is not str or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", value):
        raise JobStoreError("The job tool name is invalid.")
    return value


def _job_id(value: Any) -> str:
    if type(value) is not str or not re.fullmatch(r"[0-9a-f]{32}", value):
        raise JobStoreError("The job identifier is invalid.")
    return value


def _request_id(value: Any) -> str | None:
    if value is None:
        return None
    try:
        if type(value) is not str or not re.fullmatch(r"[A-Fa-f0-9-]{32,36}", value):
            raise ValueError
        return uuid.UUID(value).hex
    except ValueError:
        raise JobStoreError("The job request identifier must be a UUID.") from None


def _positive_id(value: Any, *, optional: bool = False) -> int | None:
    if optional and value is None:
        return None
    if type(value) is not int or not 0 < value <= 2**63 - 1:
        raise JobStoreError("Job template and remote identifiers must be positive integers.")
    return value


def _timestamp(value: Any, *, optional: bool = False) -> str | None:
    if optional and value is None:
        return None
    try:
        if type(value) is not str or len(value) > 64:
            raise ValueError
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError
        return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    except (ValueError, OverflowError):
        raise JobStoreError("Job timestamps must be timezone-aware ISO timestamps.") from None


def _json(value: Any, maximum: int) -> str:
    def visit(item: Any, depth: int) -> None:
        if depth > 32:
            raise ValueError
        kind = type(item)
        if kind is dict:
            for key, child in item.items():
                if type(key) is not str:
                    raise ValueError
                visit(child, depth + 1)
        elif kind is list:
            for child in item:
                visit(child, depth + 1)
        elif kind is float:
            if not math.isfinite(item):
                raise ValueError
        elif kind not in {str, int, bool, type(None)}:
            raise ValueError
    try:
        visit(value, 0)
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        if len(encoded.encode("utf-8")) > maximum:
            raise ValueError
        return encoded
    except (ValueError, TypeError, UnicodeError, RecursionError):
        raise JobStoreError("The job payload must contain bounded, finite JSON values.") from None


def _secrets(values: Any) -> list[str]:
    if type(values) is not list or len(values) > 4096 or any(type(item) is not str or len(item) > 64 * 1024 for item in values):
        raise JobStoreError("The private job redaction metadata exceeds its limits.")
    result = list(dict.fromkeys(item for item in values if item))
    _json(result, 64 * 1024)
    return result


class JobStore:
    def __init__(self, path: Path, *, protector: CredentialProtector,
                 clock: Callable[[], datetime] | None = None, max_jobs: int = MAX_JOBS):
        if type(max_jobs) is not int or not 1 <= max_jobs <= MAX_JOBS:
            raise JobStoreError("The job history limit must be between 1 and 10000.")
        self.path = Path(os.path.abspath(path))  # Do not resolve away symlinks before checking them.
        self._protector = protector
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._max_jobs = max_jobs
        try:
            self._check_path()
            self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            try:
                descriptor = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
            except FileExistsError:
                pass
            else:
                os.close(descriptor)
            self._check_path()
            with self._connection():
                pass
        except OSError:
            raise JobStoreError("The job database could not be opened. Check its directory permissions.") from None

    def _check_path(self) -> None:
        for selected in (self.path, *self.path.parents):
            if selected.is_symlink():
                raise JobStoreError("The job database path must not use symbolic links.")
        try:
            details = self.path.lstat()
        except FileNotFoundError:
            return
        if not stat.S_ISREG(details.st_mode) or details.st_nlink != 1:
            raise JobStoreError("The job database must be a regular private file.")
        if os.name == "posix" and (details.st_uid != os.geteuid() or stat.S_IMODE(details.st_mode) != 0o600):
            raise JobStoreError("The job database must belong to the current user with permissions 0600.")
        for suffix in ("-journal", "-wal", "-shm"):
            if self.path.with_name(self.path.name + suffix).is_symlink():
                raise JobStoreError("The job database auxiliary files must not be symbolic links.")

    def _now(self) -> str:
        value = self._clock()
        if not isinstance(value, datetime) or value.tzinfo is None:
            raise JobStoreError("The job clock must return a timezone-aware datetime.")
        return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        database = None
        try:
            self._check_path()
            database = sqlite3.connect(self.path, timeout=10)
            database.row_factory = sqlite3.Row
            database.execute("PRAGMA secure_delete=ON")
            database.execute("PRAGMA trusted_schema=OFF")
            with database:
                database.execute("BEGIN IMMEDIATE")
                objects = database.execute("SELECT type,name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'").fetchall()
                version = database.execute("PRAGMA user_version").fetchone()[0]
                if version == 0 and not objects:
                    database.execute(
                        "CREATE TABLE jobs (id TEXT PRIMARY KEY, tool_name TEXT NOT NULL, title TEXT NOT NULL, "
                        "template_id INTEGER NOT NULL, mode TEXT NOT NULL, source TEXT NOT NULL, remote_job_id INTEGER, "
                        "status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, started TEXT, finished TEXT, "
                        "error TEXT, result_available INTEGER NOT NULL, request_id TEXT UNIQUE, private_payload BLOB NOT NULL)"
                    )
                    database.execute("PRAGMA user_version=1")
                    objects = database.execute("SELECT type,name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'").fetchall()
                    version = 1
                if version != 1 or {(row[0], row[1]) for row in objects} != {("table", "jobs")}:
                    raise JobStoreError("The job database schema is incompatible. Use the original job database or application version.")
                columns = {row[1]: (row[2].upper(), row[3], row[5]) for row in database.execute("PRAGMA table_info(jobs)")}
                if columns != _COLUMNS or database.execute("PRAGMA quick_check(1)").fetchone()[0] != "ok":
                    raise JobStoreError("The job database is damaged or incompatible. Restore its backup.")
                unique_columns = {
                    tuple(item[0] for item in database.execute("SELECT name FROM pragma_index_info(?) ORDER BY seqno", (index[1],)))
                    for index in database.execute("PRAGMA index_list(jobs)") if index[2] == 1 and index[4] == 0
                }
                if unique_columns != {("id",), ("request_id",)}:
                    raise JobStoreError("The job database is missing its request safety constraints. Restore its backup.")
                yield database
        except sqlite3.IntegrityError:
            raise JobStoreError("This job request is already recorded; retrieve its existing job before retrying.") from None
        except (sqlite3.Error, OSError):
            raise JobStoreError("The job database operation failed. Check its integrity and directory permissions.") from None
        finally:
            if database is not None:
                database.close()

    def _encrypt(self, payload: dict) -> bytes:
        encoded = _json(payload, MAX_PRIVATE_BYTES)
        try:
            encrypted = self._protector.encrypt(encoded)
            if type(encrypted) is not bytes or not encrypted or len(encrypted) > MAX_PRIVATE_BYTES * 2:
                raise ValueError
            return encrypted
        except Exception:
            raise JobStoreError("The job's private data could not be encrypted. Check the original encryption key or account.") from None

    def _decrypt(self, row: sqlite3.Row) -> dict:
        try:
            raw = self._protector.decrypt(row["private_payload"])
            if type(raw) is not str or len(raw.encode("utf-8")) > MAX_PRIVATE_BYTES:
                raise ValueError
            payload = json.loads(raw)
            required = {"connection_name", "controller_url", "api_path", "secrets", "request_fingerprint"}
            if type(payload) is not dict or set(payload) not in (required, required | {"result"}):
                raise ValueError
            _json(payload, MAX_PRIVATE_BYTES)
            _secrets(payload["secrets"])
            _text(payload["connection_name"], 256, optional=True)
            if payload["controller_url"] is not None:
                validate_controller_url(payload["controller_url"])
            validate_api_path(payload["api_path"])
            fingerprint = payload["request_fingerprint"]
            if fingerprint is not None and (type(fingerprint) is not str or not re.fullmatch(r"[0-9a-f]{64}", fingerprint)):
                raise ValueError
            if bool(row["result_available"]) != ("result" in payload):
                raise ValueError
            if "result" in payload:
                _json(payload["result"], MAX_RESULT_BYTES)
            return payload
        except Exception:
            raise JobStoreError("The job's private data cannot be unlocked. Restore the original database and encryption key or account.") from None

    @staticmethod
    def _public(row: sqlite3.Row) -> dict[str, Any]:
        try:
            _job_id(row["id"])
            _tool_name(row["tool_name"])
            _text(row["title"], 256)
            _positive_id(row["template_id"])
            _positive_id(row["remote_job_id"], optional=True)
            _request_id(row["request_id"])
            if row["mode"] not in {"mock", "controller"} or row["source"] not in {"mcp", "console"} or row["status"] not in STATUSES:
                raise ValueError
            for name in ("created_at", "updated_at", "started", "finished"):
                _timestamp(row[name], optional=name in {"started", "finished"})
            _text(row["error"], 2048, optional=True)
            if (row["result_available"] not in {0, 1} or type(row["private_payload"]) is not bytes
                    or not 0 < len(row["private_payload"]) <= MAX_PRIVATE_BYTES * 2):
                raise ValueError
            result = {key: row[key] for key in _PUBLIC_FIELDS}
            result["result_available"] = bool(result["result_available"])
            return result
        except (ValueError, TypeError, JobStoreError):
            raise JobStoreError("A stored job record is invalid. Restore the job database backup.") from None

    def create(self, *, tool_name: str, title: str, template_id: int, mode: str,
               connection_name: str | None, controller_url: str | None, api_path: str,
               source: str = "mcp", secrets: list[str] | None = None,
               request_id: str | None = None, request_fingerprint: str | None = None) -> dict[str, Any]:
        _tool_name(tool_name)
        _text(title, 256)
        _positive_id(template_id)
        _text(connection_name, 256, optional=True)
        if type(mode) is not str or mode not in {"mock", "controller"} or type(source) is not str or source not in {"mcp", "console"}:
            raise JobStoreError("The job mode or source is invalid.")
        if mode == "controller" and controller_url is None:
            raise JobStoreError("Controller jobs require an approved controller origin.")
        try:
            origin = validate_controller_url(controller_url) if controller_url is not None else None
            api_path = validate_api_path(api_path)
        except StorageError:
            raise JobStoreError("The job controller origin or API path is invalid.") from None
        request_id = _request_id(request_id)
        if request_fingerprint is not None and (type(request_fingerprint) is not str or not re.fullmatch(r"[0-9a-f]{64}", request_fingerprint)):
            raise JobStoreError("The private job request fingerprint is invalid.")
        payload = {"connection_name": connection_name, "controller_url": origin, "api_path": api_path,
                   "secrets": _secrets([] if secrets is None else secrets), "request_fingerprint": request_fingerprint}
        encrypted = self._encrypt(payload)
        identity, now = uuid.uuid4().hex, self._now()
        with self._connection() as database:
            if database.execute("SELECT count(*) FROM jobs").fetchone()[0] >= self._max_jobs:
                raise JobStoreError("The job history capacity has been reached. No existing or active jobs were deleted.")
            database.execute(
                "INSERT INTO jobs (id,tool_name,title,template_id,mode,source,status,created_at,updated_at,result_available,request_id,private_payload) "
                "VALUES (?,?,?,?,?,?,'queued',?,?,0,?,?)",
                (identity, tool_name, title, template_id, mode, source, now, now, request_id, encrypted),
            )
            return self._public(database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone())

    def update(self, identity: str, **fields: Any) -> dict[str, Any]:
        _job_id(identity)
        allowed = {"remote_job_id", "status", "started", "finished", "error"}
        if not fields or set(fields) - allowed:
            raise JobStoreError("Only job status, remote identifier, timestamps and safe errors can be updated.")
        normalized = dict(fields)
        if "remote_job_id" in fields:
            normalized["remote_job_id"] = _positive_id(fields["remote_job_id"], optional=True)
        if "status" in fields and (type(fields["status"]) is not str or fields["status"] not in STATUSES):
            raise JobStoreError("The job status is invalid.")
        for field in {"started", "finished"} & fields.keys():
            normalized[field] = _timestamp(fields[field], optional=True)
        if "error" in fields:
            normalized["error"] = _text(fields["error"], 2048, optional=True)
        normalized["updated_at"] = self._now()
        with self._connection() as database:
            current = database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone()
            if current is None:
                raise JobStoreError("The requested job does not exist.")
            self._public(current)
            assignments = ",".join(f"{key}=?" for key in normalized)  # Keys come only from the allowlist above.
            database.execute(f"UPDATE jobs SET {assignments} WHERE id=?", (*normalized.values(), identity))
            return self._public(database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone())

    def get(self, identity: str, include_result: bool = False) -> dict[str, Any] | None:
        _job_id(identity)
        with self._connection() as database:
            row = database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone()
            if row is None:
                return None
            result = self._public(row)
            if include_result and result["result_available"]:
                result["result"] = self._decrypt(row)["result"]
            return result

    def private(self, identity: str) -> dict[str, Any] | None:
        _job_id(identity)
        with self._connection() as database:
            row = database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone()
            if row is None:
                return None
            return {**self._public(row), **self._decrypt(row), "request_id": row["request_id"]}

    def lookup_request(self, request_id: str) -> dict[str, Any] | None:
        normalized = _request_id(request_id)
        if normalized is None:
            raise JobStoreError("The job request identifier must be a UUID.")
        with self._connection() as database:
            row = database.execute("SELECT * FROM jobs WHERE request_id=?", (normalized,)).fetchone()
            return self._public(row) if row else None

    def list(self, *, status: str | None = None, tool_name: str | None = None,
             limit: int = 50, offset: int = 0) -> dict[str, Any]:
        if type(limit) is not int or not 1 <= limit <= 200 or type(offset) is not int or not 0 <= offset <= MAX_JOBS:
            raise JobStoreError("Job pagination requires a limit of 1-200 and an offset of 0-10000.")
        clauses, values = [], []
        if status is not None:
            if type(status) is not str or status not in STATUSES:
                raise JobStoreError("The job status filter is invalid.")
            clauses.append("status=?")
            values.append(status)
        if tool_name is not None:
            clauses.append("tool_name=?")
            values.append(_tool_name(tool_name))
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self._connection() as database:
            count = database.execute("SELECT count(*) FROM jobs" + where, values).fetchone()[0]
            rows = database.execute("SELECT * FROM jobs" + where + " ORDER BY created_at DESC,rowid DESC LIMIT ? OFFSET ?",
                                    (*values, limit, offset)).fetchall()
            return {"jobs": [self._public(row) for row in rows], "count": count, "limit": limit, "offset": offset}

    def mark_interrupted(self) -> int:
        active = sorted(STATUSES - TERMINAL_STATUSES - {"unknown"})
        with self._connection() as database:
            return database.execute(
                "UPDATE jobs SET status='unknown',updated_at=?,error=? WHERE status IN (" + ",".join("?" for _ in active) + ")",
                (self._now(), "Server restarted before tracking completed. Check the remote job before retrying.", *active),
            ).rowcount

    def save_result(self, identity: str, result: Any) -> dict[str, Any]:
        _job_id(identity)
        detached = json.loads(_json(result, MAX_RESULT_BYTES))
        with self._connection() as database:
            row = database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone()
            if row is None:
                raise JobStoreError("The requested job does not exist.")
            self._public(row)
            payload = self._decrypt(row)
            payload["result"] = detached
            database.execute("UPDATE jobs SET private_payload=?,result_available=1,updated_at=? WHERE id=?",
                             (self._encrypt(payload), self._now(), identity))
            return self._public(database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone())

    def add_secrets(self, identity: str, values: list[str]) -> None:
        _job_id(identity)
        _secrets(values)
        with self._connection() as database:
            row = database.execute("SELECT * FROM jobs WHERE id=?", (identity,)).fetchone()
            if row is None:
                raise JobStoreError("The requested job does not exist.")
            self._public(row)
            payload = self._decrypt(row)
            payload["secrets"] = _secrets(list(dict.fromkeys([*payload["secrets"], *values])))
            database.execute("UPDATE jobs SET private_payload=?,updated_at=? WHERE id=?",
                             (self._encrypt(payload), self._now(), identity))
